package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigListModel;

public interface MarginAmountService extends RestClientService {
    String NAME = "marginAmount";

    /**
     * Save list of MarginAmount Configuration data.
     *
     * @return
     */
    MarginAmountDealGovernanceConfigListModel saveMarginAmountData(MarginAmountDealGovernanceConfigListModel listModel);
}
