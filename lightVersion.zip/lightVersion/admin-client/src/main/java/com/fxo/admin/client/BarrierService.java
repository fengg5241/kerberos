package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.BarrierDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface BarrierService extends RestClientService {
    String NAME = "barrier";

    /**
     * Save list of Barrier configuration data.
     *
     * @return
     */
    BarrierDealGovernanceConfigListModel saveBarrierData(BarrierDealGovernanceConfigListModel listModel);
}
