package com.fxo.admin.client.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fxo.admin.client.FXOEventBlockingDateService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.client.util.FXOStringUtility;
import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

public class FXOEventBlockingDateServiceImpl extends BaseServiceImpl implements
		FXOEventBlockingDateService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXOEventBlockingDateServiceImpl.class);

	public FXOEventBlockingDateServiceImpl(String endpoint, String resourcePath) {
		super(endpoint, resourcePath);
	}

	@Override
	public String getServiceName() {
		return FXOEventBlockingDateService.SERVICE_NAME;
	}

	@Override
	public FXOEventBlockingDateConfigListModel getEventBlockingDatesList() {

		logger.info("Trying to get EventBlockingDatesList");

		Map<String, Object> queryParams = new HashMap<>();
		return this.get(resourcePath + buildQueryParams("", queryParams),
				FXOEventBlockingDateConfigListModel.class);
	}

	@Override
	public boolean saveEventBlockingDates(
			FXOEventBlockingDateConfigModel fxoEventBlockingDateConfigModel) {

		logger.info("Trying to save EventBlockingDates");

		return this.post(resourcePath, fxoEventBlockingDateConfigModel,
				Boolean.class);
	}

	@Override
	public boolean deleteEventBlockingDateById(String eventId) {

		logger.info("Trying to delete EventBlockingDateById");

		Map<String, Object> queryParams = new HashMap<>();

		if (FXOStringUtility.isNotEmpty(eventId)) {
			queryParams.put("userId", eventId);
		}
		return this.post(resourcePath + SERVICES.DELETE.code
				+ buildQueryParams("", queryParams), "", Boolean.class);
	}

	private enum SERVICES {
		DELETE("/deleteEvent");

		String code;

		SERVICES(String code) {
			this.code = code;
		}
	}

}
