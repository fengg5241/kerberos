package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.DealGovernanceConfigListModel;

public interface ThresholdService extends RestClientService {
	String NAME = "thresholds" ;

	/**
	 * Return the global deal govn threshold configuration data.
	 * @return
	 */
	DealGovernanceConfigListModel getDealGovernanceThresolds();

	/*
	* Return deal govn threshold configuration data for this currency and counter currency.
	* @return
	*/
	DealGovernanceConfigListModel getDealGovernanceThresolds(String currency, String counterCurrency);

	/**
	 * Save Deal governance thresholds
	 * @return Updated thresholds
	 */
	DealGovernanceConfigListModel saveDealGovernanceThresolds(DealGovernanceConfigListModel postData);
	
	/**
	 * Save Deal governance thresholds for a currency pair
	 * @return Updated thresholds
	 */
	DealGovernanceConfigListModel saveDealGovernanceThresolds(String currency, String counterCurrency, DealGovernanceConfigListModel postData);
	/**
	 * Get list of already customised currency pairs
	 * @return Customised Currency Pairs
	 */		
	CurrencyPairConfigListModel getCustomisedCurrencyPairs();
	/**
	 * Get list of currency pairs which are not customised
	 * @return  Non Customised Currency Pairs
	 */
	CurrencyPairConfigListModel getNonCustomisedCurrencyPairs();
	/**
	 *Delete customised currency pair
	 * @return Customised Currency Pairs
	 */
	CurrencyPairConfigListModel deleteCustomisedCurrencyPair(String currency, String counterCurrency);
}
