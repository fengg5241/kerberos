package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.constants.dealing.FXOCurrencyPairStatuses;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.CurrencyPairProductConfigListModel;
import com.fxo.rest.model.CurrencyPairProductConfigResponseModel;

import java.util.List;

public interface CurrencyService extends RestClientService {
	String SERVICE_NAME = "currency";

	/**
	 * Sets the status for all pairs of the passed in currency and product
	 * 
	 * @param status The status to be set
	 * @param currency The currency whose pairs need to be updated
	 * @param product The product code. If not passed, all pairs will be updated
	 * @param updatedBy The id of the user requesting the change
	 * @return The number of pairs updated
	 */
	CurrencyPairProductConfigResponseModel setStatus(STATUS status, String currency, String product, String updatedBy);
	
	/**
	 * Sets the status for the passed in currency and currency pair and product
	 * 
	 * @param status The status to be set
	 * @param currency The currency that needs to be updated
	 * @param counterCurrency The currency pair that needs to be updated
	 * @param product The product code. If not passed, all pairs will be updated
	 * @param updatedBy The id of the user requesting the change
	 * @return The number of pairs updated
	 */
	CurrencyPairProductConfigResponseModel setStatus(STATUS status, String currency, String counterCurrency, String product, String updatedBy);
	
	/**
	 * @return Returns all the currency pairs configured in the system
	 */
	CurrencyPairProductConfigListModel getCurrencyPairs();

	/**
	 * @return Returns all the currency pairs configured in the system without anf product information
	 */
	CurrencyPairConfigListModel getCurrencyPairsWithoutProductInfo();

	/**
	 * Saves precision information for the passed in collection of currency pairs
	 * 
	 * @param currencyPairs The currency pairs with the updated information
	 * @return The updated collection of currency pairs
	 */
	CurrencyPairConfigListModel savePrecisionData(List<CurrencyPairConfigModel> currencyPairs);
	
	enum STATUS {
		ON(FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON),
		OFF(FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF),
		RFQ(FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ), 
		;

		public final String code;
		STATUS(String code) {
			this.code = code;
		}
		public static STATUS fromString(String code) {
			for (STATUS s : STATUS.values()) {
				if (s.code.equalsIgnoreCase(code)) return s;
			}
			return null;
		}
	}
}
