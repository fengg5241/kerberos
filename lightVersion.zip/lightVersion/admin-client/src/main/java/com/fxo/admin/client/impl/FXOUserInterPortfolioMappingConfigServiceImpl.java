package com.fxo.admin.client.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fxo.admin.client.FXOUserInterPortfolioMappingConfigService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.client.util.FXOStringUtility;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

public class FXOUserInterPortfolioMappingConfigServiceImpl extends
		BaseServiceImpl implements FXOUserInterPortfolioMappingConfigService {

	public FXOUserInterPortfolioMappingConfigServiceImpl(String endpoint,
			String resourcePath) {

		super(endpoint, resourcePath);
	}

	private static final Logger logger = LoggerFactory
			.getLogger(FXOUserInterPortfolioMappingConfigServiceImpl.class);

	@Override
	public String getServiceName() {

		return FXOUserInterPortfolioMappingConfigService.SERVICE_NAME;
	}

	@Override
	public FXOUserInterPortfolioMappingConfigListWrapperModel getAllFXOUserInterPortfolioConfigMappings() {

		logger.info("Trying to getAllUserInterPortFolioConfigMappings for all userIds");
		Map<String, Object> queryParams = new HashMap<>();

		return this.get(resourcePath + buildQueryParams("", queryParams),
				FXOUserInterPortfolioMappingConfigListWrapperModel.class);
	}

	@Override
	public FXOUserInterPortfolioMappingConfigListModel updateUserInterPortfolioMappings(
			FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel) {
		logger.info("Trying to updateUserInterPortfolioMappings for all userIds");
		return this.post(resourcePath,
				fxoUserInterPortfolioMappingConfigListModel,
				FXOUserInterPortfolioMappingConfigListModel.class);
	}

	@Override
	public FXOUserInterPortfolioMappingConfigListModel getInterPortfolioConfigListByUserId(
			String userId) {

		logger.info("Trying to getInterPortfolioConfigListByUserId for the userId "
				+ userId);

		Map<String, Object> queryParams = new HashMap<>();

		return this.get(
				resourcePath + buildQueryParams("/" + userId, queryParams),
				FXOUserInterPortfolioMappingConfigListModel.class);
	}

	@Override
	public Boolean deleteInterPortfolioByUserId(String userId) {
		// TODO Auto-generated method stub

		logger.info("Trying to deleteInterPortfolio for the userId " + userId);
		Map<String, Object> queryParams = new HashMap<>();
		if (FXOStringUtility.isNotEmpty(userId)) {
			queryParams.put("userId", userId);
		}
		return this.post(resourcePath + SERVICES.DELETE.code
				+ buildQueryParams("", queryParams), "", Boolean.class);
	}

	private enum SERVICES {
		DELETE("/deletePortfolios");

		String code;

		SERVICES(String code) {
			this.code = code;
		}
	}
}
