package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 17/02/2016.
 */
public interface NotionalService extends RestClientService {
    String NAME = "notional" ;
    /**
     * Save list of Notional data.
     * @return
     */
     InvestmentAmountDealGovernanceConfigListModel saveNotionalData(InvestmentAmountDealGovernanceConfigListModel listModel);
}
