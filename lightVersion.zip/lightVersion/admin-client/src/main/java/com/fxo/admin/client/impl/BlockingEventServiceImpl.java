package com.fxo.admin.client.impl;

import com.fxo.admin.client.BlockingEventService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

/**
 * Created by rajeshkumarb on 06/06/2017.
 */
public class BlockingEventServiceImpl extends
        BaseServiceImpl implements BlockingEventService {

    public BlockingEventServiceImpl(String endpoint, String resourcePath) {
        super(endpoint, resourcePath);
    }

    @Override
    public String getServiceName() {
        return BlockingEventService.SERVICE_NAME;
    }

    @Override
    public FXOEventBlockingDateConfigListModel getAllBlockingEvents() {
        return this.get(resourcePath + SERVICES.GET_ALL.code, FXOEventBlockingDateConfigListModel.class);
    }

    @Override
    public FXOEventBlockingDateConfigListModel deleteBlockingEvent(String eventId) {
        String param = buildQueryParams(SERVICES.DELETE.code, mapFor("eventId", eventId));
        return this.post(resourcePath + param, null, FXOEventBlockingDateConfigListModel.class);
    }

    @Override
    public Boolean addBlockingEvent(FXOEventBlockingDateConfigModel eventBlockingDateConfigModel) {
        return this.post(resourcePath + SERVICES.ADD.code,
                eventBlockingDateConfigModel,
                Boolean.class);
    }

    private enum SERVICES {
        GET_ALL("/getEventList"),
        ADD("/saveEvent"),
        DELETE("/deleteEvent");

        String code;

        SERVICES(String code) {
            this.code = code;
        }
    }
}
