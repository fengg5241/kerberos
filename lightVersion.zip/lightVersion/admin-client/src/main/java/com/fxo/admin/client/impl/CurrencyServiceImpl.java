package com.fxo.admin.client.impl;

import com.fxo.admin.client.CurrencyService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.rest.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class CurrencyServiceImpl extends BaseServiceImpl implements CurrencyService {
	public CurrencyServiceImpl(String endpoint, String resourcePath) {
		super(endpoint, resourcePath);
	}

	@Override
	public CurrencyPairProductConfigResponseModel setStatus(STATUS status, String currency, String product, String updatedBy) {
		return setStatus(status, currency, null, product, updatedBy);
	}

	@Override
	public CurrencyPairProductConfigResponseModel setStatus(STATUS status, String currency, String counterCurrency, String product, String updatedBy) {
		logger.debug("Updating status to {} for {}/{} and {}", new String[] {status.code, currency, counterCurrency, product});
		CurrencyPairProductConfigModel request = new CurrencyPairProductConfigModel();
		request.setStatus(status.code)
			.setProduct(product)
			.setCurrency(currency)
			.setCounterCurrency(counterCurrency)
			.setUpdatedBy(updatedBy)
		;
		return this.post(this.resourcePath, request, CurrencyPairProductConfigResponseModel.class);
	}

	@Override
	public CurrencyPairProductConfigListModel getCurrencyPairs() {
		logger.debug("Trying to get all currency pairs");
		return this.get(this.resourcePath, CurrencyPairProductConfigListModel.class);
	}

	@Override
	public CurrencyPairConfigListModel getCurrencyPairsWithoutProductInfo() {
		logger.debug("Trying to get currency pairs without product info");
		return this.get(this.resourcePath + SERVICES.PRECISION.code, CurrencyPairConfigListModel.class);
	}

	@Override
	public CurrencyPairConfigListModel savePrecisionData(List<CurrencyPairConfigModel> currencyPairs) {
		logger.debug("Saving precision data for {} currency pairs", currencyPairs.size());
		CurrencyPairConfigListModel request = new CurrencyPairConfigListModel()
				.setConfiguration(currencyPairs);
		return this.post(this.resourcePath + SERVICES.PRECISION.code, request, CurrencyPairConfigListModel.class);
	}

	private enum SERVICES {
		PRECISION("/precision");
		String code;
		SERVICES(String code) {this.code = code;}
	}
	
	@Override
	public String getServiceName() {
		return CurrencyService.SERVICE_NAME;
	}
	private static final Logger logger = LoggerFactory.getLogger(CurrencyServiceImpl.class);
}
