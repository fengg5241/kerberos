package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.DeltaPercentDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 22/02/2016.
 */
public interface DeltaPctService extends RestClientService {


    String NAME = "deltaPercent";

    /**
     * Save list of Delta Percent data.
     *
     * @return
     */
    DeltaPercentDealGovernanceConfigListModel saveDeltaPercentData(DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel);


}
