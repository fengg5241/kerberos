package com.fxo.admin.client.impl;

import com.fxo.admin.client.DealingHoursService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.rest.model.FXOCurrentDealingHoursModel;
import com.fxo.rest.model.FXODealingHoursModel;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class DealingHoursServiceImpl extends BaseServiceImpl implements DealingHoursService {
  public DealingHoursServiceImpl(String endpoint, String resourcePath) {
    super(endpoint, resourcePath);
  }

  @Override
  public FXOCurrentDealingHoursModel getTodaysHours() {
    logger.debug("Getting todays dealing hours");
    return this.get(resourcePath + SERVICES.TODAY.code, FXOCurrentDealingHoursModel.class);
  }

  @Override
  public void setDealingHour(FXODealingHoursModel hour) {
    logger.debug("Setting dealing hours");
    this.post(resourcePath + SERVICES.SAVE_TODAYS_HOURS.code, hour, FXODealingHoursModel.class);
  }

  @Override
  public boolean isSystemOn() {
    FXOCurrentDealingHoursModel todaysHours = getTodaysHours();
    return todaysHours.getStartTime().isBeforeNow() && todaysHours.getEndTime().isAfterNow();
  }

  @Override
  public boolean isSystemOff() {
    return !isSystemOn();
  }

  @Override
  public void setDealingHours(List<FXODealingHoursModel> hours) {
    for(FXODealingHoursModel m: hours) this.setDealingHour(m);
  }

  @Override
  public void stopDealingNow(String userId) {
    this.setDealingHour(FXODealingHoursModel.stopNow(userId));
  }

  @Override
  public void stopDealingAt(String userId, DateTime stopTime) {
    this.setDealingHour(FXODealingHoursModel.stopAt(userId, stopTime));
  }

  @Override
  public void startDealingNow(String userId) {
    this.setDealingHour(FXODealingHoursModel.startNow(userId));
  }

  @Override
  public void startDealingAt(String userId, DateTime startTime) {
    this.setDealingHour(FXODealingHoursModel.startAt(userId, startTime));
  }

  @Override
  public void startDealingTill(String userId, DateTime stopTime) {
    this.setDealingHour(FXODealingHoursModel.startNow(userId));
    stopDealingAt(userId, stopTime);
  }

  @Override
  public FXOCurrentDealingHoursModel getOfficialHours() {
   return this.get(resourcePath + SERVICES.OFFICIAL_HOURS.code, FXOCurrentDealingHoursModel.class);
  }

  @Override
  public FXOCurrentDealingHoursModel updateOfficialHours(DateTime startTime, DateTime stopTime, String userId) {
    FXOCurrentDealingHoursModel hours = new FXOCurrentDealingHoursModel()
        .setDate(LocalDate.now())
        .setEndTime(stopTime).setEndTimeUpdatedBy(userId)
        .setStartTime(startTime).setStartTimeUpdatedBy(userId);
    return this.post(resourcePath + SERVICES.UPDATE_OFFICIAL_HOURS.code, hours, FXOCurrentDealingHoursModel.class);
  }

  @Override
  public String getServiceName() {
    return DealingHoursService.NAME;
  }

  private enum SERVICES {
    TODAY("/today"), SAVE_TODAYS_HOURS("/save"), OFFICIAL_HOURS("/official"), UPDATE_OFFICIAL_HOURS(OFFICIAL_HOURS.code + "/save");
    String code;
    SERVICES(String code) {this.code = code;}
  }

  private static final Logger logger = LoggerFactory.getLogger(DealingHoursServiceImpl.NAME);
}
