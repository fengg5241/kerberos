package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface CurrencyHedgeService extends RestClientService {
    String NAME = "currencyHedge";

    /**
     * Save list of Currency Hedge configuration data.
     *
     * @return
     */
    CurrencyHedgeDealGovernanceConfigListModel saveCurrencyHedgeData(CurrencyHedgeDealGovernanceConfigListModel listModel);
}
