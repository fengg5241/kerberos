package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.FXOCurrentDealingHoursModel;
import com.fxo.rest.model.FXODealingHoursModel;
import org.joda.time.DateTime;

import java.util.List;

public interface DealingHoursService extends RestClientService {
  /**
   * Returns todays dealing hours
   * @return
   */
  FXOCurrentDealingHoursModel getTodaysHours();

  /**
   * Helper method to determine if the system is currently on
   *
   * @return true if the system is currently on
   */
  boolean isSystemOn();

  /**
   * Helper method to determine if the system is currently off
   *
   * @return true if the system is currently off
   */
  boolean isSystemOff();

  /**
   * Sets the dealing hours for the passed in date and the time
   *
   * @param hours
   *  The action determines whether this is the start or the stop time
   */
  void setDealingHours(List<FXODealingHoursModel> hours);

  /**
   * Sets the dealing hour to the passed in time
   *
   * @param hour
   *  The action determines whether this is the start or the stop time
   */
  void setDealingHour(FXODealingHoursModel hour);

  /**
   * Stops all dealing activities immediately
   *
   * @param userId The id of the user requesting the application to stop.
   */
  void stopDealingNow(String userId);

  /**
   * Stops all dealing activities immediately
   *
   * @param userId The id of the user requesting the application to stop.
   * @param stopTime The new stop time for the application
   */
  void stopDealingAt(String userId, DateTime stopTime);

  /**
   * Start dealing services till the specified stop time.
   *
   * @param userId The id of the user requesting the appliction to stop.
   */
  void startDealingNow(String userId);

  /**
   * Start dealing services till the specified stop time.
   *
   * @param userId The id of the user requesting the appliction to stop.
   * @param startTime The time when the application should start.
   */
  void startDealingAt(String userId, DateTime startTime);

  /**
   * Start dealing services till the specified stop time.
   *
   * @param userId The id of the user requesting the appliction to stop.
   * @param stopTime The time when the application should be stopped.
   */
  void startDealingTill(String userId, DateTime stopTime);

  /**
   * Returns the official dealing hours configured for the system
   *
   * @return
   */
  FXOCurrentDealingHoursModel getOfficialHours();

  /**
   * Updates the official dealing hours in the system
   */
  FXOCurrentDealingHoursModel updateOfficialHours(DateTime startTime, DateTime stopTime, String userId);

  final String NAME = "dealingHours";
}
