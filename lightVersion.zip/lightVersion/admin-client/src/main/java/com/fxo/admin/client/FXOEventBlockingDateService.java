package com.fxo.admin.client;

import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

public interface FXOEventBlockingDateService {

	String SERVICE_NAME = "eventBlock";

	public FXOEventBlockingDateConfigListModel getEventBlockingDatesList();

	public boolean saveEventBlockingDates(
			FXOEventBlockingDateConfigModel fxoEventBlockingDateConfigModel);

	public boolean deleteEventBlockingDateById(String eventId);

}
