package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface RawPremiumService extends RestClientService {
		String NAME = "rawPremium";

		/**
		 * Save list of Raw Premium data.
		 *
		 * @return
		 */
		RawPremiumDealGovernanceConfigListModel savePremiumData(RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel);
}
