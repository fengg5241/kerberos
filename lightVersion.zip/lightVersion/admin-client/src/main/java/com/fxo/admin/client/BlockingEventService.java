package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

/**
 * Created by rajeshkumarb on 06/06/2017.
 */
public interface BlockingEventService extends RestClientService {
    String SERVICE_NAME = "blockingEvent";

    FXOEventBlockingDateConfigListModel getAllBlockingEvents();

    FXOEventBlockingDateConfigListModel deleteBlockingEvent(String eventId);

    Boolean addBlockingEvent(FXOEventBlockingDateConfigModel eventBlockingDateConfigModel);
}
