package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 22/02/2016.
 */
public interface DeltaAmountService extends RestClientService {


    String NAME = "deltaAmount";

    /**
     * Save list of Delta Amount data.
     *
     * @return
     */
    DeltaAmountDealGovernanceConfigListModel saveDeltaAmountData(DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel);
}
