package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.VolatilityDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface VolatilityService extends RestClientService {
    String NAME = "volatility";

    /**
     * Save list of Volatility data.
     *
     * @return
     */
    VolatilityDealGovernanceConfigListModel saveVolatilityData(VolatilityDealGovernanceConfigListModel listModel);
}
