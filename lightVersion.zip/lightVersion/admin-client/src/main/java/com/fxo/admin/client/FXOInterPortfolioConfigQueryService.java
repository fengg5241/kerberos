package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.FXOInterPortfolioConfigListModel;

public interface FXOInterPortfolioConfigQueryService extends RestClientService{
	
	String SERVICE_NAME = "interPortfolio";
	
	public FXOInterPortfolioConfigListModel getUnAssignedPortfoliosForUserId(String userId);

}
