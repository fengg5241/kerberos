package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

public interface FXOUserInterPortfolioMappingConfigService extends RestClientService{
	
	String SERVICE_NAME = "userInterPortfolioMapping";
	
	FXOUserInterPortfolioMappingConfigListWrapperModel getAllFXOUserInterPortfolioConfigMappings();

	FXOUserInterPortfolioMappingConfigListModel updateUserInterPortfolioMappings(FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel);
	
	FXOUserInterPortfolioMappingConfigListModel getInterPortfolioConfigListByUserId(String userId);
	
	Boolean deleteInterPortfolioByUserId(String userId);

}
