package com.fxo.admin.client.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fxo.admin.client.FXOInterPortfolioConfigQueryService;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.rest.model.FXOInterPortfolioConfigListModel;

public class FXOInterPortfolioConfigQueryServiceImpl extends BaseServiceImpl
		implements FXOInterPortfolioConfigQueryService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXOInterPortfolioConfigQueryServiceImpl.class);

	public FXOInterPortfolioConfigQueryServiceImpl(String endpoint,
			String resourcePath) {

		super(endpoint, resourcePath);
	}

	@Override
	public String getServiceName() {
		// TODO Auto-generated method stub
		return FXOInterPortfolioConfigQueryServiceImpl.SERVICE_NAME;
	}

	@Override
	public FXOInterPortfolioConfigListModel getUnAssignedPortfoliosForUserId(
			String userId) {

		logger.info("Trying to getUnAssignedPortfoliosForUserId for the userId "
				+ userId);

		Map<String, Object> queryParams = new HashMap<>();

		return this.get(
				resourcePath + buildQueryParams("/{userId}", queryParams),
				FXOInterPortfolioConfigListModel.class);
	}

}
