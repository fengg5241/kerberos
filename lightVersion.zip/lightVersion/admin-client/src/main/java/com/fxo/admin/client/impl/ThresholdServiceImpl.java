package com.fxo.admin.client.impl;

import com.fxo.admin.client.*;
import com.fxo.client.service.impl.BaseServiceImpl;
import com.fxo.rest.model.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;

public class ThresholdServiceImpl extends BaseServiceImpl implements
		ThresholdService, NotionalService, DeltaAmountService, DeltaPctService,
		VolatilityService, StealthService, TenorService, BarrierService,
		RawPremiumService, CurrencyHedgeService, VegaService,
		MarginAmountService {
	public ThresholdServiceImpl(String endpoint, String resourcePath) {
		super(endpoint, resourcePath);
	}

	@Override
	public DealGovernanceConfigListModel getDealGovernanceThresolds() {
		return this.getDealGovernanceThresolds(null, null);
	}

	@Override
	public DealGovernanceConfigListModel getDealGovernanceThresolds(
			String currency, String counterCurrency) {
		logger.debug("Getting deal governance thresholds");
		if (currency != null && counterCurrency == null || currency == null
				&& counterCurrency != null) {
			// Both parameters must be NULL or both must be NOT NULL
			throw new IllegalArgumentException(
					"Both currency and counter currency are required");
		}
		HashMap<String, Object> queryParams = new HashMap<String, Object>();
		if (currency != null && counterCurrency != null) {
			queryParams.put("currency", currency);
			queryParams.put("counterCurrency", counterCurrency);
		}
		return this.get(resourcePath + this.buildQueryParams("", queryParams),
				DealGovernanceConfigListModel.class, new Object[0]);
	}

	@Override
	public DealGovernanceConfigListModel saveDealGovernanceThresolds(
			DealGovernanceConfigListModel postData) {
		return this.saveDealGovernanceThresolds(null, null, postData);
	}

	@Override
	public DealGovernanceConfigListModel saveDealGovernanceThresolds(
			String currency, String counterCurrency,
			DealGovernanceConfigListModel postData) {
		logger.debug("Getting deal governance thresholds");
		HashMap<String, Object> queryParams = new HashMap<String, Object>();
		if (currency != null && counterCurrency != null) {
			queryParams.put("currency", currency);
			queryParams.put("counterCurrency", counterCurrency);
		}
		return this.post(
				resourcePath + SERVICES.SAVE_ALL.code
						+ this.buildQueryParams("", queryParams), postData,
				DealGovernanceConfigListModel.class);
	}

	@Override
	public String getServiceName() {
		return ThresholdService.NAME;
	}

	@Override
	public InvestmentAmountDealGovernanceConfigListModel saveNotionalData(
			InvestmentAmountDealGovernanceConfigListModel investmentAmtDealGovConfigListModel) {
		logger.debug("Saving Notional Data");
		return this.post(resourcePath + SERVICES.NOTIONAL.code,
				investmentAmtDealGovConfigListModel,
				InvestmentAmountDealGovernanceConfigListModel.class);
	}

	@Override
	public DeltaAmountDealGovernanceConfigListModel saveDeltaAmountData(
			DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel) {
		logger.debug("Saving Delta Amount Data");
		return this.post(resourcePath + SERVICES.DELTA_AMOUNT.code,
				deltaAmountDealGovernanceConfigListModel,
				DeltaAmountDealGovernanceConfigListModel.class);
	}

	@Override
	public DeltaPercentDealGovernanceConfigListModel saveDeltaPercentData(
			DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel) {
		logger.debug("Saving Delta Amount Data");
		return this.post(resourcePath + SERVICES.DELTA_PERCENT.code,
				deltaPercentDealGovernanceConfigListModel,
				DeltaPercentDealGovernanceConfigListModel.class);
	}

	@Override
	public VolatilityDealGovernanceConfigListModel saveVolatilityData(
			VolatilityDealGovernanceConfigListModel volatilityDealGovernanceConfigListModel) {
		logger.debug("Saving Volatility  Data");
		return this.post(resourcePath + SERVICES.VOLATILITY.code,
				volatilityDealGovernanceConfigListModel,
				VolatilityDealGovernanceConfigListModel.class);
	}

	@Override
	public StealthDealGovernanceConfigListModel saveStealthData(
			StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel) {
		logger.debug("Saving Stealth  Data");
		return this.post(resourcePath + SERVICES.STEALTH.code,
				stealthDealGovernanceConfigListModel,
				StealthDealGovernanceConfigListModel.class);
	}

	@Override
	public TenorDealGovernanceConfigListModel saveTenorData(
			TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel) {
		logger.debug("Saving Tenor  Data");
		return this.post(resourcePath + SERVICES.TENOR.code,
				tenorDealGovernanceConfigListModel,
				TenorDealGovernanceConfigListModel.class);
	}

	@Override
	public BarrierDealGovernanceConfigListModel saveBarrierData(
			BarrierDealGovernanceConfigListModel listModel) {
		logger.debug("Saving Barrier  Data");
		return this.post(resourcePath + SERVICES.BARRIER.code, listModel,
				BarrierDealGovernanceConfigListModel.class);
	}

	@Override
	public CurrencyHedgeDealGovernanceConfigListModel saveCurrencyHedgeData(
			CurrencyHedgeDealGovernanceConfigListModel listModel) {
		logger.debug("Saving Currency hedge  Data");
		return this.post(resourcePath + SERVICES.CURRENCY_HEDGE.code,
				listModel, CurrencyHedgeDealGovernanceConfigListModel.class);

	}

	@Override
	public MarginAmountDealGovernanceConfigListModel saveMarginAmountData(
			MarginAmountDealGovernanceConfigListModel listModel) {
		logger.debug("Saving Margin Amount  Data");
		return this.post(resourcePath + SERVICES.MARGIN_AMOUNT.code, listModel,
				MarginAmountDealGovernanceConfigListModel.class);

	}

	@Override
	public RawPremiumDealGovernanceConfigListModel savePremiumData(
			RawPremiumDealGovernanceConfigListModel premiumListModel) {
		logger.debug("Saving Premium  Data");
		return this
				.post(resourcePath + SERVICES.PREMIUM.code, premiumListModel,
						RawPremiumDealGovernanceConfigListModel.class);
	}

	@Override
	public VegaDealGovernanceConfigListModel saveVegaData(
			VegaDealGovernanceConfigListModel listModel) {
		logger.debug("Saving Vega  Data");
		return this.post(resourcePath + SERVICES.VEGA.code, listModel,
				VegaDealGovernanceConfigListModel.class);
	}

	private enum SERVICES {
		NOTIONAL("/investmentAmount"), DELTA_AMOUNT("/deltaAmount"), DELTA_PERCENT(
				"/deltaPercent"), VOLATILITY("/volatility"), TENOR("/tenor"), STEALTH(
				"/stealth"), VEGA("/vega"), MARGIN_AMOUNT("/marginAmount"), BARRIER(
				"/barrier"), CURRENCY_HEDGE("/currencyHedge"), PREMIUM(
				"/rawPremium"), SAVE_ALL("/save"), CURRENCY_PAIRS(
				"/currencyPairs"), CUSTOM_CURRENCY_PAIRS(
				"/currencyPairs/customize"), DELETE("/delete");

		String code;

		SERVICES(String code) {
			this.code = code;
		}
	}

	private static final Logger logger = LoggerFactory
			.getLogger(ThresholdServiceImpl.class);

	@Override
	public CurrencyPairConfigListModel getCustomisedCurrencyPairs() {
		logger.debug("Getting customised currency pairs");
		return this.get(resourcePath + SERVICES.CURRENCY_PAIRS.code,
				CurrencyPairConfigListModel.class);
	}

	@Override
	public CurrencyPairConfigListModel getNonCustomisedCurrencyPairs() {
		logger.debug("Getting non customised currency pairs");
		return this.get(resourcePath + SERVICES.CUSTOM_CURRENCY_PAIRS.code,
				CurrencyPairConfigListModel.class);
	}

	@Override
	public CurrencyPairConfigListModel deleteCustomisedCurrencyPair(
			String currency, String counterCurrency) {
		logger.debug("Delete customised currency pair");
		HashMap<String, Object> queryParams = new HashMap<String, Object>();
		if (currency != null && counterCurrency != null) {
			queryParams.put("currency", currency);
			queryParams.put("counterCurrency", counterCurrency);

			this.delete(
					resourcePath + SERVICES.DELETE.code
							+ this.buildQueryParams("", queryParams),
					CurrencyPairConfigListModel.class);
			return getCustomisedCurrencyPairs();
		} else {
			throw new IllegalArgumentException(
					"Currency or Counter Currency cannot be null");
		}
	}
}
