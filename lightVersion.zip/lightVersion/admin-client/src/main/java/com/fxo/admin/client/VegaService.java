package com.fxo.admin.client;

import com.fxo.client.service.RestClientService;
import com.fxo.rest.model.VegaDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface VegaService extends RestClientService {
    String NAME = "vega";

    /**
     * Save list of Vega Configuration data.
     *
     * @return
     */
    VegaDealGovernanceConfigListModel saveVegaData(VegaDealGovernanceConfigListModel listModel);
}
