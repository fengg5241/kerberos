package com.fxo.admin.client;

import com.fxo.rest.model.StealthDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface StealthService {
	
	 String NAME = "stealth";
    /**
     * Save Stealth Configuration List data
     *
     * @param listModel
     * @return
     */
    StealthDealGovernanceConfigListModel saveStealthData(StealthDealGovernanceConfigListModel listModel);
}

