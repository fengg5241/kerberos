package com.fxo.admin.client;

import com.fxo.rest.model.TenorDealGovernanceConfigListModel;

/**
 * Created by rajeshkumarb on 23/02/2016.
 */
public interface TenorService {
	 String NAME = "tenor";

    /**
     * Save Tenor Configuration List data
     * @param listModel
     * @return
     */
    TenorDealGovernanceConfigListModel saveTenorData(TenorDealGovernanceConfigListModel listModel);
}
