package com.fxo.admin.client.test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fxo.rest.model.FXOMessageDetailModel;
import com.fxo.rest.model.FXOMessageModel;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.math.MathContext;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class BaseTest {

  protected static final String WS_ENDPOINT = "http://localhost:10080/fxows/admin";

  @Autowired
  protected RestTemplate restTemplate;

  protected static MathContext precision = new MathContext(2);

  @Autowired private ObjectMapper mapper;

  public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
      MediaType.APPLICATION_JSON.getSubtype(),
      Charset.forName("utf8")
      );

  protected MockRestServiceServer server;

  @Before
  public void init() {
    server = MockRestServiceServer.createServer(restTemplate);
  }

  protected String convertToJson(Object o) throws Throwable {
      return mapper.writeValueAsString(o);
  }

  protected FXOMessageModel getMockErrorJson() {
    List<String> fields = new ArrayList<String>();
    fields.add("F1");
    FXOMessageDetailModel detailModel = new FXOMessageDetailModel()
        .setMessage("Amount is required").setMessageCode("CODE")
        .setMessageFields(fields);
    List<FXOMessageDetailModel> errors = new ArrayList<>();
    errors.add(detailModel);
    return new FXOMessageModel().setErrors(errors).setMessages(new ArrayList<FXOMessageDetailModel>()).setWarnings(new ArrayList<FXOMessageDetailModel>());
  }

  protected String buildQueryParams(String fromPath, Map<String, Object> params) {
    UriComponentsBuilder builder = UriComponentsBuilder.fromPath(fromPath);
    for (Map.Entry<String, Object> entry: params.entrySet()) {
      builder.queryParam(entry.getKey(), entry.getValue());
    }
    return builder.build().encode().toString();
  }

  public BaseTest() {
  }

}
