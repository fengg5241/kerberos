package com.fxo.admin.client.test;

import com.fxo.admin.client.DealingHoursService;
import com.fxo.rest.model.FXOCurrentDealingHoursModel;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.method;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.withSuccess;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:fxo-admin-client.xml")
public class DealingHoursServiceTest extends BaseTest {

  private static final DateTime START_TIME = DateTime.now().minusHours(2);
  private static final DateTime STOP_TIME = START_TIME.plusHours(4);
  protected static final String ENDPOINT = "/fxoDealingHours";

  @Autowired private DealingHoursService service;

  @Test
  public void testGetTodaysHours() throws Throwable {
    server.expect(requestTo(WS_ENDPOINT + ENDPOINT + "/today"))
    .andExpect(method(HttpMethod.GET))
    .andRespond(withSuccess(convertToJson(getMockHours()), MediaType.APPLICATION_JSON)
    );
    FXOCurrentDealingHoursModel todaysHours = service.getTodaysHours();
    Assert.assertNotNull(todaysHours);
    assertThat(todaysHours.getStartTime().getMillis(), is(START_TIME.getMillis()));
    assertThat(todaysHours.getEndTime().getMillis(), is(STOP_TIME.getMillis()));
    server.verify();
  }

  @Test
  public void testIsSystemOn() throws Throwable {
    server.expect(requestTo(WS_ENDPOINT + ENDPOINT + "/today"))
    .andExpect(method(HttpMethod.GET))
    .andRespond(withSuccess(convertToJson(getMockHours()), MediaType.APPLICATION_JSON)
    );
    Boolean isOn = service.isSystemOn();
    assertTrue(isOn);
    server.verify();
  }

  @Test
  public void testIsSystemOff() throws Throwable {
    DateTime mockEnd = getMockHours().getEndTime().minusHours(3);
    server.expect(requestTo(WS_ENDPOINT + ENDPOINT + "/today"))
    .andExpect(method(HttpMethod.GET))
    .andRespond(withSuccess(convertToJson(getMockHours().setEndTime(mockEnd)), MediaType.APPLICATION_JSON)
    );
    Boolean isOff = service.isSystemOff();
    assertTrue(isOff);
    server.verify();
  }

  private FXOCurrentDealingHoursModel getMockHours() {
    FXOCurrentDealingHoursModel mock = new FXOCurrentDealingHoursModel()
        .setDate(LocalDate.now()).setStartTime(START_TIME).setEndTime(STOP_TIME)
        ;
    return mock;
  }
}
