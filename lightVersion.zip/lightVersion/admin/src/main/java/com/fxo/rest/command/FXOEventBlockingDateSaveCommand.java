package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.admin.dto.FXOEventBlockingDateConfigListDTO;
import com.fxo.admin.service.IFXOEventBlockingDateConfigService;
import com.fxo.rest.converter.FXOEventBlockingDateConfigDTOModelConverter;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

public class FXOEventBlockingDateSaveCommand implements
		Callable<ResponseEntity<Boolean>> {

	@Autowired
	private IFXOEventBlockingDateConfigService fxoEventBlockingDateConfigService;

	@Autowired
	private FXOEventBlockingDateConfigDTOModelConverter fxoEventBlockingDateConfigDTOModelConverter;

	private FXOEventBlockingDateConfigModel eventBlockingDateConfigModel;

	public FXOEventBlockingDateSaveCommand(
			IFXOEventBlockingDateConfigService fxoEventBlockingDateConfigService,
			FXOEventBlockingDateConfigDTOModelConverter fxoEventBlockingDateConfigDTOModelConverter,
			FXOEventBlockingDateConfigModel fxoEventBlockingDateConfigModel) {

		if (fxoEventBlockingDateConfigService == null) {
			throw new IllegalStateException("Service is not set.");
		}

		if (fxoEventBlockingDateConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoEventBlockingDateConfigDTOModelConverter is not set.");
		}

		this.fxoEventBlockingDateConfigDTOModelConverter = fxoEventBlockingDateConfigDTOModelConverter;
		this.fxoEventBlockingDateConfigService = fxoEventBlockingDateConfigService;
		this.eventBlockingDateConfigModel = fxoEventBlockingDateConfigModel;

	}

	@Override
	public ResponseEntity<Boolean> call() throws Exception {

		FXOEventBlockingDateConfigDTO eventBlockingDateConfigDTO = (eventBlockingDateConfigModel != null) ? fxoEventBlockingDateConfigDTOModelConverter
				.fromModel(eventBlockingDateConfigModel) : null;

		FXOEventBlockingDateConfigListDTO fxoEventBlockingDateConfigListDTO = (eventBlockingDateConfigDTO != null) ? FXOEventBlockingDateConfigListDTO
				.getInstance().setFxoEventBlockingDateConfigDTO(
						eventBlockingDateConfigDTO) : null;

		ResponseEntity<Boolean> responseEntity = null;

		if (fxoEventBlockingDateConfigListDTO != null) {
			fxoEventBlockingDateConfigService
					.saveEventBlockingDate(fxoEventBlockingDateConfigListDTO);

			responseEntity = new ResponseEntity<Boolean>(Boolean.TRUE,
					HttpStatus.OK);

		}

		return responseEntity;
	}

}
