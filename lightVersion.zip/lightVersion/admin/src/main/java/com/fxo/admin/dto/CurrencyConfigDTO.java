package com.fxo.admin.dto;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CurrencyConfigDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String currency;
	private String amountPrecision;
	private String updatedBy;
	private DateTime updatedAt;

	public String getCurrency() {
		return currency;
	}

	public CurrencyConfigDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getAmountPrecision() {
		return amountPrecision;
	}

	public CurrencyConfigDTO setAmountPrecision(String amountPrecision) {
		this.amountPrecision = amountPrecision;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public CurrencyConfigDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public CurrencyConfigDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
