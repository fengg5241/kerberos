package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.CurrencyConfigModel;

@Component
public class CurrencyConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<CurrencyConfigDTO, CurrencyConfigModel> {

}
