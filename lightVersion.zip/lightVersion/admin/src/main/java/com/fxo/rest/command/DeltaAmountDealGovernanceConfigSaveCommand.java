package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;

public class DeltaAmountDealGovernanceConfigSaveCommand implements
		Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;

	public DeltaAmountDealGovernanceConfigSaveCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (deltaAmountDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"deltaAmountDealGovernanceConfigListModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.deltaAmountDealGovernanceConfigListModel = deltaAmountDealGovernanceConfigListModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<DeltaAmountDealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> deltaAmountDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getDeltaAmountThresholdDTOs(deltaAmountDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceConfigAdminService.updateDealGovernanceParameters(
				deltaAmountDealGovernanceConfigDTOs, validationCode);

		dealGovernanceConfigAdminService.refreshDealGovernanceCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getDeltaAmountThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<DeltaAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<DeltaAmountDealGovernanceConfigListModel>(
				deltaAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
