package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.model.FXOInterPortfolioConfigListModel;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;

public class FXOInterPortfolioConfigQueryCommand implements
		Callable<ResponseEntity<FXOInterPortfolioConfigListModel>> {

	private final IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService;

	private final String userId;

	private final FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	public FXOInterPortfolioConfigQueryCommand(
			String userId,
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService,
			FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter) {

		if (FXOStringUtility.isEmpty(userId)) {
			throw new IllegalStateException("UserId is not set");
		}

		if (fxoUserInterPortfolioMappingConfigQueryService == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigQueryService is not set");
		}

		if (fxoInterPortfolioConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoInterPortfolioConfigDTOModelConverter is not set");
		}

		this.userId = userId;
		this.fxoUserInterPortfolioMappingConfigQueryService = fxoUserInterPortfolioMappingConfigQueryService;
		this.fxoInterPortfolioConfigDTOModelConverter = fxoInterPortfolioConfigDTOModelConverter;

	}

	@Override
	public ResponseEntity<FXOInterPortfolioConfigListModel> call()
			throws Exception {

		List<FXOInterPortfolioConfigDTO> interPortfolioConfigDTOs = fxoUserInterPortfolioMappingConfigQueryService
				.getAllUnAssignedUserInterPortfolio(userId);

		List<FXOInterPortfolioConfigModel> fxoInterPortfolioConfigModels = (interPortfolioConfigDTOs != null) ? fxoInterPortfolioConfigDTOModelConverter
				.toModels(interPortfolioConfigDTOs) : null;

		return new ResponseEntity<FXOInterPortfolioConfigListModel>(
				new FXOInterPortfolioConfigListModel()
						.setInterPortfolios(fxoInterPortfolioConfigModels),
				HttpStatus.OK);
	}
}
