package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.admin.constants.FXOAdminMessageCodes;
import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.admin.dto.converter.UserInterPortfolioConfigDTOEntityConverter;
import com.fxo.api.service.IFXOUserInterPortfolioMappingService;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.FXOAdminActionTypes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.dao.repository.FXOInterPortfolioRepository;
import com.fxo.dao.repository.FXOUserInterPortfolioMappingRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.validation.ValidationService;

/**
 * @author lakshmikanth
 *
 */
@Service
public class UserInterPortfolioMappingConfigAdminServiceImpl implements
		IUserInterPortfolioMappingConfigAdminService {

	private static final Logger logger = LoggerFactory
			.getLogger(UserInterPortfolioMappingConfigAdminServiceImpl.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private FXOUserInterPortfolioMappingRepository fxoUserInterPortfolioMappingRepository;

	@Autowired
	private FXOInterPortfolioRepository fxoInterPortfolioRepository;

	@Autowired
	private UserInterPortfolioConfigDTOEntityConverter userInterPortfolioConfigDTOEntityConverter;

	@Autowired
	private IFXOUserInterPortfolioMappingService fxoUserInterPortfolioMappingService;

	@Autowired
	private IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService;

	@Autowired
	private ValidationService validationService;

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllFXOUserInterPortfolioMappings", allEntries = true),
			@CacheEvict(value = "getAllFXOUserInterPortfolioMappingsByUserId", allEntries = true),
			@CacheEvict(value = "getAllFXOUserInterPortfolioConfigMappings", allEntries = true),
			@CacheEvict(value = "getAllUnAssignedUserInterPortfolio", allEntries = true),
			@CacheEvict(value = "getInterPortflioConfigMappingsByUserId", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateUserInterPortfolioMappings(
			FXOUserInterPortfolioMappingConfigListWrapperDTO configListWrapperDTO) {

		validationService.validate(configListWrapperDTO);

		List<FXOUserInterPortfolioMapping> entitiesToPersist = null;

		for (FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO : configListWrapperDTO
				.getInterPortfolioMappingConfiguration()) {

			entitiesToPersist = fetchUserInterPortfolioMappingConfigEntitiesByUserId(fxoUserInterPortfolioMappingConfigListDTO);
		}

		if (entitiesToPersist != null
				&& FXOBooleanUtility.isFalse(entitiesToPersist.isEmpty())) {
			logger.info("fxoUserInterPortfolioMappingRepository saveFXOUserInterPortfolioMapping: the size is: "
					+ entitiesToPersist.size());
			fxoUserInterPortfolioMappingRepository
					.saveFXOUserInterPortfolioMapping(entitiesToPersist);
		}

	}

	public List<FXOUserInterPortfolioMapping> fetchUserInterPortfolioMappingConfigEntitiesByUserId(
			FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO) {

		if (FXOStringUtility.isEmpty(fxoUserInterPortfolioMappingConfigListDTO
				.getUserId())) {
			logger.info("updateUserInterPortfolioMappings user ID is empty");
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_USER_INFO_REQUIRED);
		}

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOs = fxoUserInterPortfolioMappingConfigListDTO
				.getInterPortfolios();

		if (fxoInterPortfolioConfigDTOs == null
				|| fxoInterPortfolioConfigDTOs.isEmpty()) {
			logger.info("updateUserInterPortfolioMappings fxoInterPortfolioConfigDTO List is empty");
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_PORTFOLIO_REQUIRED);
		}

		List<FXOUserInterPortfolioMapping> entitiesToPersist = new ArrayList<FXOUserInterPortfolioMapping>();

		for (FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO : fxoInterPortfolioConfigDTOs) {

			FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity = fxoUserInterPortfolioMappingRepository
					.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
							fxoUserInterPortfolioMappingConfigListDTO
									.getUserId(), fxoInterPortfolioConfigDTO
									.getInterPortfolio(), false);

			if (fxoUserInterPortfolioMappingEntity == null) {

				FXOInterPortfolio fxoInterPortfolio = fxoInterPortfolioRepository
						.getOneInterPortfolio(fxoInterPortfolioConfigDTO
								.getInterPortfolio());

				if (fxoInterPortfolio == null || fxoInterPortfolio.isInactive()) {
					logger.info(String.format(
							"InterPortfolio %s doesn't exist in database",
							fxoInterPortfolioConfigDTO.getInterPortfolio()));
					throw new ApplicationRuntimeException("",
							FXOMessageCodes.ERR_PORTFOLIO_INVALID);
				} else {
					FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingNew = userInterPortfolioConfigDTOEntityConverter
							.toEntity(fxoInterPortfolioConfigDTO);

					fxoUserInterPortfolioMappingNew
							.setInterPortfolio(fxoInterPortfolio)
							.setUserID(
									fxoUserInterPortfolioMappingConfigListDTO
											.getUserId())
							.setActive(BooleanCodes.BooleanCodes_True)
							.setCreatedBy(
									fxoInterPortfolioConfigDTO.getUpdatedBy())
							.setCreatedDate(
									DateTimeUtil.getCurrentSQLTimeStamp())
							.setLastUpdatedBy(
									fxoInterPortfolioConfigDTO.getUpdatedBy())
							.setLastUpdatedDate(
									DateTimeUtil
											.convertDateTimeToTimeStamp(fxoInterPortfolioConfigDTO
													.getUpdatedAt()));
					entitiesToPersist.add(fxoUserInterPortfolioMappingNew);
				}
			} else {
				if (checkForModification(fxoInterPortfolioConfigDTO,
						fxoUserInterPortfolioMappingEntity)) {
					FXOAdminActionTypes type = getAdminActionType(
							fxoInterPortfolioConfigDTO,
							fxoUserInterPortfolioMappingEntity);

					fxoUserInterPortfolioMappingEntity
							.setActive(
									type == FXOAdminActionTypes.ACTIVATE ? BooleanCodes.BooleanCodes_True
											: BooleanCodes.BooleanCodes_False)
							.setLastUpdatedBy(
									fxoInterPortfolioConfigDTO.getUpdatedBy())
							.setLastUpdatedDate(
									DateTimeUtil.getCurrentSQLTimeStamp());

					entitiesToPersist.add(fxoUserInterPortfolioMappingEntity);
				}
			}
		}
		return entitiesToPersist;
	}

	public FXOAdminActionTypes getAdminActionType(
			FXOInterPortfolioConfigDTO fxoInterPortfolioDTO,
			FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity) {

		FXOAdminActionTypes fxoAdminActionType = null;

		if ((FXOBooleanUtility.isTrue(fxoInterPortfolioDTO.getActive()) && FXOBooleanUtility
				.isFalse(fxoUserInterPortfolioMappingEntity.getActive()))) {
			fxoAdminActionType = FXOAdminActionTypes.ACTIVATE;
		} else if ((FXOBooleanUtility.isFalse(fxoInterPortfolioDTO.getActive()) && FXOBooleanUtility
				.isTrue(fxoUserInterPortfolioMappingEntity.getActive()))) {
			fxoAdminActionType = FXOAdminActionTypes.DEACTIVATE;
		} else {

			logger.error(String
					.format("UserInterPortfolio Entity is in InCorrectState [ userId : %s - interPortfolio : %s ]",
							fxoUserInterPortfolioMappingEntity.getUserID(),
							fxoInterPortfolioDTO.getInterPortfolio()));

			throw new ApplicationRuntimeException(
					FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_INVALID
							+ ","
							+ fxoUserInterPortfolioMappingEntity.getUserID()
							+ "," + fxoInterPortfolioDTO.getInterPortfolio());
		}

		return fxoAdminActionType;
	}

	public Boolean checkForModification(
			FXOInterPortfolioConfigDTO fxoInterPortfolioDTO,
			FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity) {
		return FXOBooleanUtility.areNotIdentical(
				fxoInterPortfolioDTO.getActive(),
				fxoUserInterPortfolioMappingEntity.isActive());
	}

	@Async
	@Override
	public void refreshUserInterPortfolioCache() {
		fxoUserInterPortfolioMappingService
				.loadFXOUserInterPortfolioMappingsData();

		fxoUserInterPortfolioMappingConfigQueryService
				.getAllFXOUserInterPortfolioConfigMappings();
	}

}
