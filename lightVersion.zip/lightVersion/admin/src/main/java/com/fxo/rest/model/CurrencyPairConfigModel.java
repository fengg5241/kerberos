package com.fxo.rest.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;
import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairConfigModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String currency;
	private String counterCurrency;
	private String ratePrecision;
	private String distanceFromSpot;
	private String pipUnitValue;
	private String minDistanceFromDeltaSpot;
	private String maxDistanceFromDeltaSpot;
	
	
	@NotNull
	@NotEmpty
	private String updatedBy;
	private DateTime updatedAt;

	public String getCurrency() {
		return currency;
	}

	public CurrencyPairConfigModel setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public CurrencyPairConfigModel setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getRatePrecision() {
		return ratePrecision;
	}

	public CurrencyPairConfigModel setRatePrecision(String ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public String getDistanceFromSpot() {
		return distanceFromSpot;
	}

	public CurrencyPairConfigModel setDistanceFromSpot(String distanceFromSpot) {
		this.distanceFromSpot = distanceFromSpot;
		return this;
	}

	public String getPipUnitValue() {
		return pipUnitValue;
	}

	public CurrencyPairConfigModel setPipUnitValue(String pipUnitValue) {
		this.pipUnitValue = pipUnitValue;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public CurrencyPairConfigModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public CurrencyPairConfigModel setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}
	
	public String getMinDistanceFromDeltaSpot() {
		return minDistanceFromDeltaSpot;
	}

	public CurrencyPairConfigModel setMinDistanceFromDeltaSpot(String minDistanceFromDeltaSpot) {
		this.minDistanceFromDeltaSpot = minDistanceFromDeltaSpot;
		return this;
	}

	public String getMaxDistanceFromDeltaSpot() {
		return maxDistanceFromDeltaSpot;
	}

	public CurrencyPairConfigModel setMaxDistanceFromDeltaSpot(String maxDistanceFromDeltaSpot) {
		this.maxDistanceFromDeltaSpot = maxDistanceFromDeltaSpot;
		return this;
	}

}
