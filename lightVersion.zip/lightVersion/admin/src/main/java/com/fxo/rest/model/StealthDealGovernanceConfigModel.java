package com.fxo.rest.model;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class StealthDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private BigDecimal maximumPercent;

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public StealthDealGovernanceConfigModel setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}
}
