package com.fxo.admin.service;

import java.io.Serializable;
import java.util.List;

import com.fxo.admin.dto.CurrencyConfigDTO;

/**
 * @author lakshmikanth
 *
 */
public interface ICurrencyConfigService extends Serializable {

	public List<CurrencyConfigDTO> getAllCurrencies();

	public List<CurrencyConfigDTO> updateCurrencies(
			List<CurrencyConfigDTO> currencyDTOs);

	void refreshCurrencyCache();

}
