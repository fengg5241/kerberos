package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<CurrencyPairConfigModel> configuration;

	public List<CurrencyPairConfigModel> getConfiguration() {
		return configuration;
	}

	public CurrencyPairConfigListModel setConfiguration(
			List<CurrencyPairConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
