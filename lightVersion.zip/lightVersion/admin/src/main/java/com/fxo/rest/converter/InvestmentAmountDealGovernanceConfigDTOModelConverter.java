package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigModel;

@Component(value = "investmentAmountDealGovernanceConfigDTOModelConverter")
public class InvestmentAmountDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, InvestmentAmountDealGovernanceConfigModel> {

}
