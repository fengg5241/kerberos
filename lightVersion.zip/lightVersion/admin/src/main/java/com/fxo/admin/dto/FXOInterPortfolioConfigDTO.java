package com.fxo.admin.dto;

import org.joda.time.DateTime;
import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.BaseCustomDTO;

public class FXOInterPortfolioConfigDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String interPortfolio;

	@Property(policy = PojomaticPolicy.TO_STRING)
	private String updatedBy;

	@Property(policy = PojomaticPolicy.TO_STRING)
	private DateTime updatedAt;

	@Property(policy = PojomaticPolicy.TO_STRING)
	private Boolean active;

	public String getInterPortfolio() {
		return interPortfolio;
	}

	public FXOInterPortfolioConfigDTO setInterPortfolio(String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public FXOInterPortfolioConfigDTO setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXOInterPortfolioConfigDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public FXOInterPortfolioConfigDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
