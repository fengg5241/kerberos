package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyConfigListModel extends BaseCustomModel {
	private static final long serialVersionUID = 1L;

	private List<CurrencyConfigModel> configuration;

	public List<CurrencyConfigModel> getConfiguration() {
		return configuration;
	}

	public CurrencyConfigListModel setConfiguration(
			List<CurrencyConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
