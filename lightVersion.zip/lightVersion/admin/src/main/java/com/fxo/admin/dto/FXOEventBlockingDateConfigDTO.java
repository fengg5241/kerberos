package com.fxo.admin.dto;

import java.util.List;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXOEventBlockingDateConfigDTO extends AuditableDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String eventDescription;

	private String active;

	private List<CurrencyPairConfigDTO> currencyPair;

	private List<String> product;

	private LocalDate expiryDateThresholdMin;

	private LocalDate expiryDateThresholdMax;

	public String getEventDescription() {
		return eventDescription;
	}

	public FXOEventBlockingDateConfigDTO setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXOEventBlockingDateConfigDTO setActive(String active) {
		this.active = active;
		return this;
	}

	public List<CurrencyPairConfigDTO> getCurrencyPair() {
		return currencyPair;
	}

	public FXOEventBlockingDateConfigDTO setCurrencyPair(
			List<CurrencyPairConfigDTO> currencyPair) {
		this.currencyPair = currencyPair;
		return this;
	}

	public List<String> getProduct() {
		return product;
	}

	public FXOEventBlockingDateConfigDTO setProduct(List<String> product) {
		this.product = product;
		return this;
	}

	public LocalDate getExpiryDateThresholdMin() {
		return expiryDateThresholdMin;
	}

	public FXOEventBlockingDateConfigDTO setExpiryDateThresholdMin(
			LocalDate expiryDateThresholdMin) {
		this.expiryDateThresholdMin = expiryDateThresholdMin;
		return this;
	}

	public LocalDate getExpiryDateThresholdMax() {
		return expiryDateThresholdMax;
	}

	public FXOEventBlockingDateConfigDTO setExpiryDateThresholdMax(
			LocalDate expiryDateThresholdMax) {
		this.expiryDateThresholdMax = expiryDateThresholdMax;
		return this;
	}

	public static FXOEventBlockingDateConfigDTO getInstance() {
		return new FXOEventBlockingDateConfigDTO();
	}
}
