package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DeltaAmountDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<DeltaAmountDealGovernanceConfigModel> configuration;

	public List<DeltaAmountDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public DeltaAmountDealGovernanceConfigListModel setConfiguration(
			List<DeltaAmountDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
