package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class CurrencyHedgeDealGovernanceCcyPairConfigSaveCommand implements
		Callable<ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>> {

	private static final Logger logger = LoggerFactory
			.getLogger(CurrencyHedgeDealGovernanceCcyPairConfigSaveCommand.class);

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION;

	public CurrencyHedgeDealGovernanceCcyPairConfigSaveCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (currencyHedgeDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"currencyHedgeDealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.currencyHedgeDealGovernanceConfigListModel = currencyHedgeDealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel> call() {

		// check if currencyPair is customized
		Boolean isCurrencyPairCustomizedForDealGovernance = dealGovernanceCcyPairConfigAdminService
				.isCurrencyPairCustomizedForDealGovernance(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		if (!isCurrencyPairCustomizedForDealGovernance) {
			logger.error(String.format(
					"CurrencyPair %s/%s not customized for DealGovernance",
					currencyPairConfigModel.getCurrency(),
					currencyPairConfigModel.getCounterCurrency()));
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED
							+ "," + currencyPairConfigModel.getCurrency() + ","
							+ currencyPairConfigModel.getCounterCurrency());
		}

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> currencyHedgeDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getCurrencyHedgeThresholdDTOs(currencyHedgeDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService.saveDealGovernanceParameters(
				validationCode, currencyPairConfigModel.getCurrency(),
				currencyPairConfigModel.getCounterCurrency(),
				currencyHedgeDealGovernanceConfigDTOs);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getCurrencyHedgeThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel> responseEntity = new ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>(
				currencyHedgeDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
