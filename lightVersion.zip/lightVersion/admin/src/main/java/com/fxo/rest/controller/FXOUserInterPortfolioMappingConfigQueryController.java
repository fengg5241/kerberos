package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.rest.command.FXOInterPortfolioConfigMappingByUserIdCommand;
import com.fxo.rest.command.GetAllUserInterPortfolioMappingsQueryCommand;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.converter.FXOUserInterPortfolioMappingConfigListDTOModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

@Controller
@RequestMapping(value = "/admin/userInterPortfolioMapping")
public class FXOUserInterPortfolioMappingConfigQueryController {

	@Autowired
	private IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;

	@Autowired
	private FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter;

	@Autowired
	private FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	// get All CurrencyPair-Product mappings (for all products)
	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	public Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel>> getAllUserInterPortfolios() {
		return new GetAllUserInterPortfolioMappingsQueryCommand(
				fxoUserInterPortfolioMappingQueryService,
				fxoUserInterPortfolioMappingConfigListDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{userId}", produces = "application/json")
	public Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>> getInterPortfolioConfigListByUserId(
			@PathVariable(value = "userId") String userId) {

		return new FXOInterPortfolioConfigMappingByUserIdCommand(userId,
				fxoUserInterPortfolioMappingQueryService,
				fxoInterPortfolioConfigDTOModelConverter);
	}

}