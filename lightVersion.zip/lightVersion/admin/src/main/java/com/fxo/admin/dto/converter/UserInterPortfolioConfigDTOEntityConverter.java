package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class UserInterPortfolioConfigDTOEntityConverter
		extends
		BaseCustomDTOEntityConverter<FXOInterPortfolioConfigDTO, FXOUserInterPortfolioMapping> {

}
