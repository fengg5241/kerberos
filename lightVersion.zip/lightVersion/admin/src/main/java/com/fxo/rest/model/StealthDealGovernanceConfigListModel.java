package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class StealthDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<StealthDealGovernanceConfigModel> configuration;

	public List<StealthDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public StealthDealGovernanceConfigListModel setConfiguration(
			List<StealthDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
