package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.rest.command.BarrierDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.BarrierDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.BarrierDealGovernanceConfigListCommand;
import com.fxo.rest.command.BarrierDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.CurrencyHedgeDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.CurrencyHedgeDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.CurrencyHedgeDealGovernanceConfigListCommand;
import com.fxo.rest.command.CurrencyHedgeDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.DeleteCcyPairsCustomizationForDealGovernanceCommand;
import com.fxo.rest.command.DeltaAmountDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.DeltaAmountDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.DeltaAmountDealGovernanceConfigListCommand;
import com.fxo.rest.command.DeltaAmountDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.DeltaPercentDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.DeltaPercentDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.DeltaPercentDealGovernanceConfigListCommand;
import com.fxo.rest.command.DeltaPercentDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.GetAllDealGovCustomizationsForACcyPairCommand;
import com.fxo.rest.command.GetAllDealGovernanceConfigurationsCommand;
import com.fxo.rest.command.GetCcyPairsCustomizedForDealGovCommand;
import com.fxo.rest.command.GetCcyPairsForDealGovernanceCustomizationCommand;
import com.fxo.rest.command.InvestmentAmountDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.InvestmentAmountDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.InvestmentAmountDealGovernanceConfigListCommand;
import com.fxo.rest.command.InvestmentAmountDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.MarginAmountDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.MarginAmountDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.MarginAmountDealGovernanceConfigListCommand;
import com.fxo.rest.command.MarginAmountDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.RawPremiumDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.RawPremiumDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.RawPremiumDealGovernanceConfigListCommand;
import com.fxo.rest.command.RawPremiumDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.SaveAllDealGovernanceConfigCustomizationsCommand;
import com.fxo.rest.command.StealthDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.StealthDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.StealthDealGovernanceConfigListCommand;
import com.fxo.rest.command.StealthDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.TenorDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.TenorDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.TenorDealGovernanceConfigListCommand;
import com.fxo.rest.command.TenorDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.VegaDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.VegaDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.VegaDealGovernanceConfigListCommand;
import com.fxo.rest.command.VegaDealGovernanceConfigSaveCommand;
import com.fxo.rest.command.VolatilityDealGovernanceCcyPairConfigListCommand;
import com.fxo.rest.command.VolatilityDealGovernanceCcyPairConfigSaveCommand;
import com.fxo.rest.command.VolatilityDealGovernanceConfigListCommand;
import com.fxo.rest.command.VolatilityDealGovernanceConfigSaveCommand;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.converter.DealGovernanceConfigDTOModelConverterFactory;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.BarrierDealGovernanceConfigListModel;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.DealGovernanceConfigListModel;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.DeltaPercentDealGovernanceConfigListModel;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigListModel;
import com.fxo.rest.model.StealthDealGovernanceConfigListModel;
import com.fxo.rest.model.TenorDealGovernanceConfigListModel;
import com.fxo.rest.model.VegaDealGovernanceConfigListModel;
import com.fxo.rest.model.VolatilityDealGovernanceConfigListModel;

@Controller
@RequestMapping(value = "/admin/dealGovernance")
public class DealGovernanceConfigController {

	private static final Logger logger = LoggerFactory
			.getLogger(DealGovernanceConfigController.class);

	@Autowired
	private IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;

	@Autowired
	private IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;

	@Autowired
	private DealGovernanceConfigDTOModelConverterFactory dealGovernanceConfigDTOModelFactory;

	@Autowired
	private DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	@Autowired
	private CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;

	@RequestMapping(method = RequestMethod.GET, value = "/currencyPairs", produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairConfigListModel>> getCurrencyPairsCustomizedForDealGovernance() {

		return new GetCcyPairsCustomizedForDealGovCommand(
				dealGovernanceCcyPairConfigAdminService,
				currencyPairConfigDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/currencyPairs/customize", produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairConfigListModel>> getCurrencyPairsAvaialableForDealGovernanceCustomization() {

		return new GetCcyPairsForDealGovernanceCustomizationCommand(
				dealGovernanceCcyPairConfigAdminService,
				currencyPairConfigDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	public Callable<ResponseEntity<DealGovernanceConfigListModel>> getDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<DealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new GetAllDealGovCustomizationsForACcyPairCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new GetAllDealGovernanceConfigurationsCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/investmentAmount", produces = "application/json")
	public Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> getInvestmentAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new InvestmentAmountDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new InvestmentAmountDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/investmentAmount", produces = "application/json")
	public Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> saveInvestmentAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel) {

		Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new InvestmentAmountDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					investmentAmountDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new InvestmentAmountDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					investmentAmountDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/deltaAmount", produces = "application/json")
	public Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> getDeltaAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new DeltaAmountDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new DeltaAmountDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deltaAmount", produces = "application/json")
	public Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> saveDeltaAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel) {

		Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new DeltaAmountDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					deltaAmountDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new DeltaAmountDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					deltaAmountDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/deltaPercent", produces = "application/json")
	public Callable<ResponseEntity<DeltaPercentDealGovernanceConfigListModel>> getDeltaPercentDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<DeltaPercentDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new DeltaPercentDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new DeltaPercentDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deltaPercent", produces = "application/json")
	public Callable<ResponseEntity<DeltaPercentDealGovernanceConfigListModel>> saveDeltaPercentDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel) {

		Callable<ResponseEntity<DeltaPercentDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new DeltaPercentDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					deltaPercentDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new DeltaPercentDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					deltaPercentDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/vega", produces = "application/json")
	public Callable<ResponseEntity<VegaDealGovernanceConfigListModel>> getVegaDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<VegaDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new VegaDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new VegaDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;

	}

	@RequestMapping(method = RequestMethod.POST, value = "/vega", produces = "application/json")
	public Callable<ResponseEntity<VegaDealGovernanceConfigListModel>> saveVegaDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody VegaDealGovernanceConfigListModel vegaDealGovernanceConfigListModel) {

		Callable<ResponseEntity<VegaDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new VegaDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					vegaDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new VegaDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					vegaDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/volatility", produces = "application/json")
	public Callable<ResponseEntity<VolatilityDealGovernanceConfigListModel>> getVolatilityDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<VolatilityDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new VolatilityDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new VolatilityDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/volatility", produces = "application/json")
	public Callable<ResponseEntity<VolatilityDealGovernanceConfigListModel>> saveVolatilityDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody VolatilityDealGovernanceConfigListModel volatilityDealGovernanceConfigListModel) {

		Callable<ResponseEntity<VolatilityDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new VolatilityDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					volatilityDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new VolatilityDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					volatilityDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/stealth", produces = "application/json")
	public Callable<ResponseEntity<StealthDealGovernanceConfigListModel>> getStealthDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<StealthDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new StealthDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new StealthDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/stealth", produces = "application/json")
	public Callable<ResponseEntity<StealthDealGovernanceConfigListModel>> saveStealthDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel) {

		Callable<ResponseEntity<StealthDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new StealthDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					stealthDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new StealthDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					stealthDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/tenor", produces = "application/json")
	public Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> getTenorDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new TenorDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new TenorDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/tenor", produces = "application/json")
	public Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> saveTenorDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel) {

		Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new TenorDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					tenorDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new TenorDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					tenorDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/currencyHedge", produces = "application/json")
	public Callable<ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>> getCurrencyHedgeDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new CurrencyHedgeDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new CurrencyHedgeDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/currencyHedge", produces = "application/json")
	public Callable<ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>> saveTraderNotificationDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel) {

		Callable<ResponseEntity<CurrencyHedgeDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new CurrencyHedgeDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					currencyHedgeDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new CurrencyHedgeDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					currencyHedgeDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/marginAmount", produces = "application/json")
	public Callable<ResponseEntity<MarginAmountDealGovernanceConfigListModel>> getMarginAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<MarginAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new MarginAmountDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new MarginAmountDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/marginAmount", produces = "application/json")
	public Callable<ResponseEntity<MarginAmountDealGovernanceConfigListModel>> saveMarginAmountDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel) {

		Callable<ResponseEntity<MarginAmountDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new MarginAmountDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					marginAmountDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new MarginAmountDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					marginAmountDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/rawPremium", produces = "application/json")
	public Callable<ResponseEntity<RawPremiumDealGovernanceConfigListModel>> getRawPremiumDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<RawPremiumDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new RawPremiumDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new RawPremiumDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/rawPremium", produces = "application/json")
	public Callable<ResponseEntity<RawPremiumDealGovernanceConfigListModel>> saveRawPremiumDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel) {

		Callable<ResponseEntity<RawPremiumDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new RawPremiumDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					rawPremiumDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new RawPremiumDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					rawPremiumDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/barrier", produces = "application/json")
	public Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> getBarrierDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency) {

		Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new BarrierDealGovernanceCcyPairConfigListCommand(
					dealGovernanceCcyPairConfigAdminService,
					dealGovernanceConfigListModelConveter, currency,
					counterCurrency);
		} else {
			responseEntity = new BarrierDealGovernanceConfigListCommand(
					dealGovernanceConfigAdminService,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/barrier", produces = "application/json")
	public Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> saveBarrierDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel) {

		Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isNotEmpty(currency)
				&& FXOStringUtility.isNotEmpty(counterCurrency)) {
			responseEntity = new BarrierDealGovernanceCcyPairConfigSaveCommand(
					dealGovernanceCcyPairConfigAdminService,
					barrierDealGovernanceConfigListModel,
					new CurrencyPairConfigModel().setCurrency(currency)
							.setCounterCurrency(counterCurrency),
					dealGovernanceConfigListModelConveter);
		} else {
			responseEntity = new BarrierDealGovernanceConfigSaveCommand(
					dealGovernanceConfigAdminService,
					barrierDealGovernanceConfigListModel,
					dealGovernanceConfigListModelConveter);
		}

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.POST, value = "/save", produces = "application/json")
	public Callable<ResponseEntity<DealGovernanceConfigListModel>> saveAllDealGovernanceConfigParameters(
			@RequestParam(value = "currency", required = false) String currency,
			@RequestParam(value = "counterCurrency", required = false) String counterCurrency,
			@Valid @RequestBody DealGovernanceConfigListModel dealGovernanceConfigListModel) {

		Callable<ResponseEntity<DealGovernanceConfigListModel>> responseEntity = null;

		if (FXOStringUtility.isEmpty(currency)
				|| FXOStringUtility.isEmpty(counterCurrency)) {
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		responseEntity = new SaveAllDealGovernanceConfigCustomizationsCommand(
				dealGovernanceCcyPairConfigAdminService,
				dealGovernanceConfigListModel, new CurrencyPairConfigModel()
						.setCurrency(currency).setCounterCurrency(
								counterCurrency),
				currencyPairConfigDTOModelConverter,
				dealGovernanceConfigListModelConveter);

		return responseEntity;
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/delete", produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairConfigListModel>> deleteCustomization(
			@RequestParam(value = "currency", required = true) String currency,
			@RequestParam(value = "counterCurrency", required = true) String counterCurrency) {

		return new DeleteCcyPairsCustomizationForDealGovernanceCommand(
				dealGovernanceCcyPairConfigAdminService,
				currencyPairConfigDTOModelConverter, currency, counterCurrency);
	}

}
