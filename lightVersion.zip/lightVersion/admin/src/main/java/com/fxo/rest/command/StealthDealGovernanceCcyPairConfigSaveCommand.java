package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.StealthDealGovernanceConfigListModel;

public class StealthDealGovernanceCcyPairConfigSaveCommand implements
		Callable<ResponseEntity<StealthDealGovernanceConfigListModel>> {

	private static final Logger logger = LoggerFactory
			.getLogger(StealthDealGovernanceCcyPairConfigSaveCommand.class);

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION;

	public StealthDealGovernanceCcyPairConfigSaveCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (stealthDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"stealthDealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.stealthDealGovernanceConfigListModel = stealthDealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<StealthDealGovernanceConfigListModel> call() {

		// check if currencyPair is customized
		Boolean isCurrencyPairCustomizedForDealGovernance = dealGovernanceCcyPairConfigAdminService
				.isCurrencyPairCustomizedForDealGovernance(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		if (!isCurrencyPairCustomizedForDealGovernance) {
			logger.error(String.format(
					"CurrencyPair %s/%s not customized for DealGovernance",
					currencyPairConfigModel.getCurrency(),
					currencyPairConfigModel.getCounterCurrency()));
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED
							+ "," + currencyPairConfigModel.getCurrency() + ","
							+ currencyPairConfigModel.getCounterCurrency());
		}

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> stealthDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getStealthThresholdDTOs(stealthDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService.saveDealGovernanceParameters(
				validationCode, currencyPairConfigModel.getCurrency(),
				currencyPairConfigModel.getCounterCurrency(),
				stealthDealGovernanceConfigDTOs);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getStealthThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<StealthDealGovernanceConfigListModel> responseEntity = new ResponseEntity<StealthDealGovernanceConfigListModel>(
				stealthDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
