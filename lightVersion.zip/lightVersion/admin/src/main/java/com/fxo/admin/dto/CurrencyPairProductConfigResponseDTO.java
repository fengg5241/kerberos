package com.fxo.admin.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CurrencyPairProductConfigResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String product;
	private String currency;
	private String counterCurrency;
	private String status;
	private Integer currencyPairCount;

	public String getCurrency() {
		return currency;
	}

	public CurrencyPairProductConfigResponseDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairProductConfigResponseDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public Integer getCurrencyPairCount() {
		return currencyPairCount;
	}

	public CurrencyPairProductConfigResponseDTO setCurrencyPairCount(
			Integer currencyPairCount) {
		this.currencyPairCount = currencyPairCount;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public CurrencyPairProductConfigResponseDTO setCounterCurrency(
			String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public CurrencyPairProductConfigResponseDTO setProduct(String product) {
		this.product = product;
		return this;
	}

}
