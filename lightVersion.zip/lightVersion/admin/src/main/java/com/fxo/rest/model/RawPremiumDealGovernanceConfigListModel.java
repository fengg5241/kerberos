package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class RawPremiumDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<RawPremiumDealGovernanceConfigModel> configuration;

	public List<RawPremiumDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public RawPremiumDealGovernanceConfigListModel setConfiguration(
			List<RawPremiumDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
