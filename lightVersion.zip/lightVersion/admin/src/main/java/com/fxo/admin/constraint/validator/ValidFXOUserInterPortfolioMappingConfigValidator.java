/**
 * 
 */
package com.fxo.admin.constraint.validator;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.admin.constants.FXOAdminMessageCodes;
import com.fxo.admin.constraint.ValidFXOUserInterPortfolioMappingConfig;
import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.api.dto.FXOInterPortfolioDTO;
import com.fxo.api.service.IFXOInterPortfolioService;
import com.fxo.dao.entity.FenicsTicket;
import com.fxo.dao.repository.FenicsTicketRepository;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

/**
 * @author lakshmikanth
 *
 */
public class ValidFXOUserInterPortfolioMappingConfigValidator
		implements
		ConstraintValidator<ValidFXOUserInterPortfolioMappingConfig, FXOUserInterPortfolioMappingConfigListWrapperDTO> {

	@Autowired
	FenicsTicketRepository fenicsTicketRepository;

	@Autowired
	IFXOInterPortfolioService fxoInterPortfolioService;

	@Override
	public void initialize(
			ValidFXOUserInterPortfolioMappingConfig constraintAnnotation) {

	}

	@Override
	public boolean isValid(
			FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - ValidUserInterPortfolioMapping
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// NULL Check
		Boolean hasANonNullUserInterPortfolioMappingConfigListWrapper = (fxoUserInterPortfolioMappingConfigListWrapperDTO != null)
				&& (fxoUserInterPortfolioMappingConfigListWrapperDTO
						.getInterPortfolioMappingConfiguration() != null)
				&& FXOBooleanUtility
						.isFalse(fxoUserInterPortfolioMappingConfigListWrapperDTO
								.getInterPortfolioMappingConfiguration()
								.isEmpty());

		predicateResultSet
				.add(hasANonNullUserInterPortfolioMappingConfigListWrapper);

		if (FXOBooleanUtility
				.isFalse(hasANonNullUserInterPortfolioMappingConfigListWrapper)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_WRAPPER_INVALID)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();

		}

		// Mappings Check (Null & Empty)
		else {

			for (FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO : fxoUserInterPortfolioMappingConfigListWrapperDTO
					.getInterPortfolioMappingConfiguration()) {
				Boolean isAValidFXOUserInterPortfolioMapping = isAValidFXOUserInterPortfolioMapping(
						fxoUserInterPortfolioMappingConfigListDTO, context);

				predicateResultSet.add(isAValidFXOUserInterPortfolioMapping);
			}

		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAValidFXOUserInterPortfolioMapping(
			FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - ValidFXOUserInterPortfolioMapping
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		Boolean isUserInterPortfolioMappingCollectionValid = fxoUserInterPortfolioMappingConfigListDTO != null
				&& fxoUserInterPortfolioMappingConfigListDTO
						.getInterPortfolios() != null
				&& FXOBooleanUtility
						.isFalse(fxoUserInterPortfolioMappingConfigListDTO
								.getInterPortfolios().isEmpty());

		predicateResultSet.add(isUserInterPortfolioMappingCollectionValid);

		if (FXOBooleanUtility
				.isFalse(isUserInterPortfolioMappingCollectionValid)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_COLLECTION_INVALID)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		else {

			for (FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO : fxoUserInterPortfolioMappingConfigListDTO
					.getInterPortfolios()) {

				Boolean hasNonNullInterPortfolioConfig = (fxoInterPortfolioConfigDTO != null);

				predicateResultSet.add(hasNonNullInterPortfolioConfig);

				if (FXOBooleanUtility.isFalse(hasNonNullInterPortfolioConfig)) {

					context.buildConstraintViolationWithTemplate(
							FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_INVALID
									+ ","
									+ fxoUserInterPortfolioMappingConfigListDTO
											.getUserId())
							.addConstraintViolation()
							.disableDefaultConstraintViolation();
				}

				else {

					if (FXOBooleanUtility.isFalse(fxoInterPortfolioConfigDTO
							.getActive())) {

						Boolean isAllowedToDeleteMapping = isAllowedToDeleteMapping(
								fxoUserInterPortfolioMappingConfigListDTO
										.getUserId(),
								fxoInterPortfolioConfigDTO.getInterPortfolio(),
								context);

						predicateResultSet.add(isAllowedToDeleteMapping);

					} else {
						Boolean isAllowedToAddMapping = isAllowedToAddMapping(
								fxoUserInterPortfolioMappingConfigListDTO
										.getUserId(),
								fxoInterPortfolioConfigDTO.getInterPortfolio(),
								context);

						predicateResultSet.add(isAllowedToAddMapping);
					}

				}

			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAllowedToDeleteMapping(String userId,
			String interPortfolio, ConstraintValidatorContext context) {

		List<FenicsTicket> fenicsTickets = fenicsTicketRepository
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

		boolean isAllowedToDeleteMapping = (fenicsTickets == null || fenicsTickets
				.isEmpty());

		if (FXOBooleanUtility.isFalse(isAllowedToDeleteMapping)) {

			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_DELETE_A_PORTFOLIO_DEAL_EXISTS
							+ "," + userId + "," + interPortfolio)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		return isAllowedToDeleteMapping;
	}

	public boolean isAllowedToAddMapping(String userId, String interPortfolio,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - isAllowedToAddMapping
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// emptyString check
		Boolean hasNonNullInterPortfolio = FXOStringUtility
				.isNotEmpty(interPortfolio);

		predicateResultSet.add(hasNonNullInterPortfolio);

		if (FXOBooleanUtility.isFalse(hasNonNullInterPortfolio)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID
							+ "," + userId).addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		// and Portfolio Static check
		else {

			FXOInterPortfolioDTO fxoInterPortfolioDTO = fxoInterPortfolioService
					.getOneFXOInterPortfolio(interPortfolio);

			Boolean hasAValidInterPortfolio = fxoInterPortfolioDTO != null;

			predicateResultSet.add(hasAValidInterPortfolio);

			if (FXOBooleanUtility.isFalse(hasAValidInterPortfolio)) {
				context.buildConstraintViolationWithTemplate(
						FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID
								+ "," + userId + "," + interPortfolio)
						.addConstraintViolation()
						.disableDefaultConstraintViolation();
			} else {

				Boolean isPortfolioActive = fxoInterPortfolioDTO.getActive();

				predicateResultSet.add(isPortfolioActive);

				if (FXOBooleanUtility.isFalse(isPortfolioActive)) {

					context.buildConstraintViolationWithTemplate(
							FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INACTIVE
									+ "," + userId + "," + interPortfolio)
							.addConstraintViolation()
							.disableDefaultConstraintViolation();
				}
			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}
}
