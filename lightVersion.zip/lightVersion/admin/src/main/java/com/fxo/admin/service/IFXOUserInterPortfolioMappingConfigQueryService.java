/**
 * 
 */
package com.fxo.admin.service;

import java.util.List;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;

/**
 * @author lakshmikanth
 *
 */
public interface IFXOUserInterPortfolioMappingConfigQueryService {

	public List<FXOUserInterPortfolioMappingConfigListDTO> getAllFXOUserInterPortfolioConfigMappings();
	
	public List<FXOInterPortfolioConfigDTO> getAllUnAssignedUserInterPortfolio(String userId);
	
	public List<FXOInterPortfolioConfigDTO> getInterPortflioConfigMappingsByUserId(String userId);
	
	public void deleteUserInterPortfolio(String userId);

}
