package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.DealGovernanceConfigListModel;

public class DealGovernanceConfigListCommand implements
		Callable<ResponseEntity<DealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceListModelConveter;

	public DealGovernanceConfigListCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (dealGovernanceListModelConveter == null) {
			throw new IllegalStateException("ServiceFactory is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.dealGovernanceListModelConveter = dealGovernanceListModelConveter;
	}

	@Override
	public ResponseEntity<DealGovernanceConfigListModel> call() {

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceConfigAdminService
				.getGlobalDealGovernanceConfigurationList();

		DealGovernanceConfigListModel dealGovernanceConfigListModel = dealGovernanceListModelConveter
				.translateDealGovernanceConfigDTOToModelObject(dealGovernanceConfigListDTO);

		ResponseEntity<DealGovernanceConfigListModel> responseEntity = new ResponseEntity<DealGovernanceConfigListModel>(
				dealGovernanceConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
