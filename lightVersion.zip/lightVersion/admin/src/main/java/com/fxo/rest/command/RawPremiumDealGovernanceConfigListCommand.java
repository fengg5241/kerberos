package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigListModel;

public class RawPremiumDealGovernanceConfigListCommand implements
		Callable<ResponseEntity<RawPremiumDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	public RawPremiumDealGovernanceConfigListCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {
		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
	}

	@Override
	public ResponseEntity<RawPremiumDealGovernanceConfigListModel> call() {

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION;

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getRawPremiumThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<RawPremiumDealGovernanceConfigListModel> responseEntity = new ResponseEntity<RawPremiumDealGovernanceConfigListModel>(
				rawPremiumDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
