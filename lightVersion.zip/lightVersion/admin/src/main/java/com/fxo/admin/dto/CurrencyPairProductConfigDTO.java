package com.fxo.admin.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.api.dto.CodeValueDTO;

@AutoProperty
public class CurrencyPairProductConfigDTO extends CurrencyPairConfigDTO {

	private static final long serialVersionUID = 1L;

	private List<CodeValueDTO> hierarchy;
	private String product;
	private String status;

	public String getProduct() {
		return product;
	}

	public CurrencyPairProductConfigDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairProductConfigDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public List<CodeValueDTO> getHierarchy() {
		return hierarchy;
	}

	public CurrencyPairProductConfigDTO setHierarchy(
			List<CodeValueDTO> hierarchy) {
		this.hierarchy = hierarchy;
		return this;
	}

}
