package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class MarginAmountDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private String minimum;
	private String minimumPercent;
	private String maximumPercent;

	public String getMinimum() {
		return minimum;
	}

	public MarginAmountDealGovernanceConfigModel setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public String getMinimumPercent() {
		return minimumPercent;
	}

	public MarginAmountDealGovernanceConfigModel setMinimumPercent(
			String minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMaximumPercent() {
		return maximumPercent;
	}

	public MarginAmountDealGovernanceConfigModel setMaximumPercent(
			String maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

}
