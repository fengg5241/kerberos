package com.fxo.rest.model;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class RawPremiumDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private BigDecimal minimumPercent;
	private BigDecimal maximumPercent;
	private String direction;

	public BigDecimal getMinimumPercent() {
		return minimumPercent;
	}

	public RawPremiumDealGovernanceConfigModel setMinimumPercent(
			BigDecimal minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public RawPremiumDealGovernanceConfigModel setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public RawPremiumDealGovernanceConfigModel setDirection(String direction) {
		this.direction = direction;
		return this;
	}

}
