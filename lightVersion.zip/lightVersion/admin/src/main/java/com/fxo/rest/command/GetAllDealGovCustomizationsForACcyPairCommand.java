package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.DealGovernanceConfigListModel;

public class GetAllDealGovCustomizationsForACcyPairCommand implements
		Callable<ResponseEntity<DealGovernanceConfigListModel>> {

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;
	private final String currency;
	private final String counterCurrency;

	public GetAllDealGovCustomizationsForACcyPairCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter,
			String currency, String counterCurrency) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		if (currency == null) {
			throw new IllegalStateException("currency is not set.");
		}

		if (counterCurrency == null) {
			throw new IllegalStateException("counterCurrency is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
		this.currency = currency;
		this.counterCurrency = counterCurrency;
	}

	@Override
	public ResponseEntity<DealGovernanceConfigListModel> call() {

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceCcyPairConfigAdminService
				.getAllDealGovernanceParameters(currency, counterCurrency);

		DealGovernanceConfigListModel dealGovernanceConfigListModel = dealGovernanceConfigListModelConveter
				.translateDealGovernanceConfigDTOToModelObject(dealGovernanceConfigListDTO);

		ResponseEntity<DealGovernanceConfigListModel> responseEntity = new ResponseEntity<DealGovernanceConfigListModel>(
				dealGovernanceConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
