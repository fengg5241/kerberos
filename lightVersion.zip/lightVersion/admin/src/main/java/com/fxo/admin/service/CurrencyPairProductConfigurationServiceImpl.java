package com.fxo.admin.service;

import static ch.lambdaj.Lambda.forEach;
import static ch.lambdaj.Lambda.having;
import static ch.lambdaj.Lambda.on;
import static ch.lambdaj.Lambda.select;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.equalTo;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.admin.dto.CurrencyPairProductConfigResponseDTO;
import com.fxo.admin.dto.converter.CurrencyPairProductConfigDTOEntityConverter;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.dao.entity.CurrencyPairProduct;
import com.fxo.dao.repository.CurrencyPairProductRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;

/**
 * @author lakshmikanth
 *
 */
@Service
public class CurrencyPairProductConfigurationServiceImpl implements
		ICurrencyPairProductConfigurationService {

	private static final Logger logger = LoggerFactory
			.getLogger(CurrencyPairProductConfigurationServiceImpl.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private CurrencyPairProductRepository currencyPairProductRepository;

	@Autowired
	private CurrencyPairProductConfigDTOEntityConverter currencyPairProductConfigDTOEntityConverter;

	@Autowired
	private IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@Override
	@Transactional(readOnly = true)
	@Cacheable(value = { "getAllCurrencyPairProductsConfiguration" })
	public List<CurrencyPairProductConfigDTO> getAllCurrencyPairProductsConfiguration() {
		boolean onlyActive = false;

		List<CurrencyPairProduct> currencyPairs = currencyPairProductRepository
				.getCurrencyPairs(onlyActive);

		List<CurrencyPairProductConfigDTO> currencyPairProductConfigDTOs = currencyPairProductConfigDTOEntityConverter
				.fromEntities(currencyPairs);

		if (currencyPairProductConfigDTOs != null) {
			for (CurrencyPairProductConfigDTO currencyPairProductConfigDTO : currencyPairProductConfigDTOs) {

				// get hierarchy of the product (use product as groupCode)
				List<CodeValueDTO> productCatalogueGroupHierarchy = fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(currencyPairProductConfigDTO
								.getProduct());

				currencyPairProductConfigDTO
						.setHierarchy(productCatalogueGroupHierarchy);
			}
		}
		return currencyPairProductConfigDTOs;
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getCurrencyPairMapGroupedByProduct", allEntries = true),
			@CacheEvict(value = "getAllUniqueCurrenciesFromCurrencyPairs", allEntries = true),
			@CacheEvict(value = "getOneCurrencyPairByCurrencyAndCounterCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getAllCurrenciesByCounterCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getAllCounterCurrenciesByCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getUniqueCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getCounterCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getAllCurrencyPairProductsConfiguration", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public CurrencyPairProductConfigResponseDTO updateCurrencyPairProductConfigurations(
			CurrencyPairProductConfigDTO currencyPairProductConfigDTO) {

		// fetch all CurrencyPairProduct entities (matching the input criteria)
		List<CurrencyPairProduct> currencyPairProductsForUpdate = fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO);

		// declare a local variable - Collection of type CurrencyPairProduct
		List<CurrencyPairProduct> currencyPairProductEntities_Updated = null;

		// update details in Database (if currencyPairProductsForUpdate is not
		// empty)
		if (currencyPairProductsForUpdate != null
				&& currencyPairProductsForUpdate.size() > 0) {
			String status = currencyPairProductConfigDTO.getStatus();
			String updatedBy = currencyPairProductConfigDTO.getUpdatedBy();
			Timestamp updatedAt = DateTimeUtil.getCurrentSQLTimeStamp();

			// set updateUserId, timeStamp for all the entities
			forEach(currencyPairProductsForUpdate).setStatus(status)
					.setLastUpdatedBy(updatedBy).setLastUpdatedDate(updatedAt);

			// push the changes to database
			currencyPairProductEntities_Updated = currencyPairProductRepository
					.saveCurrencyPairProducts(currencyPairProductsForUpdate);
		}

		// declare and initialize the response
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = new CurrencyPairProductConfigResponseDTO();
		currencyPairProductConfigResponseDTO
				.setProduct(currencyPairProductConfigDTO.getProduct());
		currencyPairProductConfigResponseDTO
				.setCurrency(currencyPairProductConfigDTO.getCurrency());
		currencyPairProductConfigResponseDTO
				.setCounterCurrency(currencyPairProductConfigDTO
						.getCounterCurrency());
		currencyPairProductConfigResponseDTO
				.setStatus(currencyPairProductConfigDTO.getStatus());

		// set the updateCount
		Integer currencyPairsUpdatedCount = (currencyPairProductEntities_Updated != null) ? currencyPairProductEntities_Updated
				.size() : 0;

		currencyPairProductConfigResponseDTO
				.setCurrencyPairCount(currencyPairsUpdatedCount);

		return currencyPairProductConfigResponseDTO;
	}

	public List<CurrencyPairProduct> fetchCurrencyPairProductEntitiesToUpdate(
			CurrencyPairProductConfigDTO currencyPairProductConfigDTO) {

		// retrieve input parameters into local variables
		String group = FXOStringUtility.isNotEmpty(currencyPairProductConfigDTO
				.getProduct()) ? currencyPairProductConfigDTO.getProduct()
				: ProductGroups.PRODUCT_GROUP_MASTER;
		String currency = currencyPairProductConfigDTO.getCurrency();
		String counterCurrency = currencyPairProductConfigDTO
				.getCounterCurrency();

		if (FXOStringUtility.isEmpty(currency)) {
			logger.info("Currency is required for CurrencyPair-Product Mapping Update");
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_CURRENCY_REQUIRED);
		}

		// get All Products
		List<String> products = fxoProductCatalogueGroupService
				.getAllProducts(group);

		// declare and initialize a collection to CurrencyPairProduct entities
		List<CurrencyPairProduct> currencyPairProductsForUpdate = new ArrayList<CurrencyPairProduct>();

		// for each product fetch Entities and add to a collection
		for (String product : products) {

			// for Currency (can be located at Fore or counter)
			if (FXOStringUtility.isEmpty(counterCurrency)) {
				List<CurrencyPairProduct> currencyPairProducts = currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product, false);

				if (currencyPairProducts != null
						&& currencyPairProducts.size() > 0) {
					currencyPairProductsForUpdate.addAll(currencyPairProducts);
				}

			}

			// for currencyPair
			else {
				CurrencyPairProduct currencyPairProduct = currencyPairProductRepository
						.getCurrencyPairProduct(currency, counterCurrency,
								product, false);

				if (currencyPairProduct != null) {
					currencyPairProductsForUpdate.add(currencyPairProduct);
				} else {

					String currencypair = currency + "/" + counterCurrency;
					String message = "CurrencyPair- " + currencypair
							+ " Details not found for: product-> " + product;

					logger.info(message);

					throw new ApplicationRuntimeException(message,
							FXOMessageCodes.ERR_CURRENCY_PAIR + ","
									+ currencypair + "," + "for " + product);

				}

			}

		}

		String status = currencyPairProductConfigDTO.getStatus();

		// filter fetched CurrencyPairProduct Entities (by Status, no need
		// to update the database entities with same Status [status in
		// input])
		List<CurrencyPairProduct> currencyPairProductsForUpdate_Filtered = filterCurrencyPairProductEntities(
				status, currencyPairProductsForUpdate);

		return currencyPairProductsForUpdate_Filtered;
	}

	/**
	 * filters the currencyPairProduct entities which don't have status same as
	 * input status
	 * 
	 * @param status
	 * @param currencyPairProductsForUpdate
	 * @return
	 */
	public List<CurrencyPairProduct> filterCurrencyPairProductEntities(
			String status,
			List<CurrencyPairProduct> currencyPairProductsForUpdate) {
		// apply filter (for entities with status not same as input Status)
		return select(
				currencyPairProductsForUpdate,
				having(on(CurrencyPairProduct.class).getStatus(),
						not(equalTo(status))));
	}
}
