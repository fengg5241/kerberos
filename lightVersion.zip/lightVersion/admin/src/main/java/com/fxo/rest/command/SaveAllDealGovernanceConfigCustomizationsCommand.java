package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.DealGovernanceConfigListModel;

public class SaveAllDealGovernanceConfigCustomizationsCommand implements
		Callable<ResponseEntity<DealGovernanceConfigListModel>> {

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final DealGovernanceConfigListModel dealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	public SaveAllDealGovernanceConfigCustomizationsCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			DealGovernanceConfigListModel dealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (dealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.dealGovernanceConfigListModel = dealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.currencyPairConfigDTOModelConverter = currencyPairConfigDTOModelConverter;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
	}

	@Override
	public ResponseEntity<DealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceConfigListModelConveter
				.translateDealGovernanceConfigModelToDTOObject(dealGovernanceConfigListModel);

		CurrencyPairConfigDTO currencyPairConfigDTO = currencyPairConfigDTOModelConverter
				.fromModel(currencyPairConfigModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService
				.saveAllDealGovernanceParameters(currencyPairConfigDTO,
						dealGovernanceConfigListDTO);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		DealGovernanceConfigListDTO dealGovernanceConfigListDTO_Response = dealGovernanceCcyPairConfigAdminService
				.getAllDealGovernanceParameters(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		DealGovernanceConfigListModel dealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.translateDealGovernanceConfigDTOToModelObject(dealGovernanceConfigListDTO_Response);

		ResponseEntity<DealGovernanceConfigListModel> responseEntity = new ResponseEntity<DealGovernanceConfigListModel>(
				dealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
