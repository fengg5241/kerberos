/**
 * 
 */
package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ch.lambdaj.Lambda;

import com.fxo.admin.constants.FXOAdminMessageCodes;
import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.converter.FXOInterPortfolioConfigDTOEntityConverter;
import com.fxo.admin.dto.converter.FXOInterPortfolioListDTOEntityConverter;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.dao.entity.FenicsTicket;
import com.fxo.dao.repository.FXOInterPortfolioRepository;
import com.fxo.dao.repository.FXOUserInterPortfolioMappingRepository;
import com.fxo.dao.repository.FenicsTicketRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

/**
 * @author lakshmikanth
 *
 */
@Service
public class FXOUserInterPortfolioMappingConfigQueryServiceImpl implements
		IFXOUserInterPortfolioMappingConfigQueryService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXOUserInterPortfolioMappingConfigQueryServiceImpl.class);

	@Autowired
	private FXOUserInterPortfolioMappingRepository fxoUserInterPortfolioMappingRepository;

	@Autowired
	private FXOInterPortfolioConfigDTOEntityConverter fxoUserInterPortfolioConfigDTOEntityConverter;

	@Autowired
	private FXOInterPortfolioRepository fxoInterPortfolioRepository;

	@Autowired
	private FXOInterPortfolioListDTOEntityConverter fxoInterPortfolioListDTOEntityConverter;

	@Autowired
	FenicsTicketRepository fenicsTicketRepository;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fxo.admin.service.IFXOUserInterPortfolioMappingQueryService#
	 * getAllFXOUserInterPortfolioMappings()
	 */
	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	@Cacheable(value = { "getAllFXOUserInterPortfolioConfigMappings" })
	public List<FXOUserInterPortfolioMappingConfigListDTO> getAllFXOUserInterPortfolioConfigMappings() {

		Map<String, List<FXOUserInterPortfolioMapping>> fxoUserInterPortfolioMappingGrouped = fxoUserInterPortfolioMappingRepository
				.getAllUserInterPortfolioMappingsByUserId();

		List<FXOUserInterPortfolioMappingConfigListDTO> fxoUserInterPortfolioMappingConfigListDTOs = new ArrayList<FXOUserInterPortfolioMappingConfigListDTO>();

		for (String groupedUserId : fxoUserInterPortfolioMappingGrouped
				.keySet()) {

			List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = fxoUserInterPortfolioMappingGrouped
					.get(groupedUserId);

			List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOs = fxoUserInterPortfolioConfigDTOEntityConverter
					.fromEntities(fxoUserInterPortfolioMappings);

			FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = new FXOUserInterPortfolioMappingConfigListDTO()
					.setInterPortfolios(fxoInterPortfolioConfigDTOs).setUserId(
							groupedUserId);

			fxoUserInterPortfolioMappingConfigListDTOs
					.add(fxoUserInterPortfolioMappingConfigListDTO);
		}

		return fxoUserInterPortfolioMappingConfigListDTOs;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	@Cacheable(value = { "getAllUnAssignedUserInterPortfolio" }, key = "#userId.toString()")
	public List<FXOInterPortfolioConfigDTO> getAllUnAssignedUserInterPortfolio(
			String userId) {

		if (FXOStringUtility.isEmpty(userId)) {
			throw new ApplicationRuntimeException(
					"UserId is either empty or null",
					FXOMessageCodes.ERR_USER_INFO_REQUIRED);
		} else {

			List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappingEntities = fxoUserInterPortfolioMappingRepository
					.getAllUserInterPortfolioMappingByUser(userId);

			List<FXOInterPortfolioConfigDTO> existingFxoInterPortfolioConfigDTOsByUserId = (fxoUserInterPortfolioMappingEntities != null) ? fxoUserInterPortfolioConfigDTOEntityConverter
					.fromEntities(fxoUserInterPortfolioMappingEntities) : null;

			List<FXOInterPortfolio> fxoInterPortfolioEntities = fxoInterPortfolioRepository
					.getAllInterPortfolio();

			List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOs = (fxoInterPortfolioEntities != null) ? fxoInterPortfolioListDTOEntityConverter
					.fromEntities(fxoInterPortfolioEntities) : null;

			if (existingFxoInterPortfolioConfigDTOsByUserId != null) {

				fxoInterPortfolioConfigDTOs
						.removeAll(existingFxoInterPortfolioConfigDTOsByUserId);
			}

			return Collections.unmodifiableList(fxoInterPortfolioConfigDTOs);
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, readOnly = true)
	@Cacheable(value = { "getInterPortflioConfigMappingsByUserId" }, key = "#userId.toString()")
	public List<FXOInterPortfolioConfigDTO> getInterPortflioConfigMappingsByUserId(
			String userId) {

		if (FXOStringUtility.isEmpty(userId)) {

			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_USER_INFO_REQUIRED);
		}
		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappingEntities = fxoUserInterPortfolioMappingRepository
				.getAllUserInterPortfolioMappingByUser(userId);

		return (fxoUserInterPortfolioMappingEntities != null) ? fxoUserInterPortfolioConfigDTOEntityConverter
				.fromEntities(fxoUserInterPortfolioMappingEntities) : null;
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllFXOUserInterPortfolioMappings", allEntries = true),
			@CacheEvict(value = "getAllFXOUserInterPortfolioMappingsByUserId", allEntries = true),
			@CacheEvict(value = "getAllFXOUserInterPortfolioConfigMappings", allEntries = true),
			@CacheEvict(value = "getAllUnAssignedUserInterPortfolio", allEntries = true),
			@CacheEvict(value = "getInterPortflioConfigMappingsByUserId", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRES_NEW, readOnly = true)
	public void deleteUserInterPortfolio(String userId) {

		if (FXOStringUtility.isEmpty(userId)) {

			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_USER_INFO_REQUIRED);
		}

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappingEntities = fxoUserInterPortfolioMappingRepository
				.getAllUserInterPortfolioMappingByUser(userId);

		if (CollectionUtils.isEmpty(fxoUserInterPortfolioMappingEntities)) {

			throw new ApplicationRuntimeException(
					"No interportfolio for the given userId",
					FXOStringUtility.joinStrings(
							Arrays.asList(
									FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_DELETE_PORTFOLIO_NOT_EXISTS,
									userId), FXOWSConstantKeys.COMMA_DELIMITER));

		} else {
			List<String> interPortfolios = getAllInterPortfoliosWithDeals(
					Collections
							.unmodifiableList(fxoUserInterPortfolioMappingEntities),
					userId);

			if (CollectionUtils.isNotEmpty(interPortfolios)) {

				// Need to refactor the below code

				throw new ApplicationRuntimeException(
						"Deals are available for few interportfolios",
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_DELETE_PORTFOLIO_DEAL_EXISTS,
										userId,
										FXOStringUtility
												.joinStrings(
														interPortfolios,
														FXOWSConstantKeys.HYPHEN_DELIMITER)),
								FXOWSConstantKeys.COMMA_DELIMITER));
			}

			else {

				Lambda.forEach(fxoUserInterPortfolioMappingEntities).setActive(
						BooleanCodes.config.False.value);

				logger.info("Deleting all the portfolios for the given userId - "
						+ userId);

				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping(fxoUserInterPortfolioMappingEntities);
			}
		}

	}

	public List<String> getAllInterPortfoliosWithDeals(
			List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappingEntities,
			String userId) {

		List<String> interPortfolioList = new ArrayList<String>();

		for (FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping : fxoUserInterPortfolioMappingEntities) {

			String interPortfolio = fxoUserInterPortfolioMapping
					.getInterPortfolio().getInterPortfolio();

			Boolean hasInterPortfolioDeals = checkForInterPortfolioDealsByUserId(
					userId, interPortfolio);

			if (FXOBooleanUtility.isTrue(hasInterPortfolioDeals)) {
				interPortfolioList.add(interPortfolio);
			}
		}

		return interPortfolioList;
	}

	public Boolean checkForInterPortfolioDealsByUserId(String userId,
			String interPortfolio) {

		List<FenicsTicket> fenicsTickets = fenicsTicketRepository
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

		return CollectionUtils.isNotEmpty(fenicsTickets);

	}

}
