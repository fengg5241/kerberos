package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.DealGovernanceConfigListModel;

public class GetAllDealGovernanceConfigurationsCommand implements
		Callable<ResponseEntity<DealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	public GetAllDealGovernanceConfigurationsCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
	}

	@Override
	public ResponseEntity<DealGovernanceConfigListModel> call() {

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceConfigAdminService
				.getGlobalDealGovernanceConfigurationList();

		DealGovernanceConfigListModel dealGovernanceConfigListModel = dealGovernanceConfigListModelConveter
				.translateDealGovernanceConfigDTOToModelObject(dealGovernanceConfigListDTO);

		ResponseEntity<DealGovernanceConfigListModel> responseEntity = new ResponseEntity<DealGovernanceConfigListModel>(
				dealGovernanceConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
