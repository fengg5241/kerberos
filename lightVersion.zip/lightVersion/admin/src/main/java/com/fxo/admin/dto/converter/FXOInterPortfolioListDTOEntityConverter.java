package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class FXOInterPortfolioListDTOEntityConverter
		extends
		BaseCustomDTOEntityConverter<FXOInterPortfolioConfigDTO, FXOInterPortfolio> {

}
