package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.framework.dto.model.converter.BaseDTOModelConverter;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

@Component
public class FXOEventBlockingDateConfigDTOModelConverter
		extends
		BaseDTOModelConverter<FXOEventBlockingDateConfigDTO, FXOEventBlockingDateConfigModel> {

}
