package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.api.dto.FXODealGovernanceParametersDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class RawPremiumDealGovConfigSourceTargetDTOConverter
		extends
		BaseCustomSourceTargetDTOConverter<FXODealGovernanceParametersDTO, DealGovernanceConfigDTO> {

}
