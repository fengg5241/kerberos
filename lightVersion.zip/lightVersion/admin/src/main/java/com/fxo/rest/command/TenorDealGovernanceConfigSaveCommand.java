package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.TenorDealGovernanceConfigListModel;

public class TenorDealGovernanceConfigSaveCommand implements
		Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION;

	public TenorDealGovernanceConfigSaveCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (tenorDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"tenorDealGovernanceConfigListModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.tenorDealGovernanceConfigListModel = tenorDealGovernanceConfigListModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<TenorDealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> tenorDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getTenorThresholdDTOs(tenorDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceConfigAdminService.updateDealGovernanceParameters(
				tenorDealGovernanceConfigDTOs, validationCode);

		dealGovernanceConfigAdminService.refreshDealGovernanceCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getTenorThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<TenorDealGovernanceConfigListModel> responseEntity = new ResponseEntity<TenorDealGovernanceConfigListModel>(
				tenorDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
