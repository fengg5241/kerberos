package com.fxo.rest.model;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DeltaPercentDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private BigDecimal minimumPercent;
	private BigDecimal maximumPercent;

	public BigDecimal getMinimumPercent() {
		return minimumPercent;
	}

	public DeltaPercentDealGovernanceConfigModel setMinimumPercent(
			BigDecimal minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public DeltaPercentDealGovernanceConfigModel setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

}
