package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyPairProductDTO;
import com.fxo.framework.dto.model.converter.BaseDTOBaseCustomModelConverter;
import com.fxo.rest.model.CurrencyPairProductConfigModel;

@Component
public class CurrencyPairProdConfigModelToCurrencyPairProdDTOModelConverter
		extends
		BaseDTOBaseCustomModelConverter<CurrencyPairProductDTO, CurrencyPairProductConfigModel> {

}
