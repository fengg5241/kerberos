package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.service.ICurrencyPairConfigService;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class CurrencyPairConfigUpdateCommand implements
		Callable<ResponseEntity<CurrencyPairConfigListModel>> {

	private final ICurrencyPairConfigService currencyPairConfigService;
	private final CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;
	private final CurrencyPairConfigListModel currencyPairConfigListModel;

	public CurrencyPairConfigUpdateCommand(
			ICurrencyPairConfigService currencyPairConfigService,
			CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter,
			CurrencyPairConfigListModel currencyPairConfigListModel) {

		if (currencyPairConfigService == null) {
			throw new IllegalStateException(
					"currencyPairConfigService is not set.");
		}

		if (currencyPairConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairConfigDTOModelConverter is not set.");
		}

		if (currencyPairConfigListModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigListModel is not set.");
		}

		this.currencyPairConfigService = currencyPairConfigService;
		this.currencyPairConfigDTOModelConverter = currencyPairConfigDTOModelConverter;
		this.currencyPairConfigListModel = currencyPairConfigListModel;

	}

	@Override
	public ResponseEntity<CurrencyPairConfigListModel> call() {

		// convert the Model to DTO
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = currencyPairConfigDTOModelConverter
				.fromModels(currencyPairConfigListModel.getConfiguration());

		// update CurrencyPairConfiguration
		currencyPairConfigService.updateCurrencyPairs(currencyPairConfigDTOs);

		currencyPairConfigService.refreshCurrencyPairCache();

		// fetch the CurrencyPair Configuration from cache
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Latest = currencyPairConfigService
				.getAllCurrencyPairs();

		// convert Model to DTO
		List<CurrencyPairConfigModel> currencyPairConfigModels_Latest = currencyPairConfigDTOModelConverter
				.toModels(currencyPairConfigDTOs_Latest);

		// declare and initialize the return type
		CurrencyPairConfigListModel currencyPairConfigListModel_latest = new CurrencyPairConfigListModel();

		// populate response with the latest currencyPairConfigModels
		currencyPairConfigListModel_latest
				.setConfiguration(currencyPairConfigModels_Latest);

		ResponseEntity<CurrencyPairConfigListModel> responseEntity = new ResponseEntity<CurrencyPairConfigListModel>(
				currencyPairConfigListModel_latest, HttpStatus.OK);

		return responseEntity;
	}
}
