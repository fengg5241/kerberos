package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class BarrierDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<BarrierDealGovernanceConfigModel> configuration;

	public List<BarrierDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public BarrierDealGovernanceConfigListModel setConfiguration(
			List<BarrierDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
