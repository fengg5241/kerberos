package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.admin.dto.CurrencyPairProductConfigResponseDTO;
import com.fxo.admin.service.ICurrencyPairProductConfigurationService;
import com.fxo.rest.converter.CurrencyPairProductConfigDTOModelConverter;
import com.fxo.rest.converter.CurrencyPairProductConfigResponseDTOModelConverter;
import com.fxo.rest.model.CurrencyPairProductConfigModel;
import com.fxo.rest.model.CurrencyPairProductConfigResponseModel;

public class CurrencyPairProductConfigUpdateCommand implements
		Callable<ResponseEntity<CurrencyPairProductConfigResponseModel>> {

	private final ICurrencyPairProductConfigurationService currencyPairProductConfigurationService;
	private final CurrencyPairProductConfigDTOModelConverter currencyPairProductConfigDTOModelConverter;
	private final CurrencyPairProductConfigModel currencyPairProductConfigModel;
	private final CurrencyPairProductConfigResponseDTOModelConverter currencyPairProductConfigResponseDTOModelConverter;

	public CurrencyPairProductConfigUpdateCommand(
			ICurrencyPairProductConfigurationService currencyPairProductConfigurationService,
			CurrencyPairProductConfigDTOModelConverter currencyPairProductConfigDTOModelConverter,
			CurrencyPairProductConfigModel currencyPairProductConfigModel,
			CurrencyPairProductConfigResponseDTOModelConverter currencyPairProductConfigResponseDTOModelConverter) {

		if (currencyPairProductConfigurationService == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigurationService is not set.");
		}

		if (currencyPairProductConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigDTOModelConverter is not set.");
		}

		if (currencyPairProductConfigResponseDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigResponseDTOModelConverter is not set.");
		}

		if (currencyPairProductConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigModel is not set.");
		}

		this.currencyPairProductConfigurationService = currencyPairProductConfigurationService;
		this.currencyPairProductConfigDTOModelConverter = currencyPairProductConfigDTOModelConverter;
		this.currencyPairProductConfigModel = currencyPairProductConfigModel;
		this.currencyPairProductConfigResponseDTOModelConverter = currencyPairProductConfigResponseDTOModelConverter;

	}

	@Override
	public ResponseEntity<CurrencyPairProductConfigResponseModel> call() {

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO = currencyPairProductConfigDTOModelConverter
				.fromModel(currencyPairProductConfigModel);

		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO);

		CurrencyPairProductConfigResponseModel currencyPairProductConfigResponseModel = currencyPairProductConfigResponseDTOModelConverter
				.toModel(currencyPairProductConfigResponseDTO);

		ResponseEntity<CurrencyPairProductConfigResponseModel> responseEntity = new ResponseEntity<CurrencyPairProductConfigResponseModel>(
				currencyPairProductConfigResponseModel, HttpStatus.OK);

		return responseEntity;
	}
}
