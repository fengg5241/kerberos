package com.fxo.admin.service;

import java.io.Serializable;

import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;

/**
 * @author lakshmikanth
 *
 */
public interface IUserInterPortfolioMappingConfigAdminService extends
		Serializable {

	void refreshUserInterPortfolioCache();

	void updateUserInterPortfolioMappings(
			FXOUserInterPortfolioMappingConfigListWrapperDTO configListWrapperDTO);

}
