package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class FXOUserInterPortfolioMappingConfigListWrapperModel extends
		BaseCustomModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<FXOUserInterPortfolioMappingConfigListModel> interPortfolioMappingConfiguration;

	public List<FXOUserInterPortfolioMappingConfigListModel> getInterPortfolioMappingConfiguration() {
		return interPortfolioMappingConfiguration;
	}

	public FXOUserInterPortfolioMappingConfigListWrapperModel setInterPortfolioMappingConfiguration(
			List<FXOUserInterPortfolioMappingConfigListModel> interPortfolioMappingConfiguration) {
		this.interPortfolioMappingConfiguration = interPortfolioMappingConfiguration;
		return this;
	}

}
