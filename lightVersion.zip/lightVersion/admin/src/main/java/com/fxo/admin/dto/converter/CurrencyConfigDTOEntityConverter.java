package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.dao.entity.FXOCurrency;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class CurrencyConfigDTOEntityConverter extends
		BaseCustomDTOEntityConverter<CurrencyConfigDTO, FXOCurrency> {

}
