package com.fxo.rest.model;

import java.util.List;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DealGovernanceConfigBaseModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<CodeValueModel> hierarchy;
	private String product;

	private String updatedBy;
	private DateTime updatedAt;
	private Boolean active;

	public List<CodeValueModel> getHierarchy() {
		return hierarchy;
	}

	public DealGovernanceConfigBaseModel setHierarchy(
			List<CodeValueModel> hierarchy) {
		this.hierarchy = hierarchy;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public DealGovernanceConfigBaseModel setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public DealGovernanceConfigBaseModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public DealGovernanceConfigBaseModel setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public DealGovernanceConfigBaseModel setActive(Boolean active) {
		this.active = active;
		return this;
	}

}
