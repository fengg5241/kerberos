package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class CurrencyPairConfigSourceTargetDTOConverter
		extends
		BaseCustomSourceTargetDTOConverter<CurrencyPairDTO, CurrencyPairConfigDTO> {

}
