package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairProductConfigModel extends CurrencyPairConfigModel {

	private static final long serialVersionUID = 1L;

	private String product;
	private List<CodeValueModel> hierarchy;
	private String status;

	public String getProduct() {
		return product;
	}

	public CurrencyPairProductConfigModel setProduct(String product) {
		this.product = product;
		return this;
	}

	public List<CodeValueModel> getHierarchy() {
		return hierarchy;
	}

	public CurrencyPairProductConfigModel setHierarchy(
			List<CodeValueModel> hierarchy) {
		this.hierarchy = hierarchy;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairProductConfigModel setStatus(String status) {
		this.status = status;
		return this;
	}

}
