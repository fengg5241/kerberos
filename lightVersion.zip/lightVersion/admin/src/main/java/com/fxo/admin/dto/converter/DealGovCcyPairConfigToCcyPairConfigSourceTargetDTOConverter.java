package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.api.dto.FXODealGovernanceParametersCcyPairDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class DealGovCcyPairConfigToCcyPairConfigSourceTargetDTOConverter
		extends
		BaseCustomSourceTargetDTOConverter<FXODealGovernanceParametersCcyPairDTO, CurrencyPairConfigDTO> {

}
