package com.fxo.admin.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.admin.constraint.ValidFXOEventBlockingConfig;
import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
@ValidFXOEventBlockingConfig
public class FXOEventBlockingDateConfigListDTO extends BaseCustomDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private FXOEventBlockingDateConfigDTO fxoEventBlockingDateConfigDTO;

	public FXOEventBlockingDateConfigDTO getFxoEventBlockingDateConfigDTO() {
		return fxoEventBlockingDateConfigDTO;
	}

	public FXOEventBlockingDateConfigListDTO setFxoEventBlockingDateConfigDTO(
			FXOEventBlockingDateConfigDTO fxoEventBlockingDateConfigDTO) {
		this.fxoEventBlockingDateConfigDTO = fxoEventBlockingDateConfigDTO;
		return this;
	}

	public static FXOEventBlockingDateConfigListDTO getInstance() {
		return new FXOEventBlockingDateConfigListDTO();
	}
}
