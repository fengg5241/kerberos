package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.admin.service.ICurrencyPairProductConfigurationService;
import com.fxo.rest.converter.CurrencyPairProductConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyPairProductConfigListModel;
import com.fxo.rest.model.CurrencyPairProductConfigModel;

public class CurrencyPairProductConfigListCommand implements
		Callable<ResponseEntity<CurrencyPairProductConfigListModel>> {

	private final ICurrencyPairProductConfigurationService currencyPairProductConfigurationService;
	private final CurrencyPairProductConfigDTOModelConverter currencyPairProductConfigDTOModelConverter;

	public CurrencyPairProductConfigListCommand(
			ICurrencyPairProductConfigurationService currencyPairProductConfigurationService,
			CurrencyPairProductConfigDTOModelConverter currencyPairProductConfigDTOModelConverter) {

		if (currencyPairProductConfigurationService == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigurationService is not set.");
		}

		if (currencyPairProductConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairProductConfigDTOModelConverter is not set.");
		}

		this.currencyPairProductConfigurationService = currencyPairProductConfigurationService;
		this.currencyPairProductConfigDTOModelConverter = currencyPairProductConfigDTOModelConverter;
	}

	@Override
	public ResponseEntity<CurrencyPairProductConfigListModel> call() {

		List<CurrencyPairProductConfigDTO> currencyPairProductDTOs = currencyPairProductConfigurationService
				.getAllCurrencyPairProductsConfiguration();

		List<CurrencyPairProductConfigModel> currencyPairProductConfigModels = currencyPairProductConfigDTOModelConverter
				.toModels(currencyPairProductDTOs);

		CurrencyPairProductConfigListModel currencyPairProductConfigListModel = new CurrencyPairProductConfigListModel();
		currencyPairProductConfigListModel
				.setConfiguration(currencyPairProductConfigModels);

		ResponseEntity<CurrencyPairProductConfigListModel> responseEntity = new ResponseEntity<CurrencyPairProductConfigListModel>(
				currencyPairProductConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
