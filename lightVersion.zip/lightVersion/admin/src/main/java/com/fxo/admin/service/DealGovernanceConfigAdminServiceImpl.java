package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.admin.constants.FXOAdminValidationCodes;
import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.dto.converter.DealGovernanceConfigDTOEntityConverter;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.entity.converter.FXODealGovernanceParametersDTOEntityConverter;
import com.fxo.api.service.IFXODealGovernanceParametersService;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.dao.repository.FXODealGovernanceParametersRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.MathUtil;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * The Class DealGovernanceConfigAdminServiceImpl.
 *
 * @author lakshmikanth
 */
@Service
public class DealGovernanceConfigAdminServiceImpl implements
		IDealGovernanceConfigAdminService {

	private static final Logger logger = LoggerFactory
			.getLogger(DealGovernanceConfigAdminServiceImpl.class);

	@Autowired
	private FXODealGovernanceParametersRepository fxoDealGovernanceParametersRepository;

	@Autowired
	private FXODealGovernanceParametersDTOEntityConverter fxoDealGovernanceParametersDTOEntityConverter;

	@Autowired
	private IFXODealGovernanceParametersService fxoDealGovernanceParametersService;

	@Autowired
	private IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@Autowired
	private DealGovernanceConfigDTOEntityConverter dealGovernanceConfigDTOEntityConverter;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fxo.admin.service.IDealGovernanceConfigAdminService#
	 * getDealGovernanceParametersConfiguration(java.lang.String)
	 */
	@Override
	@Transactional(readOnly = true)
	@Cacheable(value = { "getDealGovernanceParametersConfigurationByValidationCode" }, key = "#validationCode")
	public List<DealGovernanceConfigDTO> getDealGovernanceParametersConfiguration(
			String validationCode) {

		// declare and initialize the collection of type DealGovernanceConfigDTO
		// (output)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs = new ArrayList<DealGovernanceConfigDTO>();

		// get the DealGovernanceParameters for the given ValidationCode (For
		// all applicable products as configured in database)
		List<FXODealGovernanceParameters> fxoDealGovernanceParameterEntities = fxoDealGovernanceParametersRepository
				.getAllDealGovernanceParameterByValidationCode(validationCode,
						false);

		if (fxoDealGovernanceParameterEntities != null
				&& fxoDealGovernanceParameterEntities.size() > 0) {

			for (FXODealGovernanceParameters fxoDealGovernanceParameters : fxoDealGovernanceParameterEntities) {

				DealGovernanceConfigDTO dealGovernanceConfigDTO = dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters);

				// get hierarchy of the product (use product as groupCode)
				List<CodeValueDTO> productCatalogueGroupHierarchy = fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(fxoDealGovernanceParameters
								.getFxoProductCatalogue().getProduct());

				// Set the hierarchy
				dealGovernanceConfigDTO
						.setHierarchy(productCatalogueGroupHierarchy);

				// add the dealGovernanceConfigDTO to collection
				dealGovernanceConfigDTOs.add(dealGovernanceConfigDTO);
			}

		}

		return dealGovernanceConfigDTOs;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fxo.admin.service.IDealGovernanceConfigAdminService#
	 * updateDealGovernanceParameters(java.util.List, java.lang.String)
	 */
	@Override
	@Caching(evict = {
			@CacheEvict(value = "getDealGovernanceParametersConfigurationByValidationCode", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersByProduct", allEntries = true),
			@CacheEvict(value = "getOneDealGovernanceParameterByProductAndValidationCode", allEntries = true),
			@CacheEvict(value = "getAllDealGovernanceParametersByValidationCode", allEntries = true),
			@CacheEvict(value = "getOneDealGovernanceParameterByProductAndValidationCodeAndDirection", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProduct", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductForTicketing", allEntries = true),			
			@CacheEvict(value = "getOneDealGovernanceParameterConfig", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public void updateDealGovernanceParameters(
			List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs,
			String validationCode) {

		List<FXODealGovernanceParameters> currentDbEntities = new ArrayList<FXODealGovernanceParameters>();

		if (dealGovernanceConfigDTOs != null
				&& !dealGovernanceConfigDTOs.isEmpty()) {

			List<String> validationsForTicketing =Lists.newArrayList(Lists.transform(Arrays.asList(FXOAdminValidationCodes.values()), new Function<FXOAdminValidationCodes,String>() { 
			        public String apply(FXOAdminValidationCodes i) { return i.toString(); }
			    }));
			
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOs) {
				dealGovernanceConfigDTO.setValidationCode(validationCode);
				if(validationsForTicketing.contains(validationCode)){
					dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_True);
				}else				{
					dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);
				}

				List<FXODealGovernanceParameters> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		if (currentDbEntities != null && currentDbEntities.size() > 0) {
			fxoDealGovernanceParametersRepository
					.saveFXODealGovernanceParametersList(currentDbEntities);
		}
	}

	/**
	 * 
	 * Fetch FXODealGovernanceParameters-Entities to update.
	 *
	 * @param dealGovernanceConfigDTO
	 *            [{@link DealGovernanceConfigDTO}]
	 * @return FXODealGovernanceParameters-Entities [ {@link List}]
	 */
	public List<FXODealGovernanceParameters> fetchFXODealGovernanceParametersEntitiesToUpdate(
			DealGovernanceConfigDTO dealGovernanceConfigDTO) {

		// retrieve input parameters into local variables
		String group = FXOStringUtility.isNotEmpty(dealGovernanceConfigDTO
				.getProduct()) ? dealGovernanceConfigDTO.getProduct()
				: ProductGroups.PRODUCT_GROUP_MASTER;
		String validationCode = dealGovernanceConfigDTO.getValidationCode();
		String direction = dealGovernanceConfigDTO.getDirection();

		if (FXOStringUtility.isEmpty(validationCode)) {
			logger.info("validationCode is required for DealGovernance Update");
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CONFIG);
		}

		// get All Products
		List<String> products = fxoProductCatalogueGroupService
				.getAllProducts(group);

		// declare and initialize a collection to CurrencyPairProduct entities
		List<FXODealGovernanceParameters> fxoDealGovernanceParametersForUpdate = new ArrayList<FXODealGovernanceParameters>();

		// for each product fetch Entities and add to a collection
		for (String product : products) {

			FXODealGovernanceParameters currentDbEntity = fxoDealGovernanceParametersRepository
					.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
							product, validationCode, direction, false);

			if (currentDbEntity == null) {

				String message = "DealGovernanceParameters [" + validationCode
						+ "] is not found for: Product-> " + product;

				logger.info(message);

				throw new ApplicationRuntimeException(message,
						FXOMessageCodes.ERR_DEAL_GOVERNANCE_PARAMETER + ","
								+ product);
			}

			// check for any modification
			if (checkForModification(dealGovernanceConfigDTO, currentDbEntity)) {
				currentDbEntity
						.setMinimum(dealGovernanceConfigDTO.getMinimum());
				currentDbEntity
						.setMaximum(dealGovernanceConfigDTO.getMaximum());
				
				currentDbEntity.setAlert(dealGovernanceConfigDTO.getAlert());
				currentDbEntity.setValidateInTicketingService(
						dealGovernanceConfigDTO.getValidateInTicketingService());
				currentDbEntity.setMinimumPercent(MathUtil.createBigDecimal(
						dealGovernanceConfigDTO.getMinimumPercent(), 4));
				currentDbEntity.setMaximumPercent(MathUtil.createBigDecimal(
						dealGovernanceConfigDTO.getMaximumPercent(), 4));

				currentDbEntity.setActive(BooleanCodes.config
						.get(dealGovernanceConfigDTO.getActive()).value);
				currentDbEntity.setLastUpdatedDate(DateTimeUtil
						.getCurrentSQLTimeStamp());
				currentDbEntity.setLastUpdatedBy(dealGovernanceConfigDTO
						.getUpdatedBy());
				fxoDealGovernanceParametersForUpdate.add(currentDbEntity);
			}

		}

		return fxoDealGovernanceParametersForUpdate;
	}

	/**
	 * Check for modification.
	 *
	 * @param dealGovernanceConfigDTO
	 *            [{@link DealGovernanceConfigDTO}]
	 * @param fxoDealGovernanceParameters
	 *            [{@link FXODealGovernanceParameters}]
	 * @return true, if modified [{@link boolean}]
	 */
	public boolean checkForModification(
			DealGovernanceConfigDTO dealGovernanceConfigDTO,
			FXODealGovernanceParameters fxoDealGovernanceParameters) {
		return !(FXOStringUtility.compare(dealGovernanceConfigDTO.getMinimum(),
				fxoDealGovernanceParameters.getMinimum()))
				||

				!(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMinimumPercent(),
						fxoDealGovernanceParameters.getMinimumPercent()))

				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMaximum(),
						fxoDealGovernanceParameters.getMaximum()))
						
				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getAlert(),
						fxoDealGovernanceParameters.getAlert()))
				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getValidateInTicketingService(),
						fxoDealGovernanceParameters.getValidateInTicketingService()))

				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMaximumPercent(),
						fxoDealGovernanceParameters.getMaximumPercent()))

				|| !(FXOStringUtility.compare(BooleanCodes.config
						.get(dealGovernanceConfigDTO.getActive()).value,
						fxoDealGovernanceParameters.getActive()));
	}

	@Override
	@Transactional(readOnly = true)
	public DealGovernanceConfigListDTO getGlobalDealGovernanceConfigurationList() {

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = new DealGovernanceConfigListDTO();

		// InvestmentAmount
		dealGovernanceConfigListDTO
				.setNotionalThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION));

		// DeltaAmount
		dealGovernanceConfigListDTO
				.setDeltaAmountThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION));

		// DeltaPercent
		dealGovernanceConfigListDTO
				.setDeltaPercentThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION));

		// Volatility
		dealGovernanceConfigListDTO
				.setVolatilityThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION));

		// Vega
		dealGovernanceConfigListDTO
				.setVegaThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION));

		// Tenor
		dealGovernanceConfigListDTO
				.setTenorThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION));

		// Stealth
		dealGovernanceConfigListDTO
				.setStealthThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION));

		// MarginAmount
		dealGovernanceConfigListDTO
				.setMarginThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION));

		// CurrencyHedge
		dealGovernanceConfigListDTO
				.setTraderNotificationThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION));

		// RawPremium
		dealGovernanceConfigListDTO
				.setPremiumThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION));

		// barrier
		dealGovernanceConfigListDTO
				.setBarrierThreshold(getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION));

		return dealGovernanceConfigListDTO;
	}

	@Async
	@Override
	public void refreshDealGovernanceCache() {
		fxoDealGovernanceParametersService.loadDealGovernanceParameters();
	}

}
