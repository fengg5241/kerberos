package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigListModel;

public class MarginAmountDealGovernanceConfigSaveCommand implements
		Callable<ResponseEntity<MarginAmountDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION;

	public MarginAmountDealGovernanceConfigSaveCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (marginAmountDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"marginAmountDealGovernanceConfigListModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.marginAmountDealGovernanceConfigListModel = marginAmountDealGovernanceConfigListModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<MarginAmountDealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> marginAmountDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getMarginAmountThresholdDTOs(marginAmountDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceConfigAdminService.updateDealGovernanceParameters(
				marginAmountDealGovernanceConfigDTOs, validationCode);

		dealGovernanceConfigAdminService.refreshDealGovernanceCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getMarginAmountThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<MarginAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<MarginAmountDealGovernanceConfigListModel>(
				marginAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
