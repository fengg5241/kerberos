package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.BarrierDealGovernanceConfigListModel;

public class BarrierDealGovernanceConfigSaveCommand implements
		Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION;

	public BarrierDealGovernanceConfigSaveCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (barrierDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"barrierDealGovernanceConfigListModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.barrierDealGovernanceConfigListModel = barrierDealGovernanceConfigListModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<BarrierDealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> barrierDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getBarrierThresholdDTOs(barrierDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceConfigAdminService.updateDealGovernanceParameters(
				barrierDealGovernanceConfigDTOs, validationCode);

		dealGovernanceConfigAdminService.refreshDealGovernanceCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getBarrierThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<BarrierDealGovernanceConfigListModel> responseEntity = new ResponseEntity<BarrierDealGovernanceConfigListModel>(
				barrierDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
