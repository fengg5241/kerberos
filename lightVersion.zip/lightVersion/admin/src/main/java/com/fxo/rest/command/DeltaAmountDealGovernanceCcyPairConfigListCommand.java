package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;

public class DeltaAmountDealGovernanceCcyPairConfigListCommand implements
		Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> {

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;
	private final String currency;
	private final String counterCurrency;

	public DeltaAmountDealGovernanceCcyPairConfigListCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter,
			String currency, String counterCurrency) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException("ServiceFactory is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		if (currency == null) {
			throw new IllegalStateException("currency is not set.");
		}

		if (counterCurrency == null) {
			throw new IllegalStateException("counterCurrency is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
		this.currency = currency;
		this.counterCurrency = counterCurrency;
	}

	@Override
	public ResponseEntity<DeltaAmountDealGovernanceConfigListModel> call() {

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currency, counterCurrency);
		
		// translate refreshed DTO Objects to Model Objects
		DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getDeltaAmountThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<DeltaAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<DeltaAmountDealGovernanceConfigListModel>(
				deltaAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
