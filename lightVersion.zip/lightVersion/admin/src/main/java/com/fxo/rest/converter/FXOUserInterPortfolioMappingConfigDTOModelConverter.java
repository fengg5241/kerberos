package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingModel;

@Component
public class FXOUserInterPortfolioMappingConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<FXOUserInterPortfolioMappingConfigDTO, FXOUserInterPortfolioMappingModel> {

}
