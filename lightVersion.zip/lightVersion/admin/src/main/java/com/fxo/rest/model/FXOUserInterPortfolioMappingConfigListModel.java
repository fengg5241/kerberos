package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;
import java.util.List;

@AutoProperty
public class FXOUserInterPortfolioMappingConfigListModel extends
		BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String userId;

	private List<FXOInterPortfolioConfigModel> interPortfolios;

	public String getUserId() {
		return userId;
	}

	public FXOUserInterPortfolioMappingConfigListModel setUserId(String userId) {
		this.userId = userId;
		return this;
	}

	public List<FXOInterPortfolioConfigModel> getInterPortfolios() {
		return interPortfolios;
	}

	public FXOUserInterPortfolioMappingConfigListModel setInterPortfolios(
			List<FXOInterPortfolioConfigModel> interPortfolios) {
		this.interPortfolios = interPortfolios;
		return this;
	}

}
