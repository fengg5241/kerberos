package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairProductConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<CurrencyPairProductConfigModel> configuration;

	public List<CurrencyPairProductConfigModel> getConfiguration() {
		return configuration;
	}

	public CurrencyPairProductConfigListModel setConfiguration(
			List<CurrencyPairProductConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
