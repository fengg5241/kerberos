package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigListModel;

public class InvestmentAmountDealGovernanceCcyPairConfigSaveCommand implements
		Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> {

	private static final Logger logger = LoggerFactory
			.getLogger(InvestmentAmountDealGovernanceCcyPairConfigSaveCommand.class);

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

	public InvestmentAmountDealGovernanceCcyPairConfigSaveCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (investmentAmountDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"investmentAmountDealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.investmentAmountDealGovernanceConfigListModel = investmentAmountDealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<InvestmentAmountDealGovernanceConfigListModel> call() {

		// check if currencyPair is customized
		Boolean isCurrencyPairCustomizedForDealGovernance = dealGovernanceCcyPairConfigAdminService
				.isCurrencyPairCustomizedForDealGovernance(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		if (!isCurrencyPairCustomizedForDealGovernance) {
			logger.error(String.format(
					"CurrencyPair %s/%s not customized for DealGovernance",
					currencyPairConfigModel.getCurrency(),
					currencyPairConfigModel.getCounterCurrency()));
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED
							+ "," + currencyPairConfigModel.getCurrency() + ","
							+ currencyPairConfigModel.getCounterCurrency());
		}

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> investmentAmountDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getInvestmentAmountThresholdDTOs(investmentAmountDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService.saveDealGovernanceParameters(
				validationCode, currencyPairConfigModel.getCurrency(),
				currencyPairConfigModel.getCounterCurrency(),
				investmentAmountDealGovernanceConfigDTOs);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getNotionalThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<InvestmentAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>(
				investmentAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
