package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.VegaDealGovernanceConfigModel;

@Component(value = "vegaDealGovernanceConfigDTOModelConverter")
public class VegaDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, VegaDealGovernanceConfigModel> {

}
