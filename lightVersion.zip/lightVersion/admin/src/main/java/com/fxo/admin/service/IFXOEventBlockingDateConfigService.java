package com.fxo.admin.service;

import java.util.List;

import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.admin.dto.FXOEventBlockingDateConfigListDTO;

public interface IFXOEventBlockingDateConfigService {

	List<FXOEventBlockingDateConfigDTO> getEventBlockingDates();

	void saveEventBlockingDate(
			FXOEventBlockingDateConfigListDTO eventBlockingDateConfigDTO);

	void deleteEventBlockingDateById(String id);

}
