package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;

@Component
public class UserInterPortfolioConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<FXOInterPortfolioConfigDTO, FXOInterPortfolioConfigModel> {

}
