package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.api.dto.FXOEventBlockingDateDTO;
import com.fxo.framework.core.dto.BaseSourceTargetDTOConverter;

@Component
public class FXOEventBlockingDateSourceTargetDTOConverter
		extends
		BaseSourceTargetDTOConverter<FXOEventBlockingDateDTO,FXOEventBlockingDateConfigDTO> {

}
