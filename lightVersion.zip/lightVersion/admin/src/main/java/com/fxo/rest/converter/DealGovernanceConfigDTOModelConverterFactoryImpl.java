package com.fxo.rest.converter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.BarrierDealGovernanceConfigModel;
import com.fxo.rest.model.BaseCustomModel;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigModel;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigModel;
import com.fxo.rest.model.DeltaPercentDealGovernanceConfigModel;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigModel;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigModel;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigModel;
import com.fxo.rest.model.StealthDealGovernanceConfigModel;
import com.fxo.rest.model.TenorDealGovernanceConfigModel;
import com.fxo.rest.model.VegaDealGovernanceConfigModel;
import com.fxo.rest.model.VolatilityDealGovernanceConfigModel;

@Component
public class DealGovernanceConfigDTOModelConverterFactoryImpl implements
		DealGovernanceConfigDTOModelConverterFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "investmentAmountDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, InvestmentAmountDealGovernanceConfigModel> investmentAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "marginAmountDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, MarginAmountDealGovernanceConfigModel> marginAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "deltaAmountDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, DeltaAmountDealGovernanceConfigModel> deltaAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "deltaPercentDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, DeltaPercentDealGovernanceConfigModel> deltaPercentDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "vegaDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, VegaDealGovernanceConfigModel> vegaDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "volatilityDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, VolatilityDealGovernanceConfigModel> volatilityDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "stealthDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, StealthDealGovernanceConfigModel> stealthDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "rawPremiumDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, RawPremiumDealGovernanceConfigModel> rawPremiumDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "currencyHedgeDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, CurrencyHedgeDealGovernanceConfigModel> currencyHedgeDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "tenorDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, TenorDealGovernanceConfigModel> tenorDealGovernanceConfigDTOModelConverter;

	@Autowired
	@Qualifier(value = "barrierDealGovernanceConfigDTOModelConverter")
	private BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, BarrierDealGovernanceConfigModel> barrierDealGovernanceConfigDTOModelConverter;

	@Override
	public BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> getDealGovernanceConfigDTOModelConverter(
			String validationCode) {

		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter = null;

		switch (validationCode) {

		case DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION:
			dealGovernanceConfigDTOModelConverter = investmentAmountDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION:
			dealGovernanceConfigDTOModelConverter = marginAmountDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION:
			dealGovernanceConfigDTOModelConverter = deltaAmountDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION:
			dealGovernanceConfigDTOModelConverter = deltaPercentDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION:
			dealGovernanceConfigDTOModelConverter = vegaDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION:
			dealGovernanceConfigDTOModelConverter = volatilityDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION:
			dealGovernanceConfigDTOModelConverter = stealthDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION:
			dealGovernanceConfigDTOModelConverter = rawPremiumDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION:
			dealGovernanceConfigDTOModelConverter = currencyHedgeDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION:
			dealGovernanceConfigDTOModelConverter = tenorDealGovernanceConfigDTOModelConverter;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION:
			dealGovernanceConfigDTOModelConverter = barrierDealGovernanceConfigDTOModelConverter;
			break;

		default:
			break;
		}

		return dealGovernanceConfigDTOModelConverter;
	}

}
