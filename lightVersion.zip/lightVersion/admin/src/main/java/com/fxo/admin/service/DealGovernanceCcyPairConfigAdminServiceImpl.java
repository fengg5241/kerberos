package com.fxo.admin.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ch.lambdaj.Lambda;

import com.fxo.admin.constants.FXOAdminValidationCodes;
import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.dto.converter.CurrencyPairConfigSourceTargetDTOConverter;
import com.fxo.admin.dto.converter.DealGovCcyPairConfigSourceTargetDTOConverter;
import com.fxo.admin.dto.converter.DealGovernanceConfigCcyPairDTOEntityConverter;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.api.dto.FXODealGovernanceParametersCcyPairDTO;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXODealGovernanceParametersCcyPairService;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.dao.entity.FXODealGovernanceParametersCcyPair;
import com.fxo.dao.repository.CurrencyPairRepository;
import com.fxo.dao.repository.FXODealGovernanceParametersCcyPairRepository;
import com.fxo.dao.repository.FXODealGovernanceParametersRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.MathUtil;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

@Service
public class DealGovernanceCcyPairConfigAdminServiceImpl implements
		IDealGovernanceCcyPairConfigAdminService {

	private static final Logger logger = LoggerFactory
			.getLogger(DealGovernanceCcyPairConfigAdminServiceImpl.class);

	@Autowired
	private IFXODealGovernanceParametersCcyPairService fxoDealGovernanceParametersCcyPairService;

	@Autowired
	private IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;

	@Autowired
	private ICurrencyPairService currencyPairService;

	@Autowired
	private IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@Autowired
	private CurrencyPairRepository currencyPairRepository;

	@Autowired
	private FXODealGovernanceParametersRepository fxoDealGovernanceParametersRepository;

	@Autowired
	private FXODealGovernanceParametersCcyPairRepository fxoDealGovernanceParametersCcyPairRepository;

	@Autowired
	private CurrencyPairConfigSourceTargetDTOConverter currencyPairConfigSourceTargetDTOConverter;

	@Autowired
	private DealGovCcyPairConfigSourceTargetDTOConverter dealGovCcyPairConfigSourceTargetDTOConverter;

	@Autowired
	private DealGovernanceConfigCcyPairDTOEntityConverter dealGovernanceConfigCcyPairDTOEntityConverter;

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public List<DealGovernanceConfigDTO> getDealGovernanceConfigListByCurrencyPair(
			String validationCode, String currency, String counterCurrency) {
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs = null;

		List<FXODealGovernanceParametersCcyPairDTO> fxoDealGovernanceParametersCcyPairDTOs = fxoDealGovernanceParametersCcyPairService
				.getAllDealGovernanceParametersCcyPairByValidationCodeAndCurrencyPair(
						validationCode, currency, counterCurrency);

		// translate fxoDealGovernanceParametersCcyPairDTOs to
		// List<DealGovernanceConfigDTO>
		if (fxoDealGovernanceParametersCcyPairDTOs != null
				&& !fxoDealGovernanceParametersCcyPairDTOs.isEmpty()) {
			dealGovernanceConfigDTOs = new ArrayList<DealGovernanceConfigDTO>();

			for (FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO : fxoDealGovernanceParametersCcyPairDTOs) {

				DealGovernanceConfigDTO dealGovernanceConfigDTO = dealGovCcyPairConfigSourceTargetDTOConverter
						.toTargetDTO(fxoDealGovernanceParametersCcyPairDTO);

				// get hierarchy of the product (use product as groupCode)
				List<CodeValueDTO> productCatalogueGroupHierarchy = fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(fxoDealGovernanceParametersCcyPairDTO
								.getFxoDealGovernanceParameters()
								.getFxoProductCatalogue().getProduct());

				// Set the hierarchy
				dealGovernanceConfigDTO
						.setHierarchy(productCatalogueGroupHierarchy);

				// add the dealGovernanceConfigDTO to collection
				dealGovernanceConfigDTOs.add(dealGovernanceConfigDTO);
			}
		}

		return dealGovernanceConfigDTOs;
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public List<CurrencyPairConfigDTO> getAllCurrencyPairsCustomizedForDealGovernance() {
		List<CurrencyPairDTO> currencyPairsCustomized = fxoDealGovernanceParametersCcyPairService
				.getAllUniqueCurrencyPairsCustomizedForDealGovernance();

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = null;

		if (currencyPairsCustomized != null
				&& currencyPairsCustomized.size() > 0) {
			currencyPairConfigDTOs = currencyPairConfigSourceTargetDTOConverter
					.toTargetDTOs(currencyPairsCustomized);
		} else {
			currencyPairConfigDTOs = new ArrayList<CurrencyPairConfigDTO>();
		}

		return currencyPairConfigDTOs;
	}

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public List<CurrencyPairConfigDTO> getAllCurrencyPairsForCustomizationForDealGovernance() {
		List<CurrencyPairDTO> currencyPairsForCustomization = fxoDealGovernanceParametersCcyPairService
				.getAllUniqueCurrencyPairsForCustomizationForDealGovernance();

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = null;

		if (currencyPairsForCustomization != null
				&& currencyPairsForCustomization.size() > 0) {

			Lambda.forEach(currencyPairsForCustomization)
					.setLastUpdatedBy(null).setLastUpdatedDate(null);

			currencyPairConfigDTOs = currencyPairConfigSourceTargetDTOConverter
					.toTargetDTOs(currencyPairsForCustomization);
		} else {
			currencyPairConfigDTOs = new ArrayList<CurrencyPairConfigDTO>();
		}

		return currencyPairConfigDTOs;
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllDealGovParamCcyPairByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getAllDealGovParamCcyPairByValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndDirectionAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "isDealGovernanceCustomizedForCurrencyPair", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByProduct", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByCcyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPairForTicketing", allEntries = true),			
			@CacheEvict(value = "getAllUniqueCurrencyPairsCustomizedForDealGovernance", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteCurrencyPairCustomizationForDealGovernance(
			String currency, String counterCurrency) {

		// check if DealGovernanceCustomization exists from currencyPair
		boolean isDealGovernanceCustomized = fxoDealGovernanceParametersCcyPairService
				.isDealGovernanceCustomizedForCurrencyPair(currency,
						counterCurrency);

		if (isDealGovernanceCustomized) {
			fxoDealGovernanceParametersCcyPairService
					.deleteDealGovernanceParametersCcyPairs(currency,
							counterCurrency);
		} else {
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED);
		}
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllDealGovParamCcyPairByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getAllDealGovParamCcyPairByValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndDirectionAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "isDealGovernanceCustomizedForCurrencyPair", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByProduct", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByCcyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPairForTicketing", allEntries = true),			
			@CacheEvict(value = "getAllUniqueCurrencyPairsCustomizedForDealGovernance", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public void saveDealGovernanceParameters(String validationCode,
			String currency, String counterCurrency,
			List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs) {

		List<FXODealGovernanceParametersCcyPair> currentDbEntities = null;

		if (dealGovernanceConfigDTOs != null
				&& dealGovernanceConfigDTOs.size() > 0) {

			currentDbEntities = new ArrayList<FXODealGovernanceParametersCcyPair>();
			List<String> validationsForTicketing =Lists.newArrayList(Lists.transform(Arrays.asList(FXOAdminValidationCodes.values()), new Function<FXOAdminValidationCodes,String>() { 
		        public String apply(FXOAdminValidationCodes i) { return i.toString(); }
		    }));
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOs) {
				dealGovernanceConfigDTO.setValidationCode(validationCode);
				if(validationsForTicketing.contains(validationCode)){
					dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_True);
				}else				{
					dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);
				}
				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		if (currentDbEntities != null && currentDbEntities.size() > 0) {
			fxoDealGovernanceParametersCcyPairRepository
					.saveFXODealGovernanceParametersCcyPairList(currentDbEntities);
		}
	}

	public List<FXODealGovernanceParametersCcyPair> fetchFXODealGovernanceParametersEntitiesToUpdate(
			String currency, String counterCurrency,
			DealGovernanceConfigDTO dealGovernanceConfigDTO) {

		Objects.requireNonNull(dealGovernanceConfigDTO.getUpdatedBy(),
				FXOMessageCodes.ERR_USER_INFO_REQUIRED);

		// retrieve input parameters into local variables
		String group = FXOStringUtility.isNotEmpty(dealGovernanceConfigDTO
				.getProduct()) ? dealGovernanceConfigDTO.getProduct()
				: ProductGroups.PRODUCT_GROUP_MASTER;
		String validationCode = dealGovernanceConfigDTO.getValidationCode();
		String direction = dealGovernanceConfigDTO.getDirection();

		if (FXOStringUtility.isEmpty(validationCode)) {
			logger.error("validationCode is required for DealGovernance Update");
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CONFIG);
		}

		// get All Products
		List<String> products = fxoProductCatalogueGroupService
				.getAllProducts(group);

		// declare and initialize a collection to
		// FXODealGovernanceParametersCcyPair entities
		List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersForUpdate = new ArrayList<FXODealGovernanceParametersCcyPair>();

		// for each product fetch Entities and add to a collection
		for (String product : products) {

			FXODealGovernanceParametersCcyPair currentDbEntity = fxoDealGovernanceParametersCcyPairRepository
					.getOneDealGovernanceParameterCcyPairByProductAndValidationCodeAndDirection(
							product, validationCode, direction, currency,
							counterCurrency, false);

			if (currentDbEntity == null) {

				currentDbEntity = new FXODealGovernanceParametersCcyPair();

				// populate DealGovernanceEntity
				FXODealGovernanceParameters globalDealGovernanceParametersEntity = fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product, validationCode, direction, false);

				Objects.requireNonNull(globalDealGovernanceParametersEntity,
						FXOMessageCodes.ERR_DEALGOVERNANCE_CONFIG);

				currentDbEntity
						.setFxoDealGovernanceParameters(globalDealGovernanceParametersEntity);

				// populate currencyPairEntity
				CurrencyPair currencyPairEntity = currencyPairRepository
						.getOneCurrencyPair(currency, counterCurrency);

				Objects.requireNonNull(currencyPairEntity,
						FXOMessageCodes.ERR_CURRENCY_PAIR + "," + currency
								+ "," + counterCurrency);

				// populate DealGovernanceCustomizations

				currentDbEntity
						.setCurrencyPair(currencyPairEntity)
						.setLegCount(
								globalDealGovernanceParametersEntity
										.getLegCount())
						.setValidateInDealGovernanceService(
								globalDealGovernanceParametersEntity
										.getValidateInDealGovernanceService())
						.setThresholdCurrency(
								globalDealGovernanceParametersEntity
										.getThresholdCurrency())
						.setDirection(
								globalDealGovernanceParametersEntity
										.getDirection())
						.setMinimum(dealGovernanceConfigDTO.getMinimum())
						.setMaximum(dealGovernanceConfigDTO.getMaximum())
						.setAlert(dealGovernanceConfigDTO.getAlert())
						.setValidateInTicketingService(
								dealGovernanceConfigDTO.getValidateInTicketingService())
						.setMinimumPercent(
								MathUtil.createBigDecimal(
										dealGovernanceConfigDTO
												.getMinimumPercent(), 6))
						.setMaximumPercent(
								MathUtil.createBigDecimal(
										dealGovernanceConfigDTO
												.getMaximumPercent(), 6))
						.setActive(
								BooleanCodes.config.get(dealGovernanceConfigDTO
										.getActive()).value)
						.setCreatedBy(dealGovernanceConfigDTO.getUpdatedBy())
						.setLastUpdatedBy(
								dealGovernanceConfigDTO.getUpdatedBy());

				Timestamp auditTime = DateTimeUtil.getCurrentSQLTimeStamp();

				currentDbEntity.setCreatedDate(auditTime).setLastUpdatedDate(
						auditTime);

				fxoDealGovernanceParametersForUpdate.add(currentDbEntity);
			}

			// check for any modification
			if (checkForModification(dealGovernanceConfigDTO, currentDbEntity)) {

				currentDbEntity
						.setMinimum(dealGovernanceConfigDTO.getMinimum())
						.setMaximum(dealGovernanceConfigDTO.getMaximum())
						.setAlert(dealGovernanceConfigDTO.getAlert())
						.setValidateInTicketingService(
								dealGovernanceConfigDTO.getValidateInTicketingService())
						.setMinimumPercent(
								MathUtil.createBigDecimal(
										dealGovernanceConfigDTO
												.getMinimumPercent(), 6))
						.setMaximumPercent(
								MathUtil.createBigDecimal(
										dealGovernanceConfigDTO
												.getMaximumPercent(), 6))
						.setActive(
								BooleanCodes.config.get(dealGovernanceConfigDTO
										.getActive()).value)
						.setLastUpdatedDate(
								DateTimeUtil.getCurrentSQLTimeStamp())
						.setLastUpdatedBy(
								dealGovernanceConfigDTO.getUpdatedBy());

				fxoDealGovernanceParametersForUpdate.add(currentDbEntity);
			}

		}

		return fxoDealGovernanceParametersForUpdate;
	}

	public boolean checkForModification(
			DealGovernanceConfigDTO dealGovernanceConfigDTO,
			FXODealGovernanceParametersCcyPair fxoDealGovernanceParametersCcyPair) {
		return !(FXOStringUtility.compare(dealGovernanceConfigDTO.getMinimum(),
				fxoDealGovernanceParametersCcyPair.getMinimum()))
				||

				!(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMinimumPercent(),
						fxoDealGovernanceParametersCcyPair.getMinimumPercent()))

				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMaximum(),
						fxoDealGovernanceParametersCcyPair.getMaximum()))
						
				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getAlert(),
						fxoDealGovernanceParametersCcyPair.getAlert()))
				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getValidateInTicketingService(),
						fxoDealGovernanceParametersCcyPair.getValidateInTicketingService()))

				|| !(FXOStringUtility.compare(
						dealGovernanceConfigDTO.getMaximumPercent(),
						fxoDealGovernanceParametersCcyPair.getMaximumPercent()))

				|| !(FXOStringUtility.compare(BooleanCodes.config
						.get(dealGovernanceConfigDTO.getActive()).value,
						fxoDealGovernanceParametersCcyPair.getActive()));
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllDealGovParamCcyPairByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getAllDealGovParamCcyPairByValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getOneDealGovParamCcyPairByProductAndValCodeAndDirectionAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "isDealGovernanceCustomizedForCurrencyPair", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByProduct", allEntries = true),
			@CacheEvict(value = "getDealGovernanceParametersCcyPairGroupedByCcyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPair", allEntries = true),
			@CacheEvict(value = "getApplicableValidationsByProductAndCurrencyPairForTicketing", allEntries = true),			
			@CacheEvict(value = "getAllUniqueCurrencyPairsCustomizedForDealGovernance", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public void saveAllDealGovernanceParameters(
			CurrencyPairConfigDTO currencyPairConfigDTO,
			DealGovernanceConfigListDTO dealGovernanceConfigDTOMaster) {

		String currency = currencyPairConfigDTO.getCurrency();
		String counterCurrency = currencyPairConfigDTO.getCounterCurrency();

		// get AuditUser
		String updatedBy = dealGovernanceConfigDTOMaster.getUpdatedBy();

		List<FXODealGovernanceParametersCcyPair> currentDbEntities = new ArrayList<FXODealGovernanceParametersCcyPair>();

		// fetch InvestmentAmount Entities for persistence
		if (dealGovernanceConfigDTOMaster.getNotionalThreshold() != null
				&& dealGovernanceConfigDTOMaster.getNotionalThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getNotionalThreshold())
					.setUpdatedBy(updatedBy);
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getNotionalThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_True);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch DeltaAmount Entities for persistence
		if (dealGovernanceConfigDTOMaster.getDeltaAmountThreshold() != null
				&& dealGovernanceConfigDTOMaster.getDeltaAmountThreshold()
						.size() > 0) {

			Lambda.forEach(
					dealGovernanceConfigDTOMaster.getDeltaAmountThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getDeltaAmountThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch Delta percent Entities for persistence
		if (dealGovernanceConfigDTOMaster.getDeltaPercentThreshold() != null
				&& dealGovernanceConfigDTOMaster.getDeltaPercentThreshold()
						.size() > 0) {

			Lambda.forEach(
					dealGovernanceConfigDTOMaster.getDeltaPercentThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getDeltaPercentThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetchVolatility Entities for persistence
		if (dealGovernanceConfigDTOMaster.getVolatilityThreshold() != null
				&& dealGovernanceConfigDTOMaster.getVolatilityThreshold()
						.size() > 0) {

			Lambda.forEach(
					dealGovernanceConfigDTOMaster.getVolatilityThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getVolatilityThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch Vega Entities for persistence
		if (dealGovernanceConfigDTOMaster.getVegaThreshold() != null
				&& dealGovernanceConfigDTOMaster.getVegaThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getVegaThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getVegaThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch Tenor Entities for persistence
		if (dealGovernanceConfigDTOMaster.getTenorThreshold() != null
				&& dealGovernanceConfigDTOMaster.getTenorThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getTenorThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getTenorThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch Stealth Entities for persistence
		if (dealGovernanceConfigDTOMaster.getStealthThreshold() != null
				&& dealGovernanceConfigDTOMaster.getStealthThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getStealthThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getStealthThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch MarginAmount Entities for persistence
		if (dealGovernanceConfigDTOMaster.getMarginThreshold() != null
				&& dealGovernanceConfigDTOMaster.getMarginThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getMarginThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getMarginThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch trader notification Entities for persistence
		if (dealGovernanceConfigDTOMaster.getTraderNotificationThreshold() != null
				&& dealGovernanceConfigDTOMaster
						.getTraderNotificationThreshold().size() > 0) {

			Lambda.forEach(
					dealGovernanceConfigDTOMaster
							.getTraderNotificationThreshold()).setUpdatedBy(
					updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getTraderNotificationThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// fetch rawPremium Entities for persistence
		if (dealGovernanceConfigDTOMaster.getPremiumThreshold() != null
				&& dealGovernanceConfigDTOMaster.getPremiumThreshold().size() > 0) {

			Lambda.forEach(dealGovernanceConfigDTOMaster.getPremiumThreshold())
					.setUpdatedBy(updatedBy);

			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : dealGovernanceConfigDTOMaster
					.getPremiumThreshold()) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		// create Customizations (initial Setup) [doesn't require setup for
		// subsequent updates after initial setup]

		Boolean isCustomized = fxoDealGovernanceParametersCcyPairService
				.isDealGovernanceCustomizedForCurrencyPair(currency,
						counterCurrency);

		if (!isCustomized) {

			// get Global Barrier Thresholds
			List<DealGovernanceConfigDTO> barrierThresholdDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION);
			

			Lambda.forEach(barrierThresholdDTOs).setUpdatedAt(null);
			Lambda.forEach(barrierThresholdDTOs).setUpdatedBy(updatedBy);

			// fetch Barrier
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : barrierThresholdDTOs) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}

			// get Global MidVol Thresholds
			List<DealGovernanceConfigDTO> midVolThresholdDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_MID_VOL_VALIDATION);

			Lambda.forEach(midVolThresholdDTOs).setUpdatedAt(null);
			Lambda.forEach(midVolThresholdDTOs).setUpdatedBy(updatedBy);

			// fetch MidVol
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : midVolThresholdDTOs) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_MID_VOL_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}

			// get ClientAmount Thresholds
			List<DealGovernanceConfigDTO> clientAmountThresholdDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_CLIENT_AMOUNT_VALIDATION);

			Lambda.forEach(clientAmountThresholdDTOs).setUpdatedAt(null);
			Lambda.forEach(clientAmountThresholdDTOs).setUpdatedBy(updatedBy);

			// fetch ClientAmount Thresholds
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : clientAmountThresholdDTOs) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_CLIENT_AMOUNT_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}

			// fetch CurrencyPair Thresholds
			List<DealGovernanceConfigDTO> currencyPairThresholdDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_PAIR_VALIDATION);

			Lambda.forEach(currencyPairThresholdDTOs).setUpdatedAt(null);
			Lambda.forEach(currencyPairThresholdDTOs).setUpdatedBy(updatedBy);

			// fetch CurrencyPair Thresholds
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : currencyPairThresholdDTOs) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_PAIR_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}

			// get HolidayCalendar Thresholds
			List<DealGovernanceConfigDTO> holidayCalendarThresholdDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(DealValidationCodes.DEAL_GOVERNANCE_HOLIDAY_CALENDAR_VALIDATION);

			Lambda.forEach(holidayCalendarThresholdDTOs).setUpdatedAt(null);
			Lambda.forEach(holidayCalendarThresholdDTOs)
					.setUpdatedBy(updatedBy);

			// fetch HolidayCalendar Thresholds
			for (DealGovernanceConfigDTO dealGovernanceConfigDTO : holidayCalendarThresholdDTOs) {
				dealGovernanceConfigDTO
						.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_HOLIDAY_CALENDAR_VALIDATION);
				dealGovernanceConfigDTO.setValidateInTicketingService(BooleanCodes.BooleanCodes_False);

				List<FXODealGovernanceParametersCcyPair> fxoDealGovernanceParametersEntitiesForUpdate = fetchFXODealGovernanceParametersEntitiesToUpdate(
						currency, counterCurrency, dealGovernanceConfigDTO);

				if (fxoDealGovernanceParametersEntitiesForUpdate != null
						&& fxoDealGovernanceParametersEntitiesForUpdate.size() > 0) {
					currentDbEntities
							.addAll(fxoDealGovernanceParametersEntitiesForUpdate);
				}

			}
		}

		if (currentDbEntities != null && currentDbEntities.size() > 0) {
			fxoDealGovernanceParametersCcyPairRepository
					.saveFXODealGovernanceParametersCcyPairList(currentDbEntities);
		}

	}

	@Override
	@Transactional(readOnly = true)
	public DealGovernanceConfigListDTO getAllDealGovernanceParameters(
			String currency, String counterCurrency) {

		DealGovernanceConfigListDTO dealGovernanceCcyPairConfigListDTO = new DealGovernanceConfigListDTO();

		// InvestmentAmount
		List<DealGovernanceConfigDTO> investmentAmountDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setNotionalThreshold(investmentAmountDealGovernanceConfigDTOs);

		// DeltaAmount
		List<DealGovernanceConfigDTO> deltaAmountDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setDeltaAmountThreshold(deltaAmountDealGovernanceConfigDTOs);

		// DeltaPercent
		List<DealGovernanceConfigDTO> deltaPercentDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setDeltaPercentThreshold(deltaPercentDealGovernanceConfigDTOs);

		// Volatility
		List<DealGovernanceConfigDTO> volatilityDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setVolatilityThreshold(volatilityDealGovernanceConfigDTOs);

		// Vega
		List<DealGovernanceConfigDTO> vegaDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setVegaThreshold(vegaDealGovernanceConfigDTOs);

		// Tenor
		List<DealGovernanceConfigDTO> tenorDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION, currency,
				counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setTenorThreshold(tenorDealGovernanceConfigDTOs);

		// Stealth
		List<DealGovernanceConfigDTO> stealthDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setStealthThreshold(stealthDealGovernanceConfigDTOs);

		// MarginAmount
		List<DealGovernanceConfigDTO> marginAmountDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setMarginThreshold(marginAmountDealGovernanceConfigDTOs);

		// CurrencyHedge
		List<DealGovernanceConfigDTO> currencyHedgeDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setTraderNotificationThreshold(currencyHedgeDealGovernanceConfigDTOs);

		// RawPremium
		List<DealGovernanceConfigDTO> rawPremiumDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setPremiumThreshold(rawPremiumDealGovernanceConfigDTOs);

		// barrier
		List<DealGovernanceConfigDTO> barrierDealGovernanceConfigDTOs = fetchDealGovernanceParametersForCustomization(
				DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION,
				currency, counterCurrency);

		dealGovernanceCcyPairConfigListDTO
				.setBarrierThreshold(barrierDealGovernanceConfigDTOs);

		return dealGovernanceCcyPairConfigListDTO;
	}

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public List<DealGovernanceConfigDTO> fetchDealGovernanceParametersForCustomization(
			String validationCode, String currency, String counterCurrency) {

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs = getDealGovernanceConfigListByCurrencyPair(
				validationCode, currency, counterCurrency);

		// get GlobalThresholds (if Thresholds are not Customized)
		if (dealGovernanceConfigDTOs == null
				|| dealGovernanceConfigDTOs.size() == 0) {
			dealGovernanceConfigDTOs = dealGovernanceConfigAdminService
					.getDealGovernanceParametersConfiguration(validationCode);

			Lambda.forEach(dealGovernanceConfigDTOs).setUpdatedBy(null);
			Lambda.forEach(dealGovernanceConfigDTOs).setUpdatedAt(null);
		}

		return dealGovernanceConfigDTOs;
	}

	@Override
	public Boolean isCurrencyPairCustomizedForDealGovernance(String currency,
			String counterCurrency) {
		return fxoDealGovernanceParametersCcyPairService
				.isDealGovernanceCustomizedForCurrencyPair(currency,
						counterCurrency);
	}

	@Override
	@Async
	public void refreshDealGovernanceCcyPairCache() {
		fxoDealGovernanceParametersCcyPairService
				.loadAllDealGovernanceParametersCustomizedByCcyPair();
	}
}
