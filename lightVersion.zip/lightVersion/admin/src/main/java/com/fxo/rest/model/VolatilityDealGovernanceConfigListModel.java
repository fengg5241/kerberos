package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class VolatilityDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<VolatilityDealGovernanceConfigModel> configuration;

	public List<VolatilityDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public VolatilityDealGovernanceConfigListModel setConfiguration(
			List<VolatilityDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
