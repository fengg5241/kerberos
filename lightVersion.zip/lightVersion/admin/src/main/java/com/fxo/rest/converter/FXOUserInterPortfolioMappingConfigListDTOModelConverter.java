package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

@Component
public class FXOUserInterPortfolioMappingConfigListDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<FXOUserInterPortfolioMappingConfigListDTO, FXOUserInterPortfolioMappingConfigListModel> {

}
