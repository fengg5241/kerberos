package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class MarginAmountDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<MarginAmountDealGovernanceConfigModel> configuration;

	public List<MarginAmountDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public MarginAmountDealGovernanceConfigListModel setConfiguration(
			List<MarginAmountDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
