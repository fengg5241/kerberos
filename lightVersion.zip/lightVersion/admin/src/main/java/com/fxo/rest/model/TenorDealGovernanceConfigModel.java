package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class TenorDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private String minimum;
	private String maximum;

	public String getMaximum() {
		return maximum;
	}

	public TenorDealGovernanceConfigModel setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public TenorDealGovernanceConfigModel setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

}
