package com.fxo.admin.dto;

import java.util.List;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class DealGovernanceConfigListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<DealGovernanceConfigDTO> notionalThreshold;
	private List<DealGovernanceConfigDTO> deltaAmountThreshold;
	private List<DealGovernanceConfigDTO> deltaPercentThreshold;
	private List<DealGovernanceConfigDTO> volatilityThreshold;
	private List<DealGovernanceConfigDTO> vegaThreshold;
	private List<DealGovernanceConfigDTO> tenorThreshold;
	private List<DealGovernanceConfigDTO> stealthThreshold;
	private List<DealGovernanceConfigDTO> marginThreshold;
	private List<DealGovernanceConfigDTO> traderNotificationThreshold;
	private List<DealGovernanceConfigDTO> premiumThreshold;
	private List<DealGovernanceConfigDTO> barrierThreshold;

	private String updatedBy;
	private DateTime updatedAt;

	public List<DealGovernanceConfigDTO> getNotionalThreshold() {
		return notionalThreshold;
	}

	public DealGovernanceConfigListDTO setNotionalThreshold(
			List<DealGovernanceConfigDTO> notionalThreshold) {
		this.notionalThreshold = notionalThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getDeltaAmountThreshold() {
		return deltaAmountThreshold;
	}

	public DealGovernanceConfigListDTO setDeltaAmountThreshold(
			List<DealGovernanceConfigDTO> deltaAmountThreshold) {
		this.deltaAmountThreshold = deltaAmountThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getDeltaPercentThreshold() {
		return deltaPercentThreshold;
	}

	public DealGovernanceConfigListDTO setDeltaPercentThreshold(
			List<DealGovernanceConfigDTO> deltaPercentThreshold) {
		this.deltaPercentThreshold = deltaPercentThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getVolatilityThreshold() {
		return volatilityThreshold;
	}

	public DealGovernanceConfigListDTO setVolatilityThreshold(
			List<DealGovernanceConfigDTO> volatilityThreshold) {
		this.volatilityThreshold = volatilityThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getVegaThreshold() {
		return vegaThreshold;
	}

	public DealGovernanceConfigListDTO setVegaThreshold(
			List<DealGovernanceConfigDTO> vegaThreshold) {
		this.vegaThreshold = vegaThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getTenorThreshold() {
		return tenorThreshold;
	}

	public DealGovernanceConfigListDTO setTenorThreshold(
			List<DealGovernanceConfigDTO> tenorThreshold) {
		this.tenorThreshold = tenorThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getStealthThreshold() {
		return stealthThreshold;
	}

	public DealGovernanceConfigListDTO setStealthThreshold(
			List<DealGovernanceConfigDTO> stealthThreshold) {
		this.stealthThreshold = stealthThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getMarginThreshold() {
		return marginThreshold;
	}

	public DealGovernanceConfigListDTO setMarginThreshold(
			List<DealGovernanceConfigDTO> marginThreshold) {
		this.marginThreshold = marginThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getTraderNotificationThreshold() {
		return traderNotificationThreshold;
	}

	public DealGovernanceConfigListDTO setTraderNotificationThreshold(
			List<DealGovernanceConfigDTO> traderNotificationThreshold) {
		this.traderNotificationThreshold = traderNotificationThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getPremiumThreshold() {
		return premiumThreshold;
	}

	public DealGovernanceConfigListDTO setPremiumThreshold(
			List<DealGovernanceConfigDTO> premiumThreshold) {
		this.premiumThreshold = premiumThreshold;
		return this;
	}

	public List<DealGovernanceConfigDTO> getBarrierThreshold() {
		return barrierThreshold;
	}

	public DealGovernanceConfigListDTO setBarrierThreshold(
			List<DealGovernanceConfigDTO> barrierThreshold) {
		this.barrierThreshold = barrierThreshold;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public DealGovernanceConfigListDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public DealGovernanceConfigListDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
