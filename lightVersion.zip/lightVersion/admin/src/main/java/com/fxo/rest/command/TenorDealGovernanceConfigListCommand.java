package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.TenorDealGovernanceConfigListModel;

public class TenorDealGovernanceConfigListCommand implements
		Callable<ResponseEntity<TenorDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	public TenorDealGovernanceConfigListCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;
	}

	@Override
	public ResponseEntity<TenorDealGovernanceConfigListModel> call() {
		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION;

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getTenorThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<TenorDealGovernanceConfigListModel> responseEntity = new ResponseEntity<TenorDealGovernanceConfigListModel>(
				tenorDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
