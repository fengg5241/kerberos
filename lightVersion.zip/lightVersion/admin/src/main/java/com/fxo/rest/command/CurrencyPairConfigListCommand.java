package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.service.ICurrencyPairConfigService;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class CurrencyPairConfigListCommand implements
		Callable<ResponseEntity<CurrencyPairConfigListModel>> {

	private final ICurrencyPairConfigService currencyPairConfigService;
	private final CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;

	public CurrencyPairConfigListCommand(
			ICurrencyPairConfigService currencyPairConfigService,
			CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter) {

		if (currencyPairConfigService == null) {
			throw new IllegalStateException(
					"currencyPairConfigService is not set.");
		}

		if (currencyPairConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairConfigDTOModelConverter is not set.");
		}

		this.currencyPairConfigService = currencyPairConfigService;
		this.currencyPairConfigDTOModelConverter = currencyPairConfigDTOModelConverter;
	}

	@Override
	public ResponseEntity<CurrencyPairConfigListModel> call() {

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = currencyPairConfigService
				.getAllCurrencyPairs();

		List<CurrencyPairConfigModel> currencyPairConfigModels = currencyPairConfigDTOModelConverter
				.toModels(currencyPairConfigDTOs);

		CurrencyPairConfigListModel currencyPairConfigListModel = new CurrencyPairConfigListModel();
		currencyPairConfigListModel.setConfiguration(currencyPairConfigModels);

		ResponseEntity<CurrencyPairConfigListModel> responseEntity = new ResponseEntity<CurrencyPairConfigListModel>(
				currencyPairConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
