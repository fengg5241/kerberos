package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class DealGovernanceConfigDTOEntityConverter
		extends
		BaseCustomDTOEntityConverter<DealGovernanceConfigDTO, FXODealGovernanceParameters> {

}
