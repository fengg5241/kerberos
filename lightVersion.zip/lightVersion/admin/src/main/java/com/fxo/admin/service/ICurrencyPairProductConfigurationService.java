package com.fxo.admin.service;

import java.io.Serializable;
import java.util.List;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.admin.dto.CurrencyPairProductConfigResponseDTO;

/**
 * @author lakshmikanth
 *
 */
public interface ICurrencyPairProductConfigurationService extends Serializable {

	CurrencyPairProductConfigResponseDTO updateCurrencyPairProductConfigurations(
			CurrencyPairProductConfigDTO currencyPairProductConfigDTO);

	List<CurrencyPairProductConfigDTO> getAllCurrencyPairProductsConfiguration();

}
