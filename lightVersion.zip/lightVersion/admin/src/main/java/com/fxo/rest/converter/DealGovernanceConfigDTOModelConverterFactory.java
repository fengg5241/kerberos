package com.fxo.rest.converter;

import java.io.Serializable;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.BaseCustomModel;

public interface DealGovernanceConfigDTOModelConverterFactory extends Serializable {

	public BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> getDealGovernanceConfigDTOModelConverter(
			String validationCode);
}
