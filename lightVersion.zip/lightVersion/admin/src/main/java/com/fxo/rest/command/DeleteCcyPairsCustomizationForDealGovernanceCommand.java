package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class DeleteCcyPairsCustomizationForDealGovernanceCommand implements
		Callable<ResponseEntity<CurrencyPairConfigListModel>> {

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceConfigCcyPairAdminService;
	private final CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;
	private final String currency;
	private final String counterCurrency;

	public DeleteCcyPairsCustomizationForDealGovernanceCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceConfigCcyPairAdminService,
			CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter,
			String currency, String counterCurrency) {

		if (dealGovernanceConfigCcyPairAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigCcyPairAdminService is not set.");
		}

		if (currencyPairConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairConfigDTOModelConverter is not set.");
		}

		this.dealGovernanceConfigCcyPairAdminService = dealGovernanceConfigCcyPairAdminService;
		this.currencyPairConfigDTOModelConverter = currencyPairConfigDTOModelConverter;
		this.currency = currency;
		this.counterCurrency = counterCurrency;
	}

	@Override
	public ResponseEntity<CurrencyPairConfigListModel> call() {

		// delete customizations
		dealGovernanceConfigCcyPairAdminService
				.deleteCurrencyPairCustomizationForDealGovernance(currency,
						counterCurrency);

		// get All CurrencypairsCustomized from refreshed database cache
		List<CurrencyPairConfigDTO> CurrencyPairConfigDTOList = dealGovernanceConfigCcyPairAdminService
				.getAllCurrencyPairsCustomizedForDealGovernance();

		// translate DTO to Model
		List<CurrencyPairConfigModel> CurrencyPairConfigModelList = currencyPairConfigDTOModelConverter
				.toModels(CurrencyPairConfigDTOList);

		CurrencyPairConfigListModel currencyPairConfigListModel = new CurrencyPairConfigListModel();

		currencyPairConfigListModel
				.setConfiguration(CurrencyPairConfigModelList);

		ResponseEntity<CurrencyPairConfigListModel> responseEntity = new ResponseEntity<CurrencyPairConfigListModel>(
				currencyPairConfigListModel, HttpStatus.OK);

		return responseEntity;
	}
}
