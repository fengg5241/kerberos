package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.admin.service.IUserInterPortfolioMappingConfigAdminService;
import com.fxo.rest.command.UserInterPortfolioMappingConfigDeleteCommand;
import com.fxo.rest.command.UserInterPortfolioMappingUpdateCommand;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.converter.FXOUserInterPortfolioMappingConfigListDTOModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

@Controller
@RequestMapping(value = "/admin/userInterPortfolioMapping")
public class FXOUserInterPortfolioMappingConfigAdminController {

	@Autowired
	private IUserInterPortfolioMappingConfigAdminService userInterPortfolioMappingConfigService;

	@Autowired
	private FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter;

	@Autowired
	private IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;

	@Autowired
	private FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	// get All CurrencyPair-Product mappings (for all products)
	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	public Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>> updateUserInterPortfolioMappings(
			@Valid @RequestBody FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel) {
		return new UserInterPortfolioMappingUpdateCommand(
				userInterPortfolioMappingConfigService,
				fxoUserInterPortfolioMappingConfigListDTOModelConverter,
				fxoUserInterPortfolioMappingConfigListModel,
				fxoUserInterPortfolioMappingQueryService,
				fxoInterPortfolioConfigDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deletePortfolios", produces = "application/json")
	public Callable<ResponseEntity<Boolean>> deleteUserInterPortfolioMappings(
			@RequestParam(value = "userId", required = true) String userId) {

		return new UserInterPortfolioMappingConfigDeleteCommand(
				fxoUserInterPortfolioMappingQueryService, userId);
	}

}