package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.BarrierDealGovernanceConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class BarrierDealGovernanceCcyPairConfigSaveCommand implements
		Callable<ResponseEntity<BarrierDealGovernanceConfigListModel>> {

	private static final Logger logger = LoggerFactory
			.getLogger(BarrierDealGovernanceCcyPairConfigSaveCommand.class);

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION;

	public BarrierDealGovernanceCcyPairConfigSaveCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (barrierDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"barrierDealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.barrierDealGovernanceConfigListModel = barrierDealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<BarrierDealGovernanceConfigListModel> call() {

		// check if currencyPair is customized
		Boolean isCurrencyPairCustomizedForDealGovernance = dealGovernanceCcyPairConfigAdminService
				.isCurrencyPairCustomizedForDealGovernance(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		if (!isCurrencyPairCustomizedForDealGovernance) {
			logger.error(String.format(
					"CurrencyPair %s/%s not customized for DealGovernance",
					currencyPairConfigModel.getCurrency(),
					currencyPairConfigModel.getCounterCurrency()));
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED
							+ "," + currencyPairConfigModel.getCurrency() + ","
							+ currencyPairConfigModel.getCounterCurrency());
		}

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> barrierDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getBarrierThresholdDTOs(barrierDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService.saveDealGovernanceParameters(
				validationCode, currencyPairConfigModel.getCurrency(),
				currencyPairConfigModel.getCounterCurrency(),
				barrierDealGovernanceConfigDTOs);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getBarrierThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<BarrierDealGovernanceConfigListModel> responseEntity = new ResponseEntity<BarrierDealGovernanceConfigListModel>(
				barrierDealGovernanceConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
