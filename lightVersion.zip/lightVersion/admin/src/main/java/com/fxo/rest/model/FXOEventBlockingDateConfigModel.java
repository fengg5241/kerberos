package com.fxo.rest.model;

import java.util.List;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.rest.model.AuditableModel;

@AutoProperty
public class FXOEventBlockingDateConfigModel extends AuditableModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String eventDescription;

	private String active;

	private List<CurrencyPairConfigModel> currencyPair;

	private List<String> product;

	private LocalDate expiryDateThresholdMin;

	private LocalDate expiryDateThresholdMax;

	public String getEventDescription() {
		return eventDescription;
	}

	public FXOEventBlockingDateConfigModel setEventDescription(
			String eventDescription) {
		this.eventDescription = eventDescription;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXOEventBlockingDateConfigModel setActive(String active) {
		this.active = active;
		return this;
	}

	public List<CurrencyPairConfigModel> getCurrencyPair() {
		return currencyPair;
	}

	public FXOEventBlockingDateConfigModel setCurrencyPair(
			List<CurrencyPairConfigModel> currencyPair) {
		this.currencyPair = currencyPair;
		return this;
	}

	public List<String> getProduct() {
		return product;
	}

	public FXOEventBlockingDateConfigModel setProduct(List<String> product) {
		this.product = product;
		return this;
	}

	public LocalDate getExpiryDateThresholdMin() {
		return expiryDateThresholdMin;
	}

	public FXOEventBlockingDateConfigModel setExpiryDateThresholdMin(
			LocalDate expiryDateThresholdMin) {
		this.expiryDateThresholdMin = expiryDateThresholdMin;
		return this;
	}

	public LocalDate getExpiryDateThresholdMax() {
		return expiryDateThresholdMax;
	}

	public FXOEventBlockingDateConfigModel setExpiryDateThresholdMax(
			LocalDate expiryDateThresholdMax) {
		this.expiryDateThresholdMax = expiryDateThresholdMax;
		return this;
	}

	public static FXOEventBlockingDateConfigModel getInstance() {
		return new FXOEventBlockingDateConfigModel();
	}

}
