package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairProductConfigResponseDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.CurrencyPairProductConfigResponseModel;

@Component
public class CurrencyPairProductConfigResponseDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<CurrencyPairProductConfigResponseDTO, CurrencyPairProductConfigResponseModel> {

}
