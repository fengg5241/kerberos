package com.fxo.admin.dto;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CurrencyPairConfigDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String currency;
	private String counterCurrency;
	private String ratePrecision;
	private String distanceFromSpot;
	private String pipUnitValue;
	private String updatedBy;
	private DateTime updatedAt;
	private String minDistanceFromDeltaSpot;
	private String maxDistanceFromDeltaSpot;
	
	
	public String getMinDistanceFromDeltaSpot() {
		return minDistanceFromDeltaSpot;
	}

	public CurrencyPairConfigDTO setMinDistanceFromDeltaSpot(String minDistanceFromDeltaSpot) {
		this.minDistanceFromDeltaSpot = minDistanceFromDeltaSpot;
		return this;
	}

	public String getMaxDistanceFromDeltaSpot() {
		return maxDistanceFromDeltaSpot;
	}

	public CurrencyPairConfigDTO setMaxDistanceFromDeltaSpot(String maxDistanceFromDeltaSpot) {
		this.maxDistanceFromDeltaSpot = maxDistanceFromDeltaSpot;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public CurrencyPairConfigDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public CurrencyPairConfigDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public CurrencyPairConfigDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public CurrencyPairConfigDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public String getRatePrecision() {
		return ratePrecision;
	}

	public CurrencyPairConfigDTO setRatePrecision(String ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public String getDistanceFromSpot() {
		return distanceFromSpot;
	}

	public CurrencyPairConfigDTO setDistanceFromSpot(String distanceFromSpot) {
		this.distanceFromSpot = distanceFromSpot;
		return this;
	}

	public String getPipUnitValue() {
		return pipUnitValue;
	}

	public CurrencyPairConfigDTO setPipUnitValue(String pipUnitValue) {
		this.pipUnitValue = pipUnitValue;
		return this;
	}

}
