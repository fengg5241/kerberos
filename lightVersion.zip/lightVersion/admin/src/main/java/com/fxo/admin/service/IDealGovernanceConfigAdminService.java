package com.fxo.admin.service;

import java.util.List;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;

/**
 * The Interface IDealGovernanceConfigAdminService.
 *
 * @author lakshmikanth
 */
public interface IDealGovernanceConfigAdminService {

	/**
	 * Update dealGovernanceParameters.
	 *
	 * @param dealGovernanceConfigDTOs
	 *            [{@link List}]
	 * @param validationCode
	 *            [{@link String}]
	 */
	void updateDealGovernanceParameters(
			List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs,
			String validationCode);

	/**
	 * Gets the dealGovernanceParameters configuration.
	 *
	 * @param validationCode
	 *            [{@link String}]
	 * @return DealGovernanceConfigDTOs [{@link List}]
	 */
	List<DealGovernanceConfigDTO> getDealGovernanceParametersConfiguration(
			String validationCode);

	public DealGovernanceConfigListDTO getGlobalDealGovernanceConfigurationList();

	void refreshDealGovernanceCache();

}
