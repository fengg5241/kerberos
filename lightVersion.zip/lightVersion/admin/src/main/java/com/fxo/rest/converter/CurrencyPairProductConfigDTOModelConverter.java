package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.CurrencyPairProductConfigModel;

@Component
public class CurrencyPairProductConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<CurrencyPairProductConfigDTO, CurrencyPairProductConfigModel> {

}
