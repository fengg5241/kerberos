package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

public class FXOInterPortfolioConfigMappingByUserIdCommand implements
		Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>> {

	private final IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService;

	private FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	private final String userId;

	public FXOInterPortfolioConfigMappingByUserIdCommand(
			String userId,
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService,
			FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter) {

		if (fxoUserInterPortfolioMappingConfigQueryService == null) {
			throw new IllegalStateException();
		}

		if (fxoInterPortfolioConfigDTOModelConverter == null) {
			throw new IllegalStateException();
		}

		this.userId = userId;
		this.fxoUserInterPortfolioMappingConfigQueryService = fxoUserInterPortfolioMappingConfigQueryService;
		this.fxoInterPortfolioConfigDTOModelConverter = fxoInterPortfolioConfigDTOModelConverter;
	}

	@Override
	public ResponseEntity<FXOUserInterPortfolioMappingConfigListModel> call()
			throws Exception {

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOs = fxoUserInterPortfolioMappingConfigQueryService
				.getInterPortflioConfigMappingsByUserId(userId);

		List<FXOInterPortfolioConfigModel> fxoInterPortfolioConfigModels = fxoInterPortfolioConfigDTOModelConverter
				.toModels(fxoInterPortfolioConfigDTOs);

		return new ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>(
				new FXOUserInterPortfolioMappingConfigListModel()
						.setInterPortfolios(fxoInterPortfolioConfigModels)
						.setUserId(userId), HttpStatus.OK);

	}

}
