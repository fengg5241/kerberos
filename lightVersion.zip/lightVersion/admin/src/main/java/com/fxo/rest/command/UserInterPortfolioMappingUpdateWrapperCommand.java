package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.admin.service.IUserInterPortfolioMappingConfigAdminService;
import com.fxo.rest.converter.FXOUserInterPortfolioMappingConfigListWrapperDTOModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

public class UserInterPortfolioMappingUpdateWrapperCommand
		implements
		Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel>> {

	private final IUserInterPortfolioMappingConfigAdminService userInterPortfolioMappingConfigService;
	private final FXOUserInterPortfolioMappingConfigListWrapperDTOModelConverter fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter;
	private final FXOUserInterPortfolioMappingConfigListWrapperModel fxoUserInterPortfolioMappingConfigListWrapperModel;
	private final IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;

	public UserInterPortfolioMappingUpdateWrapperCommand(
			IUserInterPortfolioMappingConfigAdminService userInterPortfolioMappingConfigService,
			FXOUserInterPortfolioMappingConfigListWrapperDTOModelConverter fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter,
			FXOUserInterPortfolioMappingConfigListWrapperModel fxoUserInterPortfolioMappingConfigListWrapperModel,
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService) {

		if (userInterPortfolioMappingConfigService == null) {
			throw new IllegalStateException(
					"userInterPortfolioMappingConfigService is not set.");
		}

		if (fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter is not set.");
		}

		if (fxoUserInterPortfolioMappingConfigListWrapperModel == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigListWrapperModel is not set.");
		}

		if (fxoUserInterPortfolioMappingQueryService == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingQueryService is not set.");
		}

		this.userInterPortfolioMappingConfigService = userInterPortfolioMappingConfigService;
		this.fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter = fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter;
		this.fxoUserInterPortfolioMappingConfigListWrapperModel = fxoUserInterPortfolioMappingConfigListWrapperModel;
		this.fxoUserInterPortfolioMappingQueryService = fxoUserInterPortfolioMappingQueryService;
	}

	@Override
	public ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel> call() {

		FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO = fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter
				.fromModel(fxoUserInterPortfolioMappingConfigListWrapperModel);

		userInterPortfolioMappingConfigService
				.updateUserInterPortfolioMappings(fxoUserInterPortfolioMappingConfigListWrapperDTO);

		userInterPortfolioMappingConfigService.refreshUserInterPortfolioCache();

		List<FXOUserInterPortfolioMappingConfigListDTO> fxoUserInterPortfolioMappingConfigListDTOList = fxoUserInterPortfolioMappingQueryService
				.getAllFXOUserInterPortfolioConfigMappings();

		FXOUserInterPortfolioMappingConfigListWrapperModel fxoUserInterPortfolioMappingConfigListWrapperModel = (fxoUserInterPortfolioMappingConfigListDTOList != null) ? fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter
				.toModel(new FXOUserInterPortfolioMappingConfigListWrapperDTO()
						.setInterPortfolioMappingConfiguration(fxoUserInterPortfolioMappingConfigListDTOList))
				: null;

		return new ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel>(
				fxoUserInterPortfolioMappingConfigListWrapperModel,
				HttpStatus.OK);
	}
}
