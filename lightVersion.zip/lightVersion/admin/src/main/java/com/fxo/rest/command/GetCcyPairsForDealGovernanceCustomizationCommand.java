package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairConfigModel;

public class GetCcyPairsForDealGovernanceCustomizationCommand implements
		Callable<ResponseEntity<CurrencyPairConfigListModel>> {

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;

	public GetCcyPairsForDealGovernanceCustomizationCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (currencyPairConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyPairConfigDTOModelConverter is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.currencyPairConfigDTOModelConverter = currencyPairConfigDTOModelConverter;
	}

	@Override
	public ResponseEntity<CurrencyPairConfigListModel> call() {

		CurrencyPairConfigListModel currencyPairConfigListModel = new CurrencyPairConfigListModel();

		List<CurrencyPairConfigDTO> CurrencyPairConfigDTOList = dealGovernanceCcyPairConfigAdminService
				.getAllCurrencyPairsForCustomizationForDealGovernance();

		List<CurrencyPairConfigModel> CurrencyPairConfigModelList = currencyPairConfigDTOModelConverter
				.toModels(CurrencyPairConfigDTOList);

		currencyPairConfigListModel
				.setConfiguration(CurrencyPairConfigModelList);

		ResponseEntity<CurrencyPairConfigListModel> responseEntity = new ResponseEntity<CurrencyPairConfigListModel>(
				currencyPairConfigListModel, HttpStatus.OK);

		return responseEntity;
	}
}
