package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class InvestmentAmountDealGovernanceConfigListModel extends
		BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<InvestmentAmountDealGovernanceConfigModel> configuration;

	public List<InvestmentAmountDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public InvestmentAmountDealGovernanceConfigListModel setConfiguration(
			List<InvestmentAmountDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
