package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.admin.dto.FXOEventBlockingDateConfigListDTO;
import com.fxo.admin.dto.converter.FXOEventBlockingDateSourceTargetDTOConverter;
import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.api.dto.FXOEventBlockingDateDTO;
import com.fxo.api.service.ICurrencyPairGroupService;
import com.fxo.api.service.IFXOEventBlockingDateService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.validation.ValidationService;

@Service
public class FXOEventBlockingDateConfigServiceImpl implements
		IFXOEventBlockingDateConfigService {

	@Autowired
	IFXOEventBlockingDateService fxoEventBlockingDateService;

	@Autowired
	FXOEventBlockingDateSourceTargetDTOConverter fxoEventBlockingDateSourceTargetDTOConverter;

	@Autowired
	ICurrencyPairGroupService currencyPairService;

	@Autowired
	private ValidationService validationService;

	@Override
	public List<FXOEventBlockingDateConfigDTO> getEventBlockingDates() {

		List<FXOEventBlockingDateDTO> blockingDateDTOs = fxoEventBlockingDateService
				.getEventBlockingDates();
		List<FXOEventBlockingDateConfigDTO> blockingDateConfigDTOs = (blockingDateDTOs != null) ? fxoEventBlockingDateSourceTargetDTOConverter
				.toTargetDTOs(blockingDateDTOs) : null;
		return blockingDateConfigDTOs;
	}

	@Override
	public void saveEventBlockingDate(
			FXOEventBlockingDateConfigListDTO eventBlockingDateConfigDTO) {

		Objects.requireNonNull(eventBlockingDateConfigDTO);

		validationService.validate(eventBlockingDateConfigDTO);

		fxoEventBlockingDateService
				.saveEventBlockingDate(constructFXOEventBlockingDateDTO(eventBlockingDateConfigDTO
						.getFxoEventBlockingDateConfigDTO()));
	}

	@Override
	public void deleteEventBlockingDateById(String eventId) {

		if (FXOStringUtility.isEmpty(eventId)) {
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_EVENT_BLOCK_EVENT_ID);
		}
		fxoEventBlockingDateService.deleteEventBlockingDateById(eventId);
	}

	private FXOEventBlockingDateDTO constructFXOEventBlockingDateDTO(
			FXOEventBlockingDateConfigDTO eventBlockingDateConfigDTO) {

		FXOEventBlockingDateDTO fxoEventBlockingDateDTO = FXOEventBlockingDateDTO
				.getInstance();

		List<CurrencyPairDTO> currencyPairDTOs = null;

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = eventBlockingDateConfigDTO
				.getCurrencyPair();

		if (CollectionUtils.isNotEmpty(currencyPairConfigDTOs)) {
			currencyPairDTOs = new ArrayList<CurrencyPairDTO>();
			for (CurrencyPairConfigDTO currencyPairConfigDTO : currencyPairConfigDTOs) {

				CurrencyPairDTO currencyPairDTO = currencyPairService
						.getOneCurrencyPair(
								currencyPairConfigDTO.getCurrency(),
								currencyPairConfigDTO.getCounterCurrency());

				currencyPairDTOs.add(currencyPairDTO);

			}
		}

		List<String> products = new ArrayList<String>();
		for (String product : eventBlockingDateConfigDTO.getProduct()) {
			products.add(product);
		}

		fxoEventBlockingDateDTO
				.setCurrencyPair(currencyPairDTOs)
				.setEventDescription(
						eventBlockingDateConfigDTO.getEventDescription())
				.setExpiryDateThresholdMax(
						eventBlockingDateConfigDTO.getExpiryDateThresholdMax())
				.setExpiryDateThresholdMin(
						eventBlockingDateConfigDTO.getExpiryDateThresholdMin())
				.setProduct(products)
				.setCreatedBy(eventBlockingDateConfigDTO.getCreatedBy())
				.setCreatedDate(eventBlockingDateConfigDTO.getCreatedDate())
				.setLastUpdatedBy(eventBlockingDateConfigDTO.getLastUpdatedBy())
				.setLastUpdatedDate(
						eventBlockingDateConfigDTO.getLastUpdatedDate());

		return fxoEventBlockingDateDTO;
	}

}
