package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.TenorDealGovernanceConfigModel;

@Component(value ="tenorDealGovernanceConfigDTOModelConverter")
public class TenorDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, TenorDealGovernanceConfigModel> {

}
