package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigModel;

@Component(value = "marginAmountDealGovernanceConfigDTOModelConverter")
public class MarginAmountDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, MarginAmountDealGovernanceConfigModel> {

}
