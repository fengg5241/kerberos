package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigListModel;

public class InvestmentAmountDealGovernanceConfigSaveCommand implements
		Callable<ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>> {

	private final IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;
	private final InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

	public InvestmentAmountDealGovernanceConfigSaveCommand(
			IDealGovernanceConfigAdminService dealGovernanceConfigAdminService,
			InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigAdminService is not set.");
		}

		if (investmentAmountDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"investmentAmountDealGovernanceConfigListModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceConfigAdminService = dealGovernanceConfigAdminService;
		this.investmentAmountDealGovernanceConfigListModel = investmentAmountDealGovernanceConfigListModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<InvestmentAmountDealGovernanceConfigListModel> call() {

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> investmentAmountDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getInvestmentAmountThresholdDTOs(investmentAmountDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceConfigAdminService.updateDealGovernanceParameters(
				investmentAmountDealGovernanceConfigDTOs, validationCode);

		dealGovernanceConfigAdminService.refreshDealGovernanceCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceConfigAdminService
				.getDealGovernanceParametersConfiguration(validationCode);

		// translate refreshed DTO Objects to Model Objects
		InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getNotionalThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<InvestmentAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<InvestmentAmountDealGovernanceConfigListModel>(
				investmentAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
