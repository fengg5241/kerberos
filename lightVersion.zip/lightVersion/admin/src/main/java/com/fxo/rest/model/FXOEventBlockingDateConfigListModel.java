package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class FXOEventBlockingDateConfigListModel extends BaseCustomModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<FXOEventBlockingDateConfigModel> fxoEventBlockingDateConfigModels;

	public List<FXOEventBlockingDateConfigModel> getFxoEventBlockingDateConfigModels() {
		return fxoEventBlockingDateConfigModels;
	}

	public FXOEventBlockingDateConfigListModel setFxoEventBlockingDateConfigModels(
			List<FXOEventBlockingDateConfigModel> fxoEventBlockingDateConfigModels) {
		this.fxoEventBlockingDateConfigModels = fxoEventBlockingDateConfigModels;
		return this;
	}

	public static FXOEventBlockingDateConfigListModel getInstance() {
		return new FXOEventBlockingDateConfigListModel();
	}

}
