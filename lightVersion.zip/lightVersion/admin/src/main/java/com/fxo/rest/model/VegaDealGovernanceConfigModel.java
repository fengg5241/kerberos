package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class VegaDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private String minimum;
	private String maximum;

	public String getMaximum() {
		return maximum;
	}

	public VegaDealGovernanceConfigModel setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public VegaDealGovernanceConfigModel setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

}
