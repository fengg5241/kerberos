package com.fxo.admin.service;

import java.io.Serializable;
import java.util.List;

import com.fxo.admin.dto.CurrencyPairConfigDTO;

/**
 * @author lakshmikanth
 *
 */
public interface ICurrencyPairConfigService extends Serializable {

	public List<CurrencyPairConfigDTO> getAllCurrencyPairs();

	public List<CurrencyPairConfigDTO> updateCurrencyPairs(
			List<CurrencyPairConfigDTO> currencyPairConfigDTOs);

	void refreshCurrencyPairCache();

}
