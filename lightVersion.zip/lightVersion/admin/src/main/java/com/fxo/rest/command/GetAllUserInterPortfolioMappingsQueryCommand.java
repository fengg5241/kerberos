/**
 * 
 */
package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.rest.converter.FXOUserInterPortfolioMappingConfigListDTOModelConverter;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

/**
 * @author lakshmikanth
 *
 */
public class GetAllUserInterPortfolioMappingsQueryCommand
		implements
		Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel>> {

	private final IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;

	private final FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter;

	public GetAllUserInterPortfolioMappingsQueryCommand(
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService,
			FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter) {

		if (fxoUserInterPortfolioMappingQueryService == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingQueryService is not set.");
		}

		if (fxoUserInterPortfolioMappingConfigListDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigListDTOModelConverter is not set.");
		}

		this.fxoUserInterPortfolioMappingQueryService = fxoUserInterPortfolioMappingQueryService;
		this.fxoUserInterPortfolioMappingConfigListDTOModelConverter = fxoUserInterPortfolioMappingConfigListDTOModelConverter;
	}

	@Override
	public ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel> call() {

		List<FXOUserInterPortfolioMappingConfigListDTO> fxoUserInterPortfolioMappingConfigListDTOs = fxoUserInterPortfolioMappingQueryService
				.getAllFXOUserInterPortfolioConfigMappings();

		List<FXOUserInterPortfolioMappingConfigListModel> fxoUserInterPortfolioMappingConfigListModels = (fxoUserInterPortfolioMappingConfigListDTOs != null) ? fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.toModels(fxoUserInterPortfolioMappingConfigListDTOs) : null;

		return new ResponseEntity<FXOUserInterPortfolioMappingConfigListWrapperModel>(
				new FXOUserInterPortfolioMappingConfigListWrapperModel()
						.setInterPortfolioMappingConfiguration(fxoUserInterPortfolioMappingConfigListModels),
				HttpStatus.OK);
	}

}
