package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class CurrencyPairConfigDTOEntityConverter extends
		BaseCustomDTOEntityConverter<CurrencyPairConfigDTO, CurrencyPair> {

}
