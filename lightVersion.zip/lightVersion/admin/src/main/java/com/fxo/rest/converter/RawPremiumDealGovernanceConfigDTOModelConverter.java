package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigModel;

@Component(value = "rawPremiumDealGovernanceConfigDTOModelConverter")
public class RawPremiumDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, RawPremiumDealGovernanceConfigModel> {

}
