package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.admin.service.IFXOEventBlockingDateConfigService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.FXOEventBlockingDateConfigDTOModelConverter;
import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

public class FXOEventBlockingDateDeleteCommand implements
		Callable<ResponseEntity<FXOEventBlockingDateConfigListModel>> {
	
	@Autowired
	private IFXOEventBlockingDateConfigService fxoEventBlockingDateConfigService;

	@Autowired
	private FXOEventBlockingDateConfigDTOModelConverter fxoEventBlockingDateConfigDTOModelConverter;
	
	private String eventId;

	public FXOEventBlockingDateDeleteCommand(
			IFXOEventBlockingDateConfigService fxoEventBlockingDateConfigService,
			FXOEventBlockingDateConfigDTOModelConverter fxoEventBlockingDateConfigDTOModelConverter,
			String eventId) {

		if (fxoEventBlockingDateConfigService == null) {
			throw new IllegalStateException("Service is not set.");
		}

		if (fxoEventBlockingDateConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoEventBlockingDateConfigDTOModelConverter is not set.");
		}

		if (eventId == null) {
			throw new ApplicationRuntimeException("eventId is required",
					FXOMessageCodes.ERR_EVENT_BLOCK_EVENT_ID);
		}

		this.fxoEventBlockingDateConfigDTOModelConverter = fxoEventBlockingDateConfigDTOModelConverter;
		this.fxoEventBlockingDateConfigService = fxoEventBlockingDateConfigService;
		this.eventId = eventId;

	}

	@Override
	public ResponseEntity<FXOEventBlockingDateConfigListModel> call()
			throws Exception {

		fxoEventBlockingDateConfigService
				.deleteEventBlockingDateById(eventId);
		
		List<FXOEventBlockingDateConfigDTO> blockingDateConfigDTOs = fxoEventBlockingDateConfigService
				.getEventBlockingDates();
		
		List<FXOEventBlockingDateConfigModel> blockingDateConfigModels = (blockingDateConfigDTOs != null) ? fxoEventBlockingDateConfigDTOModelConverter
				.toModels(blockingDateConfigDTOs) : null;

		FXOEventBlockingDateConfigListModel blockingDateConfigListModel = FXOEventBlockingDateConfigListModel
				.getInstance().setFxoEventBlockingDateConfigModels(
						blockingDateConfigModels);

		ResponseEntity<FXOEventBlockingDateConfigListModel> responseEntity = new ResponseEntity<FXOEventBlockingDateConfigListModel>(
				blockingDateConfigListModel, HttpStatus.OK);
		
		return responseEntity;
	}

}
