package com.fxo.rest.model;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class FXOInterPortfolioConfigModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String interPortfolio;

	private String updatedBy;

	private DateTime updatedAt;

	private Boolean active;

	public String getInterPortfolio() {
		return interPortfolio;
	}

	public FXOInterPortfolioConfigModel setInterPortfolio(String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public FXOInterPortfolioConfigModel setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXOInterPortfolioConfigModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public FXOInterPortfolioConfigModel setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
