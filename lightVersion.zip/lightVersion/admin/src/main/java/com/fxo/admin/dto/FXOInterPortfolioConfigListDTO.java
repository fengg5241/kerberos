package com.fxo.admin.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOInterPortfolioConfigListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<FXOInterPortfolioConfigDTO> interPortfolios;

	public List<FXOInterPortfolioConfigDTO> getInterPortfolios() {
		return interPortfolios;
	}

	public FXOInterPortfolioConfigListDTO setInterPortfolios(
			List<FXOInterPortfolioConfigDTO> interPortfolios) {
		this.interPortfolios = interPortfolios;
		return this;
	}

}
