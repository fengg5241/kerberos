package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.CurrencyPairConfigModel;

@Component
public class CurrencyPairConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<CurrencyPairConfigDTO, CurrencyPairConfigModel> {

}
