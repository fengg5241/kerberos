package com.fxo.rest.command;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.admin.service.IUserInterPortfolioMappingConfigAdminService;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.converter.FXOUserInterPortfolioMappingConfigListDTOModelConverter;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

public class UserInterPortfolioMappingUpdateCommand implements
		Callable<ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>> {

	private final IUserInterPortfolioMappingConfigAdminService userInterPortfolioMappingConfigService;
	private final FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter;
	private final FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel;
	private final IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;
	private final FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	public UserInterPortfolioMappingUpdateCommand(
			IUserInterPortfolioMappingConfigAdminService userInterPortfolioMappingConfigService,
			FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter,
			FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel,
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService,
			FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter) {

		if (userInterPortfolioMappingConfigService == null) {
			throw new IllegalStateException(
					"userInterPortfolioMappingConfigService is not set.");
		}

		if (fxoUserInterPortfolioMappingConfigListDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter is not set.");
		}

		if (fxoUserInterPortfolioMappingConfigListModel == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigListModel is not set.");
		}

		if (fxoUserInterPortfolioMappingQueryService == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingQueryService is not set.");
		}

		if (fxoInterPortfolioConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoInterPortfolioConfigDTOModelConverter is not set.");
		}

		this.userInterPortfolioMappingConfigService = userInterPortfolioMappingConfigService;
		this.fxoUserInterPortfolioMappingConfigListDTOModelConverter = fxoUserInterPortfolioMappingConfigListDTOModelConverter;
		this.fxoUserInterPortfolioMappingConfigListModel = fxoUserInterPortfolioMappingConfigListModel;
		this.fxoUserInterPortfolioMappingQueryService = fxoUserInterPortfolioMappingQueryService;
		this.fxoInterPortfolioConfigDTOModelConverter = fxoInterPortfolioConfigDTOModelConverter;

	}

	@Override
	public ResponseEntity<FXOUserInterPortfolioMappingConfigListModel> call()
			throws Exception {

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.fromModel(fxoUserInterPortfolioMappingConfigListModel);

		userInterPortfolioMappingConfigService
				.updateUserInterPortfolioMappings(new FXOUserInterPortfolioMappingConfigListWrapperDTO().setInterPortfolioMappingConfiguration(Arrays
						.asList(fxoUserInterPortfolioMappingConfigListDTO)));

		userInterPortfolioMappingConfigService.refreshUserInterPortfolioCache();

		List<FXOInterPortfolioConfigDTO> fxoUserInterPortfolioMappingConfigDTOList = fxoUserInterPortfolioMappingQueryService
				.getInterPortflioConfigMappingsByUserId(fxoUserInterPortfolioMappingConfigListDTO
						.getUserId());

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel = new FXOUserInterPortfolioMappingConfigListModel();

		if (CollectionUtils
				.isNotEmpty(fxoUserInterPortfolioMappingConfigDTOList)) {

			List<FXOInterPortfolioConfigModel> fxoInterPortfolioConfigModels = fxoInterPortfolioConfigDTOModelConverter
					.toModels(fxoUserInterPortfolioMappingConfigDTOList);

			fxoUserInterPortfolioMappingConfigListModel.setUserId(
					fxoUserInterPortfolioMappingConfigListDTO.getUserId())
					.setInterPortfolios(fxoInterPortfolioConfigModels);
		}

		return new ResponseEntity<FXOUserInterPortfolioMappingConfigListModel>(
				fxoUserInterPortfolioMappingConfigListModel, HttpStatus.OK);
	}

}
