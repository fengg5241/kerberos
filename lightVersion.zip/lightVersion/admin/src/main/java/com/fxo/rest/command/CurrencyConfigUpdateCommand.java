package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.admin.service.ICurrencyConfigService;
import com.fxo.rest.converter.CurrencyConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyConfigListModel;
import com.fxo.rest.model.CurrencyConfigModel;

public class CurrencyConfigUpdateCommand implements
		Callable<ResponseEntity<CurrencyConfigListModel>> {

	private final ICurrencyConfigService currencyConfigService;
	private final CurrencyConfigDTOModelConverter currencyConfigDTOModelConverter;
	private final CurrencyConfigListModel currencyConfigListModel;

	public CurrencyConfigUpdateCommand(
			ICurrencyConfigService currencyConfigService,
			CurrencyConfigDTOModelConverter currencyConfigDTOModelConverter,
			CurrencyConfigListModel currencyConfigListModel) {

		if (currencyConfigService == null) {
			throw new IllegalStateException("currencyConfigService is not set.");
		}

		if (currencyConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"fxoCurrencyConfigDTOModelConverter is not set.");
		}

		if (currencyConfigListModel == null) {
			throw new IllegalStateException(
					"fxoCurrencyConfigListModel is not set.");
		}

		this.currencyConfigService = currencyConfigService;
		this.currencyConfigDTOModelConverter = currencyConfigDTOModelConverter;
		this.currencyConfigListModel = currencyConfigListModel;

	}

	@Override
	public ResponseEntity<CurrencyConfigListModel> call() {

		List<CurrencyConfigDTO> currencyConfigDTOs = currencyConfigDTOModelConverter
				.fromModels(currencyConfigListModel.getConfiguration());

		currencyConfigService.updateCurrencies(currencyConfigDTOs);

		currencyConfigService.refreshCurrencyCache();

		List<CurrencyConfigModel> currencyConfigModels_Response = currencyConfigDTOModelConverter
				.toModels(currencyConfigService.getAllCurrencies());

		CurrencyConfigListModel fxoCurrencyConfigListModel_Response = new CurrencyConfigListModel();
		fxoCurrencyConfigListModel_Response
				.setConfiguration(currencyConfigModels_Response);

		ResponseEntity<CurrencyConfigListModel> responseEntity = new ResponseEntity<CurrencyConfigListModel>(
				fxoCurrencyConfigListModel_Response, HttpStatus.OK);

		return responseEntity;
	}
}
