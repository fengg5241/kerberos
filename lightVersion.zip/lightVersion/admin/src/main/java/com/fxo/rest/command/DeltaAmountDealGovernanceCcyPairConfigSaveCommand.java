package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.service.IDealGovernanceCcyPairConfigAdminService;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.model.CurrencyPairConfigModel;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;

public class DeltaAmountDealGovernanceCcyPairConfigSaveCommand implements
		Callable<ResponseEntity<DeltaAmountDealGovernanceConfigListModel>> {

	private static final Logger logger = LoggerFactory
			.getLogger(DeltaAmountDealGovernanceCcyPairConfigSaveCommand.class);

	private final IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService;
	private final DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel;
	private final CurrencyPairConfigModel currencyPairConfigModel;
	private final DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	private final String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;

	public DeltaAmountDealGovernanceCcyPairConfigSaveCommand(
			IDealGovernanceCcyPairConfigAdminService dealGovernanceCcyPairConfigAdminService,
			DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel,
			CurrencyPairConfigModel currencyPairConfigModel,
			DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter) {

		if (dealGovernanceCcyPairConfigAdminService == null) {
			throw new IllegalStateException(
					"dealGovernanceCcyPairConfigAdminService is not set.");
		}

		if (deltaAmountDealGovernanceConfigListModel == null) {
			throw new IllegalStateException(
					"deltaAmountDealGovernanceConfigListModel is not set.");
		}

		if (currencyPairConfigModel == null) {
			throw new IllegalStateException(
					"currencyPairConfigModel is not set.");
		}

		if (dealGovernanceConfigListModelConveter == null) {
			throw new IllegalStateException(
					"dealGovernanceConfigListModelConveter is not set.");
		}

		this.dealGovernanceCcyPairConfigAdminService = dealGovernanceCcyPairConfigAdminService;
		this.deltaAmountDealGovernanceConfigListModel = deltaAmountDealGovernanceConfigListModel;
		this.currencyPairConfigModel = currencyPairConfigModel;
		this.dealGovernanceConfigListModelConveter = dealGovernanceConfigListModelConveter;

	}

	@Override
	public ResponseEntity<DeltaAmountDealGovernanceConfigListModel> call() {

		// check if currencyPair is customized
		Boolean isCurrencyPairCustomizedForDealGovernance = dealGovernanceCcyPairConfigAdminService
				.isCurrencyPairCustomizedForDealGovernance(
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		if (!isCurrencyPairCustomizedForDealGovernance) {
			logger.error(String.format(
					"CurrencyPair %s/%s not customized for DealGovernance",
					currencyPairConfigModel.getCurrency(),
					currencyPairConfigModel.getCounterCurrency()));
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_DEALGOVERNANCE_CCYPAIR_NOT_CUSTOMIZED
							+ "," + currencyPairConfigModel.getCurrency() + ","
							+ currencyPairConfigModel.getCounterCurrency());
		}

		// translate Threshold-Model-Objects to DTOs
		List<DealGovernanceConfigDTO> deltaAmountDealGovernanceConfigDTOs = dealGovernanceConfigListModelConveter
				.getDeltaAmountThresholdDTOs(deltaAmountDealGovernanceConfigListModel);

		// update Thresholds
		dealGovernanceCcyPairConfigAdminService.saveDealGovernanceParameters(
				validationCode, currencyPairConfigModel.getCurrency(),
				currencyPairConfigModel.getCounterCurrency(),
				deltaAmountDealGovernanceConfigDTOs);

		dealGovernanceCcyPairConfigAdminService
				.refreshDealGovernanceCcyPairCache();

		// get Refreshed Data (from database/cache)
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Response = dealGovernanceCcyPairConfigAdminService
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currencyPairConfigModel.getCurrency(),
						currencyPairConfigModel.getCounterCurrency());

		// translate refreshed DTO Objects to Model Objects
		DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel_Response = dealGovernanceConfigListModelConveter
				.getDeltaAmountThresholdListModel(dealGovernanceConfigDTOs_Response);

		ResponseEntity<DeltaAmountDealGovernanceConfigListModel> responseEntity = new ResponseEntity<DeltaAmountDealGovernanceConfigListModel>(
				deltaAmountDealGovernanceConfigListModel_Response,
				HttpStatus.OK);

		return responseEntity;
	}
}
