package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fxo.admin.service.IFXOEventBlockingDateConfigService;
import com.fxo.rest.command.FXOEventBlockingDateDeleteCommand;
import com.fxo.rest.command.FXOEventBlockingDateGetCommand;
import com.fxo.rest.command.FXOEventBlockingDateSaveCommand;
import com.fxo.rest.converter.FXOEventBlockingDateConfigDTOModelConverter;
import com.fxo.rest.model.FXOEventBlockingDateConfigListModel;
import com.fxo.rest.model.FXOEventBlockingDateConfigModel;

@Controller
@RequestMapping(value = "/admin/eventBlock")
public class FXOEventBlockingDateController {

	@Autowired
	IFXOEventBlockingDateConfigService fxoEventBlockingDateConfigService;

	@Autowired
	FXOEventBlockingDateConfigDTOModelConverter fxoEventBlockingDateConfigDTOModelConverter;

	@RequestMapping(method = RequestMethod.GET, value = "/getEventList", produces = "application/json")
	public Callable<ResponseEntity<FXOEventBlockingDateConfigListModel>> getEventBlockingDates() {
		return new FXOEventBlockingDateGetCommand(
				fxoEventBlockingDateConfigService,
				fxoEventBlockingDateConfigDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveEvent", produces = "application/json")
	public Callable<ResponseEntity<Boolean>> saveEventBlockingDates(
			@RequestBody FXOEventBlockingDateConfigModel fxoEventBlockingDateConfigModel) {
		return new FXOEventBlockingDateSaveCommand(
				fxoEventBlockingDateConfigService,
				fxoEventBlockingDateConfigDTOModelConverter,
				fxoEventBlockingDateConfigModel);
	}

	@RequestMapping(method = RequestMethod.POST, value = "/deleteEvent", produces = "application/json")
	public Callable<ResponseEntity<FXOEventBlockingDateConfigListModel>> deleteEventBlockingDates(
			@RequestParam(value = "eventId", required = true) String eventId) {
		return new FXOEventBlockingDateDeleteCommand(
				fxoEventBlockingDateConfigService,
				fxoEventBlockingDateConfigDTOModelConverter, eventId);
	}

}
