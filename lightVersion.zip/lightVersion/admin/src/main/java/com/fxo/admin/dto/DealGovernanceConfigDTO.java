package com.fxo.admin.dto;

import java.util.List;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.api.dto.CodeValueDTO;
import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class DealGovernanceConfigDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<CodeValueDTO> hierarchy;

	private String product;
	private String minimum;
	private String maximum;
	private String alert;
	private String minimumPercent;
	private String maximumPercent;
	private String direction;
	private String thresholdCurrency;
	private String validateInTicketingService;
	private Boolean active;
	private String updatedBy;
	private DateTime updatedAt;

	private String validationCode;
	
	public List<CodeValueDTO> getHierarchy() {
		return hierarchy;
	}

	public DealGovernanceConfigDTO setHierarchy(List<CodeValueDTO> hierarchy) {
		this.hierarchy = hierarchy;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public DealGovernanceConfigDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public DealGovernanceConfigDTO setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public DealGovernanceConfigDTO setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public String getMinimumPercent() {
		return minimumPercent;
	}

	public DealGovernanceConfigDTO setMinimumPercent(String minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMaximumPercent() {
		return maximumPercent;
	}

	public DealGovernanceConfigDTO setMaximumPercent(String maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public DealGovernanceConfigDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public DealGovernanceConfigDTO setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public DealGovernanceConfigDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public DealGovernanceConfigDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public DealGovernanceConfigDTO setValidationCode(String validationCode) {
		this.validationCode = validationCode;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public DealGovernanceConfigDTO setThresholdCurrency(String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}
	
	public String getAlert() {
		return alert;
	}

	public DealGovernanceConfigDTO setAlert(String alert) {
		this.alert = alert;
		return this;
	}
	
	public String getValidateInTicketingService() {
		return validateInTicketingService;
	}

	public DealGovernanceConfigDTO setValidateInTicketingService(String validateInTicketingService) {
		this.validateInTicketingService = validateInTicketingService;
		return this;

	}

}
