package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class FXOInterPortfolioConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<FXOInterPortfolioConfigModel> interPortfolios;

	public List<FXOInterPortfolioConfigModel> getInterPortfolios() {
		return interPortfolios;
	}

	public FXOInterPortfolioConfigListModel setInterPortfolios(
			List<FXOInterPortfolioConfigModel> interPortfolios) {
		this.interPortfolios = interPortfolios;
		return this;
	}

}
