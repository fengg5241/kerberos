package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.dao.entity.FXODealGovernanceParametersCcyPair;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class DealGovernanceConfigCcyPairDTOEntityConverter
		extends
		BaseCustomDTOEntityConverter<DealGovernanceConfigDTO, FXODealGovernanceParametersCcyPair> {

}
