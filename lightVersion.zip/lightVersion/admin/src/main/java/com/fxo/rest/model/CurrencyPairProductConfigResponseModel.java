package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairProductConfigResponseModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String product;
	private String currency;
	private String counterCurrency;
	private String status;
	private Integer currencyPairCount;

	public String getProduct() {
		return product;
	}

	public CurrencyPairProductConfigResponseModel setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public CurrencyPairProductConfigResponseModel setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public CurrencyPairProductConfigResponseModel setCounterCurrency(
			String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairProductConfigResponseModel setStatus(String status) {
		this.status = status;
		return this;
	}

	public Integer getCurrencyPairCount() {
		return currencyPairCount;
	}

	public CurrencyPairProductConfigResponseModel setCurrencyPairCount(
			Integer currencyPairCount) {
		this.currencyPairCount = currencyPairCount;
		return this;
	}

}
