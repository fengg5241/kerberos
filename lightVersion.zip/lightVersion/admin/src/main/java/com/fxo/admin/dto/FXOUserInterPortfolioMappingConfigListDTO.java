package com.fxo.admin.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOUserInterPortfolioMappingConfigListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String userId;

	private List<FXOInterPortfolioConfigDTO> interPortfolios;

	public String getUserId() {
		return userId;

	}

	public FXOUserInterPortfolioMappingConfigListDTO setUserId(String userId) {
		this.userId = userId;
		return this;
	}

	public List<FXOInterPortfolioConfigDTO> getInterPortfolios() {
		return interPortfolios;
	}

	public FXOUserInterPortfolioMappingConfigListDTO setInterPortfolios(
			List<FXOInterPortfolioConfigDTO> interPortfolios) {
		this.interPortfolios = interPortfolios;
		return this;
	}

}
