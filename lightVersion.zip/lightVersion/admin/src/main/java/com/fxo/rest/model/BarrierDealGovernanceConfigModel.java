package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class BarrierDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

}
