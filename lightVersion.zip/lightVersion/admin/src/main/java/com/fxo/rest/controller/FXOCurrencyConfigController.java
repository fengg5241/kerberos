package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fxo.admin.service.ICurrencyConfigService;
import com.fxo.rest.command.CurrencyConfigListCommand;
import com.fxo.rest.command.CurrencyConfigUpdateCommand;
import com.fxo.rest.converter.CurrencyConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyConfigListModel;

@Controller
@RequestMapping(value = "/admin/currency")
public class FXOCurrencyConfigController {

	@Autowired
	private ICurrencyConfigService currencyConfigService;

	@Autowired
	private CurrencyConfigDTOModelConverter currencyConfigDTOModelConverter;

	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	public Callable<ResponseEntity<CurrencyConfigListModel>> getFXOCurrencyConfiguration() {
		return new CurrencyConfigListCommand(currencyConfigService,
				currencyConfigDTOModelConverter);
	}

	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	public Callable<ResponseEntity<CurrencyConfigListModel>> save(
			@RequestBody CurrencyConfigListModel fxoCurrencyConfigListModel) {
		return new CurrencyConfigUpdateCommand(currencyConfigService,
				currencyConfigDTOModelConverter, fxoCurrencyConfigListModel);
	}

}