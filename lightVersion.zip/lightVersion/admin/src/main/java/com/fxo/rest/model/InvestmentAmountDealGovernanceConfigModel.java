package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class InvestmentAmountDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private String minimum;
	private String maximum;
	private String alert;


	public String getMinimum() {
		return minimum;
	}

	public InvestmentAmountDealGovernanceConfigModel setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public InvestmentAmountDealGovernanceConfigModel setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}
	
	public String getAlert() {
		return alert;
	}

	public InvestmentAmountDealGovernanceConfigModel setAlert(String alert) {
		this.alert = alert;
		return this;
	}

}
