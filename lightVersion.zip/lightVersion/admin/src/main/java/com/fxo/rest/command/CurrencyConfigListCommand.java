package com.fxo.rest.command;

import java.util.List;
import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.admin.service.ICurrencyConfigService;
import com.fxo.rest.converter.CurrencyConfigDTOModelConverter;
import com.fxo.rest.model.CurrencyConfigListModel;
import com.fxo.rest.model.CurrencyConfigModel;

public class CurrencyConfigListCommand implements
		Callable<ResponseEntity<CurrencyConfigListModel>> {

	private final ICurrencyConfigService currencyConfigService;
	private final CurrencyConfigDTOModelConverter currencyConfigDTOModelConverter;

	public CurrencyConfigListCommand(
			ICurrencyConfigService currencyConfigService,
			CurrencyConfigDTOModelConverter currencyConfigDTOModelConverter) {

		if (currencyConfigService == null) {
			throw new IllegalStateException("fxoCurrencyService is not set.");
		}

		if (currencyConfigDTOModelConverter == null) {
			throw new IllegalStateException(
					"currencyConfigDTOModelConverter is not set.");
		}

		this.currencyConfigService = currencyConfigService;
		this.currencyConfigDTOModelConverter = currencyConfigDTOModelConverter;
	}

	@Override
	public ResponseEntity<CurrencyConfigListModel> call() {

		List<CurrencyConfigDTO> currencyConfigDTOs = currencyConfigService
				.getAllCurrencies();

		List<CurrencyConfigModel> fxoCurrencyConfigModels = currencyConfigDTOModelConverter
				.toModels(currencyConfigDTOs);

		CurrencyConfigListModel fxoCurrencyConfigListModel = new CurrencyConfigListModel();
		fxoCurrencyConfigListModel.setConfiguration(fxoCurrencyConfigModels);

		ResponseEntity<CurrencyConfigListModel> responseEntity = new ResponseEntity<CurrencyConfigListModel>(
				fxoCurrencyConfigListModel, HttpStatus.OK);

		return responseEntity;
	}

}
