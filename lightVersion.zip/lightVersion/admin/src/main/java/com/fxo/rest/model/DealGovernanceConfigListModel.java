package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private InvestmentAmountDealGovernanceConfigListModel notionalThreshold;
	private DeltaAmountDealGovernanceConfigListModel deltaAmountThreshold;
	private DeltaPercentDealGovernanceConfigListModel deltaPercentThreshold;
	private VolatilityDealGovernanceConfigListModel volatilityThreshold;
	private VegaDealGovernanceConfigListModel vegaThreshold;
	private TenorDealGovernanceConfigListModel tenorThreshold;
	private StealthDealGovernanceConfigListModel stealthThreshold;
	private MarginAmountDealGovernanceConfigListModel marginThreshold;
	private CurrencyHedgeDealGovernanceConfigListModel traderNotificationThreshold;
	private RawPremiumDealGovernanceConfigListModel premiumThreshold;
	private BarrierDealGovernanceConfigListModel barrierThreshold;

	private String updatedBy;

	public InvestmentAmountDealGovernanceConfigListModel getNotionalThreshold() {
		return notionalThreshold;
	}

	public DealGovernanceConfigListModel setNotionalThreshold(
			InvestmentAmountDealGovernanceConfigListModel notionalThreshold) {
		this.notionalThreshold = notionalThreshold;
		return this;
	}

	public DeltaAmountDealGovernanceConfigListModel getDeltaAmountThreshold() {
		return deltaAmountThreshold;
	}

	public DealGovernanceConfigListModel setDeltaAmountThreshold(
			DeltaAmountDealGovernanceConfigListModel deltaAmountThreshold) {
		this.deltaAmountThreshold = deltaAmountThreshold;
		return this;
	}

	public DeltaPercentDealGovernanceConfigListModel getDeltaPercentThreshold() {
		return deltaPercentThreshold;
	}

	public DealGovernanceConfigListModel setDeltaPercentThreshold(
			DeltaPercentDealGovernanceConfigListModel deltaPercentThreshold) {
		this.deltaPercentThreshold = deltaPercentThreshold;
		return this;
	}

	public VolatilityDealGovernanceConfigListModel getVolatilityThreshold() {
		return volatilityThreshold;
	}

	public DealGovernanceConfigListModel setVolatilityThreshold(
			VolatilityDealGovernanceConfigListModel volatilityThreshold) {
		this.volatilityThreshold = volatilityThreshold;
		return this;
	}

	public VegaDealGovernanceConfigListModel getVegaThreshold() {
		return vegaThreshold;
	}

	public DealGovernanceConfigListModel setVegaThreshold(
			VegaDealGovernanceConfigListModel vegaThreshold) {
		this.vegaThreshold = vegaThreshold;
		return this;
	}

	public TenorDealGovernanceConfigListModel getTenorThreshold() {
		return tenorThreshold;
	}

	public DealGovernanceConfigListModel setTenorThreshold(
			TenorDealGovernanceConfigListModel tenorThreshold) {
		this.tenorThreshold = tenorThreshold;
		return this;
	}

	public StealthDealGovernanceConfigListModel getStealthThreshold() {
		return stealthThreshold;
	}

	public DealGovernanceConfigListModel setStealthThreshold(
			StealthDealGovernanceConfigListModel stealthThreshold) {
		this.stealthThreshold = stealthThreshold;
		return this;
	}

	public MarginAmountDealGovernanceConfigListModel getMarginThreshold() {
		return marginThreshold;
	}

	public DealGovernanceConfigListModel setMarginThreshold(
			MarginAmountDealGovernanceConfigListModel marginThreshold) {
		this.marginThreshold = marginThreshold;
		return this;
	}

	public CurrencyHedgeDealGovernanceConfigListModel getTraderNotificationThreshold() {
		return traderNotificationThreshold;
	}

	public DealGovernanceConfigListModel setTraderNotificationThreshold(
			CurrencyHedgeDealGovernanceConfigListModel traderNotificationThreshold) {
		this.traderNotificationThreshold = traderNotificationThreshold;
		return this;
	}

	public RawPremiumDealGovernanceConfigListModel getPremiumThreshold() {
		return premiumThreshold;
	}

	public DealGovernanceConfigListModel setPremiumThreshold(
			RawPremiumDealGovernanceConfigListModel premiumThreshold) {
		this.premiumThreshold = premiumThreshold;
		return this;
	}

	public BarrierDealGovernanceConfigListModel getBarrierThreshold() {
		return barrierThreshold;
	}

	public DealGovernanceConfigListModel setBarrierThreshold(
			BarrierDealGovernanceConfigListModel barrierThreshold) {
		this.barrierThreshold = barrierThreshold;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public DealGovernanceConfigListModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

}
