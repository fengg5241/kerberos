package com.fxo.rest.model;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class FXOUserInterPortfolioMappingConfigModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String userID;

	private String interPortfolioId;

	private String updatedBy;

	private DateTime updatedAt;

	private Boolean active;

	public String getUserID() {
		return userID;
	}

	public FXOUserInterPortfolioMappingConfigModel setUserID(String userID) {
		this.userID = userID;
		return this;
	}

	public String getInterPortfolioId() {
		return interPortfolioId;
	}

	public FXOUserInterPortfolioMappingConfigModel setInterPortfolioId(
			String interPortfolioId) {
		this.interPortfolioId = interPortfolioId;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public FXOUserInterPortfolioMappingConfigModel setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXOUserInterPortfolioMappingConfigModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public FXOUserInterPortfolioMappingConfigModel setUpdatedAt(
			DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
