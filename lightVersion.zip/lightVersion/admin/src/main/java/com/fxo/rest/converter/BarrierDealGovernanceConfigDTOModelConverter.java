package com.fxo.rest.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.model.BarrierDealGovernanceConfigModel;

@Component(value = "barrierDealGovernanceConfigDTOModelConverter")
public class BarrierDealGovernanceConfigDTOModelConverter
		extends
		BaseCustomDTOBaseCustomModelConverter<DealGovernanceConfigDTO, BarrierDealGovernanceConfigModel> {

}
