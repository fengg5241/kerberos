package com.fxo.admin.constants;

public enum FXOAdminValidationCodes {
	DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;
}
