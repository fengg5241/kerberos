package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;
import com.fxo.rest.command.FXOInterPortfolioConfigQueryCommand;
import com.fxo.rest.converter.FXOInterPortfolioConfigDTOModelConverter;
import com.fxo.rest.model.FXOInterPortfolioConfigListModel;

@Controller
@RequestMapping("/admin/interPortfolio")
public class FXOInterPortfolioConfigQueryController {
	
	@Autowired
	private IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingQueryService;

	@Autowired
	private FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;
	
	@RequestMapping(method = RequestMethod.GET, value = "/{userId}", produces = "application/json")
	public Callable<ResponseEntity<FXOInterPortfolioConfigListModel>> getUnAssignedPortfolios(
			@PathVariable(value = "userId") String userId) {
		
		return new FXOInterPortfolioConfigQueryCommand(userId,
				fxoUserInterPortfolioMappingQueryService,
				fxoInterPortfolioConfigDTOModelConverter);
	}

}
