package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class TenorDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<TenorDealGovernanceConfigModel> configuration;

	public List<TenorDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public TenorDealGovernanceConfigListModel setConfiguration(
			List<TenorDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
