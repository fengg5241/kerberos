package com.fxo.rest.model;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyHedgeDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private List<CurrencyHedgeDealGovernanceConfigModel> configuration;

	public List<CurrencyHedgeDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public CurrencyHedgeDealGovernanceConfigListModel setConfiguration(
			List<CurrencyHedgeDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
