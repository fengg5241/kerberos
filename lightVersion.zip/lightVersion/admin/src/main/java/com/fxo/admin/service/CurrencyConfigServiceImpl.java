package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.admin.dto.converter.CurrencyConfigDTOEntityConverter;
import com.fxo.admin.dto.converter.CurrencyConfigSourceTargetDTOConverter;
import com.fxo.api.dto.FXOCurrencyDTO;
import com.fxo.api.service.IFXOCurrencyService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.dao.entity.FXOCurrency;
import com.fxo.dao.repository.FXOCurrencyRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.MathUtil;

/**
 * @author lakshmikanth
 *
 */
@Service
public class CurrencyConfigServiceImpl implements ICurrencyConfigService {

	private static final Logger logger = LoggerFactory
			.getLogger(CurrencyConfigServiceImpl.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private FXOCurrencyRepository fxoCurrencyRepository;

	@Autowired
	private IFXOCurrencyService fxoCurrencyService;

	@Autowired
	private CurrencyConfigDTOEntityConverter currencyConfigDTOEntityConverter;

	@Autowired
	private CurrencyConfigSourceTargetDTOConverter currencyConfigSourceTargetDTOConverter;

	@Override
	@Transactional(readOnly = true)
	public List<CurrencyConfigDTO> getAllCurrencies() {

		List<FXOCurrencyDTO> fxoCurrencyDTOs = fxoCurrencyService
				.getAllFXOCurrencies();

		List<CurrencyConfigDTO> currencyConfigDTOs = null;

		if (fxoCurrencyDTOs != null) {
			currencyConfigDTOs = currencyConfigSourceTargetDTOConverter
					.toTargetDTOs(fxoCurrencyDTOs);
		}

		return currencyConfigDTOs;
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllFXOCurrencies", allEntries = true),
			@CacheEvict(value = "getOneFXOCurrency", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public List<CurrencyConfigDTO> updateCurrencies(
			List<CurrencyConfigDTO> currencyConfigDTOs) {

		List<FXOCurrency> entitiesToPersist = new ArrayList<FXOCurrency>();

		for (CurrencyConfigDTO currencyConfigDTO : currencyConfigDTOs) {

			String currencyCode = currencyConfigDTO.getCurrency();

			FXOCurrency fxoCurrencyEntity = fxoCurrencyRepository
					.getOneFXOCurrency(currencyCode);

			if (fxoCurrencyEntity == null) {
				logger.info(String.format(
						"Currency %s doesn't exist in database", currencyCode));
				throw new ApplicationRuntimeException("",
						FXOMessageCodes.ERR_CURRENCY);
			}

			// check for any modification
			if (checkForModification(currencyConfigDTO, fxoCurrencyEntity)) {
				fxoCurrencyEntity.setAmountPrecision(MathUtil
						.createInteger(currencyConfigDTO.getAmountPrecision()));

				fxoCurrencyEntity.setLastUpdatedDate(DateTimeUtil
						.getCurrentSQLTimeStamp());
				fxoCurrencyEntity.setLastUpdatedBy(currencyConfigDTO
						.getUpdatedBy());

				entitiesToPersist.add(fxoCurrencyEntity);
			}

		}

		List<FXOCurrency> entitiesPersisted = (entitiesToPersist != null && entitiesToPersist
				.size() > 0) ? fxoCurrencyRepository
				.saveFXOCurrencies(entitiesToPersist) : null;

		List<CurrencyConfigDTO> currencyConfigDTOs_Persisted = (entitiesPersisted != null && entitiesPersisted
				.size() > 0) ? currencyConfigDTOEntityConverter
				.fromEntities(entitiesPersisted) : null;

		return currencyConfigDTOs_Persisted;
	}

	public boolean checkForModification(CurrencyConfigDTO currencyConfigDTO,
			FXOCurrency fxoCurrencyEntity) {
		return !(FXOStringUtility.compare(
				currencyConfigDTO.getAmountPrecision(),
				fxoCurrencyEntity.getAmountPrecision()));
	}

	@Override
	@Async
	public void refreshCurrencyCache() {
		fxoCurrencyService.loadCurrencyData();
	}

}
