package com.fxo.rest.model;

import java.util.List;

import javax.validation.Valid;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class VegaDealGovernanceConfigListModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	@Valid
	private List<VegaDealGovernanceConfigModel> configuration;

	public List<VegaDealGovernanceConfigModel> getConfiguration() {
		return configuration;
	}

	public VegaDealGovernanceConfigListModel setConfiguration(
			List<VegaDealGovernanceConfigModel> configuration) {
		this.configuration = configuration;
		return this;
	}

}
