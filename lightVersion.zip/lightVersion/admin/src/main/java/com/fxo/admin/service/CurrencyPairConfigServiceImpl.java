package com.fxo.admin.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.converter.CurrencyPairConfigDTOEntityConverter;
import com.fxo.admin.dto.converter.CurrencyPairConfigSourceTargetDTOConverter;
import com.fxo.api.service.ICurrencyPairGroupService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.dao.repository.CurrencyPairRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.MathUtil;

/**
 * @author lakshmikanth
 *
 */
@Service
public class CurrencyPairConfigServiceImpl implements
		ICurrencyPairConfigService {

	private static final Logger logger = LoggerFactory
			.getLogger(CurrencyPairConfigServiceImpl.class);

	private static final long serialVersionUID = 1L;

	@Autowired
	private ICurrencyPairGroupService currencyPairService;

	@Autowired
	private CurrencyPairRepository currencyPairRepository;

	@Autowired
	private CurrencyPairConfigDTOEntityConverter currencyPairConfigDTOEntityConverter;

	@Autowired
	private CurrencyPairConfigSourceTargetDTOConverter currencyPairConfigSourceTargetDTOConverter;

	@Override
	@Transactional(readOnly = true)
	@Cacheable(value = { "getAllCurrencyPairsConfiguration" })
	public List<CurrencyPairConfigDTO> getAllCurrencyPairs() {

		List<CurrencyPair> currencyPairEntities = currencyPairRepository
				.getAllCurrencyPairs();

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = null;

		if (currencyPairEntities != null) {
			currencyPairConfigDTOs = currencyPairConfigDTOEntityConverter
					.fromEntities(currencyPairEntities);
		}

		return currencyPairConfigDTOs;
	}

	@Override
	@Caching(evict = {
			@CacheEvict(value = "getAllCurrencyPairs", allEntries = true),
			@CacheEvict(value = "getOneCurrencyPair", allEntries = true),
			@CacheEvict(value = "getCurrencyPairMapGroupedByProduct", allEntries = true),
			@CacheEvict(value = "getAllUniqueCurrenciesFromCurrencyPairs", allEntries = true),
			@CacheEvict(value = "getOneCurrencyPairByCurrencyAndCounterCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getAllCurrenciesByCounterCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getAllCounterCurrenciesByCurrencyAndProduct", allEntries = true),
			@CacheEvict(value = "getUniqueCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getCounterCurrenciesByGroup", allEntries = true),
			@CacheEvict(value = "getAllCurrencyPairProductsConfiguration", allEntries = true),
			@CacheEvict(value = "getAllCurrencyPairsConfiguration", allEntries = true) })
	@Transactional(propagation = Propagation.REQUIRED)
	public List<CurrencyPairConfigDTO> updateCurrencyPairs(
			List<CurrencyPairConfigDTO> currencyPairConfigDTOs) {

		List<CurrencyPair> entitiesToPersist = new ArrayList<CurrencyPair>();

		for (CurrencyPairConfigDTO currencyPairConfigDTO : currencyPairConfigDTOs) {

			String currency = currencyPairConfigDTO.getCurrency();
			String counterCurrency = currencyPairConfigDTO.getCounterCurrency();

			CurrencyPair currencyPairEntity = currencyPairRepository
					.getOneCurrencyPair(currency, counterCurrency);

			if (currencyPairEntity == null) {
				logger.info(String.format(
						"CurrencyPair %s-%s doesn't exist in database",
						currency, counterCurrency));
				throw new ApplicationRuntimeException("",
						FXOMessageCodes.ERR_CURRENCY_PAIR);
			}

			// check for any modification
			if (checkForModification(currencyPairConfigDTO, currencyPairEntity)) {
				currencyPairEntity
						.setRatePrecision(MathUtil
								.createInteger(currencyPairConfigDTO
										.getRatePrecision()));
				currencyPairEntity.setMinDistanceFromDeltaSpot(MathUtil
						.createInteger(currencyPairConfigDTO.getMinDistanceFromDeltaSpot()));
				
				currencyPairEntity.setMaxDistanceFromDeltaSpot(MathUtil
						.createInteger(currencyPairConfigDTO.getMaxDistanceFromDeltaSpot()));
				
				currencyPairEntity.setDistanceFromSpot(MathUtil
						.createInteger(currencyPairConfigDTO
								.getDistanceFromSpot()));
				
				currencyPairEntity.setPipUnitValue(currencyPairConfigDTO
						.getPipUnitValue());
				currencyPairEntity.setLastUpdatedDate(DateTimeUtil
						.getCurrentSQLTimeStamp());
				currencyPairEntity.setLastUpdatedBy(currencyPairConfigDTO
						.getUpdatedBy());

				entitiesToPersist.add(currencyPairEntity);
			}
		}

		List<CurrencyPair> entitiesPersisted = (entitiesToPersist != null && entitiesToPersist
				.size() > 0) ? currencyPairRepository
				.saveCurrencyPairs(entitiesToPersist) : null;

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Persisted = (entitiesPersisted != null && entitiesPersisted
				.size() > 0) ? currencyPairConfigDTOEntityConverter
				.fromEntities(entitiesPersisted) : null;

		return currencyPairConfigDTOs_Persisted;
	}

	public boolean checkForModification(
			CurrencyPairConfigDTO currencyPairConfigDTO,
			CurrencyPair currencyPairEntity) {
		return !(FXOStringUtility.compare(
				currencyPairConfigDTO.getDistanceFromSpot(),
				currencyPairEntity.getDistanceFromSpot()))

				|| !(FXOStringUtility.compare(
						currencyPairConfigDTO.getPipUnitValue(),
						currencyPairEntity.getPipUnitValue()))

				|| !(FXOStringUtility.compare(
						currencyPairConfigDTO.getRatePrecision(),
						currencyPairEntity.getRatePrecision()))
				
				|| !(FXOStringUtility.compare(
						currencyPairConfigDTO.getMinDistanceFromDeltaSpot(),
						currencyPairEntity.getMinDistanceFromDeltaSpot()))
				
				|| !(FXOStringUtility.compare(
						currencyPairConfigDTO.getMaxDistanceFromDeltaSpot(),
						currencyPairEntity.getMaxDistanceFromDeltaSpot()));
	}

	@Async
	@Override
	public void refreshCurrencyPairCache() {
		currencyPairService.loadCurrencyPairData();
		currencyPairService.loadCurrencyPairProductData();
	}

}
