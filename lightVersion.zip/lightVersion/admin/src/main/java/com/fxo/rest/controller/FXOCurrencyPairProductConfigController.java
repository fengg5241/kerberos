package com.fxo.rest.controller;

import java.util.concurrent.Callable;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fxo.admin.service.ICurrencyPairConfigService;
import com.fxo.admin.service.ICurrencyPairProductConfigurationService;
import com.fxo.rest.command.CurrencyPairConfigListCommand;
import com.fxo.rest.command.CurrencyPairConfigUpdateCommand;
import com.fxo.rest.command.CurrencyPairProductConfigListCommand;
import com.fxo.rest.command.CurrencyPairProductConfigUpdateCommand;
import com.fxo.rest.converter.CurrencyPairConfigDTOModelConverter;
import com.fxo.rest.converter.CurrencyPairProductConfigDTOModelConverter;
import com.fxo.rest.converter.CurrencyPairProductConfigResponseDTOModelConverter;
import com.fxo.rest.model.CurrencyPairConfigListModel;
import com.fxo.rest.model.CurrencyPairProductConfigListModel;
import com.fxo.rest.model.CurrencyPairProductConfigModel;
import com.fxo.rest.model.CurrencyPairProductConfigResponseModel;

@Controller
@RequestMapping(value = "/admin/currencyPair")
public class FXOCurrencyPairProductConfigController {

	@Autowired
	private ICurrencyPairProductConfigurationService currencyPairProductConfigurationService;

	@Autowired
	private CurrencyPairProductConfigDTOModelConverter currencyPairProductConfigDTOModelConverter;

	@Autowired
	private CurrencyPairProductConfigResponseDTOModelConverter currencyPairProductConfigResponseDTOModelConverter;

	@Autowired
	private ICurrencyPairConfigService currencyPairConfigService;

	@Autowired
	private CurrencyPairConfigDTOModelConverter currencyPairConfigDTOModelConverter;

	// get All CurrencyPair-Product mappings (for all products)
	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairProductConfigListModel>> getCurrencyPairProductConfiguration() {
		return new CurrencyPairProductConfigListCommand(
				currencyPairProductConfigurationService,
				currencyPairProductConfigDTOModelConverter);
	}

	// update CurrencyPair-Product Mapping ( - applyStatus for a given Currency
	// (as for and counter) OR -applyStatus for a currencyPair)
	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairProductConfigResponseModel>> updateCurrencyPairProducts(
			@Valid @RequestBody CurrencyPairProductConfigModel currencyPairProductConfigModel) {
		return new CurrencyPairProductConfigUpdateCommand(
				currencyPairProductConfigurationService,
				currencyPairProductConfigDTOModelConverter,
				currencyPairProductConfigModel,
				currencyPairProductConfigResponseDTOModelConverter);
	}

	// get All CurrencyPairs
	@RequestMapping(method = RequestMethod.GET, value = "/precision", produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairConfigListModel>> getCurrencyPairConfiguration() {
		return new CurrencyPairConfigListCommand(currencyPairConfigService,
				currencyPairConfigDTOModelConverter);
	}

	// update a CurrencyPair configuration (precision,pipUnit,distanceFromSpot)
	@RequestMapping(method = RequestMethod.POST, value = "/precision", produces = "application/json")
	public Callable<ResponseEntity<CurrencyPairConfigListModel>> updateCurrencyPairConfiguration(
			@Valid @RequestBody CurrencyPairConfigListModel currencyPairConfigListModel) {
		return new CurrencyPairConfigUpdateCommand(currencyPairConfigService,
				currencyPairConfigDTOModelConverter,
				currencyPairConfigListModel);
	}

}