package com.fxo.admin.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.admin.constraint.ValidFXOUserInterPortfolioMappingConfig;
import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
@ValidFXOUserInterPortfolioMappingConfig
public class FXOUserInterPortfolioMappingConfigListWrapperDTO extends
		BaseCustomDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<FXOUserInterPortfolioMappingConfigListDTO> interPortfolioMappingConfiguration;

	public List<FXOUserInterPortfolioMappingConfigListDTO> getInterPortfolioMappingConfiguration() {
		return interPortfolioMappingConfiguration;
	}

	public FXOUserInterPortfolioMappingConfigListWrapperDTO setInterPortfolioMappingConfiguration(
			List<FXOUserInterPortfolioMappingConfigListDTO> interPortfolioMappingConfiguration) {
		this.interPortfolioMappingConfiguration = interPortfolioMappingConfiguration;
		return this;
	}

}
