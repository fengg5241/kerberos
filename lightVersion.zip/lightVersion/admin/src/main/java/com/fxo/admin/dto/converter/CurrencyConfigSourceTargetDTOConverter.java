package com.fxo.admin.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.api.dto.FXOCurrencyDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class CurrencyConfigSourceTargetDTOConverter extends
		BaseCustomSourceTargetDTOConverter<FXOCurrencyDTO, CurrencyConfigDTO> {

}
