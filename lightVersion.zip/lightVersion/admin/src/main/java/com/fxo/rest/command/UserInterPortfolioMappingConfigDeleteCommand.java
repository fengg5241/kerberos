package com.fxo.rest.command;

import java.util.concurrent.Callable;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fxo.admin.service.IFXOUserInterPortfolioMappingConfigQueryService;

public class UserInterPortfolioMappingConfigDeleteCommand implements
		Callable<ResponseEntity<Boolean>> {

	private IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService;
	private String userId;

	public UserInterPortfolioMappingConfigDeleteCommand(
			IFXOUserInterPortfolioMappingConfigQueryService fxoUserInterPortfolioMappingConfigQueryService,
			String userId) {

		if (fxoUserInterPortfolioMappingConfigQueryService == null) {
			throw new IllegalStateException(
					"fxoUserInterPortfolioMappingConfigQueryService is not set.");
		}

		this.fxoUserInterPortfolioMappingConfigQueryService = fxoUserInterPortfolioMappingConfigQueryService;
		this.userId = userId;
	}

	@Override
	public ResponseEntity<Boolean> call() throws Exception {

		fxoUserInterPortfolioMappingConfigQueryService
				.deleteUserInterPortfolio(userId);

		ResponseEntity<Boolean> responseEntity = new ResponseEntity<Boolean>(
				Boolean.TRUE, HttpStatus.OK);

		return responseEntity;
	}

}
