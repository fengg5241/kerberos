package com.fxo.rest.converter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.rest.model.BarrierDealGovernanceConfigListModel;
import com.fxo.rest.model.BarrierDealGovernanceConfigModel;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigListModel;
import com.fxo.rest.model.CurrencyHedgeDealGovernanceConfigModel;
import com.fxo.rest.model.DealGovernanceConfigListModel;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.DeltaAmountDealGovernanceConfigModel;
import com.fxo.rest.model.DeltaPercentDealGovernanceConfigListModel;
import com.fxo.rest.model.DeltaPercentDealGovernanceConfigModel;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.InvestmentAmountDealGovernanceConfigModel;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigListModel;
import com.fxo.rest.model.MarginAmountDealGovernanceConfigModel;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigListModel;
import com.fxo.rest.model.RawPremiumDealGovernanceConfigModel;
import com.fxo.rest.model.StealthDealGovernanceConfigListModel;
import com.fxo.rest.model.StealthDealGovernanceConfigModel;
import com.fxo.rest.model.TenorDealGovernanceConfigListModel;
import com.fxo.rest.model.TenorDealGovernanceConfigModel;
import com.fxo.rest.model.VegaDealGovernanceConfigListModel;
import com.fxo.rest.model.VegaDealGovernanceConfigModel;
import com.fxo.rest.model.VolatilityDealGovernanceConfigListModel;
import com.fxo.rest.model.VolatilityDealGovernanceConfigModel;

@Component
public class DealGovernanceConfigListModelConveter {

	@Autowired
	private DealGovernanceConfigDTOModelConverterFactory dealGovernanceConfigDTOModelConverterFactory;

	public DealGovernanceConfigListModel translateDealGovernanceConfigDTOToModelObject(
			DealGovernanceConfigListDTO dealGovernanceConfigListDTO) {

		DealGovernanceConfigListModel dealGovernanceConfigListModel = null;

		if (dealGovernanceConfigListDTO != null) {

			dealGovernanceConfigListModel = new DealGovernanceConfigListModel();

			InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel = getNotionalThresholdListModel(dealGovernanceConfigListDTO
					.getNotionalThreshold());

			dealGovernanceConfigListModel
					.setNotionalThreshold(investmentAmountDealGovernanceConfigListModel);

			MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel = getMarginAmountThresholdListModel(dealGovernanceConfigListDTO
					.getMarginThreshold());

			dealGovernanceConfigListModel
					.setMarginThreshold(marginAmountDealGovernanceConfigListModel);

			DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel = getDeltaAmountThresholdListModel(dealGovernanceConfigListDTO
					.getDeltaAmountThreshold());

			dealGovernanceConfigListModel
					.setDeltaAmountThreshold(deltaAmountDealGovernanceConfigListModel);

			DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel = getDeltaPercentThresholdListModel(dealGovernanceConfigListDTO
					.getDeltaPercentThreshold());

			dealGovernanceConfigListModel
					.setDeltaPercentThreshold(deltaPercentDealGovernanceConfigListModel);

			VegaDealGovernanceConfigListModel vegaDealGovernanceConfigListModel = getVegaThresholdListModel(dealGovernanceConfigListDTO
					.getVegaThreshold());

			dealGovernanceConfigListModel
					.setVegaThreshold(vegaDealGovernanceConfigListModel);

			VolatilityDealGovernanceConfigListModel volatilityDealGovernanceConfigListModel = getVolatilityThresholdListModel(dealGovernanceConfigListDTO
					.getVolatilityThreshold());

			dealGovernanceConfigListModel
					.setVolatilityThreshold(volatilityDealGovernanceConfigListModel);

			StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel = getStealthThresholdListModel(dealGovernanceConfigListDTO
					.getStealthThreshold());

			dealGovernanceConfigListModel
					.setStealthThreshold(stealthDealGovernanceConfigListModel);

			RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel = getRawPremiumThresholdListModel(dealGovernanceConfigListDTO
					.getPremiumThreshold());

			dealGovernanceConfigListModel
					.setPremiumThreshold(rawPremiumDealGovernanceConfigListModel);

			CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel = getCurrencyHedgeThresholdListModel(dealGovernanceConfigListDTO
					.getTraderNotificationThreshold());

			dealGovernanceConfigListModel
					.setTraderNotificationThreshold(currencyHedgeDealGovernanceConfigListModel);

			TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel = getTenorThresholdListModel(dealGovernanceConfigListDTO
					.getTenorThreshold());

			dealGovernanceConfigListModel
					.setTenorThreshold(tenorDealGovernanceConfigListModel);

			BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel = getBarrierThresholdListModel(dealGovernanceConfigListDTO
					.getBarrierThreshold());

			dealGovernanceConfigListModel
					.setBarrierThreshold(barrierDealGovernanceConfigListModel);

		}

		return dealGovernanceConfigListModel;

	}

	public DealGovernanceConfigListDTO translateDealGovernanceConfigModelToDTOObject(
			DealGovernanceConfigListModel dealGovernanceConfigListModel) {

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = null;

		if (dealGovernanceConfigListModel != null) {

			dealGovernanceConfigListDTO = new DealGovernanceConfigListDTO();

			dealGovernanceConfigListDTO
					.setUpdatedBy(dealGovernanceConfigListModel.getUpdatedBy());

			List<DealGovernanceConfigDTO> notionalThresholdDTOs = getInvestmentAmountThresholdDTOs(dealGovernanceConfigListModel
					.getNotionalThreshold());

			dealGovernanceConfigListDTO
					.setNotionalThreshold(notionalThresholdDTOs);

			List<DealGovernanceConfigDTO> deltaAmountThresholdDTOs = getDeltaAmountThresholdDTOs(dealGovernanceConfigListModel
					.getDeltaAmountThreshold());

			dealGovernanceConfigListDTO
					.setDeltaAmountThreshold(deltaAmountThresholdDTOs);

			List<DealGovernanceConfigDTO> deltaPercentThresholdDTOs = getDeltaPercentThresholdDTOs(dealGovernanceConfigListModel
					.getDeltaPercentThreshold());

			dealGovernanceConfigListDTO
					.setDeltaPercentThreshold(deltaPercentThresholdDTOs);

			List<DealGovernanceConfigDTO> marginAmountThresholdDTOs = getMarginAmountThresholdDTOs(dealGovernanceConfigListModel
					.getMarginThreshold());

			dealGovernanceConfigListDTO
					.setMarginThreshold(marginAmountThresholdDTOs);

			List<DealGovernanceConfigDTO> rawPremiumThresholdDTOs = getRawPremiumThresholdDTOs(dealGovernanceConfigListModel
					.getPremiumThreshold());

			dealGovernanceConfigListDTO
					.setPremiumThreshold(rawPremiumThresholdDTOs);

			List<DealGovernanceConfigDTO> traderNotificationThresholdDTOs = getCurrencyHedgeThresholdDTOs(dealGovernanceConfigListModel
					.getTraderNotificationThreshold());

			dealGovernanceConfigListDTO
					.setTraderNotificationThreshold(traderNotificationThresholdDTOs);

			List<DealGovernanceConfigDTO> tenorThresholdDTOs = getTenorThresholdDTOs(dealGovernanceConfigListModel
					.getTenorThreshold());

			dealGovernanceConfigListDTO.setTenorThreshold(tenorThresholdDTOs);

			List<DealGovernanceConfigDTO> vegaThresholdDTOs = getVegaThresholdDTOs(dealGovernanceConfigListModel
					.getVegaThreshold());

			dealGovernanceConfigListDTO.setVegaThreshold(vegaThresholdDTOs);

			List<DealGovernanceConfigDTO> volatilityThresholdDTOs = getVolatilityThresholdDTOs(dealGovernanceConfigListModel
					.getVolatilityThreshold());

			dealGovernanceConfigListDTO
					.setVolatilityThreshold(volatilityThresholdDTOs);

			List<DealGovernanceConfigDTO> stealthThresholdDTOs = getStealthThresholdDTOs(dealGovernanceConfigListModel
					.getStealthThreshold());

			dealGovernanceConfigListDTO
					.setStealthThreshold(stealthThresholdDTOs);

			List<DealGovernanceConfigDTO> barrierThresholdDTOs = getBarrierThresholdDTOs(dealGovernanceConfigListModel
					.getBarrierThreshold());

			dealGovernanceConfigListDTO
					.setBarrierThreshold(barrierThresholdDTOs);
		}

		return dealGovernanceConfigListDTO;

	}

	public InvestmentAmountDealGovernanceConfigListModel getNotionalThresholdListModel(
			List<DealGovernanceConfigDTO> notionalDealGovernanceConfigDTOs) {

		InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel = new InvestmentAmountDealGovernanceConfigListModel();

		if (notionalDealGovernanceConfigDTOs != null
				&& notionalDealGovernanceConfigDTOs.size() > 0) {

			List<InvestmentAmountDealGovernanceConfigModel> notionalDealGovernanceConfigModels = ((InvestmentAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION)))
					.toModels(notionalDealGovernanceConfigDTOs);

			if (notionalDealGovernanceConfigModels != null
					&& notionalDealGovernanceConfigModels.size() > 0) {

				investmentAmountDealGovernanceConfigListModel
						.setConfiguration(notionalDealGovernanceConfigModels);
			}

		}

		return investmentAmountDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getInvestmentAmountThresholdDTOs(
			InvestmentAmountDealGovernanceConfigListModel investmentAmountDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> investmentAmountThresholdDTOs = null;

		if (investmentAmountDealGovernanceConfigListModel != null
				&& investmentAmountDealGovernanceConfigListModel
						.getConfiguration() != null
				&& !investmentAmountDealGovernanceConfigListModel
						.getConfiguration().isEmpty()) {

			// get DTOModel Converter for MarginAmount
			InvestmentAmountDealGovernanceConfigDTOModelConverter investmentAmountDealGovernanceConfigDTOModelConverter = ((InvestmentAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			investmentAmountThresholdDTOs = investmentAmountDealGovernanceConfigDTOModelConverter
					.fromModels(investmentAmountDealGovernanceConfigListModel
							.getConfiguration());
		}

		return investmentAmountThresholdDTOs;

	}

	public MarginAmountDealGovernanceConfigListModel getMarginAmountThresholdListModel(
			List<DealGovernanceConfigDTO> marginAmountGovernanceConfigDTOs) {

		MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel = new MarginAmountDealGovernanceConfigListModel();

		if (marginAmountGovernanceConfigDTOs != null
				&& marginAmountGovernanceConfigDTOs.size() > 0) {

			List<MarginAmountDealGovernanceConfigModel> marginAmountDealGovernanceConfigModels = ((MarginAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION)))
					.toModels(marginAmountGovernanceConfigDTOs);

			if (marginAmountDealGovernanceConfigModels != null
					&& marginAmountDealGovernanceConfigModels.size() > 0) {

				marginAmountDealGovernanceConfigListModel
						.setConfiguration(marginAmountDealGovernanceConfigModels);
			}

		}

		return marginAmountDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getMarginAmountThresholdDTOs(
			MarginAmountDealGovernanceConfigListModel marginAmountDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> marginAmountThresholdDTOs = null;

		if (marginAmountDealGovernanceConfigListModel != null
				&& marginAmountDealGovernanceConfigListModel.getConfiguration() != null
				&& !marginAmountDealGovernanceConfigListModel
						.getConfiguration().isEmpty()) {

			// get DTOModel Converter for MarginAmount
			MarginAmountDealGovernanceConfigDTOModelConverter marginAmountDealGovernanceConfigDTOModelConverter = ((MarginAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			marginAmountThresholdDTOs = marginAmountDealGovernanceConfigDTOModelConverter
					.fromModels(marginAmountDealGovernanceConfigListModel
							.getConfiguration());
		}

		return marginAmountThresholdDTOs;

	}

	public DeltaAmountDealGovernanceConfigListModel getDeltaAmountThresholdListModel(
			List<DealGovernanceConfigDTO> deltaAmountDealGovernanceConfigDTOs) {

		DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel = new DeltaAmountDealGovernanceConfigListModel();

		if (deltaAmountDealGovernanceConfigDTOs != null
				&& deltaAmountDealGovernanceConfigDTOs.size() > 0) {

			List<DeltaAmountDealGovernanceConfigModel> deltaAmountDealGovernanceConfigModels = ((DeltaAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION)))
					.toModels(deltaAmountDealGovernanceConfigDTOs);

			if (deltaAmountDealGovernanceConfigModels != null
					&& deltaAmountDealGovernanceConfigModels.size() > 0) {

				deltaAmountDealGovernanceConfigListModel
						.setConfiguration(deltaAmountDealGovernanceConfigModels);
			}

		}

		return deltaAmountDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getDeltaAmountThresholdDTOs(
			DeltaAmountDealGovernanceConfigListModel deltaAmountDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> deltaAmountThresholdDTOs = null;

		if (deltaAmountDealGovernanceConfigListModel != null
				&& deltaAmountDealGovernanceConfigListModel.getConfiguration() != null
				&& !deltaAmountDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for DeltaAmount
			DeltaAmountDealGovernanceConfigDTOModelConverter deltaAmountDealGovernanceConfigDTOModelConverter = ((DeltaAmountDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			return deltaAmountDealGovernanceConfigDTOModelConverter
					.fromModels(deltaAmountDealGovernanceConfigListModel
							.getConfiguration());

		}

		return deltaAmountThresholdDTOs;
	}

	public DeltaPercentDealGovernanceConfigListModel getDeltaPercentThresholdListModel(
			List<DealGovernanceConfigDTO> deltaPercentDealGovernanceConfigDTOs) {

		DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel = new DeltaPercentDealGovernanceConfigListModel();

		if (deltaPercentDealGovernanceConfigDTOs != null
				&& deltaPercentDealGovernanceConfigDTOs.size() > 0) {

			List<DeltaPercentDealGovernanceConfigModel> deltaPercentDealGovernanceConfigModels = ((DeltaPercentDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION)))
					.toModels(deltaPercentDealGovernanceConfigDTOs);

			if (deltaPercentDealGovernanceConfigModels != null
					&& deltaPercentDealGovernanceConfigModels.size() > 0) {

				deltaPercentDealGovernanceConfigListModel
						.setConfiguration(deltaPercentDealGovernanceConfigModels);
			}

		}

		return deltaPercentDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getDeltaPercentThresholdDTOs(
			DeltaPercentDealGovernanceConfigListModel deltaPercentDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> deltaPercentThresholdDTOs = null;

		if (deltaPercentDealGovernanceConfigListModel != null
				&& deltaPercentDealGovernanceConfigListModel.getConfiguration() != null
				&& !deltaPercentDealGovernanceConfigListModel
						.getConfiguration().isEmpty()) {

			// get DTOModel Converter for DeltaPercent
			DeltaPercentDealGovernanceConfigDTOModelConverter deltaPercentDealGovernanceConfigDTOModelConverter = ((DeltaPercentDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			deltaPercentThresholdDTOs = deltaPercentDealGovernanceConfigDTOModelConverter
					.fromModels(deltaPercentDealGovernanceConfigListModel
							.getConfiguration());

		}

		return deltaPercentThresholdDTOs;
	}

	public VegaDealGovernanceConfigListModel getVegaThresholdListModel(
			List<DealGovernanceConfigDTO> vegaDealGovernanceConfigDTOs) {

		VegaDealGovernanceConfigListModel vegaDealGovernanceConfigListModel = new VegaDealGovernanceConfigListModel();

		if (vegaDealGovernanceConfigDTOs != null
				&& vegaDealGovernanceConfigDTOs.size() > 0) {

			List<VegaDealGovernanceConfigModel> vegaDealGovernanceConfigModels = ((VegaDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION)))
					.toModels(vegaDealGovernanceConfigDTOs);

			if (vegaDealGovernanceConfigModels != null
					&& vegaDealGovernanceConfigModels.size() > 0) {

				vegaDealGovernanceConfigListModel
						.setConfiguration(vegaDealGovernanceConfigModels);
			}

		}

		return vegaDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getVegaThresholdDTOs(
			VegaDealGovernanceConfigListModel vegaDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> vegaThresholdDTOs = null;

		if (vegaDealGovernanceConfigListModel != null
				&& vegaDealGovernanceConfigListModel.getConfiguration() != null
				&& !vegaDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Vega
			VegaDealGovernanceConfigDTOModelConverter vegaDealGovernanceConfigDTOModelConverter = ((VegaDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			vegaThresholdDTOs = vegaDealGovernanceConfigDTOModelConverter
					.fromModels(vegaDealGovernanceConfigListModel
							.getConfiguration());

		}

		return vegaThresholdDTOs;

	}

	public VolatilityDealGovernanceConfigListModel getVolatilityThresholdListModel(
			List<DealGovernanceConfigDTO> volatilityDealGovernanceConfigDTOs) {

		VolatilityDealGovernanceConfigListModel volatilityDealGovernanceConfigListModel = new VolatilityDealGovernanceConfigListModel();

		if (volatilityDealGovernanceConfigDTOs != null
				&& volatilityDealGovernanceConfigDTOs.size() > 0) {

			List<VolatilityDealGovernanceConfigModel> volatilityDealGovernanceConfigModels = ((VolatilityDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION)))
					.toModels(volatilityDealGovernanceConfigDTOs);

			if (volatilityDealGovernanceConfigModels != null
					&& volatilityDealGovernanceConfigModels.size() > 0) {

				volatilityDealGovernanceConfigListModel
						.setConfiguration(volatilityDealGovernanceConfigModels);
			}

		}

		return volatilityDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getVolatilityThresholdDTOs(
			VolatilityDealGovernanceConfigListModel volatilityDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> volatilityThresholdDTOs = null;

		if (volatilityDealGovernanceConfigListModel != null
				&& volatilityDealGovernanceConfigListModel.getConfiguration() != null
				&& !volatilityDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Volatility
			VolatilityDealGovernanceConfigDTOModelConverter volatilityDealGovernanceConfigDTOModelConverter = ((VolatilityDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			volatilityThresholdDTOs = volatilityDealGovernanceConfigDTOModelConverter
					.fromModels(volatilityDealGovernanceConfigListModel
							.getConfiguration());
		}

		return volatilityThresholdDTOs;

	}

	public StealthDealGovernanceConfigListModel getStealthThresholdListModel(
			List<DealGovernanceConfigDTO> stealthDealGovernanceConfigDTOs) {

		StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel = new StealthDealGovernanceConfigListModel();

		if (stealthDealGovernanceConfigDTOs != null
				&& stealthDealGovernanceConfigDTOs.size() > 0) {

			List<StealthDealGovernanceConfigModel> stealthDealGovernanceConfigModels = ((StealthDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION)))
					.toModels(stealthDealGovernanceConfigDTOs);

			if (stealthDealGovernanceConfigModels != null
					&& stealthDealGovernanceConfigModels.size() > 0) {

				stealthDealGovernanceConfigListModel
						.setConfiguration(stealthDealGovernanceConfigModels);
			}

		}

		return stealthDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getStealthThresholdDTOs(
			StealthDealGovernanceConfigListModel stealthDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> stealthThresholdDTOs = null;

		if (stealthDealGovernanceConfigListModel != null
				&& stealthDealGovernanceConfigListModel.getConfiguration() != null
				&& !stealthDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Stealth
			StealthDealGovernanceConfigDTOModelConverter stealthDealGovernanceConfigDTOModelConverter = ((StealthDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			stealthThresholdDTOs = stealthDealGovernanceConfigDTOModelConverter
					.fromModels(stealthDealGovernanceConfigListModel
							.getConfiguration());
		}

		return stealthThresholdDTOs;

	}

	public RawPremiumDealGovernanceConfigListModel getRawPremiumThresholdListModel(
			List<DealGovernanceConfigDTO> rawPremiumDealGovernanceConfigDTOs) {

		RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel = new RawPremiumDealGovernanceConfigListModel();

		if (rawPremiumDealGovernanceConfigDTOs != null
				&& rawPremiumDealGovernanceConfigDTOs.size() > 0) {

			List<RawPremiumDealGovernanceConfigModel> rawPremiumDealGovernanceConfigModels = ((RawPremiumDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION)))
					.toModels(rawPremiumDealGovernanceConfigDTOs);

			if (rawPremiumDealGovernanceConfigModels != null
					&& rawPremiumDealGovernanceConfigModels.size() > 0) {

				rawPremiumDealGovernanceConfigListModel
						.setConfiguration(rawPremiumDealGovernanceConfigModels);
			}

		}

		return rawPremiumDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getRawPremiumThresholdDTOs(
			RawPremiumDealGovernanceConfigListModel rawPremiumDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> rawPremiumThresholdDTOs = null;

		if (rawPremiumDealGovernanceConfigListModel != null
				&& rawPremiumDealGovernanceConfigListModel.getConfiguration() != null
				&& !rawPremiumDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Rawpremium
			RawPremiumDealGovernanceConfigDTOModelConverter rawPremiumDealGovernanceConfigDTOModelConverter = ((RawPremiumDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			rawPremiumThresholdDTOs = rawPremiumDealGovernanceConfigDTOModelConverter
					.fromModels(rawPremiumDealGovernanceConfigListModel
							.getConfiguration());
		}

		return rawPremiumThresholdDTOs;

	}

	public CurrencyHedgeDealGovernanceConfigListModel getCurrencyHedgeThresholdListModel(
			List<DealGovernanceConfigDTO> currencyHedgeDealGovernanceConfigDTOs) {

		CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel = new CurrencyHedgeDealGovernanceConfigListModel();

		if (currencyHedgeDealGovernanceConfigDTOs != null
				&& currencyHedgeDealGovernanceConfigDTOs.size() > 0) {

			List<CurrencyHedgeDealGovernanceConfigModel> currencyHedgeDealGovernanceConfigModels = ((CurrencyHedgeDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION)))
					.toModels(currencyHedgeDealGovernanceConfigDTOs);

			if (currencyHedgeDealGovernanceConfigModels != null
					&& currencyHedgeDealGovernanceConfigModels.size() > 0) {

				currencyHedgeDealGovernanceConfigListModel
						.setConfiguration(currencyHedgeDealGovernanceConfigModels);
			}

		}

		return currencyHedgeDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getCurrencyHedgeThresholdDTOs(
			CurrencyHedgeDealGovernanceConfigListModel currencyHedgeDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> currencyHedgeThresholdDTOs = null;

		if (currencyHedgeDealGovernanceConfigListModel != null
				&& currencyHedgeDealGovernanceConfigListModel
						.getConfiguration() != null
				&& !currencyHedgeDealGovernanceConfigListModel
						.getConfiguration().isEmpty()) {

			// get DTOModel Converter for CurrencyHedge
			CurrencyHedgeDealGovernanceConfigDTOModelConverter currencyHedgeDealGovernanceConfigDTOModelConverter = ((CurrencyHedgeDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			currencyHedgeThresholdDTOs = currencyHedgeDealGovernanceConfigDTOModelConverter
					.fromModels(currencyHedgeDealGovernanceConfigListModel
							.getConfiguration());
		}

		return currencyHedgeThresholdDTOs;

	}

	public TenorDealGovernanceConfigListModel getTenorThresholdListModel(
			List<DealGovernanceConfigDTO> tenorDealGovernanceConfigDTOs) {

		TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel = new TenorDealGovernanceConfigListModel();

		if (tenorDealGovernanceConfigDTOs != null
				&& tenorDealGovernanceConfigDTOs.size() > 0) {

			List<TenorDealGovernanceConfigModel> tenorDealGovernanceConfigModels = ((TenorDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION)))
					.toModels(tenorDealGovernanceConfigDTOs);

			if (tenorDealGovernanceConfigModels != null
					&& tenorDealGovernanceConfigModels.size() > 0) {

				tenorDealGovernanceConfigListModel
						.setConfiguration(tenorDealGovernanceConfigModels);
			}

		}

		return tenorDealGovernanceConfigListModel;
	}

	public List<DealGovernanceConfigDTO> getTenorThresholdDTOs(
			TenorDealGovernanceConfigListModel tenorDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> tenorThresholdDTOs = null;

		if (tenorDealGovernanceConfigListModel != null
				&& tenorDealGovernanceConfigListModel.getConfiguration() != null
				&& !tenorDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Tenor
			TenorDealGovernanceConfigDTOModelConverter tenorDealGovernanceConfigDTOModelConverter = ((TenorDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			tenorThresholdDTOs = tenorDealGovernanceConfigDTOModelConverter
					.fromModels(tenorDealGovernanceConfigListModel
							.getConfiguration());
		}

		return tenorThresholdDTOs;

	}

	public BarrierDealGovernanceConfigListModel getBarrierThresholdListModel(
			List<DealGovernanceConfigDTO> barrierDealGovernanceConfigDTOs) {

		BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel = new BarrierDealGovernanceConfigListModel();

		if (barrierDealGovernanceConfigDTOs != null
				&& barrierDealGovernanceConfigDTOs.size() > 0) {
			List<BarrierDealGovernanceConfigModel> barrierDealGovernanceConfigModels = ((BarrierDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION)))
					.toModels(barrierDealGovernanceConfigDTOs);
			barrierDealGovernanceConfigListModel
					.setConfiguration(barrierDealGovernanceConfigModels);
		}

		return barrierDealGovernanceConfigListModel;

	}

	public List<DealGovernanceConfigDTO> getBarrierThresholdDTOs(
			BarrierDealGovernanceConfigListModel barrierDealGovernanceConfigListModel) {

		List<DealGovernanceConfigDTO> barrierThresholdDTOs = null;

		if (barrierDealGovernanceConfigListModel != null
				&& barrierDealGovernanceConfigListModel.getConfiguration() != null
				&& !barrierDealGovernanceConfigListModel.getConfiguration()
						.isEmpty()) {

			// get DTOModel Converter for Barrier
			BarrierDealGovernanceConfigDTOModelConverter barrierDealGovernanceConfigDTOModelConverter = ((BarrierDealGovernanceConfigDTOModelConverter) (dealGovernanceConfigDTOModelConverterFactory
					.getDealGovernanceConfigDTOModelConverter(DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION)));

			// translate Threshold-Model-Objects to DTOs
			barrierThresholdDTOs = barrierDealGovernanceConfigDTOModelConverter
					.fromModels(barrierDealGovernanceConfigListModel
							.getConfiguration());

		}

		return barrierThresholdDTOs;

	}
}
