package com.fxo.rest.model;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyConfigModel extends BaseCustomModel {

	private static final long serialVersionUID = 1L;

	private String currency;
	private String amountPrecision;
	private String updatedBy;
	private DateTime updatedAt;

	public String getCurrency() {
		return currency;
	}

	public CurrencyConfigModel setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getAmountPrecision() {
		return amountPrecision;
	}

	public CurrencyConfigModel setAmountPrecision(String amountPrecision) {
		this.amountPrecision = amountPrecision;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public CurrencyConfigModel setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public CurrencyConfigModel setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
