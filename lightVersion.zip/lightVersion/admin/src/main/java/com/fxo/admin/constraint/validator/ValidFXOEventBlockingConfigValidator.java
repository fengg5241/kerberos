package com.fxo.admin.constraint.validator;

import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;

import com.fxo.admin.constants.FXOAdminMessageCodes;
import com.fxo.admin.constraint.ValidFXOEventBlockingConfig;
import com.fxo.admin.dto.FXOEventBlockingDateConfigDTO;
import com.fxo.admin.dto.FXOEventBlockingDateConfigListDTO;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

public class ValidFXOEventBlockingConfigValidator
		implements
		ConstraintValidator<ValidFXOEventBlockingConfig, FXOEventBlockingDateConfigListDTO> {

	@Override
	public void initialize(ValidFXOEventBlockingConfig constraintAnnotation) {

	}

	@Override
	public boolean isValid(
			FXOEventBlockingDateConfigListDTO fxoEventBlockingDateConfigListDTO,
			ConstraintValidatorContext context) {

		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		FXOEventBlockingDateConfigDTO fxoEventBlockingDateConfigDTO = fxoEventBlockingDateConfigListDTO
				.getFxoEventBlockingDateConfigDTO();

		Boolean hasNonEmptyEvent = FXOStringUtility
				.isNotEmpty(fxoEventBlockingDateConfigDTO.getEventDescription());

		predicateResultSet.add(hasNonEmptyEvent);

		if (FXOBooleanUtility.isFalse(hasNonEmptyEvent)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_EVENT_DESCRIPTION_EMPTY)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		Boolean hasNonEmptyCurrencyPair = CollectionUtils
				.isNotEmpty(fxoEventBlockingDateConfigDTO.getCurrencyPair());
		predicateResultSet.add(hasNonEmptyCurrencyPair);

		if (FXOBooleanUtility.isFalse(hasNonEmptyCurrencyPair)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_CURRENCY_PAIR_NOT_EXISTS)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		Boolean hasNonEmptyProductList = CollectionUtils
				.isNotEmpty(fxoEventBlockingDateConfigDTO.getProduct());
		predicateResultSet.add(hasNonEmptyProductList);

		if (FXOBooleanUtility.isFalse(hasNonEmptyProductList)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_PRODUCT_NOT_EXISTS)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}
		
		Boolean hasNonNullExpiryMaximumDate = fxoEventBlockingDateConfigDTO
				.getExpiryDateThresholdMax() != null;
		predicateResultSet.add(hasNonNullExpiryMaximumDate);
		
		if (FXOBooleanUtility.isFalse(hasNonNullExpiryMaximumDate)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_DATE_INVALID)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		Boolean hasNonNullExpiryMinimumDate = fxoEventBlockingDateConfigDTO
				.getExpiryDateThresholdMin() != null;

		if (FXOBooleanUtility.isFalse(hasNonNullExpiryMinimumDate)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_DATE_INVALID)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}
		predicateResultSet.add(hasNonNullExpiryMinimumDate);

		Boolean hasValidDateRange = fxoEventBlockingDateConfigDTO
				.getExpiryDateThresholdMin().isEqual(
						fxoEventBlockingDateConfigDTO
								.getExpiryDateThresholdMax())
				|| fxoEventBlockingDateConfigDTO.getExpiryDateThresholdMax()
						.isAfter(
								fxoEventBlockingDateConfigDTO
										.getExpiryDateThresholdMin());

		predicateResultSet.add(hasValidDateRange);

		if (FXOBooleanUtility.isFalse(hasValidDateRange)) {
			context.buildConstraintViolationWithTemplate(
					FXOAdminMessageCodes.ERR_EVENT_BLOCK_DATE_RANGE_INVALID)
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}
}
