package com.fxo.admin.dto;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOUserInterPortfolioMappingConfigDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String userID;

	private String interPortfolioId;

	private String updatedBy;

	private DateTime updatedAt;

	private Boolean active;

	public String getUserID() {
		return userID;
	}

	public FXOUserInterPortfolioMappingConfigDTO setUserID(String userID) {
		this.userID = userID;
		return this;
	}

	public String getInterPortfolioId() {
		return interPortfolioId;
	}

	public FXOUserInterPortfolioMappingConfigDTO setInterPortfolioId(
			String interPortfolioId) {
		this.interPortfolioId = interPortfolioId;
		return this;
	}

	public Boolean getActive() {
		return active;
	}

	public FXOUserInterPortfolioMappingConfigDTO setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXOUserInterPortfolioMappingConfigDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public FXOUserInterPortfolioMappingConfigDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

}
