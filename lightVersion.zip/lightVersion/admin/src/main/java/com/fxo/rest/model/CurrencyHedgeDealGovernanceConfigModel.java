package com.fxo.rest.model;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyHedgeDealGovernanceConfigModel extends
		DealGovernanceConfigBaseModel {

	private static final long serialVersionUID = 1L;

	private String maximum;

	public String getMaximum() {
		return maximum;
	}

	public CurrencyHedgeDealGovernanceConfigModel setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

}
