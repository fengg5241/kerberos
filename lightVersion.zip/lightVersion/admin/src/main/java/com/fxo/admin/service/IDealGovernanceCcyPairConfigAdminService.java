package com.fxo.admin.service;

import java.util.List;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;

/**
 * The Interface IDealGovernanceCcyPairConfigAdminService.
 *
 * @author lakshmikanth
 */
public interface IDealGovernanceCcyPairConfigAdminService {

	public List<DealGovernanceConfigDTO> getDealGovernanceConfigListByCurrencyPair(
			String validationCode, String currency, String counterCurrency);

	public List<CurrencyPairConfigDTO> getAllCurrencyPairsCustomizedForDealGovernance();

	public List<CurrencyPairConfigDTO> getAllCurrencyPairsForCustomizationForDealGovernance();

	public void deleteCurrencyPairCustomizationForDealGovernance(
			String currency, String counterCurrency);

	public void saveDealGovernanceParameters(String validationCode,
			String currency, String counterCurrency,
			List<DealGovernanceConfigDTO> governanceConfigDTOs);

	public void saveAllDealGovernanceParameters(
			CurrencyPairConfigDTO currencyPairConfigDTO,
			DealGovernanceConfigListDTO dealGovernanceConfigListDTO);

	public DealGovernanceConfigListDTO getAllDealGovernanceParameters(
			String currency, String counterCurrency);

	public Boolean isCurrencyPairCustomizedForDealGovernance(String currency,
			String counterCurrency);

	void refreshDealGovernanceCcyPairCache();

}