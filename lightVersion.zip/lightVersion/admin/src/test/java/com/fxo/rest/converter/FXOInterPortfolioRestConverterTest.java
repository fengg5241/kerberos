package com.fxo.rest.converter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;

@Test
@ContextConfiguration("classpath:./com/fxo/admin/rest/converter/test-admin-converters.xml")
public class FXOInterPortfolioRestConverterTest extends
		AbstractTestNGSpringContextTests {

	public static final String dateTimePattern = "dd-MMM-yy hh.mm.ss aa";

	@Autowired
	FXOInterPortfolioConfigDTOModelConverter fxoInterPortfolioConfigDTOModelConverter;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

	}

	private DateTime getDateTimeFromString(String input) {

		return DateTime
				.parse(input, DateTimeFormat.forPattern(dateTimePattern));
	}

	private FXOInterPortfolioConfigDTO getAnFXOInterPortfolioConfigDTO(
			String interPortfolio, String updatedBy, String updatedAt,
			Boolean active) {

		return new FXOInterPortfolioConfigDTO().setActive(active)
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(getDateTimeFromString(updatedAt));

	}

	public void shouldConvertFXOInterPortfolioConfigDTOModelConverter() {

		// given
		String interPortfolio_1 = "PORT 1";
		String updatedBy_1 = "SPL USER";
		String updatedAt_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1, updatedBy_1, updatedAt_1, active_1);

		// when

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel = fxoInterPortfolioConfigDTOModelConverter
				.toModel(fxoInterPortfolioConfigDTO_1);

		// then
		assertThat(fxoInterPortfolioConfigModel).isNotNull();

		String interPortfolio_2 = "PORT 2";
		String updatedBy_2 = "SPL USER";
		String updatedAt_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_2, updatedBy_2, updatedAt_2, active_2);

		List<FXOInterPortfolioConfigDTO> portfolioConfigDTOs = Arrays.asList(
				fxoInterPortfolioConfigDTO_1, fxoInterPortfolioConfigDTO_2);

		// when
		List<FXOInterPortfolioConfigModel> portfolioConfigModels = fxoInterPortfolioConfigDTOModelConverter
				.toModels(portfolioConfigDTOs);

		// then
		assertThat(portfolioConfigModels).isNotNull();
		assertThat(portfolioConfigModels).isNotEmpty();
		assertThat(portfolioConfigModels.size()).isEqualTo(
				portfolioConfigDTOs.size());

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1 = portfolioConfigModels
				.get(0);

		assertThat(fxoInterPortfolioConfigModel_1).isNotNull();

		assertThat(fxoInterPortfolioConfigModel_1.getInterPortfolio())
				.isEqualTo(interPortfolio_1);

		assertThat(fxoInterPortfolioConfigModel_1.getUpdatedBy()).isEqualTo(
				updatedBy_1);

		assertThat(fxoInterPortfolioConfigModel_1.getUpdatedAt()).isEqualTo(
				getDateTimeFromString(updatedAt_1));

		assertThat(fxoInterPortfolioConfigModel_1.getActive()).isEqualTo(
				active_1);

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_2 = portfolioConfigModels
				.get(1);

		assertThat(fxoInterPortfolioConfigModel_2).isNotNull();

		assertThat(fxoInterPortfolioConfigModel_2.getInterPortfolio())
				.isEqualTo(interPortfolio_2);

		assertThat(fxoInterPortfolioConfigModel_2.getUpdatedBy()).isEqualTo(
				updatedBy_2);

		assertThat(fxoInterPortfolioConfigModel_2.getUpdatedAt()).isEqualTo(
				getDateTimeFromString(updatedAt_2));

		assertThat(fxoInterPortfolioConfigModel_2.getActive()).isEqualTo(
				active_2);

	}
}
