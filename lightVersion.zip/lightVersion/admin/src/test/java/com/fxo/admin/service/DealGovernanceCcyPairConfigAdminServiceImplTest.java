package com.fxo.admin.service;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.springframework.test.util.ReflectionTestUtils;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.dto.converter.CurrencyPairConfigSourceTargetDTOConverter;
import com.fxo.admin.dto.converter.DealGovCcyPairConfigSourceTargetDTOConverter;
import com.fxo.admin.dto.converter.DealGovernanceConfigCcyPairDTOEntityConverter;
import com.fxo.admin.util.FXOAdminTestUtil;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.CurrencyDTO;
import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.api.dto.FXODealGovernanceParametersCcyPairDTO;
import com.fxo.api.dto.FXODealGovernanceParametersDTO;
import com.fxo.api.dto.FXOProductCatalogueDTO;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXODealGovernanceParametersCcyPairService;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.dealing.Directions;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.constants.dealing.Products;
import com.fxo.dao.entity.Currency;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.dao.entity.FXODealGovernanceParametersCcyPair;
import com.fxo.dao.entity.FXOProductCatalogue;
import com.fxo.dao.repository.CurrencyPairRepository;
import com.fxo.dao.repository.FXODealGovernanceParametersCcyPairRepository;
import com.fxo.dao.repository.FXODealGovernanceParametersRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.rest.converter.BarrierDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.CurrencyHedgeDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.DealGovernanceConfigListModelConveter;
import com.fxo.rest.converter.DeltaAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.DeltaPercentDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.InvestmentAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.MarginAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.RawPremiumDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.StealthDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.TenorDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.VegaDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.VolatilityDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.model.DealGovernanceConfigListModel;

/**
 * @author lakshmikanth
 *
 */
@Test
@ContextConfiguration(locations = { "classpath:test-fxo-service.xml" })
public class DealGovernanceCcyPairConfigAdminServiceImplTest extends
		AbstractTestNGSpringContextTests {

	@Mock
	IFXODealGovernanceParametersCcyPairService fxoDealGovernanceParametersCcyPairService;

	@Mock
	IDealGovernanceConfigAdminService dealGovernanceConfigAdminService;

	@Mock
	ICurrencyPairService currencyPairService;

	@Mock
	IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@Mock
	CurrencyPairRepository currencyPairRepository;

	@Mock
	FXODealGovernanceParametersRepository fxoDealGovernanceParametersRepository;

	@Mock
	FXODealGovernanceParametersCcyPairRepository fxoDealGovernanceParametersCcyPairRepository;

	@Autowired
	CurrencyPairConfigSourceTargetDTOConverter currencyPairConfigSourceTargetDTOConverter;

	@Autowired
	DealGovCcyPairConfigSourceTargetDTOConverter dealGovCcyPairConfigSourceTargetDTOConverter;

	@Autowired
	DealGovernanceConfigCcyPairDTOEntityConverter dealGovernanceConfigCcyPairDTOEntityConverter;

	@Autowired
	private com.fxo.framework.core.spring.web.MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

	@Autowired
	DealGovernanceConfigListModelConveter dealGovernanceConfigListModelConveter;

	@Autowired
	InvestmentAmountDealGovernanceConfigDTOModelConverter investmentAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	MarginAmountDealGovernanceConfigDTOModelConverter marginAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	DeltaAmountDealGovernanceConfigDTOModelConverter deltaAmountDealGovernanceConfigDTOModelConverter;

	@Autowired
	DeltaPercentDealGovernanceConfigDTOModelConverter deltaPercentDealGovernanceConfigDTOModelConverter;

	@Autowired
	VegaDealGovernanceConfigDTOModelConverter vegaDealGovernanceConfigDTOModelConverter;

	@Autowired
	VolatilityDealGovernanceConfigDTOModelConverter volatilityDealGovernanceConfigDTOModelConverter;

	@Autowired
	StealthDealGovernanceConfigDTOModelConverter stealthDealGovernanceConfigDTOModelConverter;

	@Autowired
	RawPremiumDealGovernanceConfigDTOModelConverter rawPremiumDealGovernanceConfigDTOModelConverter;

	@Autowired
	CurrencyHedgeDealGovernanceConfigDTOModelConverter currencyHedgeDealGovernanceConfigDTOModelConverter;

	@Autowired
	TenorDealGovernanceConfigDTOModelConverter tenorDealGovernanceConfigDTOModelConverter;

	@Autowired
	BarrierDealGovernanceConfigDTOModelConverter barrierDealGovernanceConfigDTOModelConverter;

	@Autowired
	com.fxo.rest.converter.DealGovernanceConfigDTOModelConverterFactoryImpl dealGovernanceConfigDTOModelConverterFactory;

	@InjectMocks
	DealGovernanceCcyPairConfigAdminServiceImpl dealGovernanceCcyPairConfigAdminServiceImpl;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

		ReflectionTestUtils.setField(
				dealGovernanceCcyPairConfigAdminServiceImpl,
				"dealGovCcyPairConfigSourceTargetDTOConverter",
				dealGovCcyPairConfigSourceTargetDTOConverter);

		ReflectionTestUtils.setField(
				dealGovernanceCcyPairConfigAdminServiceImpl,
				"dealGovernanceConfigCcyPairDTOEntityConverter",
				dealGovernanceConfigCcyPairDTOEntityConverter);

		ReflectionTestUtils.setField(
				dealGovernanceCcyPairConfigAdminServiceImpl,
				"currencyPairConfigSourceTargetDTOConverter",
				currencyPairConfigSourceTargetDTOConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"investmentAmountDealGovernanceConfigDTOModelConverter",
				investmentAmountDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"marginAmountDealGovernanceConfigDTOModelConverter",
				marginAmountDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"deltaAmountDealGovernanceConfigDTOModelConverter",
				deltaAmountDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"deltaPercentDealGovernanceConfigDTOModelConverter",
				deltaPercentDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"vegaDealGovernanceConfigDTOModelConverter",
				vegaDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"volatilityDealGovernanceConfigDTOModelConverter",
				volatilityDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"stealthDealGovernanceConfigDTOModelConverter",
				stealthDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"rawPremiumDealGovernanceConfigDTOModelConverter",
				rawPremiumDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"currencyHedgeDealGovernanceConfigDTOModelConverter",
				currencyHedgeDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"tenorDealGovernanceConfigDTOModelConverter",
				tenorDealGovernanceConfigDTOModelConverter);

		ReflectionTestUtils.setField(
				dealGovernanceConfigDTOModelConverterFactory,
				"barrierDealGovernanceConfigDTOModelConverter",
				barrierDealGovernanceConfigDTOModelConverter);

	}

	private DealGovernanceConfigDTO getADealGovernanceConfigDTO(
			List<CodeValueDTO> hierarchy, String product,
			String validationCode, String direction, String minimum,
			String maximum, String minimumPercent, String maximumPercent,
			String updatedBy, DateTime updatedAt, Boolean active) {

		DealGovernanceConfigDTO dealGovernanceConfigDTO = new DealGovernanceConfigDTO();

		dealGovernanceConfigDTO.setActive(active).setHierarchy(hierarchy)
				.setValidationCode(validationCode).setProduct(product)
				.setDirection(direction).setMinimum(minimum)
				.setMaximum(maximum).setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent).setUpdatedBy(updatedBy)
				.setUpdatedAt(updatedAt);

		return dealGovernanceConfigDTO;
	}

	private FXOProductCatalogue getAFXOProductCatalogue(String product,
			String optionType) {

		return new FXOProductCatalogue().setProduct(product).setOptionType(
				optionType);
	}

	private FXOProductCatalogueDTO getAFXOProductCatalogueDTO(String product,
			String optionType) {

		return new FXOProductCatalogueDTO().setProduct(product).setOptionType(
				optionType);
	}

	private FXODealGovernanceParametersCcyPair getAFXODealGovernanceParametersCcyPair(
			String product, String optionType, String validationCode,
			int legCount, String currency, String counterCurrency,
			String direction, String minimum, String maximum,
			BigDecimal minimumPercent, BigDecimal maximumPercent,
			String createdBy, Timestamp createdDate, String lastUpdatedBy,
			Timestamp lastUpdatedDate, String active) {

		FXODealGovernanceParametersCcyPair fxoDealGovernanceParametersCcyPair = new FXODealGovernanceParametersCcyPair();

		FXODealGovernanceParameters fxoDealGovernanceParameters = getAFXODealGovernanceParameters(
				null, null, null, legCount, null, null, null, null, null, null,
				null, null, null, null).setValidationCode(validationCode)
				.setFxoProductCatalogue(
						getAFXOProductCatalogue(product, optionType));

		fxoDealGovernanceParametersCcyPair
				.setFxoDealGovernanceParameters(fxoDealGovernanceParameters)
				.setCurrencyPair(
						getACurrencyPair(currency, counterCurrency,
								lastUpdatedBy, lastUpdatedDate))
				.setDirection(direction)
				.setMinimum(minimum)
				.setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent)
				.setActive(active)
				.setValidateInDealGovernanceService(
						BooleanCodes.BooleanCodes_True).setCreatedBy(createdBy)
				.setCreatedDate(createdDate).setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedDate);

		return fxoDealGovernanceParametersCcyPair;
	}

	private FXODealGovernanceParameters getAFXODealGovernanceParameters(
			String product, String optionType, String validationCode,
			int legCount, String direction, String minimum, String maximum,
			BigDecimal minimumPercent, BigDecimal maximumPercent,
			String createdBy, Timestamp createdDate, String lastUpdatedBy,
			Timestamp lastUpdatedDate, String active) {

		FXODealGovernanceParameters fxoDealGovernanceParameters = new FXODealGovernanceParameters();

		fxoDealGovernanceParameters
				.setFxoProductCatalogue(
						getAFXOProductCatalogue(product, optionType))
				.setValidationCode(validationCode)
				.setLegCount(legCount)
				.setDirection(direction)
				.setMinimum(minimum)
				.setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent)
				.setActive(active)
				.setValidateInDealGovernanceService(
						BooleanCodes.BooleanCodes_True).setCreatedBy(createdBy)
				.setCreatedDate(createdDate).setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedDate);

		return fxoDealGovernanceParameters;
	}

	private FXODealGovernanceParametersDTO getAFXODealGovernanceParametersDTO(
			String product, String optionType, String validationCode,
			String direction, String minimum, String maximum,
			BigDecimal minimumPercent, BigDecimal maximumPercent,
			String createdBy, Timestamp createdDate, String lastUpdatedBy,
			Timestamp lastUpdatedDate, String active) {

		FXODealGovernanceParametersDTO fxoDealGovernanceParametersDTO = new FXODealGovernanceParametersDTO();

		fxoDealGovernanceParametersDTO
				.setFxoProductCatalogue(
						getAFXOProductCatalogueDTO(product, optionType))
				.setValidationCode(validationCode)
				.setDirection(direction)
				.setMinimum(minimum)
				.setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent)
				.setActive(active)
				.setValidateInDealGovernanceService(
						BooleanCodes.BooleanCodes_True).setCreatedBy(createdBy)
				.setCreatedDate(createdDate).setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedDate);

		return fxoDealGovernanceParametersDTO;
	}

	private FXODealGovernanceParametersCcyPairDTO getAFXODealGovernanceParametersCcyPairDTO(
			String product, String optionType, String validationCode,
			String currency, String counterCurrency, String direction,
			String minimum, String maximum, BigDecimal minimumPercent,
			BigDecimal maximumPercent, String createdBy, Timestamp createdDate,
			String lastUpdatedBy, Timestamp lastUpdatedDate, String active) {

		FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO = new FXODealGovernanceParametersCcyPairDTO();

		FXODealGovernanceParametersDTO fxoDealGovernanceParametersDTO = getAFXODealGovernanceParametersDTO(
				null, null, null, null, null, null, null, null, null, null,
				null, null, null).setValidationCode(validationCode)
				.setFxoProductCatalogue(
						getAFXOProductCatalogueDTO(product, optionType));

		fxoDealGovernanceParametersCcyPairDTO
				.setFxoDealGovernanceParameters(fxoDealGovernanceParametersDTO)
				.setCurrencyPair(
						getACurrencyPairDTO(currency, counterCurrency,
								lastUpdatedBy, lastUpdatedDate))
				.setDirection(direction)
				.setMinimum(minimum)
				.setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent)
				.setActive(active)
				.setValidateInDealGovernanceService(
						BooleanCodes.BooleanCodes_True).setCreatedBy(createdBy)
				.setCreatedDate(createdDate).setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedDate);

		return fxoDealGovernanceParametersCcyPairDTO;
	}

	private CodeValueDTO getACodeValueDTO(String code, String value) {
		return new CodeValueDTO().setCode(code).setValue(value);
	}

	private CurrencyPairConfigDTO getACurrencyPairConfigDTO(String currency,
			String counterCurrency, String updatedBy, DateTime updatedAt) {
		return new CurrencyPairConfigDTO().setCurrency(currency)
				.setCounterCurrency(counterCurrency).setUpdatedAt(updatedAt)
				.setUpdatedBy(updatedBy);
	}

	private CurrencyPairDTO getACurrencyPairDTO(String currency,
			String counterCurrency, String updatedBy, Timestamp updatedAt) {
		CurrencyPairDTO currencyPairDTO = new CurrencyPairDTO().setCurrency(
				getACurrencyDTO(currency)).setCounterCurrency(
				getACurrencyDTO(counterCurrency));

		currencyPairDTO.setLastUpdatedBy(updatedBy).setLastUpdatedDate(
				updatedAt);

		return currencyPairDTO;
	}

	private CurrencyPair getACurrencyPair(String currency,
			String counterCurrency, String updatedBy, Timestamp updatedAt) {
		CurrencyPair currencyPair = new CurrencyPair().setCurrency(
				getACurrency(currency)).setCounterCurrency(
				getACurrency(counterCurrency));

		currencyPair.setLastUpdatedBy(updatedBy).setLastUpdatedDate(updatedAt);

		return currencyPair;
	}

	private Currency getACurrency(String currency) {
		return new Currency().setCurrency(currency);
	}

	private CurrencyDTO getACurrencyDTO(String currency) {
		return new CurrencyDTO().setCurrency(currency);
	}

	public void verifyIsCurrencyPairCustomizedForDealGovernance() {

		String currency = "EUR";
		String counterCurrency = "USD";

		// given
		BDDMockito.given(
				fxoDealGovernanceParametersCcyPairService
						.isDealGovernanceCustomizedForCurrencyPair(currency,
								counterCurrency)).willReturn(Boolean.TRUE);

		// when
		Boolean isCustomized = dealGovernanceCcyPairConfigAdminServiceImpl
				.isCurrencyPairCustomizedForDealGovernance(currency,
						counterCurrency);

		// then
		Assertions.assertThat(isCustomized).isTrue();
	}

	public void shouldGetDealGovernanceConfigListByCurrencyPair() {

		String currency = "EUR";
		String counterCurrency = "USD";
		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_1 = Products.PRODUCT_VANILLA;
		String direction_1 = null;
		String minimum_1 = "200000";
		String maximum_1 = "10000000";
		String createdBy_1 = "SYS";
		Timestamp createdDate_1 = Timestamp.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_1 = "SGTrader";
		Timestamp lastUpdatedDate_1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_1 = new DateTime("2016-01-14T14:48:15.987");
		String active_1 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO_1 = getAFXODealGovernanceParametersCcyPairDTO(
				product_1, null, validationCode, currency, counterCurrency,
				direction_1, minimum_1, maximum_1, null, null, createdBy_1,
				createdDate_1, lastUpdatedBy_1, lastUpdatedDate_1, active_1);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_1 = getADealGovernanceConfigDTO(
				null, product_1, validationCode, direction_1, minimum_1,
				maximum_1, null, null, lastUpdatedBy_1, lastUpdatedDateTime_1,
				Boolean.valueOf(active_1));

		List<CodeValueDTO> hierarchy_VANILLA = new ArrayList<CodeValueDTO>();

		String groupCode_VANILLA = ProductGroups.PRODUCT_GROUP_VANILLA;

		String groupCodeDescription_VANILLA = "Vanilla";
		CodeValueDTO codeValueDTO_VANILLA = getACodeValueDTO(groupCode_VANILLA,
				groupCodeDescription_VANILLA);

		hierarchy_VANILLA.add(codeValueDTO_VANILLA);

		String groupCode_SO = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_SO = "Simple Option";
		CodeValueDTO codeValueDTO_SO = getACodeValueDTO(groupCode_SO,
				groupCodeDescription_SO);

		hierarchy_VANILLA.add(codeValueDTO_SO);

		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_1)).willReturn(
				hierarchy_VANILLA);

		String product_2 = Products.PRODUCT_KNOCKIN;
		String direction_2 = null;
		String minimum_2 = "300000";
		String maximum_2 = "11000000";
		String createdBy_2 = "SYS";
		Timestamp createdDate_2 = Timestamp.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_2 = "SGTrader";
		Timestamp lastUpdatedDate_2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_2 = new DateTime("2016-01-14T14:48:15.987");
		String active_2 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO_2 = getAFXODealGovernanceParametersCcyPairDTO(
				product_2, null, validationCode, currency, counterCurrency,
				direction_2, minimum_2, maximum_2, null, null, createdBy_2,
				createdDate_2, lastUpdatedBy_2, lastUpdatedDate_2, active_2);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_2 = getADealGovernanceConfigDTO(
				null, product_2, validationCode, direction_2, minimum_2,
				maximum_2, null, null, lastUpdatedBy_2, lastUpdatedDateTime_2,
				Boolean.valueOf(active_2));

		// KI

		List<CodeValueDTO> hierarchy_KI = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet_KI = ProductGroups.PRODUCT_GROUP_KI;

		String groupCodeDescription_KI = "KnockIn";
		CodeValueDTO codeValueDTO_KI = getACodeValueDTO(groupCode_ParamSet_KI,
				groupCodeDescription_KI);

		hierarchy_KI.add(codeValueDTO_KI);

		String groupCode_KI_KO = ProductGroups.PRODUCT_GROUP_KI_KO;
		String groupCodeDescription_KI_KO = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_KI_KO = getACodeValueDTO(groupCode_KI_KO,
				groupCodeDescription_KI_KO);

		hierarchy_KI.add(codeValueDTO_KI_KO);

		String groupCode_Exotic = ProductGroups.PRODUCT_GROUP_EXOTIC_OPTION;
		String groupCodeDescription_Exotic = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_Exotic = getACodeValueDTO(groupCode_Exotic,
				groupCodeDescription_Exotic);

		hierarchy_KI.add(codeValueDTO_Exotic);

		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_2)).willReturn(
				hierarchy_KI);

		List<FXODealGovernanceParametersCcyPairDTO> fxoDealGovernanceParametersCcyPairDTOs = Arrays
				.asList(fxoDealGovernanceParametersCcyPairDTO_1,
						fxoDealGovernanceParametersCcyPairDTO_2);

		BDDMockito
				.when(fxoDealGovernanceParametersCcyPairService
						.getAllDealGovernanceParametersCcyPairByValidationCodeAndCurrencyPair(
								validationCode, currency, counterCurrency))
				.thenReturn(fxoDealGovernanceParametersCcyPairDTOs);

		// when
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.getDealGovernanceConfigListByCurrencyPair(validationCode,
						currency, counterCurrency);

		// prepare expected values
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Expected = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_Expected.add(dealGovernanceConfigDTO_1
				.setHierarchy(hierarchy_VANILLA));
		dealGovernanceConfigDTOs_Expected.add(dealGovernanceConfigDTO_2
				.setHierarchy(hierarchy_KI));

		// then
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual).isNotNull();
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual.size())
				.isEqualTo(dealGovernanceConfigDTOs_Expected.size());
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual).isEqualTo(
				dealGovernanceConfigDTOs_Expected);

	}

	public void shouldGetAllCurrencyPairsCustomizedForDealGovernance() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		String updatedBy_1 = "SGTrader";
		Timestamp sqlUpdatedAt_1 = Timestamp.valueOf("2016-01-14 14:48:15.987");
		DateTime updatedAt_1 = new DateTime("2016-01-14T14:48:15.987");

		CurrencyPairDTO currencyPairDTO_1 = getACurrencyPairDTO(currency_1,
				counterCurrency_1, updatedBy_1, sqlUpdatedAt_1);

		String currency_2 = "GBP";
		String counterCurrency_2 = "SGD";
		String updatedBy_2 = "SGTrader";
		Timestamp sqlUpdatedAt_2 = Timestamp.valueOf("2016-01-14 15:49:15.987");
		DateTime updatedAt_2 = new DateTime("2016-01-14T15:49:15.987");

		CurrencyPairDTO currencyPairDTO_2 = getACurrencyPairDTO(currency_2,
				counterCurrency_2, updatedBy_2, sqlUpdatedAt_2);

		BDDMockito
				.when(fxoDealGovernanceParametersCcyPairService
						.getAllUniqueCurrencyPairsCustomizedForDealGovernance())
				.thenReturn(Arrays.asList(currencyPairDTO_1, currencyPairDTO_2));

		// when
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = dealGovernanceCcyPairConfigAdminServiceImpl
				.getAllCurrencyPairsCustomizedForDealGovernance();

		// prepare expected Data

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, updatedBy_1, updatedAt_1);

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, updatedBy_2, updatedAt_2);

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Expected = Arrays
				.asList(currencyPairConfigDTO_1, currencyPairConfigDTO_2);

		// then
		Assertions.assertThat(currencyPairConfigDTOs).isNotNull();
		Assertions.assertThat(currencyPairConfigDTOs).isNotEmpty();
		Assertions.assertThat(currencyPairConfigDTOs).isEqualTo(
				currencyPairConfigDTOs_Expected);
	}

	public void shouldGetAllCurrencyPairsForCustomizationForDealGovernance() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		String updatedBy_1 = "SGTrader";
		Timestamp sqlUpdatedAt_1 = Timestamp.valueOf("2016-01-14 14:48:15.987");

		CurrencyPairDTO currencyPairDTO_1 = getACurrencyPairDTO(currency_1,
				counterCurrency_1, updatedBy_1, sqlUpdatedAt_1);

		String currency_2 = "GBP";
		String counterCurrency_2 = "SGD";
		String updatedBy_2 = "SGTrader";
		Timestamp sqlUpdatedAt_2 = Timestamp.valueOf("2016-01-14 15:49:15.987");

		CurrencyPairDTO currencyPairDTO_2 = getACurrencyPairDTO(currency_2,
				counterCurrency_2, updatedBy_2, sqlUpdatedAt_2);

		BDDMockito
				.when(fxoDealGovernanceParametersCcyPairService
						.getAllUniqueCurrencyPairsForCustomizationForDealGovernance())
				.thenReturn(Arrays.asList(currencyPairDTO_1, currencyPairDTO_2));

		// when
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs = dealGovernanceCcyPairConfigAdminServiceImpl
				.getAllCurrencyPairsForCustomizationForDealGovernance();

		// prepare expected Data

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, null, null);

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, null, null);

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Expected = Arrays
				.asList(currencyPairConfigDTO_1, currencyPairConfigDTO_2);

		// then
		Assertions.assertThat(currencyPairConfigDTOs).isNotNull();
		Assertions.assertThat(currencyPairConfigDTOs).isNotEmpty();
		Assertions.assertThat(currencyPairConfigDTOs).isEqualTo(
				currencyPairConfigDTOs_Expected);
	}

	public void shouldFetchDealGovernanceParametersForCustomization() {

		String currency = "EUR";
		String counterCurrency = "USD";
		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_1 = Products.PRODUCT_VANILLA;
		String direction_1 = null;
		String minimum_1 = "200000";
		String maximum_1 = "10000000";
		String createdBy_1 = "SYS";
		Timestamp createdDate_1 = Timestamp.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_1 = "SGTrader";
		Timestamp lastUpdatedDate_1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_1 = new DateTime("2016-01-14T14:48:15.987");
		String active_1 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO_1 = getAFXODealGovernanceParametersCcyPairDTO(
				product_1, null, validationCode, currency, counterCurrency,
				direction_1, minimum_1, maximum_1, null, null, createdBy_1,
				createdDate_1, lastUpdatedBy_1, lastUpdatedDate_1, active_1);

		List<CodeValueDTO> hierarchy_VANILLA = new ArrayList<CodeValueDTO>();

		String groupCode_VANILLA = ProductGroups.PRODUCT_GROUP_VANILLA;

		String groupCodeDescription_VANILLA = "Vanilla";
		CodeValueDTO codeValueDTO_VANILLA = getACodeValueDTO(groupCode_VANILLA,
				groupCodeDescription_VANILLA);

		hierarchy_VANILLA.add(codeValueDTO_VANILLA);

		String groupCode_SO = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_SO = "Simple Option";
		CodeValueDTO codeValueDTO_SO = getACodeValueDTO(groupCode_SO,
				groupCodeDescription_SO);

		hierarchy_VANILLA.add(codeValueDTO_SO);

		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_1)).willReturn(
				hierarchy_VANILLA);

		String product_2 = Products.PRODUCT_KNOCKIN;
		String direction_2 = null;
		String minimum_2 = "300000";
		String maximum_2 = "11000000";
		String createdBy_2 = "SYS";
		Timestamp createdDate_2 = Timestamp.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_2 = "SGTrader";
		Timestamp lastUpdatedDate_2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_2 = new DateTime("2016-01-14T14:48:15.987");
		String active_2 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParametersCcyPairDTO fxoDealGovernanceParametersCcyPairDTO_2 = getAFXODealGovernanceParametersCcyPairDTO(
				product_2, null, validationCode, currency, counterCurrency,
				direction_2, minimum_2, maximum_2, null, null, createdBy_2,
				createdDate_2, lastUpdatedBy_2, lastUpdatedDate_2, active_2);

		// KI

		List<CodeValueDTO> hierarchy_KI = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet_KI = ProductGroups.PRODUCT_GROUP_KI;

		String groupCodeDescription_KI = "KnockIn";
		CodeValueDTO codeValueDTO_KI = getACodeValueDTO(groupCode_ParamSet_KI,
				groupCodeDescription_KI);

		hierarchy_KI.add(codeValueDTO_KI);

		String groupCode_KI_KO = ProductGroups.PRODUCT_GROUP_KI_KO;
		String groupCodeDescription_KI_KO = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_KI_KO = getACodeValueDTO(groupCode_KI_KO,
				groupCodeDescription_KI_KO);

		hierarchy_KI.add(codeValueDTO_KI_KO);

		String groupCode_Exotic = ProductGroups.PRODUCT_GROUP_EXOTIC_OPTION;
		String groupCodeDescription_Exotic = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_Exotic = getACodeValueDTO(groupCode_Exotic,
				groupCodeDescription_Exotic);

		hierarchy_KI.add(codeValueDTO_Exotic);

		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_2)).willReturn(
				hierarchy_KI);

		List<FXODealGovernanceParametersCcyPairDTO> fxoDealGovernanceParametersCcyPairDTOs = Arrays
				.asList(fxoDealGovernanceParametersCcyPairDTO_1,
						fxoDealGovernanceParametersCcyPairDTO_2);

		BDDMockito
				.when(fxoDealGovernanceParametersCcyPairService
						.getAllDealGovernanceParametersCcyPairByValidationCodeAndCurrencyPair(
								validationCode, currency, counterCurrency))
				.thenReturn(fxoDealGovernanceParametersCcyPairDTOs);

		// expected data

		DealGovernanceConfigDTO dealGovernanceConfigDTO_1 = getADealGovernanceConfigDTO(
				hierarchy_VANILLA, product_1, validationCode, direction_1,
				minimum_1, maximum_1, null, null, lastUpdatedBy_1,
				lastUpdatedDateTime_1, Boolean.valueOf(active_1));

		DealGovernanceConfigDTO dealGovernanceConfigDTO_2 = getADealGovernanceConfigDTO(
				hierarchy_KI, product_2, validationCode, direction_2,
				minimum_2, maximum_2, null, null, lastUpdatedBy_2,
				lastUpdatedDateTime_2, Boolean.valueOf(active_2));

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Expected = Arrays
				.asList(dealGovernanceConfigDTO_1, dealGovernanceConfigDTO_2);

		// when
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.fetchDealGovernanceParametersForCustomization(validationCode,
						currency, counterCurrency);

		// then
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual).isNotNull();
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual).isNotEmpty();
		Assertions.assertThat(dealGovernanceConfigDTOs_Actual).isEqualTo(
				dealGovernanceConfigDTOs_Expected);

	}

	public void shouldCheckForModification_Identical() {

		// given
		String minimum_dealGovernanceConfigDTO = "10";
		String maximum_dealGovernanceConfigDTO = "20";
		boolean active_dealGovernanceConfigDTO = true;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, null, null, null, minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, null, null,
				active_dealGovernanceConfigDTO);

		String minimum_fxoDealGovernanceParameters = "10";
		String maximum_fxoDealGovernanceParameters = "20";
		String active_fxoDealGovernanceParameters = BooleanCodes.BooleanCodes_True;

		int legCount = 1;

		FXODealGovernanceParametersCcyPair fxoDealGovernanceParametersCcyPair = getAFXODealGovernanceParametersCcyPair(
				null, null, null, legCount, null, null, null,
				minimum_fxoDealGovernanceParameters,
				maximum_fxoDealGovernanceParameters, null, null, null, null,
				null, null, active_fxoDealGovernanceParameters);

		// when
		boolean comparison_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.checkForModification(dealGovernanceConfigDTO,
						fxoDealGovernanceParametersCcyPair);

		// then assertThat(comparison_Actual).isNotNull();
		Assertions.assertThat(comparison_Actual).isFalse();

	}

	public void shouldCheckForModification_Different() {

		// given
		String minimum_dealGovernanceConfigDTO = "10";
		String maximum_dealGovernanceConfigDTO = "20";
		boolean active_dealGovernanceConfigDTO = true;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, null, null, null, minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, null, null,
				active_dealGovernanceConfigDTO);

		String minimum_fxoDealGovernanceParameters = "11";
		String maximum_fxoDealGovernanceParameters = "21";
		String active_fxoDealGovernanceParameters = BooleanCodes.BooleanCodes_False;

		int legCount = 1;

		FXODealGovernanceParametersCcyPair fxoDealGovernanceParametersCcyPair = getAFXODealGovernanceParametersCcyPair(
				null, null, null, legCount, null, null, null,
				minimum_fxoDealGovernanceParameters,
				maximum_fxoDealGovernanceParameters, null, null, null, null,
				null, null, active_fxoDealGovernanceParameters);

		// when
		boolean comparison_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.checkForModification(dealGovernanceConfigDTO,
						fxoDealGovernanceParametersCcyPair);

		// then
		Assertions.assertThat(comparison_Actual).isNotNull();
		Assertions.assertThat(comparison_Actual).isTrue();

	}

	public void shouldFetchFXODealGovernanceParametersEntitiesToUpdate_ExistingEntity() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI;
		String product = Products.PRODUCT_KNOCKIN;
		int legCount = 1;

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;
		String direction = null;

		String minimum_dealGovernanceConfigDTO = "1000000";
		String maximum_dealGovernanceConfigDTO = "2000000";
		boolean active_dealGovernanceConfigDTO = true;
		String updatedBy = "PBAdmin";

		// mock return
		BDDMockito.when(fxoProductCatalogueGroupService.getAllProducts(group))
				.thenReturn(Arrays.asList(product));

		// get an FXODealGovernanceParametersCcypair Entity

		String minimum_dealGovernanceConfigDTO_EntityInDatabase = "900000";
		String maximum_dealGovernanceConfigDTO_EntityInDatabase = "3000000";
		boolean active_dealGovernanceConfigDTO_EntityInDatabase = true;
		String createdBy_EntityInDatabase = "dealer";
		Timestamp createdAt_EntityInDatabase = Timestamp
				.valueOf("2016-05-26 12:12:12");

		FXODealGovernanceParametersCcyPair fxoDealGovernanceParametersCcyPair = getAFXODealGovernanceParametersCcyPair(
				product,
				null,
				validationCode,
				legCount,
				currency,
				counterCurrency,
				direction,
				minimum_dealGovernanceConfigDTO_EntityInDatabase,
				maximum_dealGovernanceConfigDTO_EntityInDatabase,
				null,
				null,
				createdBy_EntityInDatabase,
				createdAt_EntityInDatabase,
				null,
				null,
				BooleanCodes.config
						.get(active_dealGovernanceConfigDTO_EntityInDatabase).value);

		BDDMockito
				.when(fxoDealGovernanceParametersCcyPairRepository
						.getOneDealGovernanceParameterCcyPairByProductAndValidationCodeAndDirection(
								product, validationCode, direction, currency,
								counterCurrency, false)).thenReturn(
						fxoDealGovernanceParametersCcyPair);

		// get input data
		DealGovernanceConfigDTO dealGovernanceConfigDTOInput = getADealGovernanceConfigDTO(
				null, product, validationCode, direction,
				minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, updatedBy, null,
				active_dealGovernanceConfigDTO);

		// when
		List<FXODealGovernanceParametersCcyPair> dealGovernanceParametersCcyPairsEntities_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.fetchFXODealGovernanceParametersEntitiesToUpdate(currency,
						counterCurrency, dealGovernanceConfigDTOInput);

		// then
		Assertions.assertThat(dealGovernanceParametersCcyPairsEntities_Actual)
				.isNotNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.size())
				.isEqualTo(1);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMinimum()).isEqualTo(
				minimum_dealGovernanceConfigDTO);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMinimumPercent()).isNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMaximum()).isEqualTo(
				maximum_dealGovernanceConfigDTO);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMaximumPercent()).isNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedBy()).isEqualTo(updatedBy);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedDate()).isNotNull();
	}

	public void shouldFetchFXODealGovernanceParametersEntitiesToUpdate_NewEntity() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI;
		String product = Products.PRODUCT_KNOCKIN;
		int legCount = 1;
		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;
		String direction = null;

		String minimum_dealGovernanceConfigDTO = "1000000";
		String maximum_dealGovernanceConfigDTO = "2000000";
		boolean active_dealGovernanceConfigDTO = true;
		String updatedBy = "PBAdmin";

		// mock return
		BDDMockito.when(fxoProductCatalogueGroupService.getAllProducts(group))
				.thenReturn(Arrays.asList(product));

		String minimum_GlobaldealGovernanceConfigEntity = "1000000";
		String maximum_GlobalDealGovernanceConfigEntity = "2000000";

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product, validationCode, direction, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product,
								null,
								validationCode,
								legCount,
								direction,
								minimum_GlobaldealGovernanceConfigEntity,
								maximum_GlobalDealGovernanceConfigEntity,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO).value));

		BDDMockito.when(
				currencyPairRepository.getOneCurrencyPair(currency,
						counterCurrency)).thenReturn(
				getACurrencyPair(currency, counterCurrency, null, null));

		// get input data
		DealGovernanceConfigDTO dealGovernanceConfigDTOInput = getADealGovernanceConfigDTO(
				null, product, validationCode, direction,
				minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, updatedBy, null,
				active_dealGovernanceConfigDTO);

		// when
		List<FXODealGovernanceParametersCcyPair> dealGovernanceParametersCcyPairsEntities_Actual = dealGovernanceCcyPairConfigAdminServiceImpl
				.fetchFXODealGovernanceParametersEntitiesToUpdate(currency,
						counterCurrency, dealGovernanceConfigDTOInput);

		// then
		Assertions.assertThat(dealGovernanceParametersCcyPairsEntities_Actual)
				.isNotNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.size())
				.isEqualTo(1);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMinimum()).isEqualTo(
				minimum_dealGovernanceConfigDTO);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMinimumPercent()).isNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMaximum()).isEqualTo(
				maximum_dealGovernanceConfigDTO);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getMaximumPercent()).isNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getCreatedBy()).isEqualTo(updatedBy);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getCreatedDate()).isNotNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedBy()).isEqualTo(updatedBy);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedDate()).isNotNull();
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedBy()).isEqualTo(updatedBy);
		Assertions.assertThat(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getLastUpdatedDate()).isEqualTo(
				dealGovernanceParametersCcyPairsEntities_Actual.get(0)
						.getCreatedDate());
	}

	public void shouldSaveAllDealGovernanceParameters_InitialCustomization()
			throws IOException, URISyntaxException {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String updatedBy = "PBAdmin";

		String product_VANILLA = Products.PRODUCT_VANILLA;
		int legCount_VANILLA = 1;

		BDDMockito
				.when(fxoProductCatalogueGroupService
						.getAllProducts(product_VANILLA)).thenReturn(
						Arrays.asList(product_VANILLA));

		String validationCode_InvtAmt = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;
		String direction_InvtAmt = null;
		boolean active_dealGovernanceConfigDTO_InvtAmt = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_InvtAmt,
								direction_InvtAmt, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_InvtAmt,
								legCount_VANILLA,
								direction_InvtAmt,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_InvtAmt).value));

		String validationCode_DeltaAmt = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;
		String direction_DeltaAmt = null;
		boolean active_dealGovernanceConfigDTO_DeltaAmt = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_DeltaAmt,
								direction_DeltaAmt, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_DeltaAmt,
								legCount_VANILLA,
								direction_DeltaAmt,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_DeltaAmt).value));

		String validationCode_Delta = DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION;
		String direction_Delta = null;
		boolean active_dealGovernanceConfigDTO_Delta = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Delta,
								direction_Delta, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Delta,
								legCount_VANILLA,
								direction_Delta,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Delta).value));

		String validationCode_Vol = DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION;
		String direction_Vol = null;
		boolean active_dealGovernanceConfigDTO_Vol = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Vol,
								direction_Vol, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Vol,
								legCount_VANILLA,
								direction_Vol,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Vol).value));

		String validationCode_Vega = DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION;
		String direction_Vega = null;
		boolean active_dealGovernanceConfigDTO_Vega = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Vega,
								direction_Vega, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Vega,
								legCount_VANILLA,
								direction_Vega,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Vega).value));

		String validationCode_Tenor = DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION;
		String direction_Tenor = null;
		boolean active_dealGovernanceConfigDTO_Tenor = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Tenor,
								direction_Tenor, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Tenor,
								legCount_VANILLA,
								direction_Tenor,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Tenor).value));

		String validationCode_Stealth = DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION;
		String direction_Stealth = null;
		boolean active_dealGovernanceConfigDTO_Stealth = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Stealth,
								direction_Stealth, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Stealth,
								legCount_VANILLA,
								direction_Stealth,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Stealth).value));

		String validationCode_Margin = DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION;
		String direction_Margin = null;
		boolean active_dealGovernanceConfigDTO_Margin = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Margin,
								direction_Margin, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Margin,
								legCount_VANILLA,
								direction_Margin,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Margin).value));

		String validationCode_CcyHedge = DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION;
		String direction_CcyHedge = null;
		boolean active_dealGovernanceConfigDTO_CcyHedge = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_CcyHedge,
								direction_CcyHedge, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_CcyHedge,
								legCount_VANILLA,
								direction_CcyHedge,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_CcyHedge).value));

		String validationCode_Premium = DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION;
		String direction_Premium_Buy = Directions.DIRECTION_BUY;
		boolean active_dealGovernanceConfigDTO_Premium_Buy = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Premium,
								direction_Premium_Buy, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Premium,
								legCount_VANILLA,
								direction_Premium_Buy,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Premium_Buy).value));

		String direction_Premium_Sell = Directions.DIRECTION_SELL;
		boolean active_dealGovernanceConfigDTO_Premium_Sell = true;

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Premium,
								direction_Premium_Sell, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Premium,
								legCount_VANILLA,
								direction_Premium_Sell,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Premium_Sell).value));

		// global Barrier Validation

		String validationCode_Barrier = DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION;
		String direction_Barrier = null;
		String minimum_dealGovernanceConfigDTO_Barrier = null;
		String maximum_dealGovernanceConfigDTO_Barrier = null;
		boolean active_dealGovernanceConfigDTO_Barrier = true;

		BDDMockito
				.when(dealGovernanceConfigAdminService
						.getDealGovernanceParametersConfiguration(validationCode_Barrier))
				.thenReturn(
						Arrays.asList(getADealGovernanceConfigDTO(null,
								product_VANILLA, validationCode_Barrier,
								direction_Barrier,
								minimum_dealGovernanceConfigDTO_Barrier,
								maximum_dealGovernanceConfigDTO_Barrier, null,
								null, null, null,
								active_dealGovernanceConfigDTO_Barrier)));

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_Barrier,
								direction_Barrier, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_Barrier,
								legCount_VANILLA,
								direction_Barrier,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_Barrier).value));

		// global midvol Validation

		String validationCode_midVol = DealValidationCodes.DEAL_GOVERNANCE_MID_VOL_VALIDATION;
		String direction_midVol = null;
		String minimum_dealGovernanceConfigDTO_midVol = null;
		String maximum_dealGovernanceConfigDTO_midVol = null;
		boolean active_dealGovernanceConfigDTO_midVol = true;

		BDDMockito
				.when(dealGovernanceConfigAdminService
						.getDealGovernanceParametersConfiguration(validationCode_midVol))
				.thenReturn(
						Arrays.asList(getADealGovernanceConfigDTO(null,
								product_VANILLA, validationCode_midVol,
								direction_midVol,
								minimum_dealGovernanceConfigDTO_midVol,
								maximum_dealGovernanceConfigDTO_midVol, null,
								null, null, null,
								active_dealGovernanceConfigDTO_midVol)));

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_midVol,
								direction_midVol, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_midVol,
								legCount_VANILLA,
								direction_midVol,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_midVol).value));

		// global client-Amount Validation

		String validationCode_ClientAmount = DealValidationCodes.DEAL_GOVERNANCE_CLIENT_AMOUNT_VALIDATION;
		String direction_ClientAmount = null;
		String minimum_dealGovernanceConfigDTO_ClientAmount = null;
		String maximum_dealGovernanceConfigDTO_ClientAmount = null;
		boolean active_dealGovernanceConfigDTO_ClientAmount = true;

		BDDMockito
				.when(dealGovernanceConfigAdminService
						.getDealGovernanceParametersConfiguration(validationCode_ClientAmount))
				.thenReturn(
						Arrays.asList(getADealGovernanceConfigDTO(null,
								product_VANILLA, validationCode_ClientAmount,
								direction_ClientAmount,
								minimum_dealGovernanceConfigDTO_ClientAmount,
								maximum_dealGovernanceConfigDTO_ClientAmount,
								null, null, null, null,
								active_dealGovernanceConfigDTO_ClientAmount)));

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_ClientAmount,
								direction_ClientAmount, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_ClientAmount,
								legCount_VANILLA,
								direction_ClientAmount,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_ClientAmount).value));

		// global currencypair Validation

		String validationCode_CurrencyPair = DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_PAIR_VALIDATION;
		String direction_CurrencyPair = null;
		String minimum_dealGovernanceConfigDTO_CurrencyPair = null;
		String maximum_dealGovernanceConfigDTO_CurrencyPair = null;
		boolean active_dealGovernanceConfigDTO_CurrencyPair = true;

		BDDMockito
				.when(dealGovernanceConfigAdminService
						.getDealGovernanceParametersConfiguration(validationCode_CurrencyPair))
				.thenReturn(
						Arrays.asList(getADealGovernanceConfigDTO(null,
								product_VANILLA, validationCode_CurrencyPair,
								direction_CurrencyPair,
								minimum_dealGovernanceConfigDTO_CurrencyPair,
								maximum_dealGovernanceConfigDTO_CurrencyPair,
								null, null, null, null,
								active_dealGovernanceConfigDTO_CurrencyPair)));

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA, validationCode_CurrencyPair,
								direction_CurrencyPair, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_CurrencyPair,
								legCount_VANILLA,
								direction_CurrencyPair,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_CurrencyPair).value));

		// global holidaycalendar Validation

		String validationCode_HolidayCalendar = DealValidationCodes.DEAL_GOVERNANCE_HOLIDAY_CALENDAR_VALIDATION;
		String direction_HolidayCalendar = null;
		String minimum_dealGovernanceConfigDTO_HolidayCalendar = null;
		String maximum_dealGovernanceConfigDTO_HolidayCalendar = null;
		boolean active_dealGovernanceConfigDTO_HolidayCalendar = true;

		BDDMockito
				.when(dealGovernanceConfigAdminService
						.getDealGovernanceParametersConfiguration(validationCode_HolidayCalendar))
				.thenReturn(
						Arrays.asList(getADealGovernanceConfigDTO(
								null,
								product_VANILLA,
								validationCode_HolidayCalendar,
								direction_HolidayCalendar,
								minimum_dealGovernanceConfigDTO_HolidayCalendar,
								maximum_dealGovernanceConfigDTO_HolidayCalendar,
								null, null, null, null,
								active_dealGovernanceConfigDTO_HolidayCalendar)));

		BDDMockito
				.when(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_VANILLA,
								validationCode_HolidayCalendar,
								direction_HolidayCalendar, false))
				.thenReturn(
						getAFXODealGovernanceParameters(
								product_VANILLA,
								null,
								validationCode_HolidayCalendar,
								legCount_VANILLA,
								direction_HolidayCalendar,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								null,
								BooleanCodes.config
										.get(active_dealGovernanceConfigDTO_HolidayCalendar).value));

		BDDMockito.when(
				currencyPairRepository.getOneCurrencyPair(currency,
						counterCurrency)).thenReturn(
				getACurrencyPair(currency, counterCurrency, null, null));

		// prepare a DealGovernanceConfigListDTO from JSON

		String dealGovernanceConfigListModel_JSON = FXOAdminTestUtil
				.readFile("dealGovernanceConfigListModel_JSON.txt");

		DealGovernanceConfigListModel dealGovernanceConfigListModel = mappingJackson2HttpMessageConverter
				.getObjectMapper().readValue(
						dealGovernanceConfigListModel_JSON,
						DealGovernanceConfigListModel.class);

		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceConfigListModelConveter
				.translateDealGovernanceConfigModelToDTOObject(dealGovernanceConfigListModel);

		dealGovernanceConfigListDTO.setUpdatedBy(updatedBy);

		// when
		dealGovernanceCcyPairConfigAdminServiceImpl
				.saveAllDealGovernanceParameters(
						getACurrencyPairConfigDTO(currency, counterCurrency,
								null, null), dealGovernanceConfigListDTO);

	}

	public void shouldDelete_ExistingCustomization() throws IOException,
			URISyntaxException {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";

		BDDMockito.when(
				fxoDealGovernanceParametersCcyPairService
						.isDealGovernanceCustomizedForCurrencyPair(currency,
								counterCurrency)).thenReturn(Boolean.TRUE);

		BDDMockito
				.willDoNothing()
				.given(fxoDealGovernanceParametersCcyPairService)
				.deleteDealGovernanceParametersCcyPairs(currency,
						counterCurrency);

		// when
		dealGovernanceCcyPairConfigAdminServiceImpl
				.deleteCurrencyPairCustomizationForDealGovernance(currency,
						counterCurrency);

		// then
		BDDMockito.verify(fxoDealGovernanceParametersCcyPairService,
				Mockito.times(1)).deleteDealGovernanceParametersCcyPairs(
				currency, counterCurrency);

		BDDMockito.verify(fxoDealGovernanceParametersCcyPairService,
				Mockito.times(1)).isDealGovernanceCustomizedForCurrencyPair(
				currency, counterCurrency);
	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldDelete_ExistingCustomization_Exception()
			throws IOException, URISyntaxException {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";

		BDDMockito.when(
				fxoDealGovernanceParametersCcyPairService
						.isDealGovernanceCustomizedForCurrencyPair(currency,
								counterCurrency)).thenReturn(Boolean.FALSE);

		BDDMockito
				.willDoNothing()
				.given(fxoDealGovernanceParametersCcyPairService)
				.deleteDealGovernanceParametersCcyPairs(currency,
						counterCurrency);

		// when
		dealGovernanceCcyPairConfigAdminServiceImpl
				.deleteCurrencyPairCustomizationForDealGovernance(currency,
						counterCurrency);

		// then
		BDDMockito.verify(fxoDealGovernanceParametersCcyPairService,
				Mockito.times(0)).deleteDealGovernanceParametersCcyPairs(
				currency, counterCurrency);

		BDDMockito.verify(fxoDealGovernanceParametersCcyPairService,
				Mockito.times(1)).isDealGovernanceCustomizedForCurrencyPair(
				currency, counterCurrency);
	}
}
