package com.fxo.rest.converter;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;

@Test
@ContextConfiguration("classpath:./com/fxo/admin/rest/converter/test-admin-converters.xml")
public class FXOUserInterPortfolioMappingConfigListConverterTest extends
		AbstractTestNGSpringContextTests {

	public static final String dateTimePattern = "dd-MMM-yy hh.mm.ss aa";

	@Autowired
	FXOUserInterPortfolioMappingConfigListDTOModelConverter fxoUserInterPortfolioMappingConfigListDTOModelConverter;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

	}

	private DateTime getDateTimeFromString(String input) {

		return DateTime
				.parse(input, DateTimeFormat.forPattern(dateTimePattern));
	}

	private FXOInterPortfolioConfigDTO getAnFXOInterPortfolioConfigDTO(
			String interPortfolio, String updatedBy, String updatedAt,
			Boolean active) {

		return new FXOInterPortfolioConfigDTO().setActive(active)
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(getDateTimeFromString(updatedAt));

	}

	private FXOInterPortfolioConfigModel getAnFXOInterPortfolioConfigModel(
			String interPortfolio, String updatedBy, String updatedAt,
			Boolean active) {

		return new FXOInterPortfolioConfigModel().setActive(active)
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(getDateTimeFromString(updatedAt));

	}

	private FXOUserInterPortfolioMappingConfigListDTO getAFXOUserInterPortfolioMappingConfigListDTO() {
		return new FXOUserInterPortfolioMappingConfigListDTO();
	}

	private FXOUserInterPortfolioMappingConfigListModel getAFXOUserInterPortfolioMappingConfigListModel() {
		return new FXOUserInterPortfolioMappingConfigListModel();
	}

	private Boolean reconcileDTOAndModel(
			FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO,
			FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel) {

		return fxoInterPortfolioConfigDTO != null
				&& fxoInterPortfolioConfigModel != null
				&& fxoInterPortfolioConfigDTO.getInterPortfolio().equals(
						fxoInterPortfolioConfigModel.getInterPortfolio())
				&& fxoInterPortfolioConfigDTO.getUpdatedBy().equals(
						fxoInterPortfolioConfigModel.getUpdatedBy())
				&& fxoInterPortfolioConfigDTO.getUpdatedAt().equals(
						fxoInterPortfolioConfigModel.getUpdatedAt());
	}

	private Boolean reconcileModelAndDTO(
			FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel,
			FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO) {

		return fxoInterPortfolioConfigDTO != null
				&& fxoInterPortfolioConfigModel != null
				&& fxoInterPortfolioConfigDTO.getInterPortfolio().equals(
						fxoInterPortfolioConfigModel.getInterPortfolio())
				&& fxoInterPortfolioConfigDTO.getUpdatedBy().equals(
						fxoInterPortfolioConfigModel.getUpdatedBy());
	}

	public void shouldConvertToModels() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO_1 = getAFXOUserInterPortfolioMappingConfigListDTO()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigDTO_1_1,
								fxoInterPortfolioConfigDTO_1_2)).setUserId(
						userId_1);

		String interPortfolio_2_1 = "PORT 3";
		String updatedBy_2_1 = "SPL USER 1";
		String updatedAt_2_1 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_2_1, updatedBy_2_1, updatedAt_2_1, active_2_1);

		String interPortfolio_2_2 = "PORT 4";
		String updatedBy_2_2 = "SPL USER 2";
		String updatedAt_2_2 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_2_2, updatedBy_2_2, updatedAt_2_2, active_2_2);

		String userId_2 = "tmsguser22";

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO_2 = getAFXOUserInterPortfolioMappingConfigListDTO()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigDTO_2_1,
								fxoInterPortfolioConfigDTO_2_2)).setUserId(
						userId_2);

		List<FXOUserInterPortfolioMappingConfigListDTO> configListDTOs = Arrays
				.asList(fxoUserInterPortfolioMappingConfigListDTO_1,
						fxoUserInterPortfolioMappingConfigListDTO_2);

		// when
		List<FXOUserInterPortfolioMappingConfigListModel> configListModels = fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.toModels(configListDTOs);

		// then
		Assertions.assertThat(configListModels).isNotNull();

		Assertions.assertThat(configListModels).isNotEmpty();

		Assertions.assertThat(configListModels.size()).isEqualTo(
				configListDTOs.size());

	}

	public void shouldConvertToDTOs() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_1 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_2 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel_1 = getAFXOUserInterPortfolioMappingConfigListModel()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigModel_1_1,
								fxoInterPortfolioConfigModel_1_2)).setUserId(
						userId_1);

		String interPortfolio_2_1 = "PORT 3";
		String updatedBy_2_1 = "SPL USER 1";
		String updatedAt_2_1 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_1 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_2_1 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_2_1, updatedBy_2_1, updatedAt_2_1, active_2_1);

		String interPortfolio_2_2 = "PORT 4";
		String updatedBy_2_2 = "SPL USER 2";
		String updatedAt_2_2 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_2 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_2_2 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_2_2, updatedBy_2_2, updatedAt_2_2, active_2_2);

		String userId_2 = "tmsguser22";

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel_2 = getAFXOUserInterPortfolioMappingConfigListModel()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigModel_2_1,
								fxoInterPortfolioConfigModel_2_2)).setUserId(
						userId_2);

		List<FXOUserInterPortfolioMappingConfigListModel> configListModels = Arrays
				.asList(fxoUserInterPortfolioMappingConfigListModel_1,
						fxoUserInterPortfolioMappingConfigListModel_2);

		// when
		List<FXOUserInterPortfolioMappingConfigListDTO> configListDTOs = fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.fromModels(configListModels);

		// then
		Assertions.assertThat(configListDTOs).isNotNull();

		Assertions.assertThat(configListDTOs).isNotEmpty();

		Assertions.assertThat(configListDTOs.size()).isEqualTo(
				configListModels.size());

	}

	public void shouldConvertToModel() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO_1 = getAFXOUserInterPortfolioMappingConfigListDTO()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigDTO_1_1,
								fxoInterPortfolioConfigDTO_1_2)).setUserId(
						userId_1);

		// when
		FXOUserInterPortfolioMappingConfigListModel configListModel = fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.toModel(fxoUserInterPortfolioMappingConfigListDTO_1);

		// then
		Assertions.assertThat(configListModel).isNotNull();

		Assertions.assertThat(configListModel.getInterPortfolios()).isNotNull();

		Assertions.assertThat(configListModel.getInterPortfolios().size())
				.isEqualTo(
						fxoUserInterPortfolioMappingConfigListDTO_1
								.getInterPortfolios().size());

		AtomicInteger counter = new AtomicInteger(0);

		for (FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO : fxoUserInterPortfolioMappingConfigListDTO_1
				.getInterPortfolios()) {
			reconcileDTOAndModel(fxoInterPortfolioConfigDTO, configListModel
					.getInterPortfolios().get(counter.get()));

			counter.incrementAndGet();
		}
	}

	public void shouldConvertToDTO() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_1 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_2 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel_1 = getAFXOUserInterPortfolioMappingConfigListModel()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigModel_1_1,
								fxoInterPortfolioConfigModel_1_2)).setUserId(
						userId_1);

		// when
		FXOUserInterPortfolioMappingConfigListDTO configListDTO = fxoUserInterPortfolioMappingConfigListDTOModelConverter
				.fromModel(fxoUserInterPortfolioMappingConfigListModel_1);

		// then
		Assertions.assertThat(configListDTO).isNotNull();

		Assertions.assertThat(configListDTO.getInterPortfolios()).isNotNull();

		Assertions.assertThat(configListDTO.getInterPortfolios().size())
				.isEqualTo(
						fxoUserInterPortfolioMappingConfigListModel_1
								.getInterPortfolios().size());

		AtomicInteger counter = new AtomicInteger(0);

		for (FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel : fxoUserInterPortfolioMappingConfigListModel_1
				.getInterPortfolios()) {
			reconcileModelAndDTO(fxoInterPortfolioConfigModel, configListDTO
					.getInterPortfolios().get(counter.get()));

			counter.incrementAndGet();
		}
	}

}
