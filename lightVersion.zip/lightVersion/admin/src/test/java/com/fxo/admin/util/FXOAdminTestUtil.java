package com.fxo.admin.util;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FXOAdminTestUtil {

	public static String readFile(String filepath) throws IOException,
			URISyntaxException {

		byte[] encoded = Files.readAllBytes(Paths.get(ClassLoader
				.getSystemResource(filepath).toURI()));
		return new String(encoded, "UTF-8");
	}
}
