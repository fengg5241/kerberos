package com.fxo.rest.converter;

import java.util.Arrays;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.rest.model.FXOInterPortfolioConfigModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListModel;
import com.fxo.rest.model.FXOUserInterPortfolioMappingConfigListWrapperModel;

@Test
@ContextConfiguration("classpath:./com/fxo/admin/rest/converter/test-admin-converters.xml")
public class FXOUserInterPortfolioMappingConfigListWrapperConverterTest extends
		AbstractTestNGSpringContextTests {

	public static final String dateTimePattern = "dd-MMM-yy hh.mm.ss aa";

	@Autowired
	FXOUserInterPortfolioMappingConfigListWrapperDTOModelConverter fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

	}

	private DateTime getDateTimeFromString(String input) {

		return DateTime
				.parse(input, DateTimeFormat.forPattern(dateTimePattern));
	}

	private FXOInterPortfolioConfigDTO getAnFXOInterPortfolioConfigDTO(
			String interPortfolio, String updatedBy, String updatedAt,
			Boolean active) {

		return new FXOInterPortfolioConfigDTO().setActive(active)
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(getDateTimeFromString(updatedAt));

	}

	private FXOInterPortfolioConfigModel getAnFXOInterPortfolioConfigModel(
			String interPortfolio, String updatedBy, String updatedAt,
			Boolean active) {

		return new FXOInterPortfolioConfigModel().setActive(active)
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(getDateTimeFromString(updatedAt));

	}

	private FXOUserInterPortfolioMappingConfigListDTO getAFXOUserInterPortfolioMappingConfigListDTO() {
		return new FXOUserInterPortfolioMappingConfigListDTO();
	}

	private FXOUserInterPortfolioMappingConfigListModel getAFXOUserInterPortfolioMappingConfigListModel() {
		return new FXOUserInterPortfolioMappingConfigListModel();
	}

	public void shouldConvertToModel() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO_1 = getAFXOUserInterPortfolioMappingConfigListDTO()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigDTO_1_1,
								fxoInterPortfolioConfigDTO_1_2)).setUserId(
						userId_1);

		String interPortfolio_2_1 = "PORT 3";
		String updatedBy_2_1 = "SPL USER 1";
		String updatedAt_2_1 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_1 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2_1 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_2_1, updatedBy_2_1, updatedAt_2_1, active_2_1);

		String interPortfolio_2_2 = "PORT 4";
		String updatedBy_2_2 = "SPL USER 2";
		String updatedAt_2_2 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_2 = Boolean.TRUE;

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2_2 = getAnFXOInterPortfolioConfigDTO(
				interPortfolio_2_2, updatedBy_2_2, updatedAt_2_2, active_2_2);

		String userId_2 = "tmsguser22";

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO_2 = getAFXOUserInterPortfolioMappingConfigListDTO()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigDTO_2_1,
								fxoInterPortfolioConfigDTO_2_2)).setUserId(
						userId_2);

		FXOUserInterPortfolioMappingConfigListWrapperDTO configListWrapperDTO = new FXOUserInterPortfolioMappingConfigListWrapperDTO()
				.setInterPortfolioMappingConfiguration(Arrays.asList(
						fxoUserInterPortfolioMappingConfigListDTO_1,
						fxoUserInterPortfolioMappingConfigListDTO_2));

		// when
		FXOUserInterPortfolioMappingConfigListWrapperModel fxoUserInterPortfolioMappingConfigListWrapperModel = fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter
				.toModel(configListWrapperDTO);

		// then
		Assertions.assertThat(
				fxoUserInterPortfolioMappingConfigListWrapperModel).isNotNull();
		Assertions.assertThat(
				fxoUserInterPortfolioMappingConfigListWrapperModel
						.getInterPortfolioMappingConfiguration()).isNotNull();
		Assertions.assertThat(
				fxoUserInterPortfolioMappingConfigListWrapperModel
						.getInterPortfolioMappingConfiguration()).isNotEmpty();
		Assertions
				.assertThat(
						fxoUserInterPortfolioMappingConfigListWrapperModel
								.getInterPortfolioMappingConfiguration().size())
				.isEqualTo(
						configListWrapperDTO
								.getInterPortfolioMappingConfiguration().size());

	}

	public void shouldConvertToDTO() {

		// given
		String interPortfolio_1_1 = "PORT 1";
		String updatedBy_1_1 = "SPL USER";
		String updatedAt_1_1 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_1 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_1 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_1, updatedBy_1_1, updatedAt_1_1, active_1_1);

		String interPortfolio_1_2 = "PORT 2";
		String updatedBy_1_2 = "SPL USER";
		String updatedAt_1_2 = "08-AUG-12 12.00.00 AM";
		Boolean active_1_2 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_1_2 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_1_2, updatedBy_1_2, updatedAt_1_2, active_1_2);

		String userId_1 = "tmsguser21";

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel_1 = getAFXOUserInterPortfolioMappingConfigListModel()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigModel_1_1,
								fxoInterPortfolioConfigModel_1_2)).setUserId(
						userId_1);

		String interPortfolio_2_1 = "PORT 3";
		String updatedBy_2_1 = "SPL USER 1";
		String updatedAt_2_1 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_1 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_2_1 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_2_1, updatedBy_2_1, updatedAt_2_1, active_2_1);

		String interPortfolio_2_2 = "PORT 4";
		String updatedBy_2_2 = "SPL USER 2";
		String updatedAt_2_2 = "08-AUG-16 12.00.00 AM";
		Boolean active_2_2 = Boolean.TRUE;

		FXOInterPortfolioConfigModel fxoInterPortfolioConfigModel_2_2 = getAnFXOInterPortfolioConfigModel(
				interPortfolio_2_2, updatedBy_2_2, updatedAt_2_2, active_2_2);

		String userId_2 = "tmsguser22";

		FXOUserInterPortfolioMappingConfigListModel fxoUserInterPortfolioMappingConfigListModel_2 = getAFXOUserInterPortfolioMappingConfigListModel()
				.setInterPortfolios(
						Arrays.asList(fxoInterPortfolioConfigModel_2_1,
								fxoInterPortfolioConfigModel_2_2)).setUserId(
						userId_2);

		FXOUserInterPortfolioMappingConfigListWrapperModel configListWrapperModel = new FXOUserInterPortfolioMappingConfigListWrapperModel()
				.setInterPortfolioMappingConfiguration(Arrays.asList(
						fxoUserInterPortfolioMappingConfigListModel_1,
						fxoUserInterPortfolioMappingConfigListModel_2));

		// when
		FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO = fxoUserInterPortfolioMappingConfigListWrapperDTOModelConverter
				.fromModel(configListWrapperModel);

		// then
		Assertions.assertThat(fxoUserInterPortfolioMappingConfigListWrapperDTO)
				.isNotNull();
		Assertions.assertThat(
				fxoUserInterPortfolioMappingConfigListWrapperDTO
						.getInterPortfolioMappingConfiguration()).isNotNull();
		Assertions.assertThat(
				fxoUserInterPortfolioMappingConfigListWrapperDTO
						.getInterPortfolioMappingConfiguration()).isNotEmpty();
		Assertions
				.assertThat(
						fxoUserInterPortfolioMappingConfigListWrapperDTO
								.getInterPortfolioMappingConfiguration().size())
				.isEqualTo(
						configListWrapperModel
								.getInterPortfolioMappingConfiguration().size());

	}
}
