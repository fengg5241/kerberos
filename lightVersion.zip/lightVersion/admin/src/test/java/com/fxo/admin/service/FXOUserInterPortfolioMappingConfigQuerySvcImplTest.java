package com.fxo.admin.service;

import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.dao.entity.FenicsTicket;
import com.fxo.dao.repository.FXOUserInterPortfolioMappingRepository;
import com.fxo.dao.repository.FenicsTicketRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.DateTimeUtil;

public class FXOUserInterPortfolioMappingConfigQuerySvcImplTest {

	@Mock
	FenicsTicketRepository fenicsTicketRepository;

	@Mock
	private FXOUserInterPortfolioMappingRepository fxoUserInterPortfolioMappingRepository;

	@InjectMocks
	private FXOUserInterPortfolioMappingConfigQueryServiceImpl fxoUserInterPortfolioMappingConfigQueryServiceImpl;

	@BeforeMethod
	public void beforeMethod() {
		MockitoAnnotations.initMocks(this);
	}

	@AfterMethod
	public void afterMethod() {

	}

	@Test
	public void isDealAvailbleForUserId_Success() {

		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio)).thenReturn(
				Arrays.asList(new FenicsTicket()));

		boolean isDealAvailable = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.checkForInterPortfolioDealsByUserId(userId, interPortfolio);

		Assert.assertTrue(isDealAvailable);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

	}

	@Test
	public void isDealAvailbleForUserId_Failure() {

		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio)).thenReturn(null);

		boolean isDealAvailable = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.checkForInterPortfolioDealsByUserId(userId, interPortfolio);

		Assert.assertFalse(isDealAvailable);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

	}

	@Test
	public void arePortfoliosAllowedToDelete_Success() {

		// given
		String userId = "tmsguser1";

		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG COLL BOND";
		String interPortfolio_3 = "DBSSG CRD AFS2";

		Timestamp lastUpdateTimeStamp = DateTimeUtil.getCurrentSQLTimeStamp();

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = Arrays
				.asList(getAFXOUserInterPortfolioMappingEntity(userId,
						interPortfolio_1, "true", "user1", lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_2, "true", "user1",
								lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_3, "false", "user1",
								lastUpdateTimeStamp));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_1)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_2)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(null);

		given(
				fxoUserInterPortfolioMappingConfigQueryServiceImpl
						.checkForInterPortfolioDealsByUserId(userId,
								interPortfolio_1)).willReturn(null);

		given(
				fxoUserInterPortfolioMappingConfigQueryServiceImpl
						.checkForInterPortfolioDealsByUserId(userId,
								interPortfolio_2)).willReturn(null);

		given(
				fxoUserInterPortfolioMappingConfigQueryServiceImpl
						.checkForInterPortfolioDealsByUserId(userId,
								interPortfolio_3)).willReturn(null);

		// when
		List<String> interPortfolioList = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.getAllInterPortfoliosWithDeals(fxoUserInterPortfolioMappings,
						userId);

		// then
		Assert.assertEquals(interPortfolioList.size(), 0);

	}

	@Test
	public void arePortfoliosAllowedToDelete_Failure() {

		// given
		String userId = "tmsguser1";

		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG COLL BOND";
		String interPortfolio_3 = "DBSSG CRD AFS2";

		String activeFlag_1 = "true";
		String activeFlag_2 = "true";
		String activeFlag_3 = "false";

		Timestamp lastUpdateTimeStamp = DateTimeUtil.getCurrentSQLTimeStamp();

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = Arrays
				.asList(getAFXOUserInterPortfolioMappingEntity(userId,
						interPortfolio_1, activeFlag_1, null,
						lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_2, activeFlag_2, null,
								lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_3, activeFlag_3, null,
								lastUpdateTimeStamp));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_1)).thenReturn(
				Arrays.asList(new FenicsTicket()));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_2)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(null);
		// when
		List<String> interPortfolios = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.getAllInterPortfoliosWithDeals(fxoUserInterPortfolioMappings,
						userId);

		// then

		Assert.assertEquals(interPortfolios.size(), 1);

		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_1);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_2);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_3);

	}

	@Test
	public void shouldUpdateInterPortfolioStatusInDBForUserId() {

		// given
		String userId = "tmsguser1";

		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG COLL BOND";
		String interPortfolio_3 = "DBSSG CRD AFS2";

		String activeFlag_1 = "TRUE";
		String activeFlag_2 = "TRUE";
		String activeFlag_3 = "FALSE";

		String activeFlag = "FALSE";

		Timestamp lastUpdateTimeStamp = DateTimeUtil.getCurrentSQLTimeStamp();

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = Arrays
				.asList(getAFXOUserInterPortfolioMappingEntity(userId,
						interPortfolio_1, activeFlag_1, null,
						lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_2, activeFlag_2, null,
								lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_3, activeFlag_3, null,
								lastUpdateTimeStamp));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_1)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_2)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(null);

		Mockito.when(
				fxoUserInterPortfolioMappingRepository
						.getAllUserInterPortfolioMappingByUser(userId))
				.thenReturn(fxoUserInterPortfolioMappings);

		Mockito.when(
				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping((List<FXOUserInterPortfolioMapping>) any()))
				.thenReturn(fxoUserInterPortfolioMappings);

		// when
		fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.deleteUserInterPortfolio(userId);

		// then
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_0 = fxoUserInterPortfolioMappings
				.get(0);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_1 = fxoUserInterPortfolioMappings
				.get(1);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_2 = fxoUserInterPortfolioMappings
				.get(2);

		Assert.assertEquals(fxoUserInterPortfolioMapping_0.getActive(),
				activeFlag);
		Assert.assertEquals(fxoUserInterPortfolioMapping_1.getActive(),
				activeFlag);
		Assert.assertEquals(fxoUserInterPortfolioMapping_2.getActive(),
				activeFlag);

		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_1);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_2);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_3);
		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getAllUserInterPortfolioMappingByUser(userId);
		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.saveFXOUserInterPortfolioMapping(fxoUserInterPortfolioMappings);

	}

	@Test
	public void shouldFailToUpdateInterPortfolioStatusInDBForUserId() {

		// given
		String userId = "tmsguser1";

		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG COLL BOND";
		String interPortfolio_3 = "DBSSG CRD AFS2";

		String activeFlag_1 = "true";
		String activeFlag_2 = "true";
		String activeFlag_3 = "false";

		Timestamp lastUpdateTimeStamp = DateTimeUtil.getCurrentSQLTimeStamp();

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = Arrays
				.asList(getAFXOUserInterPortfolioMappingEntity(userId,
						interPortfolio_1, activeFlag_1, null,
						lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_2, activeFlag_2, null,
								lastUpdateTimeStamp),
						getAFXOUserInterPortfolioMappingEntity(userId,
								interPortfolio_3, activeFlag_3, null,
								lastUpdateTimeStamp));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_1)).thenReturn(
				Arrays.asList(new FenicsTicket()));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_2)).thenReturn(null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(null);

		Mockito.when(
				fxoUserInterPortfolioMappingRepository
						.getAllUserInterPortfolioMappingByUser(userId))
				.thenReturn(fxoUserInterPortfolioMappings);

		Mockito.when(
				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping((List<FXOUserInterPortfolioMapping>) any()))
				.thenReturn(fxoUserInterPortfolioMappings);

		ApplicationRuntimeException applicationRuntimeException = null;

		// when
		try {
			fxoUserInterPortfolioMappingConfigQueryServiceImpl
					.deleteUserInterPortfolio(userId);
		} catch (ApplicationRuntimeException e) {
			applicationRuntimeException = e;
		}

		// then
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_0 = fxoUserInterPortfolioMappings
				.get(0);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_1 = fxoUserInterPortfolioMappings
				.get(1);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_2 = fxoUserInterPortfolioMappings
				.get(2);

		Assert.assertEquals(fxoUserInterPortfolioMapping_0.getActive(),
				activeFlag_1);
		Assert.assertEquals(fxoUserInterPortfolioMapping_1.getActive(),
				activeFlag_2);
		Assert.assertEquals(fxoUserInterPortfolioMapping_2.getActive(),
				activeFlag_3);

		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_1);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_2);
		verify(fenicsTicketRepository, times(1)).findByUserIdAndInterPortfolio(
				userId, interPortfolio_3);
		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getAllUserInterPortfolioMappingByUser(userId);
		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.saveFXOUserInterPortfolioMapping(fxoUserInterPortfolioMappings);

	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void getNoPortfolioForUserId_Exception() {

		// Given
		String userId = "tmsguser2";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fxoUserInterPortfolioMappingRepository
						.getAllUserInterPortfolioMappingByUser(userId))
				.thenReturn(new ArrayList<FXOUserInterPortfolioMapping>());

		// when
		fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.deleteUserInterPortfolio(userId);

		// then
		verify(fenicsTicketRepository, times(0)).findByUserIdAndInterPortfolio(
				userId, interPortfolio);
		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.saveFXOUserInterPortfolioMapping(null);

	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldUpdateFail_NullUserId() {

		fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.deleteUserInterPortfolio(null);
	}

	private FXOInterPortfolio getAFXOInterPortfolioEntity(
			String interPortfolio, String active) {

		FXOInterPortfolio fxoInterPortfolio = new FXOInterPortfolio();
		fxoInterPortfolio.setActive(active).setInterPortfolio(interPortfolio);

		return fxoInterPortfolio;
	}

	private FXOUserInterPortfolioMapping getAFXOUserInterPortfolioMappingEntity(
			String userID, String interPortfolio, String active,
			String updatedBy, Timestamp updatedAt) {

		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping = new FXOUserInterPortfolioMapping();
		fxoUserInterPortfolioMapping
				.setUserID(userID)
				.setActive(active)
				.setInterPortfolio(
						getAFXOInterPortfolioEntity(interPortfolio, active))
				.setLastUpdatedBy(updatedBy).setLastUpdatedDate(updatedAt);

		return fxoUserInterPortfolioMapping;
	}
}
