package com.fxo.admin.factory;

import static org.assertj.core.api.Assertions.assertThat;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.dto.model.converter.BaseCustomDTOBaseCustomModelConverter;
import com.fxo.rest.converter.BarrierDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.CurrencyHedgeDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.DealGovernanceConfigDTOModelConverterFactoryImpl;
import com.fxo.rest.converter.DeltaAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.DeltaPercentDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.InvestmentAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.MarginAmountDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.RawPremiumDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.StealthDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.TenorDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.VegaDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.converter.VolatilityDealGovernanceConfigDTOModelConverter;
import com.fxo.rest.model.BaseCustomModel;

@Test
public class DealGovernanceConfigDTOModelConverterFactoryImplTest {

	@Mock
	private InvestmentAmountDealGovernanceConfigDTOModelConverter investmentAmountDealGovernanceConfigDTOModelConverter;

	@Mock
	private MarginAmountDealGovernanceConfigDTOModelConverter marginAmountDealGovernanceConfigDTOModelConverter;

	@Mock
	private DeltaAmountDealGovernanceConfigDTOModelConverter deltaAmountDealGovernanceConfigDTOModelConverter;

	@Mock
	private DeltaPercentDealGovernanceConfigDTOModelConverter deltaPercentDealGovernanceConfigDTOModelConverter;

	@Mock
	private VegaDealGovernanceConfigDTOModelConverter vegaDealGovernanceConfigDTOModelConverter;

	@Mock
	private VolatilityDealGovernanceConfigDTOModelConverter volatilityDealGovernanceConfigDTOModelConverter;

	@Mock
	private StealthDealGovernanceConfigDTOModelConverter stealthDealGovernanceConfigDTOModelConverter;

	@Mock
	private RawPremiumDealGovernanceConfigDTOModelConverter rawPremiumDealGovernanceConfigDTOModelConverter;

	@Mock
	private CurrencyHedgeDealGovernanceConfigDTOModelConverter currencyHedgeDealGovernanceConfigDTOModelConverter;

	@Mock
	private TenorDealGovernanceConfigDTOModelConverter tenorDealGovernanceConfigDTOModelConverter;

	@Mock
	private BarrierDealGovernanceConfigDTOModelConverter barrierDealGovernanceConfigDTOModelConverter;

	@InjectMocks
	DealGovernanceConfigDTOModelConverterFactoryImpl dealGovernanceConfigDTOModelConverterFactoryImpl;

	/**
	 * Inits the mocks.
	 */
	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	public void shouldGetDealGovernanceConfigDTOModelConverter() {

		// given
		String validationCode_InvAmt = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_InvAmt = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_InvAmt);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_InvAmt).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_InvAmt).isInstanceOf(
				InvestmentAmountDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Margin = DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_Margin = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Margin);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_Margin).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_Margin).isInstanceOf(
				MarginAmountDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_DeltaAmt = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_DeltaAmount = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_DeltaAmt);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_DeltaAmount)
				.isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_DeltaAmount)
				.isInstanceOf(
						DeltaAmountDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Delta = DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_DeltaPercent = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Delta);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_DeltaPercent)
				.isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_DeltaPercent)
				.isInstanceOf(
						DeltaPercentDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Vega = DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_Vega = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Vega);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_Vega).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_Vega).isInstanceOf(
				VegaDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Volatility = DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_Volatility = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Volatility);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_Volatility)
				.isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_Volatility)
				.isInstanceOf(
						VolatilityDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Stealth = DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_Stealth = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Stealth);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_Stealth).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_Stealth).isInstanceOf(
				StealthDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_RawPrem = DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_RawPremium = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_RawPrem);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_RawPremium)
				.isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_RawPremium)
				.isInstanceOf(
						RawPremiumDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_CurHdg = DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_CurHdg = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_CurHdg);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_CurHdg).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_CurHdg).isInstanceOf(
				CurrencyHedgeDealGovernanceConfigDTOModelConverter.class);

		// given
		String validationCode_Tenor = DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION;

		// when
		BaseCustomDTOBaseCustomModelConverter<? extends BaseCustomDTO, ? extends BaseCustomModel> dealGovernanceConfigDTOModelConverter_Tenor = dealGovernanceConfigDTOModelConverterFactoryImpl
				.getDealGovernanceConfigDTOModelConverter(validationCode_Tenor);

		// then
		assertThat(dealGovernanceConfigDTOModelConverter_Tenor).isNotNull();
		assertThat(dealGovernanceConfigDTOModelConverter_Tenor).isInstanceOf(
				TenorDealGovernanceConfigDTOModelConverter.class);
	}

}
