package com.fxo.rest.controller;

import java.nio.charset.Charset;

import org.junit.After;
import org.junit.Before;
import org.mockito.MockitoAnnotations;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fxo.constants.dealing.Products;
import com.fxo.dao.entity.FXOProductCatalogue;

public abstract class BaseControllerTest {

	public static final FXOProductCatalogue GROUP_SO = new FXOProductCatalogue()
			.setProduct(Products.PRODUCT_VANILLA);
	public static final FXOProductCatalogue GROUP_KI = new FXOProductCatalogue()
			.setProduct(Products.PRODUCT_KNOCKIN);

	protected MockMvc mockMvc;

	@Autowired
	private WebApplicationContext wac;

	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(
			MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@Before
	public void init() throws Exception {
		mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDownSubject() {
	}

	protected String convertToJson(Object o) throws Throwable {
		ObjectWriter ow = new ObjectMapper().writer()
				.withDefaultPrettyPrinter();
		return ow.writeValueAsString(o);
	}

	protected static final Object unwrapProxy(Object bean) throws Exception {
		/*
		 * If the given object is a proxy, set the return value as the object
		 * being proxied, otherwise return the given object.
		 */
		if (AopUtils.isAopProxy(bean) && bean instanceof Advised) {
			Advised advised = (Advised) bean;
			bean = advised.getTargetSource().getTarget();
		}
		return bean;
	}
}
