package com.fxo.admin.dto.converter;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.CurrencyConfigDTO;
import com.fxo.dao.entity.FXOCurrency;
import com.fxo.framework.util.DateTimeUtil;

@Test
@ContextConfiguration("classpath:./com/fxo/admin/dto/converter/test-DTOEntity-converters.xml")
public class CurrencyConfigDTOEntityConverterTest extends
		AbstractTestNGSpringContextTests {

	public static final SimpleDateFormat dateFormat = new SimpleDateFormat(
			"E MMM dd hh:mm:ss Z yyyy");

	@Autowired
	CurrencyConfigDTOEntityConverter currencyConfigDTOEntityConverter;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

	}

	public void shouldReturnCurrencyConfigDTOSingleLayer() throws ParseException {

		// Given
		Integer amtPrecision = 4;
		String updatedBy = "tmsguser2";
		String currency = "USD";
		String updatedDate = "Wed Oct 19 19:09:09 SGT 2016";

		// when
		CurrencyConfigDTO currencyConfigDTO = currencyConfigDTOEntityConverter
				.fromEntity(getAFXOCurrencyEntityFromParemeters(currency, amtPrecision,
						updatedBy, DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat, updatedDate)));

		// then
		Assert.assertNotNull(currencyConfigDTO);
		Assert.assertEquals(currencyConfigDTO.getCurrency(), currency);
		Assert.assertEquals(currencyConfigDTO.getAmountPrecision(),
				amtPrecision.toString());
		Assert.assertEquals(currencyConfigDTO.getUpdatedBy(), updatedBy);

	}

	public void shouldReturnCurrencyConfigDTOList() throws ParseException {

		// Given
		Integer amtPrecision_1 = 4;
		String updatedBy_1 = "tmsguser2";
		String currency_1 = "USD";
		String updatedDate_1 = "Wed Oct 19 19:09:09 SGT 2016";

		Integer amtPrecision_2 = 4;
		String updatedBy_2 = "tmsguser2";
		String currency_2 = "JPY";
		String updatedDate_2 = "Wed Oct 19 19:09:19 SGT 2016";

		Integer amtPrecision_3 = 4;
		String updatedBy_3 = "tmsguser2";
		String currency_3 = "SGD";
		String updatedDate_3 = "Wed Oct 19 19:09:29 SGT 2016";

		FXOCurrency fxoCurrency_1 = getAFXOCurrencyEntityFromParemeters(
				currency_1, amtPrecision_1, updatedBy_1,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,updatedDate_1));
		FXOCurrency fxoCurrency_2 = getAFXOCurrencyEntityFromParemeters(
				currency_2, amtPrecision_2, updatedBy_2,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,updatedDate_2));
		FXOCurrency fxoCurrency_3 = getAFXOCurrencyEntityFromParemeters(
				currency_3, amtPrecision_3, updatedBy_3,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,updatedDate_3));

		List<FXOCurrency> fxoCurrencies = new ArrayList<FXOCurrency>();
		fxoCurrencies.add(fxoCurrency_1);
		fxoCurrencies.add(fxoCurrency_2);
		fxoCurrencies.add(fxoCurrency_3);

		// when
		List<CurrencyConfigDTO> configDTOList = currencyConfigDTOEntityConverter
				.fromEntities(fxoCurrencies);

		// then
		Assert.assertEquals(configDTOList.size(), 3);
		Assert.assertEquals(configDTOList.size(), fxoCurrencies.size());
		Assert.assertNotNull(configDTOList);

		for (int i = 0; i < configDTOList.size(); i++) {
			Assert.assertEquals(configDTOList.get(i).getCurrency(),
					fxoCurrencies.get(i).getCurrency());
			Assert.assertEquals(configDTOList.get(i).getAmountPrecision(),
					fxoCurrencies.get(i).getAmountPrecision().toString());
			Assert.assertEquals(configDTOList.get(i).getUpdatedBy(),
					fxoCurrencies.get(i).getLastUpdatedBy());
		}
	}

	
	// Populate FXO Currency

	private FXOCurrency getAFXOCurrencyEntityFromParemeters(String currency,
			Integer amtPrecision, String updateBy, Timestamp updatedDate) {

		return (FXOCurrency) new FXOCurrency().setCurrency(currency)
				.setAmountPrecision(amtPrecision).setLastUpdatedBy(updateBy)
				.setLastUpdatedDate(updatedDate);

	}

}
