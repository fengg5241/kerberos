package com.fxo.admin.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.DealGovernanceConfigDTO;
import com.fxo.admin.dto.DealGovernanceConfigListDTO;
import com.fxo.admin.dto.converter.DealGovernanceConfigDTOEntityConverter;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.admin.BooleanCodes;
import com.fxo.constants.admin.DealValidationCodes;
import com.fxo.constants.dealing.Directions;
import com.fxo.constants.dealing.OptionTypes;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.constants.dealing.Products;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.dao.entity.FXOProductCatalogue;
import com.fxo.dao.repository.FXODealGovernanceParametersRepository;
import com.fxo.exception.ApplicationRuntimeException;

/**
 * @author lakshmikanth
 *
 */
@Test
public class DealGovernanceConfigAdminServiceImplTest {

	@Mock
	FXODealGovernanceParametersRepository fxoDealGovernanceParametersRepository;

	@Mock
	IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@Mock
	DealGovernanceConfigDTOEntityConverter dealGovernanceConfigDTOEntityConverter;

	@InjectMocks
	DealGovernanceConfigAdminServiceImpl dealGovernanceConfigAdminServiceImpl;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	private DealGovernanceConfigDTO getADealGovernanceConfigDTO(
			List<CodeValueDTO> hierarchy, String product, String direction,
			String minimum, String maximum, String minimumPercent,
			String maximumPercent, String updatedBy, DateTime updatedAt,
			Boolean active) {

		DealGovernanceConfigDTO dealGovernanceConfigDTO = new DealGovernanceConfigDTO();

		dealGovernanceConfigDTO.setActive(active).setHierarchy(hierarchy)
				.setProduct(product).setDirection(direction)
				.setMinimum(minimum).setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent).setUpdatedBy(updatedBy)
				.setUpdatedAt(updatedAt);

		return dealGovernanceConfigDTO;
	}

	private FXOProductCatalogue getAFXOProductCatalogue(String product,
			String optionType) {

		return new FXOProductCatalogue().setProduct(product).setOptionType(
				optionType);
	}

	private FXODealGovernanceParameters getAFXODealGovernanceParameters(
			String product, String optionType, String validationCode,
			String direction, String minimum, String maximum,
			BigDecimal minimumPercent, BigDecimal maximumPercent,
			String createdBy, Timestamp createdDate, String lastUpdatedBy,
			Timestamp lastUpdatedDate, String active) {

		FXODealGovernanceParameters fxoDealGovernanceParameters = new FXODealGovernanceParameters();

		FXOProductCatalogue fxoProductCatalogue = getAFXOProductCatalogue(
				product, optionType);

		fxoDealGovernanceParameters
				.setFxoProductCatalogue(fxoProductCatalogue)
				.setValidationCode(validationCode)
				.setDirection(direction)
				.setMinimum(minimum)
				.setMaximum(maximum)
				.setMinimumPercent(minimumPercent)
				.setMaximumPercent(maximumPercent)
				.setActive(active)
				.setValidateInDealGovernanceService(
						BooleanCodes.BooleanCodes_True).setCreatedBy(createdBy)
				.setCreatedDate(createdDate).setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedDate);

		return fxoDealGovernanceParameters;
	}

	private CodeValueDTO getACodeValueDTO(String code, String value) {
		return new CodeValueDTO().setCode(code).setValue(value);
	}

	public void shouldGetDealGovernanceParametersConfiguration() {

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_ParamSet1 = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet1 = null;
		String minimum_ParamSet1 = "200000";
		String maximum_ParamSet1 = "10000000";
		String createdBy_ParamSet1 = "SYS";
		Timestamp createdDate_ParamSet1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1 = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1 = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1 = getAFXODealGovernanceParameters(
				product_ParamSet1, optionType_ParamSet1, validationCode,
				direction_ParamSet1, minimum_ParamSet1, maximum_ParamSet1,
				null, null, createdBy_ParamSet1, createdDate_ParamSet1,
				lastUpdatedBy_ParamSet1, lastUpdatedDate_ParamSet1,
				active_ParamSet1);

		String product_ParamSet2 = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet2 = null;
		String minimum_ParamSet2 = "200000";
		String maximum_ParamSet2 = "10000000";
		String createdBy_ParamSet2 = "SYS";
		Timestamp createdDate_ParamSet2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2 = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2 = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2 = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2 = getAFXODealGovernanceParameters(
				product_ParamSet2, optionType_ParamSet2, validationCode,
				direction_ParamSet2, minimum_ParamSet2, maximum_ParamSet2,
				null, null, createdBy_ParamSet2, createdDate_ParamSet2,
				lastUpdatedBy_ParamSet2, lastUpdatedDate_ParamSet2,
				active_ParamSet2);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameterss = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameterss.add(fxoDealGovernanceParameters_ParamSet1);
		fxoDealGovernanceParameterss.add(fxoDealGovernanceParameters_ParamSet2);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode, false)).willReturn(
				fxoDealGovernanceParameterss);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1 = getADealGovernanceConfigDTO(
				null, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1, maximum_ParamSet1, null, null,
				lastUpdatedBy_ParamSet1, lastUpdatedDateTime_ParamSet1,
				Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1))
				.willReturn(dealGovernanceConfigDTO_ParamSet1);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2 = getADealGovernanceConfigDTO(
				null, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2, maximum_ParamSet2, null, null,
				lastUpdatedBy_ParamSet2, lastUpdatedDateTime_ParamSet2,
				Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2))
				.willReturn(dealGovernanceConfigDTO_ParamSet2);

		List<CodeValueDTO> hierarchy_1 = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet1_1 = ProductGroups.PRODUCT_GROUP_VANILLA;

		String groupCodeDescription_ParamSet1_1 = "Vanilla";
		CodeValueDTO codeValueDTO_ParamSet1_1 = getACodeValueDTO(
				groupCode_ParamSet1_1, groupCodeDescription_ParamSet1_1);

		hierarchy_1.add(codeValueDTO_ParamSet1_1);

		String groupCode_ParamSet1_2 = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_ParamSet1_2 = "Simple Option";
		CodeValueDTO codeValueDTO_ParamSet1_2 = getACodeValueDTO(
				groupCode_ParamSet1_2, groupCodeDescription_ParamSet1_2);

		hierarchy_1.add(codeValueDTO_ParamSet1_2);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1))
				.willReturn(hierarchy_1);

		List<CodeValueDTO> hierarchy_2 = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet2_1 = ProductGroups.PRODUCT_GROUP_RISKREVERSAL;

		String groupCodeDescription_ParamSet2_1 = "Risk Reversal";
		CodeValueDTO codeValueDTO_ParamSet2_1 = getACodeValueDTO(
				groupCode_ParamSet2_1, groupCodeDescription_ParamSet2_1);

		hierarchy_2.add(codeValueDTO_ParamSet2_1);

		String groupCode_ParamSet2_2 = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_ParamSet2_2 = "Simple Option";
		CodeValueDTO codeValueDTO_ParamSet2_2 = getACodeValueDTO(
				groupCode_ParamSet2_2, groupCodeDescription_ParamSet2_2);

		hierarchy_2.add(codeValueDTO_ParamSet2_2);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2))
				.willReturn(hierarchy_2);

		// when
		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Actual = dealGovernanceConfigAdminServiceImpl
				.getDealGovernanceParametersConfiguration(validationCode);

		// prepare expected Data

		// 1st

		List<CodeValueDTO> hierarchy_1_expected = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet1_1_expected = ProductGroups.PRODUCT_GROUP_VANILLA;

		String groupCodeDescription_ParamSet1_1_expected = "Vanilla";
		CodeValueDTO codeValueDTO_ParamSet1_1_expected = getACodeValueDTO(
				groupCode_ParamSet1_1_expected,
				groupCodeDescription_ParamSet1_1_expected);

		hierarchy_1_expected.add(codeValueDTO_ParamSet1_1_expected);

		String groupCode_ParamSet1_2_expected = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_ParamSet1_2_expected = "Simple Option";
		CodeValueDTO codeValueDTO_ParamSet1_2_expected = getACodeValueDTO(
				groupCode_ParamSet1_2_expected,
				groupCodeDescription_ParamSet1_2_expected);

		hierarchy_1_expected.add(codeValueDTO_ParamSet1_2_expected);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_expected = getADealGovernanceConfigDTO(
				hierarchy_1_expected, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1, maximum_ParamSet1, null, null,
				lastUpdatedBy_ParamSet1, lastUpdatedDateTime_ParamSet1,
				Boolean.TRUE);

		// 2nd

		List<CodeValueDTO> hierarchy_2_expected = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet2_1_expected = ProductGroups.PRODUCT_GROUP_RISKREVERSAL;

		String groupCodeDescription_ParamSet2_1_expected = "Risk Reversal";
		CodeValueDTO codeValueDTO_ParamSet2_1_expected = getACodeValueDTO(
				groupCode_ParamSet2_1_expected,
				groupCodeDescription_ParamSet2_1_expected);

		hierarchy_2_expected.add(codeValueDTO_ParamSet2_1_expected);

		String groupCode_ParamSet2_2_expected = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_ParamSet2_2_expected = "Simple Option";
		CodeValueDTO codeValueDTO_ParamSet2_2_expected = getACodeValueDTO(
				groupCode_ParamSet2_2_expected,
				groupCodeDescription_ParamSet2_2_expected);

		hierarchy_2_expected.add(codeValueDTO_ParamSet2_2_expected);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_expected = getADealGovernanceConfigDTO(
				hierarchy_2_expected, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2, maximum_ParamSet2, null, null,
				lastUpdatedBy_ParamSet2, lastUpdatedDateTime_ParamSet2,
				Boolean.TRUE);

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_expected = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_expected
				.add(dealGovernanceConfigDTO_ParamSet1_expected);
		dealGovernanceConfigDTOs_expected
				.add(dealGovernanceConfigDTO_ParamSet2_expected);

		// then
		assertThat(dealGovernanceConfigDTOs_Actual).isNotNull();
		assertThat(dealGovernanceConfigDTOs_Actual).isEqualTo(
				dealGovernanceConfigDTOs_expected);

		verify(fxoDealGovernanceParametersRepository, times(1))
				.getAllDealGovernanceParameterByValidationCode(validationCode,
						false);

		verify(dealGovernanceConfigDTOEntityConverter, times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1);

		verify(dealGovernanceConfigDTOEntityConverter, times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2);

		verify(fxoProductCatalogueGroupService, times(1))
				.getHierarchyAsCodeValue(product_ParamSet1);

		verify(fxoProductCatalogueGroupService, times(1))
				.getHierarchyAsCodeValue(product_ParamSet2);

	}

	public void shouldCheckForModification_Identical() {

		// given
		String minimum_dealGovernanceConfigDTO = "10";
		String maximum_dealGovernanceConfigDTO = "20";
		boolean active_dealGovernanceConfigDTO = true;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, null, null, minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, null, null,
				active_dealGovernanceConfigDTO);

		String minimum_fxoDealGovernanceParameters = "10";
		String maximum_fxoDealGovernanceParameters = "20";
		String active_fxoDealGovernanceParameters = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters = getAFXODealGovernanceParameters(
				null, null, null, null, minimum_fxoDealGovernanceParameters,
				maximum_fxoDealGovernanceParameters, null, null, null, null,
				null, null, active_fxoDealGovernanceParameters);

		// when
		boolean comparison_Actual = dealGovernanceConfigAdminServiceImpl
				.checkForModification(dealGovernanceConfigDTO,
						fxoDealGovernanceParameters);

		// then
		assertThat(comparison_Actual).isNotNull();
		assertThat(comparison_Actual).isFalse();

	}

	public void shouldCheckForModification_Different() {

		// given
		String minimum_dealGovernanceConfigDTO = "10";
		String maximum_dealGovernanceConfigDTO = "20";
		boolean active_dealGovernanceConfigDTO = true;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, null, null, minimum_dealGovernanceConfigDTO,
				maximum_dealGovernanceConfigDTO, null, null, null, null,
				active_dealGovernanceConfigDTO);

		String minimum_fxoDealGovernanceParameters = "11";
		String maximum_fxoDealGovernanceParameters = "21";
		String active_fxoDealGovernanceParameters = BooleanCodes.BooleanCodes_False;

		FXODealGovernanceParameters fxoDealGovernanceParameters = getAFXODealGovernanceParameters(
				null, null, null, null, minimum_fxoDealGovernanceParameters,
				maximum_fxoDealGovernanceParameters, null, null, null, null,
				null, null, active_fxoDealGovernanceParameters);

		// when
		boolean comparison_Actual = dealGovernanceConfigAdminServiceImpl
				.checkForModification(dealGovernanceConfigDTO,
						fxoDealGovernanceParameters);

		// then
		assertThat(comparison_Actual).isNotNull();
		assertThat(comparison_Actual).isTrue();

	}

	public void shouldUpdateDealGovernanceParameters() {

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_ParamSet1 = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet1 = null;
		String minimum_ParamSet1 = "200000";
		String maximum_ParamSet1 = "10000000";
		String createdBy_ParamSet1 = "SYS";
		Timestamp createdDate_ParamSet1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1 = null;
		Timestamp lastUpdatedDate_ParamSet1 = null;
		String active_ParamSet1 = BooleanCodes.BooleanCodes_True;

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products_vanilla = new ArrayList<String>();
		products_vanilla.add(product_ParamSet1);

		given(fxoProductCatalogueGroupService.getAllProducts(product_ParamSet1))
				.willReturn(products_vanilla);

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1 = getAFXODealGovernanceParameters(
				product_ParamSet1, optionType_ParamSet1, validationCode,
				direction_ParamSet1, minimum_ParamSet1, maximum_ParamSet1,
				null, null, createdBy_ParamSet1, createdDate_ParamSet1,
				lastUpdatedBy_ParamSet1, lastUpdatedDate_ParamSet1,
				active_ParamSet1);

		String product_ParamSet2 = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet2 = null;
		String minimum_ParamSet2 = "200000";
		String maximum_ParamSet2 = "10000000";
		String createdBy_ParamSet2 = "SYS";
		Timestamp createdDate_ParamSet2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2 = null;
		Timestamp lastUpdatedDate_ParamSet2 = null;
		String active_ParamSet2 = BooleanCodes.BooleanCodes_True;

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products_RR = new ArrayList<String>();
		products_RR.add(product_ParamSet2);

		given(fxoProductCatalogueGroupService.getAllProducts(product_ParamSet2))
				.willReturn(products_RR);

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2 = getAFXODealGovernanceParameters(
				product_ParamSet2, optionType_ParamSet2, validationCode,
				direction_ParamSet2, minimum_ParamSet2, maximum_ParamSet2,
				null, null, createdBy_ParamSet2, createdDate_ParamSet2,
				lastUpdatedBy_ParamSet2, lastUpdatedDate_ParamSet2,
				active_ParamSet2);

		given(
				fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_ParamSet1, validationCode,
								direction_ParamSet1, false)).willReturn(
				fxoDealGovernanceParameters_ParamSet1);

		given(
				fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_ParamSet2, validationCode,
								direction_ParamSet2, false)).willReturn(
				fxoDealGovernanceParameters_ParamSet2);

		//

		// prepare input data for DealGovernanceParametersDTO Collection

		String minimum_ParamSet1_ForUpdate = "300000";
		String maximum_ParamSet1_ForUpdate = "12000000";
		String lastUpdatedBy_ParamSet1_ForUpdate = "TraderAdmin";
		Boolean activeIndicator_ParamSet1_ForUpdate = Boolean.TRUE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Input = getADealGovernanceConfigDTO(
				null, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1_ForUpdate, maximum_ParamSet1_ForUpdate, null,
				null, lastUpdatedBy_ParamSet1_ForUpdate, null,
				activeIndicator_ParamSet1_ForUpdate);

		// 2nd

		String minimum_ParamSet2_ForUpdate = "400000";
		String maximum_ParamSet2_ForUpdate = "15000000";
		String lastUpdatedBy_ParamSet2_ForUpdate = "TraderAdmin";
		Boolean activeIndicator_ParamSet2_ForUpdate = Boolean.TRUE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Input = getADealGovernanceConfigDTO(
				null, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2_ForUpdate, maximum_ParamSet2_ForUpdate, null,
				null, lastUpdatedBy_ParamSet2_ForUpdate, null,
				activeIndicator_ParamSet2_ForUpdate);

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Input = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_Input
				.add(dealGovernanceConfigDTO_ParamSet1_Input);
		dealGovernanceConfigDTOs_Input
				.add(dealGovernanceConfigDTO_ParamSet2_Input);

		// Updated Entities

		String minimum_ParamSet1_Updated = "300000";
		String maximum_ParamSet1_Updated = "12000000";
		String lastUpdatedBy_ParamSet1_Updated = "TraderAdmin";
		String activeIndicator_ParamSet1_Updated = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_Updated_ParamSet1 = getAFXODealGovernanceParameters(
				product_ParamSet1, optionType_ParamSet1, validationCode,
				direction_ParamSet1, minimum_ParamSet1_Updated,
				maximum_ParamSet1_Updated, null, null, createdBy_ParamSet1,
				createdDate_ParamSet1, lastUpdatedBy_ParamSet1_Updated,
				lastUpdatedDate_ParamSet1, activeIndicator_ParamSet1_Updated);

		String minimum_ParamSet2_Updated = "400000";
		String maximum_ParamSet2_Updated = "15000000";
		String lastUpdatedBy_ParamSet2_Updated = "TraderAdmin";
		String activeIndicator_ParamSet2_Updated = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_Updated_ParamSet2 = getAFXODealGovernanceParameters(
				product_ParamSet2, optionType_ParamSet2, validationCode,
				direction_ParamSet2, minimum_ParamSet2_Updated,
				maximum_ParamSet2_Updated, null, null, createdBy_ParamSet2,
				createdDate_ParamSet2, lastUpdatedBy_ParamSet2_Updated,
				lastUpdatedDate_ParamSet2, activeIndicator_ParamSet2_Updated);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Updated_Collection = new ArrayList<FXODealGovernanceParameters>();
		fxoDealGovernanceParameters_Updated_Collection
				.add(fxoDealGovernanceParameters_Updated_ParamSet1);
		fxoDealGovernanceParameters_Updated_Collection
				.add(fxoDealGovernanceParameters_Updated_ParamSet2);

		given(
				fxoDealGovernanceParametersRepository
						.saveFXODealGovernanceParametersList((List<FXODealGovernanceParameters>) any()))
				.willReturn(fxoDealGovernanceParameters_Updated_Collection);

		// expected Data

		// prepare expected data for DealGovernanceParametersDTO Collection

		String minimum_ParamSet1_Expected = "300000";
		String maximum_ParamSet1_Expected = "12000000";
		String lastUpdatedBy_ParamSet1_Expected = "TraderAdmin";
		Boolean activeIndicator_ParamSet1_Expected = Boolean.TRUE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Expected = getADealGovernanceConfigDTO(
				null, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1_Expected, maximum_ParamSet1_Expected, null,
				null, lastUpdatedBy_ParamSet1_Expected, null,
				activeIndicator_ParamSet1_Expected);

		// 2nd

		String minimum_ParamSet2_Expected = "400000";
		String maximum_ParamSet2_Expected = "15000000";
		String lastExpectedBy_ParamSet2_Expected = "TraderAdmin";
		Boolean activeIndicator_ParamSet2_Expected = Boolean.TRUE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Expected = getADealGovernanceConfigDTO(
				null, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2_Expected, maximum_ParamSet2_Expected, null,
				null, lastExpectedBy_ParamSet2_Expected, null,
				activeIndicator_ParamSet2_Expected);

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Expected = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_Expected
				.add(dealGovernanceConfigDTO_ParamSet1_Expected);
		dealGovernanceConfigDTOs_Expected
				.add(dealGovernanceConfigDTO_ParamSet2_Expected);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntities(fxoDealGovernanceParameters_Updated_Collection))
				.willReturn(dealGovernanceConfigDTOs_Expected);

		// when
		dealGovernanceConfigAdminServiceImpl.updateDealGovernanceParameters(
				dealGovernanceConfigDTOs_Input, validationCode);

		// then

		verify(fxoDealGovernanceParametersRepository, times(1))
				.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
						product_ParamSet1, validationCode, direction_ParamSet1,
						false);

		verify(fxoDealGovernanceParametersRepository, times(1))
				.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
						product_ParamSet2, validationCode, direction_ParamSet2,
						false);

		verify(fxoDealGovernanceParametersRepository, times(1))
				.saveFXODealGovernanceParametersList(
						(List<FXODealGovernanceParameters>) any());

	}

	public void shouldResetDealGovernanceParametersConfigurationStatus() {

		String validationCode = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_ParamSet1 = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet1 = null;
		String minimum_ParamSet1 = "200000";
		String maximum_ParamSet1 = "10000000";
		String createdBy_ParamSet1 = "SYS";
		Timestamp createdDate_ParamSet1 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1 = null;
		Timestamp lastUpdatedDate_ParamSet1 = null;
		String active_ParamSet1 = BooleanCodes.BooleanCodes_True;

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products_vanilla = new ArrayList<String>();
		products_vanilla.add(product_ParamSet1);

		given(fxoProductCatalogueGroupService.getAllProducts(product_ParamSet1))
				.willReturn(products_vanilla);

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1 = getAFXODealGovernanceParameters(
				product_ParamSet1, optionType_ParamSet1, validationCode,
				direction_ParamSet1, minimum_ParamSet1, maximum_ParamSet1,
				null, null, createdBy_ParamSet1, createdDate_ParamSet1,
				lastUpdatedBy_ParamSet1, lastUpdatedDate_ParamSet1,
				active_ParamSet1);

		String product_ParamSet2 = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2 = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet2 = null;
		String minimum_ParamSet2 = "200000";
		String maximum_ParamSet2 = "10000000";
		String createdBy_ParamSet2 = "SYS";
		Timestamp createdDate_ParamSet2 = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2 = null;
		Timestamp lastUpdatedDate_ParamSet2 = null;
		String active_ParamSet2 = BooleanCodes.BooleanCodes_True;

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products_RR = new ArrayList<String>();
		products_RR.add(product_ParamSet2);

		given(fxoProductCatalogueGroupService.getAllProducts(product_ParamSet2))
				.willReturn(products_RR);

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2 = getAFXODealGovernanceParameters(
				product_ParamSet2, optionType_ParamSet2, validationCode,
				direction_ParamSet2, minimum_ParamSet2, maximum_ParamSet2,
				null, null, createdBy_ParamSet2, createdDate_ParamSet2,
				lastUpdatedBy_ParamSet2, lastUpdatedDate_ParamSet2,
				active_ParamSet2);

		given(
				fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_ParamSet1, validationCode,
								direction_ParamSet1, false)).willReturn(
				fxoDealGovernanceParameters_ParamSet1);

		given(
				fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								product_ParamSet2, validationCode,
								direction_ParamSet2, false)).willReturn(
				fxoDealGovernanceParameters_ParamSet2);

		//

		// prepare input data for DealGovernanceParametersDTO Collection

		String minimum_ParamSet1_ForUpdate = "300000";
		String maximum_ParamSet1_ForUpdate = "12000000";
		String lastUpdatedBy_ParamSet1_ForUpdate = "TraderAdmin";
		Boolean isActive_ParamSet1_ForUpdate = Boolean.FALSE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Input = getADealGovernanceConfigDTO(
				null, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1_ForUpdate, maximum_ParamSet1_ForUpdate, null,
				null, lastUpdatedBy_ParamSet1_ForUpdate, null,
				isActive_ParamSet1_ForUpdate);

		// 2nd

		String minimum_ParamSet2_ForUpdate = "400000";
		String maximum_ParamSet2_ForUpdate = "15000000";
		String lastUpdatedBy_ParamSet2_ForUpdate = "TraderAdmin";
		Boolean isActive_ParamSet2_ForUpdate = Boolean.FALSE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Input = getADealGovernanceConfigDTO(
				null, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2_ForUpdate, maximum_ParamSet2_ForUpdate, null,
				null, lastUpdatedBy_ParamSet2_ForUpdate, null,
				isActive_ParamSet2_ForUpdate);

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Input = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_Input
				.add(dealGovernanceConfigDTO_ParamSet1_Input);
		dealGovernanceConfigDTOs_Input
				.add(dealGovernanceConfigDTO_ParamSet2_Input);

		// updated Data

		String minimum_ParamSet1_Updated = "300000";
		String maximum_ParamSet1_Updated = "12000000";
		String lastUpdatedBy_ParamSet1_Updated = "TraderAdmin";
		String isActive_ParamSet1_Updated = BooleanCodes.BooleanCodes_False;

		FXODealGovernanceParameters fxoDealGovernanceParameters_Updated_ParamSet1 = getAFXODealGovernanceParameters(
				product_ParamSet1, optionType_ParamSet1, validationCode,
				direction_ParamSet1, minimum_ParamSet1_Updated,
				maximum_ParamSet1_Updated, null, null, createdBy_ParamSet1,
				createdDate_ParamSet1, lastUpdatedBy_ParamSet1_Updated,
				lastUpdatedDate_ParamSet1, isActive_ParamSet1_Updated);

		String minimum_ParamSet2_Updated = "400000";
		String maximum_ParamSet2_Updated = "15000000";
		String lastUpdatedBy_ParamSet2_Updated = "TraderAdmin";
		String isActive_ParamSet2_Updated = BooleanCodes.BooleanCodes_False;

		FXODealGovernanceParameters fxoDealGovernanceParameters_Updated_ParamSet2 = getAFXODealGovernanceParameters(
				product_ParamSet2, optionType_ParamSet2, validationCode,
				direction_ParamSet2, minimum_ParamSet2_Updated,
				maximum_ParamSet2_Updated, null, null, createdBy_ParamSet2,
				createdDate_ParamSet2, lastUpdatedBy_ParamSet2_Updated,
				lastUpdatedDate_ParamSet2, isActive_ParamSet2_Updated);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Updated_Collection = new ArrayList<FXODealGovernanceParameters>();
		fxoDealGovernanceParameters_Updated_Collection
				.add(fxoDealGovernanceParameters_Updated_ParamSet1);
		fxoDealGovernanceParameters_Updated_Collection
				.add(fxoDealGovernanceParameters_Updated_ParamSet2);

		given(
				fxoDealGovernanceParametersRepository
						.saveFXODealGovernanceParametersList((List<FXODealGovernanceParameters>) any()))
				.willReturn(fxoDealGovernanceParameters_Updated_Collection);

		// expected Data

		// prepare expected data for DealGovernanceParametersDTO Collection
		String minimum_ParamSet1_Expected = "300000";
		String maximum_ParamSet1_Expected = "12000000";
		String lastUpdatedBy_ParamSet1_Expected = "TraderAdmin";
		Boolean isActive_ParamSet1_Expected = Boolean.FALSE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Expected = getADealGovernanceConfigDTO(
				null, product_ParamSet1, direction_ParamSet1,
				minimum_ParamSet1_Expected, maximum_ParamSet1_Expected, null,
				null, lastUpdatedBy_ParamSet1_Expected, null,
				isActive_ParamSet1_Expected);

		// 2nd
		String minimum_ParamSet2_Expected = "400000";
		String maximum_ParamSet2_Expected = "15000000";
		String lastExpectedBy_ParamSet2_Expected = "TraderAdmin";
		Boolean isActive_ParamSet2_Expected = Boolean.FALSE;

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Expected = getADealGovernanceConfigDTO(
				null, product_ParamSet2, direction_ParamSet2,
				minimum_ParamSet2_Expected, maximum_ParamSet2_Expected, null,
				null, lastExpectedBy_ParamSet2_Expected, null,
				isActive_ParamSet2_Expected);

		List<DealGovernanceConfigDTO> dealGovernanceConfigDTOs_Expected = new ArrayList<DealGovernanceConfigDTO>();
		dealGovernanceConfigDTOs_Expected
				.add(dealGovernanceConfigDTO_ParamSet1_Expected);
		dealGovernanceConfigDTOs_Expected
				.add(dealGovernanceConfigDTO_ParamSet2_Expected);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntities(fxoDealGovernanceParameters_Updated_Collection))
				.willReturn(dealGovernanceConfigDTOs_Expected);

		// This is the way to tell PowerMock to mock all static methods of a
		// given class
		// mockStatic(JodaDateUtil.class);

		// when
		dealGovernanceConfigAdminServiceImpl.updateDealGovernanceParameters(
				dealGovernanceConfigDTOs_Input, validationCode);

		// then

		verify(fxoDealGovernanceParametersRepository, times(1))
				.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
						product_ParamSet1, validationCode, direction_ParamSet1,
						false);

		verify(fxoDealGovernanceParametersRepository, times(1))
				.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
						product_ParamSet2, validationCode, direction_ParamSet2,
						false);

		verify(fxoDealGovernanceParametersRepository, times(1))
				.saveFXODealGovernanceParametersList(
						(List<FXODealGovernanceParameters>) any());

	}

	public void shouldGetGlobalDealGovernanceConfigurationList() {

		List<CodeValueDTO> hierarchy_VANILLA = new ArrayList<CodeValueDTO>();

		String groupCode_VANILLA = ProductGroups.PRODUCT_GROUP_VANILLA;

		String groupCodeDescription_VANILLA = "Vanilla";
		CodeValueDTO codeValueDTO_VANILLA = getACodeValueDTO(groupCode_VANILLA,
				groupCodeDescription_VANILLA);

		hierarchy_VANILLA.add(codeValueDTO_VANILLA);

		String groupCode_SO = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_SO = "Simple Option";
		CodeValueDTO codeValueDTO_SO = getACodeValueDTO(groupCode_SO,
				groupCodeDescription_SO);

		hierarchy_VANILLA.add(codeValueDTO_SO);

		List<CodeValueDTO> hierarchy_RR = new ArrayList<CodeValueDTO>();

		String groupCode_RR = ProductGroups.PRODUCT_GROUP_RISKREVERSAL;

		String groupCodeDescription_RR = "Risk Reversal";
		CodeValueDTO codeValueDTO_RR = getACodeValueDTO(groupCode_RR,
				groupCodeDescription_RR);

		hierarchy_RR.add(codeValueDTO_RR);
		hierarchy_RR.add(codeValueDTO_SO);

		// KI

		List<CodeValueDTO> hierarchy_KI = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet_KI = ProductGroups.PRODUCT_GROUP_KI;

		String groupCodeDescription_KI = "KnockIn";
		CodeValueDTO codeValueDTO_KI = getACodeValueDTO(groupCode_ParamSet_KI,
				groupCodeDescription_KI);

		hierarchy_KI.add(codeValueDTO_KI);

		String groupCode_KI_KO = ProductGroups.PRODUCT_GROUP_KI_KO;
		String groupCodeDescription_KI_KO = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_KI_KO = getACodeValueDTO(groupCode_KI_KO,
				groupCodeDescription_KI_KO);

		hierarchy_KI.add(codeValueDTO_KI_KO);

		String groupCode_Exotic = ProductGroups.PRODUCT_GROUP_EXOTIC_OPTION;
		String groupCodeDescription_Exotic = "KnockIn KnockOut";

		CodeValueDTO codeValueDTO_Exotic = getACodeValueDTO(groupCode_Exotic,
				groupCodeDescription_Exotic);

		hierarchy_KI.add(codeValueDTO_Exotic);

		// KO

		List<CodeValueDTO> hierarchy_KO = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet_KO = ProductGroups.PRODUCT_GROUP_KO;

		String groupCodeDescription_KO = "KnockOut";
		CodeValueDTO codeValueDTO_KO = getACodeValueDTO(groupCode_ParamSet_KO,
				groupCodeDescription_KO);

		hierarchy_KO.add(codeValueDTO_KO);

		hierarchy_KO.add(codeValueDTO_KI_KO);

		hierarchy_KO.add(codeValueDTO_Exotic);

		// InvestmentAmount

		String validationCode_InvestmentAmount = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;

		String product_ParamSet1_InvestmentAmount = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_InvestmentAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_InvestmentAmount = null;
		String minimum_ParamSet1_InvestmentAmount = "200000";
		String maximum_ParamSet1_InvestmentAmount = "10000000";
		String createdBy_ParamSet1_InvestmentAmount = "SYS";
		Timestamp createdDate_ParamSet1_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_InvestmentAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_InvestmentAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_InvestmentAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_InvestmentAmount = getAFXODealGovernanceParameters(
				product_ParamSet1_InvestmentAmount,
				optionType_ParamSet1_InvestmentAmount,
				validationCode_InvestmentAmount,
				direction_ParamSet1_InvestmentAmount,
				minimum_ParamSet1_InvestmentAmount,
				maximum_ParamSet1_InvestmentAmount, null, null,
				createdBy_ParamSet1_InvestmentAmount,
				createdDate_ParamSet1_InvestmentAmount,
				lastUpdatedBy_ParamSet1_InvestmentAmount,
				lastUpdatedDate_ParamSet1_InvestmentAmount,
				active_ParamSet1_InvestmentAmount);

		String product_ParamSet2_InvestmentAmount = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_InvestmentAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_InvestmentAmount = null;
		String minimum_ParamSet2_InvestmentAmount = "200000";
		String maximum_ParamSet2_InvestmentAmount = "10000000";
		String createdBy_ParamSet2_InvestmentAmount = "SYS";
		Timestamp createdDate_ParamSet2_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_InvestmentAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_InvestmentAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_InvestmentAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_InvestmentAmount = getAFXODealGovernanceParameters(
				product_ParamSet2_InvestmentAmount,
				optionType_ParamSet2_InvestmentAmount,
				validationCode_InvestmentAmount,
				direction_ParamSet2_InvestmentAmount,
				minimum_ParamSet2_InvestmentAmount,
				maximum_ParamSet2_InvestmentAmount, null, null,
				createdBy_ParamSet2_InvestmentAmount,
				createdDate_ParamSet2_InvestmentAmount,
				lastUpdatedBy_ParamSet2_InvestmentAmount,
				lastUpdatedDate_ParamSet2_InvestmentAmount,
				active_ParamSet2_InvestmentAmount);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_InvestmentAmount = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_InvestmentAmount
				.add(fxoDealGovernanceParameters_ParamSet1_InvestmentAmount);
		fxoDealGovernanceParameters_InvestmentAmount
				.add(fxoDealGovernanceParameters_ParamSet2_InvestmentAmount);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_InvestmentAmount, false))
				.willReturn(fxoDealGovernanceParameters_InvestmentAmount);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_InvestmentAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet1_InvestmentAmount,
				direction_ParamSet1_InvestmentAmount,
				minimum_ParamSet1_InvestmentAmount,
				maximum_ParamSet1_InvestmentAmount, null, null,
				lastUpdatedBy_ParamSet1_InvestmentAmount,
				lastUpdatedDateTime_ParamSet1_InvestmentAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_InvestmentAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_InvestmentAmount);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_InvestmentAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet2_InvestmentAmount,
				direction_ParamSet2_InvestmentAmount,
				minimum_ParamSet2_InvestmentAmount,
				maximum_ParamSet2_InvestmentAmount, null, null,
				lastUpdatedBy_ParamSet2_InvestmentAmount,
				lastUpdatedDateTime_ParamSet2_InvestmentAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_InvestmentAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_InvestmentAmount);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_InvestmentAmount))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_InvestmentAmount))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> investmentAmountThresholdDTOs = Arrays
				.asList(dealGovernanceConfigDTO_ParamSet1_InvestmentAmount,
						dealGovernanceConfigDTO_ParamSet2_InvestmentAmount);

		// DeltaAmount
		String validationCode_DeltaAmount = DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION;

		String product_ParamSet1_DeltaAmount = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_DeltaAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_DeltaAmount = null;
		String minimum_ParamSet1_DeltaAmount = "200000";
		String maximum_ParamSet1_DeltaAmount = "10000000";
		String createdBy_ParamSet1_DeltaAmount = "SYS";
		Timestamp createdDate_ParamSet1_DeltaAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_DeltaAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_DeltaAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_DeltaAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_DeltaAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_DeltaAmount = getAFXODealGovernanceParameters(
				product_ParamSet1_DeltaAmount,
				optionType_ParamSet1_DeltaAmount, validationCode_DeltaAmount,
				direction_ParamSet1_DeltaAmount, minimum_ParamSet1_DeltaAmount,
				maximum_ParamSet1_DeltaAmount, null, null,
				createdBy_ParamSet1_DeltaAmount,
				createdDate_ParamSet1_DeltaAmount,
				lastUpdatedBy_ParamSet1_DeltaAmount,
				lastUpdatedDate_ParamSet1_DeltaAmount,
				active_ParamSet1_DeltaAmount);

		String product_ParamSet2_DeltaAmount = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_DeltaAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_DeltaAmount = null;
		String minimum_ParamSet2_DeltaAmount = "200000";
		String maximum_ParamSet2_DeltaAmount = "10000000";
		String createdBy_ParamSet2_DeltaAmount = "SYS";
		Timestamp createdDate_ParamSet2_DeltaAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_DeltaAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_DeltaAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_DeltaAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_DeltaAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_DeltaAmount = getAFXODealGovernanceParameters(
				product_ParamSet2_DeltaAmount,
				optionType_ParamSet2_DeltaAmount, validationCode_DeltaAmount,
				direction_ParamSet2_DeltaAmount, minimum_ParamSet2_DeltaAmount,
				maximum_ParamSet2_DeltaAmount, null, null,
				createdBy_ParamSet2_DeltaAmount,
				createdDate_ParamSet2_DeltaAmount,
				lastUpdatedBy_ParamSet2_DeltaAmount,
				lastUpdatedDate_ParamSet2_DeltaAmount,
				active_ParamSet2_DeltaAmount);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_DeltaAmount = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_DeltaAmount
				.add(fxoDealGovernanceParameters_ParamSet1_DeltaAmount);
		fxoDealGovernanceParameters_DeltaAmount
				.add(fxoDealGovernanceParameters_ParamSet2_DeltaAmount);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_DeltaAmount, false)).willReturn(
				fxoDealGovernanceParameters_DeltaAmount);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_DeltaAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet1_DeltaAmount,
				direction_ParamSet1_DeltaAmount, minimum_ParamSet1_DeltaAmount,
				maximum_ParamSet1_DeltaAmount, null, null,
				lastUpdatedBy_ParamSet1_DeltaAmount,
				lastUpdatedDateTime_ParamSet1_DeltaAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_DeltaAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_DeltaAmount);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_DeltaAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet2_DeltaAmount,
				direction_ParamSet2_DeltaAmount, minimum_ParamSet2_DeltaAmount,
				maximum_ParamSet2_DeltaAmount, null, null,
				lastUpdatedBy_ParamSet2_DeltaAmount,
				lastUpdatedDateTime_ParamSet2_DeltaAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_DeltaAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_DeltaAmount);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_DeltaAmount))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_DeltaAmount))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> deltaAmountThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_DeltaAmount,
				dealGovernanceConfigDTO_ParamSet2_DeltaAmount);

		// DeltaPercent
		String validationCode_DeltaPercent = DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION;

		String product_ParamSet1_DeltaPercent = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_DeltaPercent = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_DeltaPercent = null;
		String minimum_ParamSet1_DeltaPercent = "10";
		String maximum_ParamSet1_DeltaPercent = "50";
		String createdBy_ParamSet1_DeltaPercent = "SYS";
		Timestamp createdDate_ParamSet1_DeltaPercent = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_DeltaPercent = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_DeltaPercent = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_DeltaPercent = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_DeltaPercent = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_DeltaPercent = getAFXODealGovernanceParameters(
				product_ParamSet1_DeltaPercent,
				optionType_ParamSet1_DeltaPercent, validationCode_DeltaPercent,
				direction_ParamSet1_DeltaPercent,
				minimum_ParamSet1_DeltaPercent, maximum_ParamSet1_DeltaPercent,
				null, null, createdBy_ParamSet1_DeltaPercent,
				createdDate_ParamSet1_DeltaPercent,
				lastUpdatedBy_ParamSet1_DeltaPercent,
				lastUpdatedDate_ParamSet1_DeltaPercent,
				active_ParamSet1_DeltaPercent);

		String product_ParamSet2_DeltaPercent = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_DeltaPercent = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_DeltaPercent = null;
		String minimum_ParamSet2_DeltaPercent = "20";
		String maximum_ParamSet2_DeltaPercent = "80";
		String createdBy_ParamSet2_DeltaPercent = "SYS";
		Timestamp createdDate_ParamSet2_DeltaPercent = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_DeltaPercent = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_DeltaPercent = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_DeltaPercent = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_DeltaPercent = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_DeltaPercent = getAFXODealGovernanceParameters(
				product_ParamSet2_DeltaPercent,
				optionType_ParamSet2_DeltaPercent, validationCode_DeltaPercent,
				direction_ParamSet2_DeltaPercent,
				minimum_ParamSet2_DeltaPercent, maximum_ParamSet2_DeltaPercent,
				null, null, createdBy_ParamSet2_DeltaPercent,
				createdDate_ParamSet2_DeltaPercent,
				lastUpdatedBy_ParamSet2_DeltaPercent,
				lastUpdatedDate_ParamSet2_DeltaPercent,
				active_ParamSet2_DeltaPercent);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_DeltaPercent = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_DeltaPercent
				.add(fxoDealGovernanceParameters_ParamSet1_DeltaPercent);
		fxoDealGovernanceParameters_DeltaPercent
				.add(fxoDealGovernanceParameters_ParamSet2_DeltaPercent);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_DeltaPercent, false))
				.willReturn(fxoDealGovernanceParameters_DeltaPercent);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_DeltaPercent = getADealGovernanceConfigDTO(
				null, product_ParamSet1_DeltaPercent,
				direction_ParamSet1_DeltaPercent,
				minimum_ParamSet1_DeltaPercent, maximum_ParamSet1_DeltaPercent,
				null, null, lastUpdatedBy_ParamSet1_DeltaPercent,
				lastUpdatedDateTime_ParamSet1_DeltaPercent, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_DeltaPercent))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_DeltaPercent);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_DeltaPercent = getADealGovernanceConfigDTO(
				null, product_ParamSet2_DeltaPercent,
				direction_ParamSet2_DeltaPercent,
				minimum_ParamSet2_DeltaPercent, maximum_ParamSet2_DeltaPercent,
				null, null, lastUpdatedBy_ParamSet2_DeltaPercent,
				lastUpdatedDateTime_ParamSet2_DeltaPercent, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_DeltaPercent))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_DeltaPercent);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_DeltaPercent))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_DeltaPercent))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> deltaPercentThresholdDTOs = Arrays
				.asList(dealGovernanceConfigDTO_ParamSet1_DeltaPercent,
						dealGovernanceConfigDTO_ParamSet2_DeltaPercent);

		// margin Amount

		String validationCode_MarginAmount = DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION;

		String product_ParamSet1_MarginAmount = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_MarginAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_MarginAmount = null;
		String minimum_ParamSet1_MarginAmount = "200000";
		BigDecimal minimumPercent_ParamSet1_MarginAmount = BigDecimal
				.valueOf(10);
		BigDecimal maximumPercent_ParamSet1_MarginAmount = BigDecimal
				.valueOf(50);
		String createdBy_ParamSet1_MarginAmount = "SYS";
		Timestamp createdDate_ParamSet1_MarginAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_MarginAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_MarginAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_MarginAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_MarginAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_MarginAmount = getAFXODealGovernanceParameters(
				product_ParamSet1_MarginAmount,
				optionType_ParamSet1_MarginAmount, validationCode_MarginAmount,
				direction_ParamSet1_MarginAmount,
				minimum_ParamSet1_MarginAmount, null,
				minimumPercent_ParamSet1_MarginAmount,
				maximumPercent_ParamSet1_MarginAmount,
				createdBy_ParamSet1_MarginAmount,
				createdDate_ParamSet1_MarginAmount,
				lastUpdatedBy_ParamSet1_MarginAmount,
				lastUpdatedDate_ParamSet1_MarginAmount,
				active_ParamSet1_MarginAmount);

		String product_ParamSet2_MarginAmount = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_MarginAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_MarginAmount = null;
		String minimum_ParamSet2_MarginAmount = "200000";
		String maximum_ParamSet2_MarginAmount = "10000000";
		BigDecimal minimumPercent_ParamSet2_MarginAmount = BigDecimal
				.valueOf(10);
		BigDecimal maximumPercent_ParamSet2_MarginAmount = BigDecimal
				.valueOf(50);
		String createdBy_ParamSet2_MarginAmount = "SYS";
		Timestamp createdDate_ParamSet2_MarginAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_MarginAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_MarginAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_MarginAmount = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_MarginAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_MarginAmount = getAFXODealGovernanceParameters(
				product_ParamSet2_MarginAmount,
				optionType_ParamSet2_MarginAmount, validationCode_MarginAmount,
				direction_ParamSet2_MarginAmount,
				minimum_ParamSet2_MarginAmount, null,
				minimumPercent_ParamSet2_MarginAmount,
				maximumPercent_ParamSet2_MarginAmount,
				createdBy_ParamSet2_MarginAmount,
				createdDate_ParamSet2_MarginAmount,
				lastUpdatedBy_ParamSet2_MarginAmount,
				lastUpdatedDate_ParamSet2_MarginAmount,
				active_ParamSet2_MarginAmount);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_MarginAmount = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_MarginAmount
				.add(fxoDealGovernanceParameters_ParamSet1_MarginAmount);
		fxoDealGovernanceParameters_MarginAmount
				.add(fxoDealGovernanceParameters_ParamSet2_MarginAmount);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_MarginAmount, false))
				.willReturn(fxoDealGovernanceParameters_MarginAmount);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_MarginAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet1_MarginAmount,
				direction_ParamSet1_MarginAmount,
				minimum_ParamSet1_MarginAmount, null,
				minimumPercent_ParamSet1_MarginAmount.toPlainString(),
				minimumPercent_ParamSet1_MarginAmount.toPlainString(),
				lastUpdatedBy_ParamSet1_MarginAmount,
				lastUpdatedDateTime_ParamSet1_MarginAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_MarginAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_MarginAmount);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_MarginAmount = getADealGovernanceConfigDTO(
				null, product_ParamSet2_MarginAmount,
				direction_ParamSet2_MarginAmount,
				minimum_ParamSet2_MarginAmount, maximum_ParamSet2_MarginAmount,
				minimumPercent_ParamSet2_MarginAmount.toPlainString(),
				minimumPercent_ParamSet2_MarginAmount.toPlainString(),
				lastUpdatedBy_ParamSet2_MarginAmount,
				lastUpdatedDateTime_ParamSet2_MarginAmount, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_MarginAmount))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_MarginAmount);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_MarginAmount))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_MarginAmount))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> marginAmountThresholdDTOs = Arrays
				.asList(dealGovernanceConfigDTO_ParamSet1_MarginAmount,
						dealGovernanceConfigDTO_ParamSet2_MarginAmount);

		// Vega
		String validationCode_Vega = DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION;
		String product_ParamSet1_Vega = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Vega = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_Vega = null;
		String minimum_ParamSet1_Vega = "0";
		String maximum_ParamSet1_Vega = "10";
		String createdBy_ParamSet1_Vega = "SYS";
		Timestamp createdDate_ParamSet1_Vega = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Vega = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Vega = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Vega = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Vega = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Vega = getAFXODealGovernanceParameters(
				product_ParamSet1_Vega, optionType_ParamSet1_Vega,
				validationCode_Vega, direction_ParamSet1_Vega,
				minimum_ParamSet1_Vega, maximum_ParamSet1_Vega, null, null,
				createdBy_ParamSet1_Vega, createdDate_ParamSet1_Vega,
				lastUpdatedBy_ParamSet1_Vega, lastUpdatedDate_ParamSet1_Vega,
				active_ParamSet1_Vega);

		String product_ParamSet2_Vega = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Vega = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_Vega = null;
		String minimum_ParamSet2_Vega = "20";
		String maximum_ParamSet2_Vega = "50";
		String createdBy_ParamSet2_Vega = "SYS";
		Timestamp createdDate_ParamSet2_Vega = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Vega = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Vega = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Vega = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Vega = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Vega = getAFXODealGovernanceParameters(
				product_ParamSet2_Vega, optionType_ParamSet2_Vega,
				validationCode_Vega, direction_ParamSet2_Vega,
				minimum_ParamSet2_Vega, maximum_ParamSet2_Vega, null, null,
				createdBy_ParamSet2_Vega, createdDate_ParamSet2_Vega,
				lastUpdatedBy_ParamSet2_Vega, lastUpdatedDate_ParamSet2_Vega,
				active_ParamSet2_Vega);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Vega = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_Vega
				.add(fxoDealGovernanceParameters_ParamSet1_Vega);
		fxoDealGovernanceParameters_Vega
				.add(fxoDealGovernanceParameters_ParamSet2_Vega);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_Vega, false)).willReturn(
				fxoDealGovernanceParameters_Vega);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Vega = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Vega, direction_ParamSet1_Vega,
				minimum_ParamSet1_Vega, maximum_ParamSet1_Vega, null, null,
				lastUpdatedBy_ParamSet1_Vega,
				lastUpdatedDateTime_ParamSet1_Vega, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Vega))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Vega);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Vega = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Vega, direction_ParamSet2_Vega,
				minimum_ParamSet2_Vega, maximum_ParamSet2_Vega, null, null,
				lastUpdatedBy_ParamSet2_Vega,
				lastUpdatedDateTime_ParamSet2_Vega, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Vega))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Vega);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Vega))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Vega))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> vegaThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Vega,
				dealGovernanceConfigDTO_ParamSet2_Vega);

		// Volatility
		String validationCode_Volatility = DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION;
		String product_ParamSet1_Volatility = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Volatility = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_Volatility = null;
		String minimum_ParamSet1_Volatility = "0";
		String maximum_ParamSet1_Volatility = "10";
		String createdBy_ParamSet1_Volatility = "SYS";
		Timestamp createdDate_ParamSet1_Volatility = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Volatility = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Volatility = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Volatility = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Volatility = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Volatility = getAFXODealGovernanceParameters(
				product_ParamSet1_Volatility, optionType_ParamSet1_Volatility,
				validationCode_Volatility, direction_ParamSet1_Volatility,
				minimum_ParamSet1_Volatility, maximum_ParamSet1_Volatility,
				null, null, createdBy_ParamSet1_Volatility,
				createdDate_ParamSet1_Volatility,
				lastUpdatedBy_ParamSet1_Volatility,
				lastUpdatedDate_ParamSet1_Volatility,
				active_ParamSet1_Volatility);

		String product_ParamSet2_Volatility = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Volatility = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_Volatility = null;
		String minimum_ParamSet2_Volatility = "20";
		String maximum_ParamSet2_Volatility = "50";
		String createdBy_ParamSet2_Volatility = "SYS";
		Timestamp createdDate_ParamSet2_Volatility = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Volatility = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Volatility = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Volatility = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Volatility = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Volatility = getAFXODealGovernanceParameters(
				product_ParamSet2_Volatility, optionType_ParamSet2_Volatility,
				validationCode_Volatility, direction_ParamSet2_Volatility,
				minimum_ParamSet2_Volatility, maximum_ParamSet2_Volatility,
				null, null, createdBy_ParamSet2_Volatility,
				createdDate_ParamSet2_Volatility,
				lastUpdatedBy_ParamSet2_Volatility,
				lastUpdatedDate_ParamSet2_Volatility,
				active_ParamSet2_Volatility);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Volatility = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_Volatility
				.add(fxoDealGovernanceParameters_ParamSet1_Volatility);
		fxoDealGovernanceParameters_Volatility
				.add(fxoDealGovernanceParameters_ParamSet2_Volatility);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_Volatility, false)).willReturn(
				fxoDealGovernanceParameters_Volatility);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Volatility = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Volatility,
				direction_ParamSet1_Volatility, minimum_ParamSet1_Volatility,
				maximum_ParamSet1_Volatility, null, null,
				lastUpdatedBy_ParamSet1_Volatility,
				lastUpdatedDateTime_ParamSet1_Volatility, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Volatility))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Volatility);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Volatility = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Volatility,
				direction_ParamSet2_Volatility, minimum_ParamSet2_Volatility,
				maximum_ParamSet2_Volatility, null, null,
				lastUpdatedBy_ParamSet2_Volatility,
				lastUpdatedDateTime_ParamSet2_Volatility, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Volatility))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Volatility);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Volatility))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Volatility))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> volatilityThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Volatility,
				dealGovernanceConfigDTO_ParamSet2_Volatility);

		// Tenor
		String validationCode_Tenor = DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION;
		String product_ParamSet1_Tenor = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Tenor = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_Tenor = null;
		String minimum_ParamSet1_Tenor = "1W";
		String maximum_ParamSet1_Tenor = "1Y";
		String createdBy_ParamSet1_Tenor = "SYS";
		Timestamp createdDate_ParamSet1_Tenor = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Tenor = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Tenor = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Tenor = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Tenor = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Tenor = getAFXODealGovernanceParameters(
				product_ParamSet1_Tenor, optionType_ParamSet1_Tenor,
				validationCode_Tenor, direction_ParamSet1_Tenor,
				minimum_ParamSet1_Tenor, maximum_ParamSet1_Tenor, null, null,
				createdBy_ParamSet1_Tenor, createdDate_ParamSet1_Tenor,
				lastUpdatedBy_ParamSet1_Tenor, lastUpdatedDate_ParamSet1_Tenor,
				active_ParamSet1_Tenor);

		String product_ParamSet2_Tenor = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Tenor = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_Tenor = null;
		String minimum_ParamSet2_Tenor = "2W";
		String maximum_ParamSet2_Tenor = "2Y";
		String createdBy_ParamSet2_Tenor = "SYS";
		Timestamp createdDate_ParamSet2_Tenor = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Tenor = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Tenor = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Tenor = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Tenor = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Tenor = getAFXODealGovernanceParameters(
				product_ParamSet2_Tenor, optionType_ParamSet2_Tenor,
				validationCode_Tenor, direction_ParamSet2_Tenor,
				minimum_ParamSet2_Tenor, maximum_ParamSet2_Tenor, null, null,
				createdBy_ParamSet2_Tenor, createdDate_ParamSet2_Tenor,
				lastUpdatedBy_ParamSet2_Tenor, lastUpdatedDate_ParamSet2_Tenor,
				active_ParamSet2_Tenor);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Tenor = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_Tenor
				.add(fxoDealGovernanceParameters_ParamSet1_Tenor);
		fxoDealGovernanceParameters_Tenor
				.add(fxoDealGovernanceParameters_ParamSet2_Tenor);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_Tenor, false)).willReturn(
				fxoDealGovernanceParameters_Tenor);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Tenor = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Tenor, direction_ParamSet1_Tenor,
				minimum_ParamSet1_Tenor, maximum_ParamSet1_Tenor, null, null,
				lastUpdatedBy_ParamSet1_Tenor,
				lastUpdatedDateTime_ParamSet1_Tenor, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Tenor))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Tenor);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Tenor = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Tenor, direction_ParamSet2_Tenor,
				minimum_ParamSet2_Tenor, maximum_ParamSet2_Tenor, null, null,
				lastUpdatedBy_ParamSet2_Tenor,
				lastUpdatedDateTime_ParamSet2_Tenor, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Tenor))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Tenor);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Tenor))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Tenor))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> tenorThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Tenor,
				dealGovernanceConfigDTO_ParamSet2_Tenor);

		// Stealth
		String validationCode_Stealth = DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION;
		String product_ParamSet1_Stealth = Products.PRODUCT_KNOCKIN;
		String optionType_ParamSet1_Stealth = OptionTypes.OPTION_TYPE_KNOCKIN;

		String direction_ParamSet1_Stealth = null;
		String minimum_ParamSet1_Stealth = "0";
		String maximum_ParamSet1_Stealth = "10";
		String createdBy_ParamSet1_Stealth = "SYS";
		Timestamp createdDate_ParamSet1_Stealth = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Stealth = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Stealth = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Stealth = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Stealth = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Stealth = getAFXODealGovernanceParameters(
				product_ParamSet1_Stealth, optionType_ParamSet1_Stealth,
				validationCode_Stealth, direction_ParamSet1_Stealth,
				minimum_ParamSet1_Stealth, maximum_ParamSet1_Stealth, null,
				null, createdBy_ParamSet1_Stealth,
				createdDate_ParamSet1_Stealth, lastUpdatedBy_ParamSet1_Stealth,
				lastUpdatedDate_ParamSet1_Stealth, active_ParamSet1_Stealth);

		String product_ParamSet2_Stealth = Products.PRODUCT_KNOCKOUT;
		String optionType_ParamSet2_Stealth = OptionTypes.OPTION_TYPE_KNOCKOUT;

		String direction_ParamSet2_Stealth = null;
		String minimum_ParamSet2_Stealth = "20";
		String maximum_ParamSet2_Stealth = "50";
		String createdBy_ParamSet2_Stealth = "SYS";
		Timestamp createdDate_ParamSet2_Stealth = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Stealth = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Stealth = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Stealth = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Stealth = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Stealth = getAFXODealGovernanceParameters(
				product_ParamSet2_Stealth, optionType_ParamSet2_Stealth,
				validationCode_Stealth, direction_ParamSet2_Stealth,
				minimum_ParamSet2_Stealth, maximum_ParamSet2_Stealth, null,
				null, createdBy_ParamSet2_Stealth,
				createdDate_ParamSet2_Stealth, lastUpdatedBy_ParamSet2_Stealth,
				lastUpdatedDate_ParamSet2_Stealth, active_ParamSet2_Stealth);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Stealth = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_Stealth
				.add(fxoDealGovernanceParameters_ParamSet1_Stealth);
		fxoDealGovernanceParameters_Stealth
				.add(fxoDealGovernanceParameters_ParamSet2_Stealth);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_Stealth, false)).willReturn(
				fxoDealGovernanceParameters_Stealth);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Stealth = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Stealth, direction_ParamSet1_Stealth,
				minimum_ParamSet1_Stealth, maximum_ParamSet1_Stealth, null,
				null, lastUpdatedBy_ParamSet1_Stealth,
				lastUpdatedDateTime_ParamSet1_Stealth, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Stealth))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Stealth);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Stealth = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Stealth, direction_ParamSet2_Stealth,
				minimum_ParamSet2_Stealth, maximum_ParamSet2_Stealth, null,
				null, lastUpdatedBy_ParamSet2_Stealth,
				lastUpdatedDateTime_ParamSet2_Stealth, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Stealth))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Stealth);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Stealth))
				.willReturn(hierarchy_KI);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Stealth))
				.willReturn(hierarchy_KO);

		List<DealGovernanceConfigDTO> stealthThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Stealth,
				dealGovernanceConfigDTO_ParamSet2_Stealth);

		// CurrencyHedge
		String validationCode_CurrencyHedge = DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_HEDGE_VALIDATION;
		String product_ParamSet1_CurrencyHedge = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_CurrencyHedge = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_CurrencyHedge = null;
		String minimum_ParamSet1_CurrencyHedge = "0";
		String maximum_ParamSet1_CurrencyHedge = "1000000";
		String createdBy_ParamSet1_CurrencyHedge = "SYS";
		Timestamp createdDate_ParamSet1_CurrencyHedge = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_CurrencyHedge = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_CurrencyHedge = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_CurrencyHedge = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_CurrencyHedge = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_CurrencyHedge = getAFXODealGovernanceParameters(
				product_ParamSet1_CurrencyHedge,
				optionType_ParamSet1_CurrencyHedge,
				validationCode_CurrencyHedge,
				direction_ParamSet1_CurrencyHedge,
				minimum_ParamSet1_CurrencyHedge,
				maximum_ParamSet1_CurrencyHedge, null, null,
				createdBy_ParamSet1_CurrencyHedge,
				createdDate_ParamSet1_CurrencyHedge,
				lastUpdatedBy_ParamSet1_CurrencyHedge,
				lastUpdatedDate_ParamSet1_CurrencyHedge,
				active_ParamSet1_CurrencyHedge);

		String product_ParamSet2_CurrencyHedge = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_CurrencyHedge = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_CurrencyHedge = null;
		String minimum_ParamSet2_CurrencyHedge = "0";
		String maximum_ParamSet2_CurrencyHedge = "2000000";
		String createdBy_ParamSet2_CurrencyHedge = "SYS";
		Timestamp createdDate_ParamSet2_CurrencyHedge = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_CurrencyHedge = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_CurrencyHedge = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_CurrencyHedge = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_CurrencyHedge = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_CurrencyHedge = getAFXODealGovernanceParameters(
				product_ParamSet2_CurrencyHedge,
				optionType_ParamSet2_CurrencyHedge,
				validationCode_CurrencyHedge,
				direction_ParamSet2_CurrencyHedge,
				minimum_ParamSet2_CurrencyHedge,
				maximum_ParamSet2_CurrencyHedge, null, null,
				createdBy_ParamSet2_CurrencyHedge,
				createdDate_ParamSet2_CurrencyHedge,
				lastUpdatedBy_ParamSet2_CurrencyHedge,
				lastUpdatedDate_ParamSet2_CurrencyHedge,
				active_ParamSet2_CurrencyHedge);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_CurrencyHedge = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_CurrencyHedge
				.add(fxoDealGovernanceParameters_ParamSet1_CurrencyHedge);
		fxoDealGovernanceParameters_CurrencyHedge
				.add(fxoDealGovernanceParameters_ParamSet2_CurrencyHedge);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_CurrencyHedge, false))
				.willReturn(fxoDealGovernanceParameters_CurrencyHedge);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_CurrencyHedge = getADealGovernanceConfigDTO(
				null, product_ParamSet1_CurrencyHedge,
				direction_ParamSet1_CurrencyHedge,
				minimum_ParamSet1_CurrencyHedge,
				maximum_ParamSet1_CurrencyHedge, null, null,
				lastUpdatedBy_ParamSet1_CurrencyHedge,
				lastUpdatedDateTime_ParamSet1_CurrencyHedge, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_CurrencyHedge))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_CurrencyHedge);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_CurrencyHedge = getADealGovernanceConfigDTO(
				null, product_ParamSet2_CurrencyHedge,
				direction_ParamSet2_CurrencyHedge,
				minimum_ParamSet2_CurrencyHedge,
				maximum_ParamSet2_CurrencyHedge, null, null,
				lastUpdatedBy_ParamSet2_CurrencyHedge,
				lastUpdatedDateTime_ParamSet2_CurrencyHedge, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_CurrencyHedge))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_CurrencyHedge);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_CurrencyHedge))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_CurrencyHedge))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> currencyHedgeThresholdDTOs = Arrays
				.asList(dealGovernanceConfigDTO_ParamSet1_CurrencyHedge,
						dealGovernanceConfigDTO_ParamSet2_CurrencyHedge);

		// RawPremium

		String validationCode_RawPremium = DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION;

		String product_ParamSet1_Buy_RawPremium = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Buy_RawPremium = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet1_Buy_RawPremium = Directions.DIRECTION_BUY;
		String minimum_ParamSet1_Buy_RawPremium = "0.08";
		String maximum_ParamSet1_Buy_RawPremium = null;
		String createdBy_ParamSet1_Buy_RawPremium = "SYS";
		Timestamp createdDate_ParamSet1_Buy_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Buy_RawPremium = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Buy_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Buy_RawPremium = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Buy_RawPremium = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Buy_RawPremium = getAFXODealGovernanceParameters(
				product_ParamSet1_Buy_RawPremium,
				optionType_ParamSet1_Buy_RawPremium, validationCode_RawPremium,
				direction_ParamSet1_Buy_RawPremium,
				minimum_ParamSet1_Buy_RawPremium,
				maximum_ParamSet1_Buy_RawPremium, null, null,
				createdBy_ParamSet1_Buy_RawPremium,
				createdDate_ParamSet1_Buy_RawPremium,
				lastUpdatedBy_ParamSet1_Buy_RawPremium,
				lastUpdatedDate_ParamSet1_Buy_RawPremium,
				active_ParamSet1_Buy_RawPremium);

		String product_ParamSet1_Sell_RawPremium = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Sell_RawPremium = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet1_Sell_RawPremium = Directions.DIRECTION_SELL;
		String minimum_ParamSet1_Sell_RawPremium = null;
		String maximum_ParamSet1_Sell_RawPremium = "5";
		String createdBy_ParamSet1_Sell_RawPremium = "SYS";
		Timestamp createdDate_ParamSet1_Sell_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Sell_RawPremium = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Sell_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Sell_RawPremium = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Sell_RawPremium = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Sell_RawPremium = getAFXODealGovernanceParameters(
				product_ParamSet1_Sell_RawPremium,
				optionType_ParamSet1_Sell_RawPremium,
				validationCode_RawPremium, direction_ParamSet1_Sell_RawPremium,
				minimum_ParamSet1_Sell_RawPremium,
				maximum_ParamSet1_Sell_RawPremium, null, null,
				createdBy_ParamSet1_Sell_RawPremium,
				createdDate_ParamSet1_Sell_RawPremium,
				lastUpdatedBy_ParamSet1_Sell_RawPremium,
				lastUpdatedDate_ParamSet1_Sell_RawPremium,
				active_ParamSet1_Sell_RawPremium);

		String product_ParamSet2_Buy_RawPremium = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Buy_RawPremium = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet2_Buy_RawPremium = Directions.DIRECTION_BUY;
		String minimum_ParamSet2_Buy_RawPremium = "0.08";
		String maximum_ParamSet2_Buy_RawPremium = null;
		String createdBy_ParamSet2_Buy_RawPremium = "SYS";
		Timestamp createdDate_ParamSet2_Buy_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Buy_RawPremium = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Buy_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Buy_RawPremium = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Buy_RawPremium = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Buy_RawPremium = getAFXODealGovernanceParameters(
				product_ParamSet2_Buy_RawPremium,
				optionType_ParamSet2_Buy_RawPremium, validationCode_RawPremium,
				direction_ParamSet2_Buy_RawPremium,
				minimum_ParamSet2_Buy_RawPremium,
				maximum_ParamSet2_Buy_RawPremium, null, null,
				createdBy_ParamSet2_Buy_RawPremium,
				createdDate_ParamSet2_Buy_RawPremium,
				lastUpdatedBy_ParamSet2_Buy_RawPremium,
				lastUpdatedDate_ParamSet2_Buy_RawPremium,
				active_ParamSet2_Buy_RawPremium);

		String product_ParamSet2_Sell_RawPremium = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Sell_RawPremium = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
		String direction_ParamSet2_Sell_RawPremium = Directions.DIRECTION_SELL;
		String minimum_ParamSet2_Sell_RawPremium = null;
		String maximum_ParamSet2_Sell_RawPremium = "5";
		String createdBy_ParamSet2_Sell_RawPremium = "SYS";
		Timestamp createdDate_ParamSet2_Sell_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Sell_RawPremium = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Sell_RawPremium = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Sell_RawPremium = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Sell_RawPremium = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Sell_RawPremium = getAFXODealGovernanceParameters(
				product_ParamSet2_Sell_RawPremium,
				optionType_ParamSet2_Sell_RawPremium,
				validationCode_RawPremium, direction_ParamSet2_Sell_RawPremium,
				minimum_ParamSet2_Sell_RawPremium,
				maximum_ParamSet2_Sell_RawPremium, null, null,
				createdBy_ParamSet2_Sell_RawPremium,
				createdDate_ParamSet2_Sell_RawPremium,
				lastUpdatedBy_ParamSet2_Sell_RawPremium,
				lastUpdatedDate_ParamSet2_Sell_RawPremium,
				active_ParamSet2_Sell_RawPremium);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_RawPremium = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_RawPremium
				.add(fxoDealGovernanceParameters_ParamSet1_Buy_RawPremium);
		fxoDealGovernanceParameters_RawPremium
				.add(fxoDealGovernanceParameters_ParamSet1_Sell_RawPremium);
		fxoDealGovernanceParameters_RawPremium
				.add(fxoDealGovernanceParameters_ParamSet2_Buy_RawPremium);
		fxoDealGovernanceParameters_RawPremium
				.add(fxoDealGovernanceParameters_ParamSet2_Sell_RawPremium);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_RawPremium, false)).willReturn(
				fxoDealGovernanceParameters_RawPremium);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Buy_RawPremium = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Buy_RawPremium,
				direction_ParamSet1_Buy_RawPremium,
				minimum_ParamSet1_Buy_RawPremium,
				maximum_ParamSet1_Buy_RawPremium, null, null,
				lastUpdatedBy_ParamSet1_Buy_RawPremium,
				lastUpdatedDateTime_ParamSet1_Buy_RawPremium, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Buy_RawPremium))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Buy_RawPremium);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Sell_RawPremium = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Sell_RawPremium,
				direction_ParamSet1_Sell_RawPremium,
				minimum_ParamSet1_Sell_RawPremium,
				maximum_ParamSet1_Sell_RawPremium, null, null,
				lastUpdatedBy_ParamSet1_Sell_RawPremium,
				lastUpdatedDateTime_ParamSet1_Sell_RawPremium, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Sell_RawPremium))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Sell_RawPremium);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Buy_RawPremium = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Buy_RawPremium,
				direction_ParamSet2_Buy_RawPremium,
				minimum_ParamSet2_Buy_RawPremium,
				maximum_ParamSet2_Buy_RawPremium, null, null,
				lastUpdatedBy_ParamSet2_Buy_RawPremium,
				lastUpdatedDateTime_ParamSet2_Buy_RawPremium, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Buy_RawPremium))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Buy_RawPremium);

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Sell_RawPremium = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Sell_RawPremium,
				direction_ParamSet2_Sell_RawPremium,
				minimum_ParamSet2_Sell_RawPremium,
				maximum_ParamSet2_Sell_RawPremium, null, null,
				lastUpdatedBy_ParamSet2_Sell_RawPremium,
				lastUpdatedDateTime_ParamSet2_Sell_RawPremium, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Sell_RawPremium))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Sell_RawPremium);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Buy_RawPremium))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Buy_RawPremium))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> rawPremiumThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Buy_RawPremium,
				dealGovernanceConfigDTO_ParamSet1_Sell_RawPremium,
				dealGovernanceConfigDTO_ParamSet2_Buy_RawPremium,
				dealGovernanceConfigDTO_ParamSet2_Sell_RawPremium);

		// Barrier

		String validationCode_Barrier = DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION;
		String product_ParamSet1_Barrier = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_Barrier = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_Barrier = null;
		String minimum_ParamSet1_Barrier = null;
		String maximum_ParamSet1_Barrier = null;
		String createdBy_ParamSet1_Barrier = "SYS";
		Timestamp createdDate_ParamSet1_Barrier = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_Barrier = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_Barrier = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet1_Barrier = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet1_Barrier = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_Barrier = getAFXODealGovernanceParameters(
				product_ParamSet1_Barrier, optionType_ParamSet1_Barrier,
				validationCode_Barrier, direction_ParamSet1_Barrier,
				minimum_ParamSet1_Barrier, maximum_ParamSet1_Barrier, null,
				null, createdBy_ParamSet1_Barrier,
				createdDate_ParamSet1_Barrier, lastUpdatedBy_ParamSet1_Barrier,
				lastUpdatedDate_ParamSet1_Barrier, active_ParamSet1_Barrier);

		String product_ParamSet2_Barrier = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_Barrier = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_Barrier = null;
		String minimum_ParamSet2_Barrier = null;
		String maximum_ParamSet2_Barrier = null;
		String createdBy_ParamSet2_Barrier = "SYS";
		Timestamp createdDate_ParamSet2_Barrier = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_Barrier = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_Barrier = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		DateTime lastUpdatedDateTime_ParamSet2_Barrier = new DateTime(
				"2016-01-14T14:48:15.987");
		String active_ParamSet2_Barrier = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_Barrier = getAFXODealGovernanceParameters(
				product_ParamSet2_Barrier, optionType_ParamSet2_Barrier,
				validationCode_Barrier, direction_ParamSet2_Barrier,
				minimum_ParamSet2_Barrier, maximum_ParamSet2_Barrier, null,
				null, createdBy_ParamSet2_Barrier,
				createdDate_ParamSet2_Barrier, lastUpdatedBy_ParamSet2_Barrier,
				lastUpdatedDate_ParamSet2_Barrier, active_ParamSet2_Barrier);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_Barrier = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_Barrier
				.add(fxoDealGovernanceParameters_ParamSet1_Barrier);
		fxoDealGovernanceParameters_Barrier
				.add(fxoDealGovernanceParameters_ParamSet2_Barrier);

		given(
				fxoDealGovernanceParametersRepository
						.getAllDealGovernanceParameterByValidationCode(
								validationCode_Barrier, false)).willReturn(
				fxoDealGovernanceParameters_Barrier);

		// prepare data for DealGovernanceParametersDTO Collection (intermediate
		// result)
		// 1st

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet1_Barrier = getADealGovernanceConfigDTO(
				null, product_ParamSet1_Barrier, direction_ParamSet1_Barrier,
				minimum_ParamSet1_Barrier, maximum_ParamSet1_Barrier, null,
				null, lastUpdatedBy_ParamSet1_Barrier,
				lastUpdatedDateTime_ParamSet1_Barrier, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet1_Barrier))
				.willReturn(dealGovernanceConfigDTO_ParamSet1_Barrier);

		// 2nd

		DealGovernanceConfigDTO dealGovernanceConfigDTO_ParamSet2_Barrier = getADealGovernanceConfigDTO(
				null, product_ParamSet2_Barrier, direction_ParamSet2_Barrier,
				minimum_ParamSet2_Barrier, maximum_ParamSet2_Barrier, null,
				null, lastUpdatedBy_ParamSet2_Barrier,
				lastUpdatedDateTime_ParamSet2_Barrier, Boolean.TRUE);

		given(
				dealGovernanceConfigDTOEntityConverter
						.fromEntity(fxoDealGovernanceParameters_ParamSet2_Barrier))
				.willReturn(dealGovernanceConfigDTO_ParamSet2_Barrier);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet1_Barrier))
				.willReturn(hierarchy_VANILLA);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(product_ParamSet2_Barrier))
				.willReturn(hierarchy_RR);

		List<DealGovernanceConfigDTO> barrierThresholdDTOs = Arrays.asList(
				dealGovernanceConfigDTO_ParamSet1_Barrier,
				dealGovernanceConfigDTO_ParamSet2_Barrier);

		// when
		DealGovernanceConfigListDTO dealGovernanceConfigListDTO = dealGovernanceConfigAdminServiceImpl
				.getGlobalDealGovernanceConfigurationList();

		// then
		assertThat(dealGovernanceConfigListDTO).isNotNull();

		assertThat(dealGovernanceConfigListDTO.getNotionalThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getNotionalThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getNotionalThreshold())
				.isEqualTo(investmentAmountThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_InvestmentAmount, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_InvestmentAmount);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_InvestmentAmount);

		assertThat(dealGovernanceConfigListDTO.getDeltaAmountThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getDeltaAmountThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getDeltaAmountThreshold())
				.isEqualTo(deltaAmountThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_DeltaAmount, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_DeltaAmount);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_DeltaAmount);

		assertThat(dealGovernanceConfigListDTO.getDeltaPercentThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getDeltaPercentThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getDeltaPercentThreshold())
				.isEqualTo(deltaPercentThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_DeltaPercent, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_DeltaPercent);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_DeltaPercent);

		assertThat(dealGovernanceConfigListDTO.getMarginThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getMarginThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getMarginThreshold()).isEqualTo(
				marginAmountThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_MarginAmount, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_MarginAmount);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_MarginAmount);

		assertThat(dealGovernanceConfigListDTO.getVegaThreshold()).isNotNull();
		assertThat(dealGovernanceConfigListDTO.getVegaThreshold()).isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getVegaThreshold()).isEqualTo(
				vegaThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_Vega, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Vega);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Vega);

		assertThat(dealGovernanceConfigListDTO.getVolatilityThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getVolatilityThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getVolatilityThreshold())
				.isEqualTo(volatilityThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_Volatility, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Volatility);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Volatility);

		assertThat(dealGovernanceConfigListDTO.getTenorThreshold()).isNotNull();
		assertThat(dealGovernanceConfigListDTO.getTenorThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getTenorThreshold()).isEqualTo(
				tenorThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_Tenor, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Tenor);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Tenor);

		assertThat(dealGovernanceConfigListDTO.getStealthThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getStealthThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getStealthThreshold())
				.isEqualTo(stealthThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_Stealth, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Stealth);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Stealth);

		assertThat(dealGovernanceConfigListDTO.getTraderNotificationThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getTraderNotificationThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getTraderNotificationThreshold())
				.isEqualTo(currencyHedgeThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_CurrencyHedge, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_CurrencyHedge);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_CurrencyHedge);

		assertThat(dealGovernanceConfigListDTO.getBarrierThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getBarrierThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getBarrierThreshold())
				.isEqualTo(barrierThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_Barrier, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Barrier);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Barrier);

		assertThat(dealGovernanceConfigListDTO.getPremiumThreshold())
				.isNotNull();
		assertThat(dealGovernanceConfigListDTO.getPremiumThreshold())
				.isNotEmpty();
		assertThat(dealGovernanceConfigListDTO.getPremiumThreshold())
				.isEqualTo(rawPremiumThresholdDTOs);

		BDDMockito.verify(fxoDealGovernanceParametersRepository,
				BDDMockito.times(1))
				.getAllDealGovernanceParameterByValidationCode(
						validationCode_RawPremium, false);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Buy_RawPremium);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet1_Sell_RawPremium);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Buy_RawPremium);

		BDDMockito.verify(dealGovernanceConfigDTOEntityConverter,
				BDDMockito.times(1)).fromEntity(
				fxoDealGovernanceParameters_ParamSet2_Sell_RawPremium);

		BDDMockito
				.verify(fxoProductCatalogueGroupService, BDDMockito.times(11))
				.getHierarchyAsCodeValue(groupCode_VANILLA);
		BDDMockito
				.verify(fxoProductCatalogueGroupService, BDDMockito.times(11))
				.getHierarchyAsCodeValue(groupCode_RR);
		BDDMockito.verify(fxoProductCatalogueGroupService, BDDMockito.times(1))
				.getHierarchyAsCodeValue(groupCode_ParamSet_KI);
		BDDMockito.verify(fxoProductCatalogueGroupService, BDDMockito.times(1))
				.getHierarchyAsCodeValue(groupCode_ParamSet_KO);

	}

	public void shouldFetchFXODealGovernanceParametersEntitiesToUpdate() {

		String validationCode_InvestmentAmount = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;
		String group = null;
		String direction = null;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, group, direction, null, null, null, null, null, null,
				true);

		dealGovernanceConfigDTO
				.setValidationCode(validationCode_InvestmentAmount);

		// prepare entity Collection Data

		String product_ParamSet1_InvestmentAmount = Products.PRODUCT_VANILLA;
		String optionType_ParamSet1_InvestmentAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet1_InvestmentAmount = null;
		String minimum_ParamSet1_InvestmentAmount = "200000";
		String maximum_ParamSet1_InvestmentAmount = "10000000";
		String createdBy_ParamSet1_InvestmentAmount = "SYS";
		Timestamp createdDate_ParamSet1_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet1_InvestmentAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet1_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");

		String active_ParamSet1_InvestmentAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet1_InvestmentAmount = getAFXODealGovernanceParameters(
				product_ParamSet1_InvestmentAmount,
				optionType_ParamSet1_InvestmentAmount,
				validationCode_InvestmentAmount,
				direction_ParamSet1_InvestmentAmount,
				minimum_ParamSet1_InvestmentAmount,
				maximum_ParamSet1_InvestmentAmount, null, null,
				createdBy_ParamSet1_InvestmentAmount,
				createdDate_ParamSet1_InvestmentAmount,
				lastUpdatedBy_ParamSet1_InvestmentAmount,
				lastUpdatedDate_ParamSet1_InvestmentAmount,
				active_ParamSet1_InvestmentAmount);

		String product_ParamSet2_InvestmentAmount = Products.PRODUCT_RISKREVERSAL;
		String optionType_ParamSet2_InvestmentAmount = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;

		String direction_ParamSet2_InvestmentAmount = null;
		String minimum_ParamSet2_InvestmentAmount = "200000";
		String maximum_ParamSet2_InvestmentAmount = "10000000";
		String createdBy_ParamSet2_InvestmentAmount = "SYS";
		Timestamp createdDate_ParamSet2_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");
		String lastUpdatedBy_ParamSet2_InvestmentAmount = "SGTrader";
		Timestamp lastUpdatedDate_ParamSet2_InvestmentAmount = Timestamp
				.valueOf("2016-01-14 14:48:15.987");

		String active_ParamSet2_InvestmentAmount = BooleanCodes.BooleanCodes_True;

		FXODealGovernanceParameters fxoDealGovernanceParameters_ParamSet2_InvestmentAmount = getAFXODealGovernanceParameters(
				product_ParamSet2_InvestmentAmount,
				optionType_ParamSet2_InvestmentAmount,
				validationCode_InvestmentAmount,
				direction_ParamSet2_InvestmentAmount,
				minimum_ParamSet2_InvestmentAmount,
				maximum_ParamSet2_InvestmentAmount, null, null,
				createdBy_ParamSet2_InvestmentAmount,
				createdDate_ParamSet2_InvestmentAmount,
				lastUpdatedBy_ParamSet2_InvestmentAmount,
				lastUpdatedDate_ParamSet2_InvestmentAmount,
				active_ParamSet2_InvestmentAmount);

		List<FXODealGovernanceParameters> fxoDealGovernanceParameters_InvestmentAmount = new ArrayList<FXODealGovernanceParameters>();

		fxoDealGovernanceParameters_InvestmentAmount
				.add(fxoDealGovernanceParameters_ParamSet1_InvestmentAmount);
		fxoDealGovernanceParameters_InvestmentAmount
				.add(fxoDealGovernanceParameters_ParamSet2_InvestmentAmount);

		// given
		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getAllProducts(ProductGroups.PRODUCT_GROUP_MASTER))
				.willReturn(
						Arrays.asList(Products.PRODUCT_VANILLA,
								Products.PRODUCT_RISKREVERSAL));

		BDDMockito
				.given(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								Products.PRODUCT_VANILLA,
								validationCode_InvestmentAmount, direction,
								false)).willReturn(
						fxoDealGovernanceParameters_ParamSet1_InvestmentAmount);

		BDDMockito
				.given(fxoDealGovernanceParametersRepository
						.getOneDealGovernanceParameterByProductAndValidationCodeAndDirection(
								Products.PRODUCT_RISKREVERSAL,
								validationCode_InvestmentAmount, direction,
								false)).willReturn(
						fxoDealGovernanceParameters_ParamSet2_InvestmentAmount);

		// when
		List<FXODealGovernanceParameters> fxoDealGovernanceParametersEntities = dealGovernanceConfigAdminServiceImpl
				.fetchFXODealGovernanceParametersEntitiesToUpdate(dealGovernanceConfigDTO);

		// then
		assertThat(fxoDealGovernanceParametersEntities).isNotNull();
		assertThat(fxoDealGovernanceParametersEntities.size()).isEqualTo(2);
		assertThat(fxoDealGovernanceParametersEntities).isEqualTo(
				fxoDealGovernanceParameters_InvestmentAmount);
	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldFetchFXODealGovernanceParametersEntitiesToUpdate_Exception() {

		String validationCode_InvestmentAmount = null;
		String group = null;
		String direction = null;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, group, direction, null, null, null, null, null, null,
				true);

		dealGovernanceConfigDTO
				.setValidationCode(validationCode_InvestmentAmount);

		// when
		dealGovernanceConfigAdminServiceImpl
				.fetchFXODealGovernanceParametersEntitiesToUpdate(dealGovernanceConfigDTO);

	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldFetchFXODealGovernanceParametersEntitiesToUpdate_DBException() {

		String validationCode_InvestmentAmount = DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION;
		String group = null;
		String direction = null;

		DealGovernanceConfigDTO dealGovernanceConfigDTO = getADealGovernanceConfigDTO(
				null, group, direction, null, null, null, null, null, null,
				true);

		dealGovernanceConfigDTO
				.setValidationCode(validationCode_InvestmentAmount);

		// given
		BDDMockito.given(
				fxoProductCatalogueGroupService
						.getAllProducts(ProductGroups.PRODUCT_GROUP_MASTER))
				.willReturn(
						Arrays.asList(Products.PRODUCT_VANILLA,
								Products.PRODUCT_RISKREVERSAL));

		// when
		dealGovernanceConfigAdminServiceImpl
				.fetchFXODealGovernanceParametersEntitiesToUpdate(dealGovernanceConfigDTO);

	}
}
