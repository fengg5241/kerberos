package com.fxo.admin.service;

import static org.hamcrest.CoreMatchers.containsString;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.converter.FXOInterPortfolioConfigDTOEntityConverter;
import com.fxo.admin.dto.converter.FXOInterPortfolioListDTOEntityConverter;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.dao.repository.FXOInterPortfolioRepository;
import com.fxo.dao.repository.FXOUserInterPortfolioMappingRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.DateTimeUtil;

public class FXOUserInterPortfolioMappingConfigQueryServiceImplTest {

	public static final SimpleDateFormat dateFormat = new SimpleDateFormat(
			"E MMM dd hh:mm:ss Z yyyy");

	@Mock
	private FXOUserInterPortfolioMappingRepository fxoUserInterPortfolioMappingRepository;

	@InjectMocks
	private FXOUserInterPortfolioMappingConfigQueryServiceImpl fxoUserInterPortfolioMappingConfigQueryServiceImpl;

	@Mock
	private FXOInterPortfolioConfigDTOEntityConverter fxoUserInterPortfolioConfigDTOEntityConverter;

	@Mock
	private FXOInterPortfolioRepository fxoInterPortfolioRepository;

	@Mock
	private FXOInterPortfolioListDTOEntityConverter fxoAdminInterPortfolioDTOEntityConverter;

	@BeforeMethod
	public void beforeMethod() {
		MockitoAnnotations.initMocks(this);
	}

	@AfterMethod
	public void afterMethod() {
	}

	@Test
	public void shouldReturnUserUnAssignedPortfolio() throws ParseException {

		// given

		String userId = "tmsguser1";

		String active__DB_1 = "true";
		String interPortfolio_DB_1 = "DBS FA INTERNAL";
		String updatedBy_DB_1 = "tmsguser1_1";

		String active_DB_2 = "true";
		String interPortfolio_DB_2 = "DBSSG AMM CDS";
		String updatedBy_DB_2 = "tmsguser1_2";

		String active_DB_3 = "true";
		String interPortfolio_DB_3 = "DBSSG CMU XTRN";
		String updatedBy_DB_3 = "tmsguser1_3";

		String active_DB_4 = "true";
		String interPortfolio_DB_4 = "DBSSG CMU YLDCP";
		String updatedBy_DB_4 = "tmsguser1_4";

		String active_DB_5 = "true";
		String interPortfolio_DB_5 = "DBSSG COLL BOND";
		String updatedBy_DB_5 = "tmsguser1_5";

		String active_DB_6 = "true";
		String interPortfolio_DB_6 = "DBSSG COMOP MGT";
		String updatedBy_DB_6 = "tmsguser1_6";

		Timestamp lastUpdateTimeStamp = DateTimeUtil.getCurrentSQLTimeStamp();

		DateTime lastUpdatedTime = DateTimeUtil
				.convertTimeStampToDateTime(lastUpdateTimeStamp);

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioUserMappings = new ArrayList<FXOUserInterPortfolioMapping>();
		fxoUserInterPortfolioUserMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active__DB_1,
						interPortfolio_DB_1, updatedBy_DB_1,
						lastUpdateTimeStamp, userId));
		fxoUserInterPortfolioUserMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_2,
						interPortfolio_DB_2, updatedBy_DB_2,
						lastUpdateTimeStamp, userId));
		fxoUserInterPortfolioUserMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_3,
						interPortfolio_DB_3, updatedBy_DB_3,
						lastUpdateTimeStamp, userId));

		List<FXOInterPortfolio> fxoUserInterPortfolioAllMappings = new ArrayList<FXOInterPortfolio>();

		fxoUserInterPortfolioAllMappings.add(getAFXOInterPortfolioEntity(
				interPortfolio_DB_4, updatedBy_DB_4, lastUpdateTimeStamp));
		fxoUserInterPortfolioAllMappings.add(getAFXOInterPortfolioEntity(
				interPortfolio_DB_3, updatedBy_DB_3, lastUpdateTimeStamp));
		fxoUserInterPortfolioAllMappings.add(getAFXOInterPortfolioEntity(
				interPortfolio_DB_5, updatedBy_DB_5, lastUpdateTimeStamp));
		fxoUserInterPortfolioAllMappings.add(getAFXOInterPortfolioEntity(
				interPortfolio_DB_6, updatedBy_DB_6, lastUpdateTimeStamp));

		String active_DTO_4 = "true";
		String interPortfolio_DTO_4 = "DBSSG CMU YLDCP";
		String updatedBy_DTO_4 = "tmsguser1_4";

		String active_DTO_5 = "true";
		String interPortfolio_DTO_5 = "DBSSG COLL BOND";
		String updatedBy_DTO_5 = "tmsguser1_5";

		String active_DTO_6 = "true";
		String interPortfolio_DTO_6 = "DBSSG COMOP MGT";
		String updatedBy_DTO_6 = "tmsguser1_6";

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOByUser = new ArrayList<FXOInterPortfolioConfigDTO>();

		fxoInterPortfolioConfigDTOByUser.add(getAFXOInterPortfolioConfigDTO(
				active__DB_1, interPortfolio_DB_1, updatedBy_DB_1,
				lastUpdatedTime));
		fxoInterPortfolioConfigDTOByUser.add(getAFXOInterPortfolioConfigDTO(
				active_DB_2, interPortfolio_DB_2, updatedBy_DB_2,
				lastUpdatedTime));
		fxoInterPortfolioConfigDTOByUser.add(getAFXOInterPortfolioConfigDTO(
				active_DB_3, interPortfolio_DB_3, updatedBy_DB_3,
				lastUpdatedTime));

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOAllMapping = new ArrayList<FXOInterPortfolioConfigDTO>();

		fxoInterPortfolioConfigDTOAllMapping
				.add(getAFXOInterPortfolioConfigDTO(active_DB_4,
						interPortfolio_DB_4, updatedBy_DB_4, lastUpdatedTime));
		fxoInterPortfolioConfigDTOAllMapping
				.add(getAFXOInterPortfolioConfigDTO(active_DB_5,
						interPortfolio_DB_5, updatedBy_DB_5, lastUpdatedTime));
		fxoInterPortfolioConfigDTOAllMapping
				.add(getAFXOInterPortfolioConfigDTO(active_DB_6,
						interPortfolio_DB_6, updatedBy_DB_6, lastUpdatedTime));
		fxoInterPortfolioConfigDTOAllMapping
				.add(getAFXOInterPortfolioConfigDTO(active_DB_3,
						interPortfolio_DB_3, updatedBy_DB_3, lastUpdatedTime));

		given(
				fxoUserInterPortfolioMappingRepository
						.getAllUserInterPortfolioMappingByUser(userId))
				.willReturn(fxoUserInterPortfolioUserMappings);

		given(fxoInterPortfolioRepository.getAllInterPortfolio()).willReturn(
				fxoUserInterPortfolioAllMappings);

		given(
				fxoUserInterPortfolioConfigDTOEntityConverter
						.fromEntities(fxoUserInterPortfolioUserMappings))
				.willReturn(fxoInterPortfolioConfigDTOByUser);

		given(
				fxoAdminInterPortfolioDTOEntityConverter
						.fromEntities(fxoUserInterPortfolioAllMappings))
				.willReturn(fxoInterPortfolioConfigDTOAllMapping);

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTO_expected = new ArrayList<FXOInterPortfolioConfigDTO>();
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DTO_4, interPortfolio_DTO_4, updatedBy_DTO_4,
				lastUpdatedTime));
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DTO_5, interPortfolio_DTO_5, updatedBy_DTO_5,
				lastUpdatedTime));
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DTO_6, interPortfolio_DTO_6, updatedBy_DTO_6,
				lastUpdatedTime));

		// when
		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTO_actual = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.getAllUnAssignedUserInterPortfolio(userId);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getAllUserInterPortfolioMappingByUser(userId);
		verify(fxoInterPortfolioRepository, times(1)).getAllInterPortfolio();

		// then
		Assert.assertNotNull(fxoInterPortfolioConfigDTO_actual);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_expected.size(),
				fxoInterPortfolioConfigDTO_actual.size());
		Assert.assertEquals(fxoInterPortfolioConfigDTO_expected,
				fxoInterPortfolioConfigDTO_actual);
		Assert.assertEquals(3, fxoInterPortfolioConfigDTO_actual.size());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1 = fxoInterPortfolioConfigDTO_actual
				.get(0);

		Assert.assertEquals(interPortfolio_DTO_4,
				fxoInterPortfolioConfigDTO_1.getInterPortfolio());
		Assert.assertEquals(updatedBy_DTO_4,
				fxoInterPortfolioConfigDTO_1.getUpdatedBy());
		Assert.assertEquals(Boolean.valueOf(active_DTO_4),
				fxoInterPortfolioConfigDTO_1.getActive());

		Assert.assertEquals(lastUpdatedTime,
				fxoInterPortfolioConfigDTO_1.getUpdatedAt());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2 = fxoInterPortfolioConfigDTO_actual
				.get(1);

		Assert.assertEquals(interPortfolio_DTO_5,
				fxoInterPortfolioConfigDTO_2.getInterPortfolio());
		Assert.assertEquals(updatedBy_DTO_5,
				fxoInterPortfolioConfigDTO_2.getUpdatedBy());
		Assert.assertEquals(Boolean.valueOf(active_DTO_4),
				fxoInterPortfolioConfigDTO_2.getActive());

		Assert.assertEquals(lastUpdatedTime,
				fxoInterPortfolioConfigDTO_1.getUpdatedAt());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_3 = fxoInterPortfolioConfigDTO_actual
				.get(2);

		Assert.assertEquals(interPortfolio_DTO_6,
				fxoInterPortfolioConfigDTO_3.getInterPortfolio());
		Assert.assertEquals(updatedBy_DTO_6,
				fxoInterPortfolioConfigDTO_3.getUpdatedBy());
		Assert.assertEquals(Boolean.valueOf(active_DTO_6),
				fxoInterPortfolioConfigDTO_3.getActive());
		Assert.assertEquals(lastUpdatedTime,
				fxoInterPortfolioConfigDTO_3.getUpdatedAt());

	}

	@Test
	public void testExceptionForEmptyUserId() {

		// Given
		String userId = "";
		ApplicationRuntimeException applicationRuntimeException = null;

		// when

		try {
			fxoUserInterPortfolioMappingConfigQueryServiceImpl
					.getAllUnAssignedUserInterPortfolio(userId);
		} catch (ApplicationRuntimeException exception) {

			applicationRuntimeException = exception;
		}

		// then
		Assert.assertEquals(FXOMessageCodes.ERR_USER_INFO_REQUIRED,
				applicationRuntimeException.getSupportCode());
		Assert.assertThat(applicationRuntimeException.getSupportCode(),
				containsString(FXOMessageCodes.ERR_USER_INFO_REQUIRED));

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getAllUserInterPortfolioMappingByUser(userId);
		verify(fxoInterPortfolioRepository, times(0)).getAllInterPortfolio();
	}

	@Test
	public void testExeptionForNullUserId() {

		// given

		String userId = null;

		ApplicationRuntimeException actualException = null;

		// when

		try {
			fxoUserInterPortfolioMappingConfigQueryServiceImpl
					.getAllUnAssignedUserInterPortfolio(userId);
		} catch (ApplicationRuntimeException exception) {
			actualException = exception;
		}

		Assertions.assertThat(actualException).isNotNull();
		Assert.assertEquals(FXOMessageCodes.ERR_USER_INFO_REQUIRED,
				actualException.getSupportCode());
		Assert.assertThat(actualException.getSupportCode(),
				containsString(FXOMessageCodes.ERR_USER_INFO_REQUIRED));

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getAllUserInterPortfolioMappingByUser(userId);
		verify(fxoInterPortfolioRepository, times(0)).getAllInterPortfolio();
	}

	private FXOUserInterPortfolioMapping getAFXOUserInterPOInterPortfolioMapping(
			String active, String interPortfolio, String lastUpdatedBy,
			Timestamp lastUpdatedDate, String userId_1) throws ParseException {

		return new FXOUserInterPortfolioMapping()
				.setActive(active)
				.setInterPortfolio(
						getAFXOInterPortfolioEntity(interPortfolio,
								lastUpdatedBy, lastUpdatedDate))
				.setUserID(userId_1);
	}

	private FXOInterPortfolio getAFXOInterPortfolioEntity(
			String interPortfolio, String lastUpdatedBy,
			Timestamp lastUpdateDate) {
		return (FXOInterPortfolio) new FXOInterPortfolio()
				.setInterPortfolio(interPortfolio)
				.setLastUpdatedDate(lastUpdateDate)
				.setLastUpdatedBy(lastUpdatedBy);
	}

	private FXOInterPortfolioConfigDTO getAFXOInterPortfolioConfigDTO(
			String active, String interPortfolio, String updatedBy,
			DateTime updatedTime) throws ParseException {

		return new FXOInterPortfolioConfigDTO()
				.setActive(Boolean.valueOf(active))
				.setInterPortfolio(interPortfolio).setUpdatedBy(updatedBy)
				.setUpdatedAt(updatedTime);
	}

	@Test
	public void shouldReturnInterPortfolioListForUserId() throws ParseException {

		// Given
		String userId = "tmsgUser2";

		String active_DB_1 = "true";
		String interPortfolio_DB_1 = "DBS FA INTERNAL";
		String updatedBy_DB_1 = "tmsguser1_1";

		String active_DB_2 = "true";
		String interPortfolio_DB_2 = "DBSSG AMM CDS";
		String updatedBy_DB_2 = "tmsguser1_2";

		String active_DB_3 = "true";
		String interPortfolio_DB_3 = "DBSSG CMU XTRN";
		String updatedBy_DB_3 = "tmsguser1_3";

		String active_DB_4 = "true";
		String interPortfolio_DB_4 = "DBSSG CMU YLDCP";
		String updatedBy_DB_4 = "tmsguser1_4";

		Timestamp lastUpdateTimeStamp_DB = DateTimeUtil
				.getCurrentSQLTimeStamp();

		DateTime lastUpdatedTime_DTO = DateTimeUtil
				.convertTimeStampToDateTime(lastUpdateTimeStamp_DB);

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappings = new ArrayList<FXOUserInterPortfolioMapping>();
		fxoUserInterPortfolioMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_1,
						interPortfolio_DB_1, updatedBy_DB_1,
						lastUpdateTimeStamp_DB, userId));
		fxoUserInterPortfolioMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_2,
						interPortfolio_DB_2, updatedBy_DB_2,
						lastUpdateTimeStamp_DB, userId));
		fxoUserInterPortfolioMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_3,
						interPortfolio_DB_3, updatedBy_DB_3,
						lastUpdateTimeStamp_DB, userId));
		fxoUserInterPortfolioMappings
				.add(getAFXOUserInterPOInterPortfolioMapping(active_DB_4,
						interPortfolio_DB_4, updatedBy_DB_4,
						lastUpdateTimeStamp_DB, userId));

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTO_expected = new ArrayList<FXOInterPortfolioConfigDTO>();

		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DB_1, interPortfolio_DB_1, updatedBy_DB_1,
				lastUpdatedTime_DTO));
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DB_1, interPortfolio_DB_2, updatedBy_DB_2,
				lastUpdatedTime_DTO));
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DB_1, interPortfolio_DB_3, updatedBy_DB_3,
				lastUpdatedTime_DTO));
		fxoInterPortfolioConfigDTO_expected.add(getAFXOInterPortfolioConfigDTO(
				active_DB_1, interPortfolio_DB_4, updatedBy_DB_4,
				lastUpdatedTime_DTO));

		given(
				fxoUserInterPortfolioMappingRepository
						.getAllUserInterPortfolioMappingByUser(userId))
				.willReturn(fxoUserInterPortfolioMappings);

		given(
				fxoUserInterPortfolioConfigDTOEntityConverter
						.fromEntities(fxoUserInterPortfolioMappings))
				.willReturn(fxoInterPortfolioConfigDTO_expected);

		// when
		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTO_actual = fxoUserInterPortfolioMappingConfigQueryServiceImpl
				.getInterPortflioConfigMappingsByUserId(userId);

		// then
		Assert.assertNotNull(fxoInterPortfolioConfigDTO_actual);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_expected,
				fxoInterPortfolioConfigDTO_actual);

		Assert.assertEquals(4, fxoInterPortfolioConfigDTO_actual.size());
		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1 = fxoInterPortfolioConfigDTO_actual
				.get(0);

		Assert.assertNotNull(fxoInterPortfolioConfigDTO_1);
		Assert.assertEquals(Boolean.valueOf(active_DB_1),
				fxoInterPortfolioConfigDTO_1.getActive());
		Assert.assertEquals(interPortfolio_DB_1,
				fxoInterPortfolioConfigDTO_1.getInterPortfolio());
		Assert.assertEquals(updatedBy_DB_1,
				fxoInterPortfolioConfigDTO_1.getUpdatedBy());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2 = fxoInterPortfolioConfigDTO_actual
				.get(1);

		Assert.assertNotNull(fxoInterPortfolioConfigDTO_2);
		Assert.assertEquals(Boolean.valueOf(active_DB_2),
				fxoInterPortfolioConfigDTO_2.getActive());
		Assert.assertEquals(interPortfolio_DB_2,
				fxoInterPortfolioConfigDTO_2.getInterPortfolio());
		Assert.assertEquals(updatedBy_DB_2,
				fxoInterPortfolioConfigDTO_2.getUpdatedBy());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_3 = fxoInterPortfolioConfigDTO_actual
				.get(2);

		Assert.assertNotNull(fxoInterPortfolioConfigDTO_3);
		Assert.assertEquals(Boolean.valueOf(active_DB_3),
				fxoInterPortfolioConfigDTO_3.getActive());
		Assert.assertEquals(interPortfolio_DB_3,
				fxoInterPortfolioConfigDTO_3.getInterPortfolio());
		Assert.assertEquals(updatedBy_DB_3,
				fxoInterPortfolioConfigDTO_3.getUpdatedBy());

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_4 = fxoInterPortfolioConfigDTO_actual
				.get(3);

		Assert.assertNotNull(fxoInterPortfolioConfigDTO_4);
		Assert.assertEquals(Boolean.valueOf(active_DB_4),
				fxoInterPortfolioConfigDTO_4.getActive());
		Assert.assertEquals(interPortfolio_DB_4,
				fxoInterPortfolioConfigDTO_4.getInterPortfolio());
		Assert.assertEquals(updatedBy_DB_4,
				fxoInterPortfolioConfigDTO_4.getUpdatedBy());
		
		verify(fxoUserInterPortfolioConfigDTOEntityConverter , times(1)).fromEntities(fxoUserInterPortfolioMappings);
		
	}

}
