package com.fxo.admin.dto.converter;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.framework.util.DateTimeUtil;

@Test
@ContextConfiguration("classpath:./com/fxo/admin/dto/converter/test-DTOEntity-converters.xml")
public class FXOInterPortfolioConfigDTOEntityConverterTest extends
		AbstractTestNGSpringContextTests {

	public static final SimpleDateFormat dateFormat = new SimpleDateFormat(
			"E MMM dd hh:mm:ss Z yyyy");

	@Autowired
	FXOInterPortfolioConfigDTOEntityConverter fxoInterPortfolioConfigDTOEntityConverter;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);

	}

	public void shouldReturnnUserInterPortfolioConfigDTOList()
			throws ParseException {

		// Given
		String userId_1 = "tmsguser2";
		String active_1 = "true";
		String lastUpdatedBy_1 = "tmsgUser2";
		String interPortfolioId_1 = "1";
		String lastUpdatedAt_1 = "Wed Oct 19 19:09:19 SGT 2016";
		String interPortfolio_1 = "DBSSG AMM CDS";

		String userId_2 = "tmsguser2";
		String active_2 = "false";
		String lastUpdatedBy_2 = "tmsgUser2";
		String interPortfolioId_2 = "2";
		String lastUpdatedAt_2 = "Wed Oct 19 19:09:29 SGT 2016";
		String interPortfolio_2 = "DBSSG CMU XTRN";

		String userId_3 = "tmsguser2";
		String active_3 = "false";
		String lastUpdatedBy_3 = "tmsgUser2";
		String interPortfolioId_3 = "3";
		String lastUpdatedAt_3 = "Wed Oct 19 19:09:39 SGT 2016";
		String interPortfolio_3 = "DBSSG CMU YLDCP";

		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_1 = getAFXOUserInterPortfolioMappingFromParemeters(
				userId_1, active_1, interPortfolioId_1, lastUpdatedBy_1,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,
						lastUpdatedAt_1), interPortfolio_1);

		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_2 = getAFXOUserInterPortfolioMappingFromParemeters(
				userId_2, active_2, interPortfolioId_2, lastUpdatedBy_2,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,
						lastUpdatedAt_2), interPortfolio_2);

		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping_3 = getAFXOUserInterPortfolioMappingFromParemeters(
				userId_3, active_3, interPortfolioId_3, lastUpdatedBy_3,
				DateTimeUtil.parseStringAsSQLTimeStamp(dateFormat,
						lastUpdatedAt_3), interPortfolio_3);

		List<FXOUserInterPortfolioMapping> fxoUserInterPortfolioMappingList = new ArrayList<FXOUserInterPortfolioMapping>();
		fxoUserInterPortfolioMappingList.add(fxoUserInterPortfolioMapping_1);
		fxoUserInterPortfolioMappingList.add(fxoUserInterPortfolioMapping_2);
		fxoUserInterPortfolioMappingList.add(fxoUserInterPortfolioMapping_3);

		List<FXOInterPortfolioConfigDTO> fxoInterPortfolioConfigDTOs = fxoInterPortfolioConfigDTOEntityConverter
				.fromEntities(fxoUserInterPortfolioMappingList);

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_1 = fxoInterPortfolioConfigDTOs
				.get(0);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_1.getInterPortfolio(),
				interPortfolio_1);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_1.getUpdatedBy(),
				lastUpdatedBy_1);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_1.getActive(),
				Boolean.valueOf(active_1));

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_2 = fxoInterPortfolioConfigDTOs
				.get(1);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_2.getInterPortfolio(),
				interPortfolio_2);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_2.getUpdatedBy(),
				lastUpdatedBy_2);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_2.getActive(),
				Boolean.valueOf(active_2));

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO_3 = fxoInterPortfolioConfigDTOs
				.get(2);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_3.getInterPortfolio(),
				interPortfolio_3);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_3.getUpdatedBy(),
				lastUpdatedBy_3);
		Assert.assertEquals(fxoInterPortfolioConfigDTO_3.getActive(),
				Boolean.valueOf(active_3));

	}

	private FXOUserInterPortfolioMapping getAFXOUserInterPortfolioMappingFromParemeters(
			String userId, String active, String interPortfolioId,
			String lastUpdatedBy, Timestamp lastUpdatedAt, String interPortfolio) {

		FXOInterPortfolio fxoInterPortfolio = new FXOInterPortfolio();
		fxoInterPortfolio.setInterPortfolio(interPortfolio).setId(
				interPortfolioId);

		return (FXOUserInterPortfolioMapping) new FXOUserInterPortfolioMapping()
				.setUserID(userId).setActive(active)
				.setInterPortfolio(fxoInterPortfolio)
				.setLastUpdatedBy(lastUpdatedBy)
				.setLastUpdatedDate(lastUpdatedAt);

	}
}
