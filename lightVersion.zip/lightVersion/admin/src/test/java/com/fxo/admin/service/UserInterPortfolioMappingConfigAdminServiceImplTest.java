package com.fxo.admin.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.joda.time.DateTime;
import org.mockito.BDDMockito;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.admin.dto.converter.UserInterPortfolioConfigDTOEntityConverter;
import com.fxo.constants.admin.FXOAdminActionTypes;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.dao.entity.FXOUserInterPortfolioMapping;
import com.fxo.dao.repository.FXOInterPortfolioRepository;
import com.fxo.dao.repository.FXOUserInterPortfolioMappingRepository;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.validation.ValidationService;

public class UserInterPortfolioMappingConfigAdminServiceImplTest {

	@Mock
	private FXOUserInterPortfolioMappingRepository fxoUserInterPortfolioMappingRepository;

	@Mock
	private FXOInterPortfolioRepository fxoInterPortfolioRepository;

	@Mock
	private UserInterPortfolioConfigDTOEntityConverter userInterPortfolioConfigDTOEntityConverter;

	@Mock
	private ValidationService validationService;

	@InjectMocks
	UserInterPortfolioMappingConfigAdminServiceImpl userInterPortfolioMappingConfigAdminServiceImpl;

	@BeforeMethod
	public void beforeMethod() {
		MockitoAnnotations.initMocks(this);
	}

	@AfterMethod
	public void afterMethod() {
	}

	private FXOInterPortfolio getAFXOInterPortfolioEntity(
			String interPortfolio, String active) {

		FXOInterPortfolio fxoInterPortfolio = new FXOInterPortfolio();
		fxoInterPortfolio.setActive(active).setInterPortfolio(interPortfolio);

		return fxoInterPortfolio;
	}

	private FXOUserInterPortfolioMapping getAFXOUserInterPortfolioMappingEntity(
			String userID, FXOInterPortfolio interPortfolio, String active,
			String updatedBy, Timestamp updatedAt) {

		FXOUserInterPortfolioMapping fxoUserInterPortfolioMapping = new FXOUserInterPortfolioMapping();
		fxoUserInterPortfolioMapping.setUserID(userID).setActive(active)
				.setInterPortfolio(interPortfolio).setLastUpdatedBy(updatedBy)
				.setLastUpdatedDate(updatedAt);

		return fxoUserInterPortfolioMapping;
	}

	private FXOInterPortfolioConfigDTO getAFXOInterPortfolioConfigDTO(
			String interPortfolio, Boolean active, String updatedBy,
			DateTime updatedAt) {

		FXOInterPortfolioConfigDTO fxoInterPortfolioConfigDTO = new FXOInterPortfolioConfigDTO();

		fxoInterPortfolioConfigDTO.setInterPortfolio(interPortfolio)
				.setActive(active).setUpdatedBy(updatedBy)
				.setUpdatedAt(updatedAt);

		return fxoInterPortfolioConfigDTO;
	}

	@Test
	public void shouldCheckForModification_Identical() {
		// given
		String interPortfolio_input = "InterPortfolio";
		Boolean active_input = true;

		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input, active_input, null, null);

		String active = "TRUE";
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity = getAFXOUserInterPortfolioMappingEntity(
				null, null, active, null, null);

		// when
		boolean isModified = userInterPortfolioMappingConfigAdminServiceImpl
				.checkForModification(fxoInterPortfolioDTO,
						fxoUserInterPortfolioMappingEntity);

		// then
		assertThat(isModified).isFalse();
	}

	@Test
	public void shouldCheckForModification_Different() {
		// given
		String interPortfolio_input = "InterPortfolio";
		Boolean active_input = false;

		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input, active_input, null, null);

		String active = "TRUE";
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity = getAFXOUserInterPortfolioMappingEntity(
				null, null, active, null, null);

		// when
		boolean isModified = userInterPortfolioMappingConfigAdminServiceImpl
				.checkForModification(fxoInterPortfolioDTO,
						fxoUserInterPortfolioMappingEntity);

		// then
		assertThat(isModified).isTrue();
	}

	@Test
	public void shouldGetAdminActionType_ACTIVATE() {
		// given
		String interPortfolio_input = "InterPortfolio";
		Boolean active_input = true;

		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input, active_input, null, null);

		String active_case1 = "FALSE";
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity = getAFXOUserInterPortfolioMappingEntity(
				null, null, active_case1, null, null);

		// when
		FXOAdminActionTypes adminActionType_case1 = userInterPortfolioMappingConfigAdminServiceImpl
				.getAdminActionType(fxoInterPortfolioDTO,
						fxoUserInterPortfolioMappingEntity);

		// then
		assertThat(adminActionType_case1).isEqualTo(
				FXOAdminActionTypes.ACTIVATE);
	}

	@Test
	public void shouldGetAdminActionType_DEACTIVATE() {
		// given
		String interPortfolio_input = "InterPortfolio";
		Boolean active_input = false;

		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input, active_input, null, null);

		String active_case1 = "TRUE";
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case1 = getAFXOUserInterPortfolioMappingEntity(
				null, null, active_case1, null, null);

		// when
		FXOAdminActionTypes adminActionType_case1 = userInterPortfolioMappingConfigAdminServiceImpl
				.getAdminActionType(fxoInterPortfolioDTO,
						fxoUserInterPortfolioMappingEntity_case1);
		// then
		assertThat(adminActionType_case1).isEqualTo(
				FXOAdminActionTypes.DEACTIVATE);
	}

	@Test
	public void updateUserInterPortfolioMappings() {
		// given
		String userId = "User1";

		List<FXOInterPortfolioConfigDTO> interPortfolios = new ArrayList<FXOInterPortfolioConfigDTO>();
		List<FXOUserInterPortfolioMapping> userInterPortfolioMappings = new ArrayList<FXOUserInterPortfolioMapping>();
		String interPortfolio_input1 = "InterPortfolio1";
		Boolean active_input1 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO1 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input1, active_input1, null, null);

		String interPortfolio_input2 = "InterPortfolio2";
		Boolean active_input2 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO2 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input2, active_input2, null, null);

		String interPortfolio_input3 = "InterPortfolio3";
		Boolean active_input3 = false;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO3 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input3, active_input3, null, null);

		String interPortfolio_input4 = "InterPortfolio4";
		Boolean active_input4 = false;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO4 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input4, active_input4, null, null);

		interPortfolios.add(fxoInterPortfolioDTO1);
		interPortfolios.add(fxoInterPortfolioDTO2);
		interPortfolios.add(fxoInterPortfolioDTO3);
		interPortfolios.add(fxoInterPortfolioDTO4);

		String active_case1 = "TRUE";
		String interPortfolio_case1 = "InterPortfolio1";
		FXOInterPortfolio fxoInterPortfolio1 = getAFXOInterPortfolioEntity(
				interPortfolio_case1, active_case1);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case1 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio1, active_case1, null, null);

		String active_case2 = "FALSE";
		String interPortfolio_case2 = "InterPortfolio2";
		FXOInterPortfolio fxoInterPortfolio2 = getAFXOInterPortfolioEntity(
				interPortfolio_case2, active_case2);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case2 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio2, active_case2, null, null);

		String active_case3 = "FALSE";
		String interPortfolio_case3 = "InterPortfolio3";
		FXOInterPortfolio fxoInterPortfolio3 = getAFXOInterPortfolioEntity(
				interPortfolio_case3, active_case3);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case3 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio3, active_case3, null, null);

		String active_case4 = "TRUE";
		String interPortfolio_case4 = "InterPortfolio4";
		FXOInterPortfolio fxoInterPortfolio4 = getAFXOInterPortfolioEntity(
				interPortfolio_case4, active_case4);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case4 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio4, active_case4, null, null);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input1, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case1);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input2, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case2);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input3, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case3);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input4, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case4);

		String interPortfolio_input5 = "InterPortfolio5";

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input5, false))
				.willReturn(null);

		userInterPortfolioMappings
				.add(fxoUserInterPortfolioMappingEntity_case2);
		userInterPortfolioMappings
				.add(fxoUserInterPortfolioMappingEntity_case4);

		given(
				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping((List<FXOUserInterPortfolioMapping>) any()))
				.willReturn(userInterPortfolioMappings);

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = new FXOUserInterPortfolioMappingConfigListDTO();
		fxoUserInterPortfolioMappingConfigListDTO.setUserId(userId)
				.setInterPortfolios(interPortfolios);

		// when
		userInterPortfolioMappingConfigAdminServiceImpl
				.updateUserInterPortfolioMappings(new FXOUserInterPortfolioMappingConfigListWrapperDTO().setInterPortfolioMappingConfiguration(Arrays
						.asList(fxoUserInterPortfolioMappingConfigListDTO)));

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input1, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input2, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input3, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input4, false);

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input5, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.saveFXOUserInterPortfolioMapping(
						(List<FXOUserInterPortfolioMapping>) any());
	}

	@Test
	public void updateUserInterPortfolioMappings_NoUpdatesToDB() {
		// given
		String userId = "User1";

		List<FXOInterPortfolioConfigDTO> interPortfolios = new ArrayList<FXOInterPortfolioConfigDTO>();
		List<FXOUserInterPortfolioMapping> userInterPortfolioMappings = new ArrayList<FXOUserInterPortfolioMapping>();
		String interPortfolio_input1 = "InterPortfolio1";
		Boolean active_input1 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO1 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input1, active_input1, null, null);

		String interPortfolio_input2 = "InterPortfolio2";

		String interPortfolio_input3 = "InterPortfolio3";
		Boolean active_input3 = false;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO3 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input3, active_input3, null, null);

		interPortfolios.add(fxoInterPortfolioDTO1);
		interPortfolios.add(fxoInterPortfolioDTO3);

		String active_case1 = "TRUE";
		String interPortfolio_case1 = "InterPortfolio1";
		FXOInterPortfolio fxoInterPortfolio1 = getAFXOInterPortfolioEntity(
				interPortfolio_case1, active_case1);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case1 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio1, active_case1, null, null);

		String active_case2 = "FALSE";
		String interPortfolio_case2 = "InterPortfolio2";
		FXOInterPortfolio fxoInterPortfolio2 = getAFXOInterPortfolioEntity(
				interPortfolio_case2, active_case2);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case2 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio2, active_case2, null, null);

		String active_case3 = "FALSE";
		String interPortfolio_case3 = "InterPortfolio3";
		FXOInterPortfolio fxoInterPortfolio3 = getAFXOInterPortfolioEntity(
				interPortfolio_case3, active_case3);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case3 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio3, active_case3, null, null);

		String active_case4 = "TRUE";
		String interPortfolio_case4 = "InterPortfolio4";
		FXOInterPortfolio fxoInterPortfolio4 = getAFXOInterPortfolioEntity(
				interPortfolio_case4, active_case4);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case4 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio4, active_case4, null, null);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input1, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case1);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input2, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case2);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input3, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case3);

		String interPortfolio_input4 = "InterPortfolio4";

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input4, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case4);

		String interPortfolio_input5 = "InterPortfolio5";

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input5, false))
				.willReturn(null);

		given(
				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping((List<FXOUserInterPortfolioMapping>) any()))
				.willReturn(userInterPortfolioMappings);

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = new FXOUserInterPortfolioMappingConfigListDTO();
		fxoUserInterPortfolioMappingConfigListDTO.setUserId(userId)
				.setInterPortfolios(interPortfolios);

		FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO = new FXOUserInterPortfolioMappingConfigListWrapperDTO()
				.setInterPortfolioMappingConfiguration(Arrays
						.asList(fxoUserInterPortfolioMappingConfigListDTO));

		BDDMockito.willDoNothing().given(validationService)
				.validate(fxoUserInterPortfolioMappingConfigListWrapperDTO);

		// when
		userInterPortfolioMappingConfigAdminServiceImpl
				.updateUserInterPortfolioMappings(new FXOUserInterPortfolioMappingConfigListWrapperDTO().setInterPortfolioMappingConfiguration(Arrays
						.asList(fxoUserInterPortfolioMappingConfigListDTO)));

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input1, false);

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input2, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input3, false);

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input4, false);

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input5, false);

		verify(fxoUserInterPortfolioMappingRepository, times(0))
				.saveFXOUserInterPortfolioMapping(
						(List<FXOUserInterPortfolioMapping>) any());
	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void updateUserInterPortfolioMappings_Exception() {
		// given
		String userId = "User1";

		List<FXOInterPortfolioConfigDTO> interPortfolios = new ArrayList<FXOInterPortfolioConfigDTO>();
		List<FXOUserInterPortfolioMapping> userInterPortfolioMappings = new ArrayList<FXOUserInterPortfolioMapping>();
		String interPortfolio_input1 = "InterPortfolio1";
		Boolean active_input1 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO1 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input1, active_input1, null, null);

		String interPortfolio_input2 = "InterPortfolio2";
		Boolean active_input2 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO2 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input2, active_input2, null, null);

		String interPortfolio_input3 = "InterPortfolio3";
		Boolean active_input3 = false;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO3 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input3, active_input3, null, null);

		String interPortfolio_input4 = "InterPortfolio4";
		Boolean active_input4 = false;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO4 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input4, active_input4, null, null);

		String interPortfolio_input5 = "InterPortfolio5";
		Boolean active_input5 = true;
		FXOInterPortfolioConfigDTO fxoInterPortfolioDTO5 = getAFXOInterPortfolioConfigDTO(
				interPortfolio_input5, active_input5, null, null);

		interPortfolios.add(fxoInterPortfolioDTO1);
		interPortfolios.add(fxoInterPortfolioDTO2);
		interPortfolios.add(fxoInterPortfolioDTO3);
		interPortfolios.add(fxoInterPortfolioDTO4);
		interPortfolios.add(fxoInterPortfolioDTO5);

		String active_case1 = "TRUE";
		String interPortfolio_case1 = "InterPortfolio1";
		FXOInterPortfolio fxoInterPortfolio1 = getAFXOInterPortfolioEntity(
				interPortfolio_case1, active_case1);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case1 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio1, active_case1, null, null);

		String active_case2 = "FALSE";
		String interPortfolio_case2 = "InterPortfolio2";
		FXOInterPortfolio fxoInterPortfolio2 = getAFXOInterPortfolioEntity(
				interPortfolio_case2, active_case2);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case2 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio2, active_case2, null, null);

		String active_case3 = "FALSE";
		String interPortfolio_case3 = "InterPortfolio3";
		FXOInterPortfolio fxoInterPortfolio3 = getAFXOInterPortfolioEntity(
				interPortfolio_case3, active_case3);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case3 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio3, active_case3, null, null);

		String active_case4 = "TRUE";
		String interPortfolio_case4 = "InterPortfolio4";
		FXOInterPortfolio fxoInterPortfolio4 = getAFXOInterPortfolioEntity(
				interPortfolio_case4, active_case4);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case4 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio4, active_case4, null, null);

		String active_case5 = "TRUE";
		String interPortfolio_case5 = "InterPortfolio5_different";
		FXOInterPortfolio fxoInterPortfolio5 = getAFXOInterPortfolioEntity(
				interPortfolio_case5, active_case5);
		FXOUserInterPortfolioMapping fxoUserInterPortfolioMappingEntity_case5 = getAFXOUserInterPortfolioMappingEntity(
				userId, fxoInterPortfolio5, active_case5, null, null);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input1, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case1);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input2, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case2);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input3, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case3);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input4, false))
				.willReturn(fxoUserInterPortfolioMappingEntity_case4);

		given(
				fxoUserInterPortfolioMappingRepository
						.getOneUserInterPortfolioMappingByUserIdAndPortfolio(
								userId, interPortfolio_input5, false))
				.willReturn(null);

		userInterPortfolioMappings
				.add(fxoUserInterPortfolioMappingEntity_case2);
		userInterPortfolioMappings
				.add(fxoUserInterPortfolioMappingEntity_case4);
		userInterPortfolioMappings
				.add(fxoUserInterPortfolioMappingEntity_case5);

		given(
				fxoUserInterPortfolioMappingRepository
						.saveFXOUserInterPortfolioMapping((List<FXOUserInterPortfolioMapping>) any()))
				.willReturn(userInterPortfolioMappings);

		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = new FXOUserInterPortfolioMappingConfigListDTO();
		fxoUserInterPortfolioMappingConfigListDTO.setUserId(userId)
				.setInterPortfolios(interPortfolios);

		// when
		userInterPortfolioMappingConfigAdminServiceImpl
				.updateUserInterPortfolioMappings(new FXOUserInterPortfolioMappingConfigListWrapperDTO().setInterPortfolioMappingConfiguration(Arrays
						.asList(fxoUserInterPortfolioMappingConfigListDTO)));

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input1, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input2, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input3, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input4, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.getOneUserInterPortfolioMappingByUserIdAndPortfolio(userId,
						interPortfolio_input5, false);

		verify(fxoUserInterPortfolioMappingRepository, times(1))
				.saveFXOUserInterPortfolioMapping(
						(List<FXOUserInterPortfolioMapping>) any());
	}
}
