package com.fxo.admin.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.CurrencyPairConfigDTO;
import com.fxo.admin.dto.converter.CurrencyPairConfigDTOEntityConverter;
import com.fxo.admin.dto.converter.CurrencyPairConfigSourceTargetDTOConverter;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.dao.entity.Currency;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.dao.repository.CurrencyPairRepository;
import com.fxo.exception.ApplicationRuntimeException;

/**
 * @author lakshmikanth
 *
 */
@Test
public class CurrencyPairConfigServiceImplTest {

	@Mock
	private CurrencyPairRepository currencyPairRepository;

	@Mock
	private CurrencyPairConfigDTOEntityConverter currencyPairConfigDTOEntityConverter;

	@Mock
	private CurrencyPairConfigSourceTargetDTOConverter currencyPairConfigSourceTargetDTOConverter;

	@Mock
	private ICurrencyPairService fxoCurrencyPairService;

	@InjectMocks
	CurrencyPairConfigServiceImpl currencyPairConfigServiceImpl;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	private Currency getACurrency(String currency) {
		return new Currency().setCurrency(currency);
	}

	private CurrencyPair getACurrencyPairEntity(String currency,
			String countercurrency, Integer ratePrecision,
			Integer distanceFromSpot, String pipUnitValue, String updatedBy,
			Timestamp updatedAt) {

		CurrencyPair currencyPair = new CurrencyPair()
				.setCurrency(getACurrency(currency))
				.setCounterCurrency(getACurrency(countercurrency))
				.setRatePrecision(ratePrecision)
				.setDistanceFromSpot(distanceFromSpot)
				.setPipUnitValue(pipUnitValue);

		currencyPair.setLastUpdatedBy(updatedBy).setLastUpdatedDate(updatedAt);

		return currencyPair;
	}

	private CurrencyPairConfigDTO getACurrencyPairConfigDTO(String currency,
			String counterCurrency, Integer ratePrecision,
			Integer distanceFromSpot, String pipUnitValue, String updatedBy,
			DateTime updatedAt) {

		CurrencyPairConfigDTO currencyPairConfigDTO = new CurrencyPairConfigDTO();

		currencyPairConfigDTO.setCurrency(currency)
				.setCounterCurrency(counterCurrency)
				.setDistanceFromSpot(String.valueOf(distanceFromSpot))
				.setPipUnitValue(String.valueOf(pipUnitValue))
				.setRatePrecision(String.valueOf(ratePrecision))
				.setUpdatedBy(updatedBy).setUpdatedAt(updatedAt);

		return currencyPairConfigDTO;
	}

	public void shouldCheckForModification_Identical() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";

		Integer ratePrecision_DB = 4;
		Integer distanceFromSpot_DB = 30;
		String pipUnitValue_DB = "0.0001";

		CurrencyPair currencyPairEntity = getACurrencyPairEntity(currency,
				counterCurrency, ratePrecision_DB, distanceFromSpot_DB,
				pipUnitValue_DB, null, null);

		Integer ratePrecision_Input = 4;
		Integer distanceFromSpot_Input = 30;
		String pipUnitValue_Input = "0.0001";

		CurrencyPairConfigDTO currencyPairConfigDTO = getACurrencyPairConfigDTO(
				currency, counterCurrency, ratePrecision_Input,
				distanceFromSpot_Input, pipUnitValue_Input, null, null);

		// when
		boolean isModified = currencyPairConfigServiceImpl
				.checkForModification(currencyPairConfigDTO, currencyPairEntity);

		// then
		assertThat(isModified).isFalse();

	}

	public void shouldCheckForModification_Different() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";

		Integer ratePrecision_DB = 4;
		Integer distanceFromSpot_DB = 31;
		String pipUnitValue_DB = "0.0001";

		CurrencyPair currencyPairEntity = getACurrencyPairEntity(currency,
				counterCurrency, ratePrecision_DB, distanceFromSpot_DB,
				pipUnitValue_DB, null, null);

		Integer ratePrecision_Input = 4;
		Integer distanceFromSpot_Input = 31;
		String pipUnitValue_Input = "0.000100";

		CurrencyPairConfigDTO currencyPairConfigDTO = getACurrencyPairConfigDTO(
				currency, counterCurrency, ratePrecision_Input,
				distanceFromSpot_Input, pipUnitValue_Input, null, null);

		// when
		boolean isModified = currencyPairConfigServiceImpl
				.checkForModification(currencyPairConfigDTO, currencyPairEntity);

		// then
		assertThat(isModified).isTrue();

	}

	public void shouldGetAllCurrencyPairs() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		Integer ratePrecision_1 = 4;
		Integer distanceFromSpot_1 = 31;
		String pipUnitValue_1 = "0.0001";

		CurrencyPair currencyPairEntity_1 = getACurrencyPairEntity(currency_1,
				counterCurrency_1, ratePrecision_1, distanceFromSpot_1,
				pipUnitValue_1, null, null);

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, ratePrecision_1,
				distanceFromSpot_1, pipUnitValue_1, null, null);

		String currency_2 = "EUR";
		String counterCurrency_2 = "SGD";
		Integer ratePrecision_2 = 4;
		Integer distanceFromSpot_2 = 31;
		String pipUnitValue_2 = "0.0001";

		CurrencyPair currencyPairEntity_2 = getACurrencyPairEntity(currency_2,
				counterCurrency_2, ratePrecision_2, distanceFromSpot_2,
				pipUnitValue_2, null, null);

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, ratePrecision_2,
				distanceFromSpot_2, pipUnitValue_2, null, null);

		String currency_3 = "JPY";
		String counterCurrency_3 = "USD";
		Integer ratePrecision_3 = 2;
		Integer distanceFromSpot_3 = 31;
		String pipUnitValue_3 = "0.01";

		CurrencyPair currencyPairEntity_3 = getACurrencyPairEntity(currency_3,
				counterCurrency_3, ratePrecision_3, distanceFromSpot_3,
				pipUnitValue_3, null, null);

		CurrencyPairConfigDTO currencyPairConfigDTO_3 = getACurrencyPairConfigDTO(
				currency_3, counterCurrency_3, ratePrecision_3,
				distanceFromSpot_3, pipUnitValue_3, null, null);

		// prepare intermediate data
		// data from Database (CurrencyPairEntities)
		List<CurrencyPair> currencyPairEntities_DB = new ArrayList<CurrencyPair>();
		currencyPairEntities_DB.add(currencyPairEntity_1);
		currencyPairEntities_DB.add(currencyPairEntity_2);
		currencyPairEntities_DB.add(currencyPairEntity_3);

		given(currencyPairRepository.getAllCurrencyPairs()).willReturn(
				currencyPairEntities_DB);

		// prepare expected data
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Expected = new ArrayList<CurrencyPairConfigDTO>();
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_1);
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_2);
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_3);

		given(
				currencyPairConfigDTOEntityConverter
						.fromEntities(currencyPairEntities_DB)).willReturn(
				currencyPairConfigDTOs_Expected);

		// when
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Actual = currencyPairConfigServiceImpl
				.getAllCurrencyPairs();

		// then
		assertThat(currencyPairConfigDTOs_Actual).isNotNull();
		assertThat(currencyPairConfigDTOs_Actual).isEqualTo(
				currencyPairConfigDTOs_Expected);

	}

	public void updateCurrencyPairs() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		Integer ratePrecision_1 = 4;
		Integer distanceFromSpot_1 = 31;
		String pipUnitValue_1 = "0.0001";
		String updatedBy_1 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, ratePrecision_1,
				distanceFromSpot_1, pipUnitValue_1, updatedBy_1, null);

		String currency_2 = "EUR";
		String counterCurrency_2 = "SGD";
		Integer ratePrecision_2 = 4;
		Integer distanceFromSpot_2 = 31;
		String pipUnitValue_2 = "0.0001";
		String updatedBy_2 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, ratePrecision_2,
				distanceFromSpot_2, pipUnitValue_2, updatedBy_2, null);

		String currency_3 = "JPY";
		String counterCurrency_3 = "USD";
		Integer ratePrecision_3 = 2;
		Integer distanceFromSpot_3 = 31;
		String pipUnitValue_3 = "0.01";
		String updatedBy_3 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_3 = getACurrencyPairConfigDTO(
				currency_3, counterCurrency_3, ratePrecision_3,
				distanceFromSpot_3, pipUnitValue_3, updatedBy_3, null);

		// prepare input data
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Input = new ArrayList<CurrencyPairConfigDTO>();
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_1);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_2);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_3);

		Integer ratePrecision_DB_1 = 4;
		Integer distanceFromSpot_DB_1 = 30;
		String pipUnitValue_DB_1 = "0.0001";

		CurrencyPair currencyPairEntity_DB_1 = getACurrencyPairEntity(
				currency_1, counterCurrency_1, ratePrecision_DB_1,
				distanceFromSpot_DB_1, pipUnitValue_DB_1, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_1,
						counterCurrency_1)).willReturn(currencyPairEntity_DB_1);

		Integer ratePrecision_DB_2 = 4;
		Integer distanceFromSpot_DB_2 = 30;
		String pipUnitValue_DB_2 = "0.0001";

		CurrencyPair currencyPairEntity_DB_2 = getACurrencyPairEntity(
				currency_2, counterCurrency_2, ratePrecision_DB_2,
				distanceFromSpot_DB_2, pipUnitValue_DB_2, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_2,
						counterCurrency_2)).willReturn(currencyPairEntity_DB_2);

		Integer ratePrecision_DB_3 = 4;
		Integer distanceFromSpot_DB_3 = 30;
		String pipUnitValue_DB_3 = "0.0001";

		CurrencyPair currencyPairEntity_DB_3 = getACurrencyPairEntity(
				currency_3, counterCurrency_3, ratePrecision_DB_3,
				distanceFromSpot_DB_3, pipUnitValue_DB_3, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_3,
						counterCurrency_3)).willReturn(currencyPairEntity_DB_3);

		Timestamp updatedAt_DB = new Timestamp(new java.util.Date().getTime());

		CurrencyPair currencyPairEntity_1 = getACurrencyPairEntity(currency_1,
				counterCurrency_1, ratePrecision_1, distanceFromSpot_1,
				pipUnitValue_1, updatedBy_1, updatedAt_DB);

		CurrencyPair currencyPairEntity_2 = getACurrencyPairEntity(currency_2,
				counterCurrency_2, ratePrecision_2, distanceFromSpot_2,
				pipUnitValue_2, updatedBy_2, updatedAt_DB);

		CurrencyPair currencyPairEntity_3 = getACurrencyPairEntity(currency_3,
				counterCurrency_3, ratePrecision_3, distanceFromSpot_3,
				pipUnitValue_3, updatedBy_3, updatedAt_DB);

		// prepare intermediate data
		// data updated in Database (CurrencyPairEntities)
		List<CurrencyPair> currencyPairEntities_Updated = new ArrayList<CurrencyPair>();
		currencyPairEntities_Updated.add(currencyPairEntity_1);
		currencyPairEntities_Updated.add(currencyPairEntity_2);
		currencyPairEntities_Updated.add(currencyPairEntity_3);

		given(
				currencyPairRepository
						.saveCurrencyPairs((List<CurrencyPair>) any()))
				.willReturn(currencyPairEntities_Updated);

		// prepare expected data

		DateTime updatedAt_Config = new DateTime(updatedAt_DB);

		CurrencyPairConfigDTO currencyPairConfigDTO_Updated_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, ratePrecision_1,
				distanceFromSpot_1, pipUnitValue_1, updatedBy_1,
				updatedAt_Config);

		CurrencyPairConfigDTO currencyPairConfigDTO_Updated_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, ratePrecision_2,
				distanceFromSpot_2, pipUnitValue_2, updatedBy_2,
				updatedAt_Config);

		CurrencyPairConfigDTO currencyPairConfigDTO_Updated_3 = getACurrencyPairConfigDTO(
				currency_3, counterCurrency_3, ratePrecision_3,
				distanceFromSpot_3, pipUnitValue_3, updatedBy_3,
				updatedAt_Config);

		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Expected = new ArrayList<CurrencyPairConfigDTO>();
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_Updated_1);
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_Updated_2);
		currencyPairConfigDTOs_Expected.add(currencyPairConfigDTO_Updated_3);

		given(
				currencyPairConfigDTOEntityConverter
						.fromEntities(currencyPairEntities_Updated))
				.willReturn(currencyPairConfigDTOs_Expected);

		// when
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Actual = currencyPairConfigServiceImpl
				.updateCurrencyPairs(currencyPairConfigDTOs_Input);

		// then
		assertThat(currencyPairConfigDTOs_Actual).isNotNull();
		assertThat(currencyPairConfigDTOs_Actual).isEqualTo(
				currencyPairConfigDTOs_Expected);

		verify(currencyPairRepository, times(1)).saveCurrencyPairs(
				(List<CurrencyPair>) any());
		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_1,
				counterCurrency_1);
		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_2,
				counterCurrency_2);
		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_3,
				counterCurrency_3);
		verify(currencyPairConfigDTOEntityConverter, times(1)).fromEntities(
				currencyPairEntities_Updated);
	}

	public void updateCurrencyPairs_NoUpdatesToDB() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		Integer ratePrecision_1 = 4;
		Integer distanceFromSpot_1 = 30;
		String pipUnitValue_1 = "0.0001";
		String updatedBy_1 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, ratePrecision_1,
				distanceFromSpot_1, pipUnitValue_1, updatedBy_1, null);

		String currency_2 = "EUR";
		String counterCurrency_2 = "SGD";
		Integer ratePrecision_2 = 4;
		Integer distanceFromSpot_2 = 30;
		String pipUnitValue_2 = "0.0001";
		String updatedBy_2 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, ratePrecision_2,
				distanceFromSpot_2, pipUnitValue_2, updatedBy_2, null);

		String currency_3 = "JPY";
		String counterCurrency_3 = "USD";
		Integer ratePrecision_3 = 2;
		Integer distanceFromSpot_3 = 30;
		String pipUnitValue_3 = "0.01";
		String updatedBy_3 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_3 = getACurrencyPairConfigDTO(
				currency_3, counterCurrency_3, ratePrecision_3,
				distanceFromSpot_3, pipUnitValue_3, updatedBy_3, null);

		// prepare input data
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Input = new ArrayList<CurrencyPairConfigDTO>();
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_1);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_2);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_3);

		Integer ratePrecision_DB_1 = 4;
		Integer distanceFromSpot_DB_1 = 30;
		String pipUnitValue_DB_1 = "0.0001";

		CurrencyPair currencyPairEntity_DB_1 = getACurrencyPairEntity(
				currency_1, counterCurrency_1, ratePrecision_DB_1,
				distanceFromSpot_DB_1, pipUnitValue_DB_1, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_1,
						counterCurrency_1)).willReturn(currencyPairEntity_DB_1);

		Integer ratePrecision_DB_2 = 4;
		Integer distanceFromSpot_DB_2 = 30;
		String pipUnitValue_DB_2 = "0.0001";

		CurrencyPair currencyPairEntity_DB_2 = getACurrencyPairEntity(
				currency_2, counterCurrency_2, ratePrecision_DB_2,
				distanceFromSpot_DB_2, pipUnitValue_DB_2, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_2,
						counterCurrency_2)).willReturn(currencyPairEntity_DB_2);

		Integer ratePrecision_DB_3 = 2;
		Integer distanceFromSpot_DB_3 = 30;
		String pipUnitValue_DB_3 = "0.01";

		CurrencyPair currencyPairEntity_DB_3 = getACurrencyPairEntity(
				currency_3, counterCurrency_3, ratePrecision_DB_3,
				distanceFromSpot_DB_3, pipUnitValue_DB_3, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_3,
						counterCurrency_3)).willReturn(currencyPairEntity_DB_3);

		// when
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Actual = currencyPairConfigServiceImpl
				.updateCurrencyPairs(currencyPairConfigDTOs_Input);

		// then
		assertThat(currencyPairConfigDTOs_Actual).isNull();

		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_1,
				counterCurrency_1);
		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_2,
				counterCurrency_2);
		verify(currencyPairRepository, times(1)).getOneCurrencyPair(currency_3,
				counterCurrency_3);

		verify(currencyPairRepository, times(0)).saveCurrencyPairs(
				(List<CurrencyPair>) any());

		verify(currencyPairConfigDTOEntityConverter, times(0)).fromEntities(
				(List<CurrencyPair>) any());

	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void updateCurrencyPairs_Exception() {

		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		Integer ratePrecision_1 = 4;
		Integer distanceFromSpot_1 = 30;
		String pipUnitValue_1 = "0.0001";
		String updatedBy_1 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_1 = getACurrencyPairConfigDTO(
				currency_1, counterCurrency_1, ratePrecision_1,
				distanceFromSpot_1, pipUnitValue_1, updatedBy_1, null);

		String currency_2 = "EUR";
		String counterCurrency_2 = "SGD";
		Integer ratePrecision_2 = 4;
		Integer distanceFromSpot_2 = 30;
		String pipUnitValue_2 = "0.0001";
		String updatedBy_2 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_2 = getACurrencyPairConfigDTO(
				currency_2, counterCurrency_2, ratePrecision_2,
				distanceFromSpot_2, pipUnitValue_2, updatedBy_2, null);

		String currency_3 = "JPY";
		String counterCurrency_3 = "USD";
		Integer ratePrecision_3 = 2;
		Integer distanceFromSpot_3 = 30;
		String pipUnitValue_3 = "0.01";
		String updatedBy_3 = "TraderAdmin";

		CurrencyPairConfigDTO currencyPairConfigDTO_3 = getACurrencyPairConfigDTO(
				currency_3, counterCurrency_3, ratePrecision_3,
				distanceFromSpot_3, pipUnitValue_3, updatedBy_3, null);

		// prepare input data
		List<CurrencyPairConfigDTO> currencyPairConfigDTOs_Input = new ArrayList<CurrencyPairConfigDTO>();
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_1);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_2);
		currencyPairConfigDTOs_Input.add(currencyPairConfigDTO_3);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_1,
						counterCurrency_1)).willReturn(null);

		Integer ratePrecision_DB_2 = 4;
		Integer distanceFromSpot_DB_2 = 30;
		String pipUnitValue_DB_2 = "0.0001";

		CurrencyPair currencyPairEntity_DB_2 = getACurrencyPairEntity(
				currency_2, counterCurrency_2, ratePrecision_DB_2,
				distanceFromSpot_DB_2, pipUnitValue_DB_2, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_2,
						counterCurrency_2)).willReturn(currencyPairEntity_DB_2);

		Integer ratePrecision_DB_3 = 2;
		Integer distanceFromSpot_DB_3 = 30;
		String pipUnitValue_DB_3 = "0.01";

		CurrencyPair currencyPairEntity_DB_3 = getACurrencyPairEntity(
				currency_3, counterCurrency_3, ratePrecision_DB_3,
				distanceFromSpot_DB_3, pipUnitValue_DB_3, null, null);

		given(
				currencyPairRepository.getOneCurrencyPair(currency_3,
						counterCurrency_3)).willReturn(currencyPairEntity_DB_3);

		// when
		currencyPairConfigServiceImpl
				.updateCurrencyPairs(currencyPairConfigDTOs_Input);

	}

}
