package com.fxo.admin.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.dto.CurrencyPairProductConfigDTO;
import com.fxo.admin.dto.CurrencyPairProductConfigResponseDTO;
import com.fxo.admin.dto.converter.CurrencyPairProductConfigDTOEntityConverter;
import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.service.IFXOProductCatalogueGroupService;
import com.fxo.constants.dealing.FXOCurrencyPairStatuses;
import com.fxo.constants.dealing.ProductGroups;
import com.fxo.constants.dealing.Products;
import com.fxo.dao.entity.Currency;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.dao.entity.CurrencyPairProduct;
import com.fxo.dao.repository.CurrencyPairProductRepository;
import com.fxo.exception.ApplicationRuntimeException;

/**
 * @author lakshmikanth
 *
 */
@Test
public class CurrencyPairProductConfigurationServiceImplTest {

	@Mock
	private CurrencyPairProductRepository currencyPairProductRepository;

	@Mock
	private CurrencyPairProductConfigDTOEntityConverter currencyPairProductConfigDTOEntityConverter;

	@Mock
	private IFXOProductCatalogueGroupService fxoProductCatalogueGroupService;

	@InjectMocks
	CurrencyPairProductConfigurationServiceImpl currencyPairProductConfigurationService;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
	}

	private CodeValueDTO getACodeValueDTO(String code, String value) {
		return new CodeValueDTO().setCode(code).setValue(value);
	}

	private Currency getACurrency(String currency) {
		return new Currency().setCurrency(currency);
	}

	private CurrencyPair getACurrencyPairEntity(String currency,
			String countercurrency, Integer ratePrecision,
			Integer distanceFromSpot, String pipUnitValue) {

		return new CurrencyPair().setCurrency(getACurrency(currency))
				.setCounterCurrency(getACurrency(countercurrency))
				.setRatePrecision(ratePrecision)
				.setDistanceFromSpot(distanceFromSpot)
				.setPipUnitValue(pipUnitValue);
	}

	private CurrencyPairProduct getACurrencyPairProductEntity(String currency,
			String countercurrency, String product, String status,
			Integer ratePrecision, Integer distanceFromSpot,
			String pipUnitValue, String updatedBy, Timestamp updatedAt) {

		CurrencyPairProduct currencyPairProduct = new CurrencyPairProduct()
				.setCurrencyPair(getACurrencyPairEntity(currency,
						countercurrency, ratePrecision, distanceFromSpot,
						pipUnitValue));

		currencyPairProduct.setStatus(status).setLastUpdatedBy(updatedBy)
				.setLastUpdatedDate(updatedAt);

		return currencyPairProduct;
	}

	private CurrencyPairProductConfigDTO getACurrencyPairProductConfigDTO(
			String currency, String counterCurrency, String product,
			String status, Integer ratePrecision, Integer distanceFromSpot,
			String pipUnitValue, String updatedBy, DateTime updatedAt,
			List<CodeValueDTO> hierarchy) {

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO = new CurrencyPairProductConfigDTO()
				.setProduct(product).setStatus(status).setHierarchy(hierarchy);
		currencyPairProductConfigDTO.setCurrency(currency)
				.setCounterCurrency(counterCurrency)
				.setDistanceFromSpot(String.valueOf(distanceFromSpot))
				.setPipUnitValue(String.valueOf(pipUnitValue))
				.setRatePrecision(String.valueOf(ratePrecision))
				.setUpdatedBy(updatedBy).setUpdatedAt(updatedAt);

		return currencyPairProductConfigDTO;
	}

	public void shouldGetAllCurrencyPairProductsConfiguration() {

		// prepare Database objects (CurrencyPairProducts)
		String product_DBEntity_1 = Products.PRODUCT_KNOCKIN;
		String currency_DBEntity_1 = "EUR";
		String counterCurrency_DBEntity_1 = "USD";
		String status_DBEntity_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;
		Integer ratePrecision_DBEntity_1 = 4;
		Integer distanceFromSpot_DBEntity_1 = 4;
		String pipUnitValue_DBEntity_1 = "0.0001";
		String lastUpdatedBy_DBEntity_1 = null;
		Timestamp lastUpdatedAt_DBEntity_1 = null;

		CurrencyPairProduct currencyPairProduct_DBEntity_1 = getACurrencyPairProductEntity(
				currency_DBEntity_1, counterCurrency_DBEntity_1,
				product_DBEntity_1, status_DBEntity_1,
				ratePrecision_DBEntity_1, distanceFromSpot_DBEntity_1,
				pipUnitValue_DBEntity_1, lastUpdatedBy_DBEntity_1,
				lastUpdatedAt_DBEntity_1);

		DateTime updatedAt_IntermediateValue_1 = null;
		List<CodeValueDTO> hierarchy_IntermediateValue_1 = null;

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_IntermediateValue_1 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_1, counterCurrency_DBEntity_1,
				product_DBEntity_1, status_DBEntity_1,
				ratePrecision_DBEntity_1, distanceFromSpot_DBEntity_1,
				pipUnitValue_DBEntity_1, lastUpdatedBy_DBEntity_1,
				updatedAt_IntermediateValue_1, hierarchy_IntermediateValue_1);

		String product_DBEntity_2 = Products.PRODUCT_KNOCKIN;
		String currency_DBEntity_2 = "EUR";
		String counterCurrency_DBEntity_2 = "SGD";
		String status_DBEntity_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		Integer ratePrecision_DBEntity_2 = 4;
		Integer distanceFromSpot_DBEntity_2 = 4;
		String pipUnitValue_DBEntity_2 = "0.0001";
		String lastUpdatedBy_DBEntity_2 = null;
		Timestamp lastUpdatedAt_DBEntity_2 = null;

		CurrencyPairProduct currencyPairProduct_DBEntity_2 = getACurrencyPairProductEntity(
				currency_DBEntity_2, counterCurrency_DBEntity_2,
				product_DBEntity_2, status_DBEntity_2,
				ratePrecision_DBEntity_2, distanceFromSpot_DBEntity_2,
				pipUnitValue_DBEntity_2, lastUpdatedBy_DBEntity_2,
				lastUpdatedAt_DBEntity_2);

		DateTime updatedAt_IntermediateValue_2 = null;
		List<CodeValueDTO> hierarchy_IntermediateValue_2 = null;

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_IntermediateValue_2 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_2, counterCurrency_DBEntity_2,
				product_DBEntity_2, status_DBEntity_2,
				ratePrecision_DBEntity_2, distanceFromSpot_DBEntity_2,
				pipUnitValue_DBEntity_2, lastUpdatedBy_DBEntity_2,
				updatedAt_IntermediateValue_2, hierarchy_IntermediateValue_2);

		String product_DBEntity_3 = Products.PRODUCT_RISKREVERSAL;
		String currency_DBEntity_3 = "EUR";
		String counterCurrency_DBEntity_3 = "SGD";
		String status_DBEntity_3 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;
		Integer ratePrecision_DBEntity_3 = 4;
		Integer distanceFromSpot_DBEntity_3 = 4;
		String pipUnitValue_DBEntity_3 = "0.0001";
		String lastUpdatedBy_DBEntity_3 = null;
		Timestamp lastUpdatedAt_DBEntity_3 = null;

		CurrencyPairProduct currencyPairProduct_DBEntity_3 = getACurrencyPairProductEntity(
				currency_DBEntity_3, counterCurrency_DBEntity_3,
				product_DBEntity_3, status_DBEntity_3,
				ratePrecision_DBEntity_3, distanceFromSpot_DBEntity_3,
				pipUnitValue_DBEntity_3, lastUpdatedBy_DBEntity_3,
				lastUpdatedAt_DBEntity_3);

		DateTime updatedAt_IntermediateValue_3 = null;
		List<CodeValueDTO> hierarchy_IntermediateValue_3 = null;

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_IntermediateValue_3 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_3, counterCurrency_DBEntity_3,
				product_DBEntity_3, status_DBEntity_3,
				ratePrecision_DBEntity_3, distanceFromSpot_DBEntity_3,
				pipUnitValue_DBEntity_3, lastUpdatedBy_DBEntity_3,
				updatedAt_IntermediateValue_3, hierarchy_IntermediateValue_3);

		String product_DBEntity_4 = Products.PRODUCT_RISKREVERSAL;
		String currency_DBEntity_4 = "EUR";
		String counterCurrency_DBEntity_4 = "USD";
		String status_DBEntity_4 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ;
		Integer ratePrecision_DBEntity_4 = 4;
		Integer distanceFromSpot_DBEntity_4 = 4;
		String pipUnitValue_DBEntity_4 = "0.0001";
		String lastUpdatedBy_DBEntity_4 = null;
		Timestamp lastUpdatedAt_DBEntity_4 = null;

		CurrencyPairProduct currencyPairProduct_DBEntity_4 = getACurrencyPairProductEntity(
				currency_DBEntity_4, counterCurrency_DBEntity_4,
				product_DBEntity_4, status_DBEntity_4,
				ratePrecision_DBEntity_4, distanceFromSpot_DBEntity_4,
				pipUnitValue_DBEntity_4, lastUpdatedBy_DBEntity_4,
				lastUpdatedAt_DBEntity_4);

		DateTime updatedAt_IntermediateValue_4 = null;
		List<CodeValueDTO> hierarchy_IntermediateValue_4 = null;

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_IntermediateValue_4 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_4, counterCurrency_DBEntity_4,
				product_DBEntity_4, status_DBEntity_4,
				ratePrecision_DBEntity_4, distanceFromSpot_DBEntity_4,
				pipUnitValue_DBEntity_4, lastUpdatedBy_DBEntity_4,
				updatedAt_IntermediateValue_4, hierarchy_IntermediateValue_4);

		List<CurrencyPairProduct> currencyPairProducts_In_Database = new ArrayList<CurrencyPairProduct>();

		currencyPairProducts_In_Database.add(currencyPairProduct_DBEntity_1);
		currencyPairProducts_In_Database.add(currencyPairProduct_DBEntity_2);
		currencyPairProducts_In_Database.add(currencyPairProduct_DBEntity_3);
		currencyPairProducts_In_Database.add(currencyPairProduct_DBEntity_4);

		given(currencyPairProductRepository.getCurrencyPairs(false))
				.willReturn(currencyPairProducts_In_Database);

		// List of Intermediate objects (CurrencyPairProductConfigDTO)
		List<CurrencyPairProductConfigDTO> currencyPairProductConfigDTOs_Intermediate = new ArrayList<CurrencyPairProductConfigDTO>();
		currencyPairProductConfigDTOs_Intermediate
				.add(currencyPairProductConfigDTO_IntermediateValue_1);
		currencyPairProductConfigDTOs_Intermediate
				.add(currencyPairProductConfigDTO_IntermediateValue_2);
		currencyPairProductConfigDTOs_Intermediate
				.add(currencyPairProductConfigDTO_IntermediateValue_3);
		currencyPairProductConfigDTOs_Intermediate
				.add(currencyPairProductConfigDTO_IntermediateValue_4);

		given(
				currencyPairProductConfigDTOEntityConverter
						.fromEntities(currencyPairProducts_In_Database))
				.willReturn(currencyPairProductConfigDTOs_Intermediate);

		// hierarchy intermediate call values

		List<CodeValueDTO> hierarchy_1 = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet1_1 = ProductGroups.PRODUCT_GROUP_KI;

		String groupCodeDescription_ParamSet1_1 = "KnockIn";
		CodeValueDTO codeValueDTO_ParamSet1_1 = getACodeValueDTO(
				groupCode_ParamSet1_1, groupCodeDescription_ParamSet1_1);

		hierarchy_1.add(codeValueDTO_ParamSet1_1);

		String groupCode_ParamSet1_2 = ProductGroups.PRODUCT_GROUP_EXOTIC_OPTION;

		String groupCodeDescription_ParamSet1_2 = "Exotic Option";
		CodeValueDTO codeValueDTO_ParamSet1_2 = getACodeValueDTO(
				groupCode_ParamSet1_2, groupCodeDescription_ParamSet1_2);

		hierarchy_1.add(codeValueDTO_ParamSet1_2);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(Products.PRODUCT_KNOCKIN))
				.willReturn(hierarchy_1);

		List<CodeValueDTO> hierarchy_2 = new ArrayList<CodeValueDTO>();

		String groupCode_ParamSet2_1 = ProductGroups.PRODUCT_GROUP_RISKREVERSAL;

		String groupCodeDescription_ParamSet2_1 = "Risk Reversal";
		CodeValueDTO codeValueDTO_ParamSet2_1 = getACodeValueDTO(
				groupCode_ParamSet2_1, groupCodeDescription_ParamSet2_1);

		hierarchy_2.add(codeValueDTO_ParamSet2_1);

		String groupCode_ParamSet2_2 = ProductGroups.PRODUCT_GROUP_SIMPLE_OPTION;

		String groupCodeDescription_ParamSet2_2 = "Simple Option";
		CodeValueDTO codeValueDTO_ParamSet2_2 = getACodeValueDTO(
				groupCode_ParamSet2_2, groupCodeDescription_ParamSet2_2);

		hierarchy_2.add(codeValueDTO_ParamSet2_2);

		given(
				fxoProductCatalogueGroupService
						.getHierarchyAsCodeValue(Products.PRODUCT_RISKREVERSAL))
				.willReturn(hierarchy_2);

		// prepare expected Values
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_ExpectedValue_1 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_1, counterCurrency_DBEntity_1,
				product_DBEntity_1, status_DBEntity_1,
				ratePrecision_DBEntity_1, distanceFromSpot_DBEntity_1,
				pipUnitValue_DBEntity_1, lastUpdatedBy_DBEntity_1,
				updatedAt_IntermediateValue_1, hierarchy_1);

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_ExpectedValue_2 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_2, counterCurrency_DBEntity_2,
				product_DBEntity_2, status_DBEntity_2,
				ratePrecision_DBEntity_2, distanceFromSpot_DBEntity_2,
				pipUnitValue_DBEntity_2, lastUpdatedBy_DBEntity_2,
				updatedAt_IntermediateValue_2, hierarchy_1);

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_ExpectedValue_3 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_3, counterCurrency_DBEntity_3,
				product_DBEntity_3, status_DBEntity_3,
				ratePrecision_DBEntity_3, distanceFromSpot_DBEntity_3,
				pipUnitValue_DBEntity_3, lastUpdatedBy_DBEntity_3,
				updatedAt_IntermediateValue_3, hierarchy_2);

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_ExpectedValue_4 = getACurrencyPairProductConfigDTO(
				currency_DBEntity_4, counterCurrency_DBEntity_4,
				product_DBEntity_4, status_DBEntity_4,
				ratePrecision_DBEntity_4, distanceFromSpot_DBEntity_4,
				pipUnitValue_DBEntity_4, lastUpdatedBy_DBEntity_4,
				updatedAt_IntermediateValue_4, hierarchy_2);

		List<CurrencyPairProductConfigDTO> currencyPairProductConfigDTOs_Expected = new ArrayList<CurrencyPairProductConfigDTO>();
		currencyPairProductConfigDTOs_Expected
				.add(currencyPairProductConfigDTO_ExpectedValue_1);
		currencyPairProductConfigDTOs_Expected
				.add(currencyPairProductConfigDTO_ExpectedValue_2);
		currencyPairProductConfigDTOs_Expected
				.add(currencyPairProductConfigDTO_ExpectedValue_3);
		currencyPairProductConfigDTOs_Expected
				.add(currencyPairProductConfigDTO_ExpectedValue_4);

		// when
		List<CurrencyPairProductConfigDTO> currencyPairProductConfigDTOs_Actual = currencyPairProductConfigurationService
				.getAllCurrencyPairProductsConfiguration();

		// then
		assertThat(currencyPairProductConfigDTOs_Actual).isNotNull();
		assertThat(currencyPairProductConfigDTOs_Actual).isEqualTo(
				currencyPairProductConfigDTOs_Expected);

		verify(currencyPairProductRepository, times(1)).getCurrencyPairs(false);
		verify(currencyPairProductConfigDTOEntityConverter, times(1))
				.fromEntities(currencyPairProducts_In_Database);

		verify(fxoProductCatalogueGroupService, times(2))
				.getHierarchyAsCodeValue(Products.PRODUCT_KNOCKIN);

		verify(fxoProductCatalogueGroupService, times(2))
				.getHierarchyAsCodeValue(Products.PRODUCT_RISKREVERSAL);

	}

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyAndAProduct() {

		// given
		String currency = "USD";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		products.add(product);

		given(fxoProductCatalogueGroupService.getAllProducts(product))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, product, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)

		String currency_1 = "RMB";
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, currency_1, product, status_1, null, null, null,
				null, null);

		String currency_2 = "SGD";
		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, currency_2, product, status_2, null, null, null,
				null, null);

		String currency_3 = "EUR";
		String status_3 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3 = getACurrencyPairProductEntity(
				currency_3, currency, product, status_3, null, null, null,
				null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB.add(currencyPairProductInDB_1);
		currencyPairProductsInDB.add(currencyPairProductInDB_2);
		currencyPairProductsInDB.add(currencyPairProductInDB_3);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product, false)).willReturn(
				currencyPairProductsInDB);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();
		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(
				product);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

	}

	// ///////////

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldNotFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyAndAProduct() {

		// given
		String currency = "";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, product, status, null, null, null, updatedBy,
				null, null);

		// when
		currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);
	}

	// //////////////////

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyAndAGroup() {

		// given
		String currency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI_KO;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		List<String> products = new ArrayList<String>();
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, group, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & USD)

		String currency_1_Product_1 = "RMB";
		String status_1_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_1 = getACurrencyPairProductEntity(
				currency, currency_1_Product_1, product_1, status_1_Product_1,
				null, null, null, null, null);

		String currency_2_Product_1 = "SGD";
		String status_2_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2_Product_1 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status_2_Product_1,
				null, null, null, null, null);

		String currency_3_Product_1 = "EUR";
		String status_3_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3_Product_1 = getACurrencyPairProductEntity(
				currency_3_Product_1, currency, product_1, status_3_Product_1,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_1 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_1_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_2_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_3_Product_1);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_1, false)).willReturn(
				currencyPairProductsInDB_Product_1);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KO & USD)

		String currency_1_Product_2 = "RMB";
		String status_1_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_2 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status_1_Product_2,
				null, null, null, null, null);

		String currency_2_Product_2 = "SGD";
		String status_2_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2_Product_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_2, product_2, status_2_Product_2,
				null, null, null, null, null);

		String currency_3_Product_2 = "EUR";
		String status_3_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3_Product_2 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status_3_Product_2,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_2 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_1_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_2_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_3_Product_2);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_2, false)).willReturn(
				currencyPairProductsInDB_Product_2);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// prepare expected Values
		List<CurrencyPairProduct> currencyPairProductsInDB_Expected = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Expected
				.addAll(currencyPairProductsInDB_Product_1);
		currencyPairProductsInDB_Expected
				.addAll(currencyPairProductsInDB_Product_2);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();

		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB_Expected);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_1, false);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_2, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

	}

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyAndAllProducts() {

		// given
		String currency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_MASTER;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		List<String> products = new ArrayList<String>();
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, group, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & USD)

		String currency_1_Product_1 = "RMB";
		String status_1_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_1 = getACurrencyPairProductEntity(
				currency, currency_1_Product_1, product_1, status_1_Product_1,
				null, null, null, null, null);

		String currency_2_Product_1 = "SGD";
		String status_2_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2_Product_1 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status_2_Product_1,
				null, null, null, null, null);

		String currency_3_Product_1 = "EUR";
		String status_3_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3_Product_1 = getACurrencyPairProductEntity(
				currency_3_Product_1, currency, product_1, status_3_Product_1,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_1 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_1_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_2_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_3_Product_1);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_1, false)).willReturn(
				currencyPairProductsInDB_Product_1);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KO & USD)

		String currency_1_Product_2 = "RMB";
		String status_1_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_2 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status_1_Product_2,
				null, null, null, null, null);

		String currency_2_Product_2 = "SGD";
		String status_2_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2_Product_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_2, product_2, status_2_Product_2,
				null, null, null, null, null);

		String currency_3_Product_2 = "EUR";
		String status_3_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3_Product_2 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status_3_Product_2,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_2 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_1_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_2_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_3_Product_2);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_2, false)).willReturn(
				currencyPairProductsInDB_Product_2);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// prepare expected Values
		List<CurrencyPairProduct> currencyPairProductsInDB_Expected = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Expected
				.addAll(currencyPairProductsInDB_Product_1);
		currencyPairProductsInDB_Expected
				.addAll(currencyPairProductsInDB_Product_2);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();

		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB_Expected);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_1, false);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_2, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

	}

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyPairAndAGroup() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI_KO;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, group, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status_1, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_1, false)).willReturn(
				currencyPairProductInDB_1);

		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_2, status_2, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_2, false)).willReturn(
				currencyPairProductInDB_2);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// prepare expected Values
		List<CurrencyPairProduct> currencyPairProductsInDB_Expected = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Expected.add(currencyPairProductInDB_1);
		currencyPairProductsInDB_Expected.add(currencyPairProductInDB_2);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();
		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB_Expected);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_1, false);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_2, false);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(
						(String) any(), (String) any(), eq(false));

	}

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyPairAndAProduct() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		products.add(product);

		given(fxoProductCatalogueGroupService.getAllProducts(product))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, product, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product, status_1, null, null, null,
				null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product, false)).willReturn(
				currencyPairProductInDB_1);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// prepare expected Values
		List<CurrencyPairProduct> currencyPairProductsInDB_Expected = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Expected.add(currencyPairProductInDB_1);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();
		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB_Expected);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(
				product);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product, false);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(
						(String) any(), (String) any(), eq(false));

	}

	@Test(expectedExceptions = ApplicationRuntimeException.class)
	public void shouldNotFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyPairAndAProduct() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		products.add(product);

		given(fxoProductCatalogueGroupService.getAllProducts(product))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, product, status, null, null, null,
				updatedBy, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product, false)).willReturn(null);

		// when
		currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

	}

	public void shouldFetchCurrencyPairProductEntitiesToUpdate_ApplyStatus_ForACurrencyPairAndAllProducts() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_MASTER;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, group, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status_1, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_1, false)).willReturn(
				currencyPairProductInDB_1);

		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_2, status_2, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_2, false)).willReturn(
				currencyPairProductInDB_2);

		// when
		List<CurrencyPairProduct> currencyPairProducts_Actual = currencyPairProductConfigurationService
				.fetchCurrencyPairProductEntitiesToUpdate(currencyPairProductConfigDTO_Input);

		// prepare expected Values
		List<CurrencyPairProduct> currencyPairProductsInDB_Expected = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Expected.add(currencyPairProductInDB_1);
		currencyPairProductsInDB_Expected.add(currencyPairProductInDB_2);

		// then
		assertThat(currencyPairProducts_Actual).isNotNull();
		assertThat(currencyPairProducts_Actual).isEqualTo(
				currencyPairProductsInDB_Expected);
		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_1, false);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_2, false);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(
						(String) any(), (String) any(), eq(false));

	}

	public void shouldFilterCurrencyPairProductEntities() {

		// given
		String currency_1 = "EUR";
		String counterCurrency_1 = "USD";
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String product_1 = Products.PRODUCT_KNOCKIN;

		CurrencyPairProduct currencyPairProduct_1 = getACurrencyPairProductEntity(
				currency_1, counterCurrency_1, product_1, status_1, null, null,
				null, null, null);

		String currency_2 = "GBP";
		String counterCurrency_2 = "SGD";
		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String product_2 = Products.PRODUCT_KNOCKIN;

		CurrencyPairProduct currencyPairProduct_2 = getACurrencyPairProductEntity(
				currency_2, counterCurrency_2, product_2, status_2, null, null,
				null, null, null);

		String currency_3 = "GBP";
		String counterCurrency_3 = "SGD";
		String status_3 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ;
		String product_3 = Products.PRODUCT_REVERSE_KNOCKOUT;

		CurrencyPairProduct currencyPairProduct_3 = getACurrencyPairProductEntity(
				currency_3, counterCurrency_3, product_3, status_3, null, null,
				null, null, null);

		String currency_4 = "RMB";
		String counterCurrency_4 = "SGD";
		String status_4 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;
		String product_4 = Products.PRODUCT_STRADDLE;

		CurrencyPairProduct currencyPairProduct_4 = getACurrencyPairProductEntity(
				currency_4, counterCurrency_4, product_4, status_4, null, null,
				null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB.add(currencyPairProduct_1);
		currencyPairProductsInDB.add(currencyPairProduct_2);
		currencyPairProductsInDB.add(currencyPairProduct_3);
		currencyPairProductsInDB.add(currencyPairProduct_4);

		// input
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		// when
		List<CurrencyPairProduct> currencyPairProductsFiltered_Actual = currencyPairProductConfigurationService
				.filterCurrencyPairProductEntities(status,
						currencyPairProductsInDB);

		// then
		assertThat(currencyPairProductsFiltered_Actual).isNotNull();
		assertThat(currencyPairProductsFiltered_Actual.size()).isEqualTo(2);

	}

	@SuppressWarnings("unchecked")
	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyAndAProduct() {

		// given
		String currency = "USD";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		products.add(product);

		given(fxoProductCatalogueGroupService.getAllProducts(product))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, product, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)

		String currency_1 = "RMB";
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, currency_1, product, status_1, null, null, null,
				null, null);

		String currency_2 = "SGD";
		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, currency_2, product, status_2, null, null, null,
				null, null);

		String currency_3 = "EUR";
		String status_3 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_3 = getACurrencyPairProductEntity(
				currency_3, currency, product, status_3, null, null, null,
				null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB.add(currencyPairProductInDB_1);
		currencyPairProductsInDB.add(currencyPairProductInDB_2);
		currencyPairProductsInDB.add(currencyPairProductInDB_3);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product, false)).willReturn(
				currencyPairProductsInDB);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_Updated_1 = getACurrencyPairProductEntity(
				currency_1, currency, product, status, null, null, updatedBy,
				null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_1);

		CurrencyPairProduct currencyPairProductInDB_Updated_2 = getACurrencyPairProductEntity(
				currency_1, currency, product, status, null, null, updatedBy,
				null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_2);

		CurrencyPairProduct currencyPairProductInDB_Updated_3 = getACurrencyPairProductEntity(
				currency_3, currency, product, status, null, null, updatedBy,
				null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_3);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(
				product);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));
		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());

	}

	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyAndAGroup() {

		// given
		String currency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI_KO;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		List<String> products = new ArrayList<String>();
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, group, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & USD)

		String currency_1_Product_1 = "RMB";
		String status_1_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_1 = getACurrencyPairProductEntity(
				currency, currency_1_Product_1, product_1, status_1_Product_1,
				null, null, null, null, null);

		String currency_2_Product_1 = "SGD";
		String status_2_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2_Product_1 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status_2_Product_1,
				null, null, null, null, null);

		String currency_3_Product_1 = "EUR";
		String status_3_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_3_Product_1 = getACurrencyPairProductEntity(
				currency_3_Product_1, currency, product_1, status_3_Product_1,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_1 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_1_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_2_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_3_Product_1);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_1, false)).willReturn(
				currencyPairProductsInDB_Product_1);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KO & USD)

		String currency_1_Product_2 = "RMB";
		String status_1_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_2 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status_1_Product_2,
				null, null, null, null, null);

		String currency_2_Product_2 = "SGD";
		String status_2_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ;

		CurrencyPairProduct currencyPairProductInDB_2_Product_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_2, product_2, status_2_Product_2,
				null, null, null, null, null);

		String currency_3_Product_2 = "EUR";
		String status_3_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_3_Product_2 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status_3_Product_2,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_2 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_1_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_2_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_3_Product_2);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_2, false)).willReturn(
				currencyPairProductsInDB_Product_2);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_Updated_1 = getACurrencyPairProductEntity(
				currency_1_Product_1, currency, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_1);

		CurrencyPairProduct currencyPairProductInDB_Updated_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_2);

		CurrencyPairProduct currencyPairProductInDB_Updated_3 = getACurrencyPairProductEntity(
				currency_3_Product_1, currency, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_3);

		CurrencyPairProduct currencyPairProductInDB_Updated_4 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_4);

		CurrencyPairProduct currencyPairProductInDB_Updated_5 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_5);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_1, false);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_2, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());

	}

	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyAndAllProducts() {

		// given
		String currency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_MASTER;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		List<String> products = new ArrayList<String>();
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, null, group, status, null, null, null, updatedBy,
				null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & USD)

		String currency_1_Product_1 = "RMB";
		String status_1_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_1 = getACurrencyPairProductEntity(
				currency, currency_1_Product_1, product_1, status_1_Product_1,
				null, null, null, null, null);

		String currency_2_Product_1 = "SGD";
		String status_2_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_RFQ;

		CurrencyPairProduct currencyPairProductInDB_2_Product_1 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status_2_Product_1,
				null, null, null, null, null);

		String currency_3_Product_1 = "EUR";
		String status_3_Product_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_3_Product_1 = getACurrencyPairProductEntity(
				currency_3_Product_1, currency, product_1, status_3_Product_1,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_1 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_1_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_2_Product_1);
		currencyPairProductsInDB_Product_1
				.add(currencyPairProductInDB_3_Product_1);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_1, false)).willReturn(
				currencyPairProductsInDB_Product_1);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KO & USD)

		String currency_1_Product_2 = "RMB";
		String status_1_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1_Product_2 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status_1_Product_2,
				null, null, null, null, null);

		String currency_2_Product_2 = "SGD";
		String status_2_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_2_Product_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_2, product_2, status_2_Product_2,
				null, null, null, null, null);

		String currency_3_Product_2 = "EUR";
		String status_3_Product_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_3_Product_2 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status_3_Product_2,
				null, null, null, null, null);

		List<CurrencyPairProduct> currencyPairProductsInDB_Product_2 = new ArrayList<CurrencyPairProduct>();
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_1_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_2_Product_2);
		currencyPairProductsInDB_Product_2
				.add(currencyPairProductInDB_3_Product_2);

		given(
				currencyPairProductRepository
						.getAllCurrencyPairsOfAProductWithAGivenCurrency(
								currency, product_2, false)).willReturn(
				currencyPairProductsInDB_Product_2);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_Updated_1 = getACurrencyPairProductEntity(
				currency_1_Product_1, currency, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_1);

		CurrencyPairProduct currencyPairProductInDB_Updated_2 = getACurrencyPairProductEntity(
				currency, currency_2_Product_1, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_2);

		CurrencyPairProduct currencyPairProductInDB_Updated_3 = getACurrencyPairProductEntity(
				currency, currency_1_Product_2, product_2, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_3);

		CurrencyPairProduct currencyPairProductInDB_Updated_4 = getACurrencyPairProductEntity(
				currency_3_Product_2, currency, product_2, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated_4);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_1, false);
		verify(currencyPairProductRepository, times(1))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product_2, false);
		verify(currencyPairProductRepository, times(0)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());

	}

	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyPairAndAProduct() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String product = Products.PRODUCT_KNOCKIN;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		products.add(product);

		given(fxoProductCatalogueGroupService.getAllProducts(product))
				.willReturn(products);

		// prepare input
		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, product, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product, status_1, null, null, null,
				null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product, false)).willReturn(
				currencyPairProductInDB_1);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_Updated = getACurrencyPairProductEntity(
				currency, counterCurrency, product, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(
				product);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(currency,
						product, false);

		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				(String) any(), (String) any(), (String) any(), eq(false));

		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());
	}

	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyPairAndAGroup() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_KI_KO;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, group, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (2
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status_1, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_1, false)).willReturn(
				currencyPairProductInDB_1);

		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_2, status_2, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_2, false)).willReturn(
				currencyPairProductInDB_2);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_Updated = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_Updated);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_1, false);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_2, false);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(
						(String) any(), (String) any(), eq(false));
		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());
	}

	public void shouldUpdateCurrencyPairProductConfigurations_ForACurrencyPairAndAllProducts() {

		// given
		String currency = "EUR";
		String counterCurrency = "USD";
		String group = ProductGroups.PRODUCT_GROUP_MASTER;
		String status = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_OFF;
		String updatedBy = "TraderAdmin";

		// collection of Strings (here input group is a product, so collection
		// to have only one item)
		List<String> products = new ArrayList<String>();
		String product_1 = Products.PRODUCT_KNOCKIN;
		String product_2 = Products.PRODUCT_KNOCKOUT;
		products.add(product_1);
		products.add(product_2);

		given(fxoProductCatalogueGroupService.getAllProducts(group))
				.willReturn(products);

		// prepare input

		CurrencyPairProductConfigDTO currencyPairProductConfigDTO_Input = getACurrencyPairProductConfigDTO(
				currency, counterCurrency, group, status, null, null, null,
				updatedBy, null, null);

		// prepare CurrencyPairProduct Entities in Database (3
		// currencyPairProduct mappings for KI & EUR)
		String status_1 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_1 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status_1, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_1, false)).willReturn(
				currencyPairProductInDB_1);

		String status_2 = FXOCurrencyPairStatuses.CURRENCY_PAIR_STATUS_ON;

		CurrencyPairProduct currencyPairProductInDB_2 = getACurrencyPairProductEntity(
				currency, counterCurrency, product_2, status_2, null, null,
				null, null, null);

		given(
				currencyPairProductRepository.getCurrencyPairProduct(currency,
						counterCurrency, product_2, false)).willReturn(
				currencyPairProductInDB_2);

		// prepare intermediate Data (Saved entities Collection)
		List<CurrencyPairProduct> currencyPairProductsInDB_Updated = new ArrayList<CurrencyPairProduct>();

		CurrencyPairProduct currencyPairProductInDB_1_Updated = getACurrencyPairProductEntity(
				currency, counterCurrency, product_1, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_1_Updated);

		CurrencyPairProduct currencyPairProductInDB_2_Updated = getACurrencyPairProductEntity(
				currency, counterCurrency, product_2, status, null, null,
				updatedBy, null, null);

		currencyPairProductsInDB_Updated.add(currencyPairProductInDB_2_Updated);

		given(
				currencyPairProductRepository
						.saveCurrencyPairProducts((List<CurrencyPairProduct>) any()))
				.willReturn(currencyPairProductsInDB_Updated);

		// when
		CurrencyPairProductConfigResponseDTO currencyPairProductConfigResponseDTO = currencyPairProductConfigurationService
				.updateCurrencyPairProductConfigurations(currencyPairProductConfigDTO_Input);

		// then
		assertThat(currencyPairProductConfigResponseDTO).isNotNull();
		assertThat(currencyPairProductConfigResponseDTO.getCurrencyPairCount())
				.isEqualTo(currencyPairProductsInDB_Updated.size());

		verify(fxoProductCatalogueGroupService, times(1)).getAllProducts(group);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_1, false);
		verify(currencyPairProductRepository, times(1)).getCurrencyPairProduct(
				currency, counterCurrency, product_2, false);
		verify(currencyPairProductRepository, times(0))
				.getAllCurrencyPairsOfAProductWithAGivenCurrency(
						(String) any(), (String) any(), eq(false));

		verify(currencyPairProductRepository, times(1))
				.saveCurrencyPairProducts((List<CurrencyPairProduct>) any());

	}

}
