package com.fxo.admin.constraint.validator;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.hibernate.validator.internal.engine.ConstraintValidatorContextImpl;
import org.hibernate.validator.internal.engine.MessageAndPath;
import org.hibernate.validator.internal.engine.PathImpl;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.fxo.admin.constants.FXOAdminMessageCodes;
import com.fxo.admin.dto.FXOInterPortfolioConfigDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListDTO;
import com.fxo.admin.dto.FXOUserInterPortfolioMappingConfigListWrapperDTO;
import com.fxo.api.dto.FXOInterPortfolioDTO;
import com.fxo.api.service.IFXOInterPortfolioService;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.dao.entity.FenicsTicket;
import com.fxo.dao.repository.FenicsTicketRepository;
import com.fxo.framework.util.FXOStringUtility;

@Test
public class ValidFXOUserInterPortfolioMappingConfigValidatorTest {

	@Mock
	FenicsTicketRepository fenicsTicketRepository;

	@Mock
	IFXOInterPortfolioService fxoInterPortfolioService;

	@InjectMocks
	ValidFXOUserInterPortfolioMappingConfigValidator validFXOUserInterPortfolioMappingConfigValidatorTest;

	ConstraintValidatorContextImpl context = null;

	@BeforeMethod
	public void initMocks() {
		MockitoAnnotations.initMocks(this);
		context = createEmptyConstraintValidatorContextImpl();

	}

	private ConstraintValidatorContextImpl createEmptyConstraintValidatorContextImpl() {
		PathImpl path = PathImpl.createRootPath();
		path.addNode("");

		ConstraintValidatorContextImpl context = new ConstraintValidatorContextImpl(
				path, null);
		context.disableDefaultConstraintViolation();
		return context;
	}

	private FXOUserInterPortfolioMappingConfigListWrapperDTO getAFXOUserInterPortfolioMappingConfigListWrapperDTO(
			List<FXOUserInterPortfolioMappingConfigListDTO> mappingConfigListDTOs) {
		return new FXOUserInterPortfolioMappingConfigListWrapperDTO()
				.setInterPortfolioMappingConfiguration(mappingConfigListDTOs);
	}

	private FXOUserInterPortfolioMappingConfigListDTO getAFXOUserInterPortfolioMappingConfigListDTO(
			String userId, List<FXOInterPortfolioConfigDTO> interPortfolios) {

		return new FXOUserInterPortfolioMappingConfigListDTO()
				.setUserId(userId).setInterPortfolios(interPortfolios);
	}

	private FXOInterPortfolioConfigDTO getAFXOInterPortfolioConfigDTO(
			String interPortfolio, Boolean status) {

		return new FXOInterPortfolioConfigDTO().setInterPortfolio(
				interPortfolio).setActive(status);
	}

	private FXOInterPortfolioDTO getAFXOInterPortfolioDTO(
			String interPortfolio, Boolean status) {
		return new FXOInterPortfolioDTO().setInterPortfolio(interPortfolio)
				.setActive(status);
	}

	public void shouldValidateToSuccessForAValidWrapper() throws IOException,
			URISyntaxException {

		String userId_1 = "tmsguser21";
		String interPortfolio_1_1 = "DBS FA INTERNAL";
		String interPortfolio_1_2 = "DBSSG ABSP PRIM";
		String interPortfolio_1_3 = "DBSSG ACU BTB";
		Boolean status_1_1 = Boolean.TRUE;
		Boolean status_1_2 = Boolean.TRUE;
		Boolean status_1_3 = Boolean.FALSE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_1 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_1, status_1_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_2, status_1_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_3, status_1_3));

		String userId_2 = "tmsguser22";
		String interPortfolio_2_1 = "DBS FA INTERNAL";
		String interPortfolio_2_2 = "DBSSG ABSP PRIM";
		String interPortfolio_2_3 = "DBSSG ACU BTB";
		Boolean status_2_1 = Boolean.TRUE;
		Boolean status_2_2 = Boolean.TRUE;
		Boolean status_2_3 = Boolean.TRUE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_2 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_1, status_2_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_2, status_2_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_3, status_2_3));

		// given
		FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO = getAFXOUserInterPortfolioMappingConfigListWrapperDTO(Arrays
				.asList(getAFXOUserInterPortfolioMappingConfigListDTO(userId_1,
						interPortfolios_1),
						getAFXOUserInterPortfolioMappingConfigListDTO(userId_2,
								interPortfolios_2)));

		Mockito.when(
				fxoInterPortfolioService.getOneFXOInterPortfolio(Mockito
						.anyString())).thenReturn(new FXOInterPortfolioDTO());

		// when
		boolean isWrapperValid = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isValid(fxoUserInterPortfolioMappingConfigListWrapperDTO,
						context);

		// then
		Assertions.assertThat(isWrapperValid).isTrue();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(5))
				.getOneFXOInterPortfolio(Mockito.anyString());

		Mockito.verify(fxoInterPortfolioService, Mockito.times(2))
				.getOneFXOInterPortfolio(interPortfolio_1_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(2))
				.getOneFXOInterPortfolio(interPortfolio_1_2);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1_3);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(Mockito.anyString(),
						Mockito.anyString());

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId_1, interPortfolio_1_3);

	}

	public void shouldValidateToFailureForAnInValidWrapper()
			throws IOException, URISyntaxException {

		String userId_1 = "tmsguser21";
		String interPortfolio_1_1 = "DBS FA INTERNAL";
		String interPortfolio_1_2 = "DBSSG ABSP PRIM";
		String interPortfolio_1_3 = "DBSSG ACU BTB";
		Boolean status_1_1 = Boolean.TRUE;
		Boolean status_1_2 = Boolean.TRUE;
		Boolean status_1_3 = Boolean.FALSE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_1 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_1, status_1_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_2, status_1_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_1_3, status_1_3));

		String userId_2 = "tmsguser22";
		String interPortfolio_2_1 = "DBS FA INTERNAL 2";
		String interPortfolio_2_2 = "DBSSG ABSP PRIM 2";
		String interPortfolio_2_3 = "DBSSG ACU BTB 2";
		Boolean status_2_1 = Boolean.TRUE;
		Boolean status_2_2 = Boolean.TRUE;
		Boolean status_2_3 = Boolean.TRUE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_2 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_1, status_2_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_2, status_2_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2_3, status_2_3));

		// given
		FXOUserInterPortfolioMappingConfigListWrapperDTO fxoUserInterPortfolioMappingConfigListWrapperDTO = getAFXOUserInterPortfolioMappingConfigListWrapperDTO(Arrays
				.asList(getAFXOUserInterPortfolioMappingConfigListDTO(userId_1,
						interPortfolios_1),
						getAFXOUserInterPortfolioMappingConfigListDTO(userId_2,
								interPortfolios_2)));

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_1_1))
				.thenReturn(
						getAFXOInterPortfolioDTO(interPortfolio_1_1, status_1_1));
		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_1_2))
				.thenReturn(
						getAFXOInterPortfolioDTO(interPortfolio_1_2, status_1_2));

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_2_1))
				.thenReturn(
						getAFXOInterPortfolioDTO(interPortfolio_2_1, status_2_1));

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_2_2))
				.thenReturn(null);

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_2_3))
				.thenReturn(
						getAFXOInterPortfolioDTO(interPortfolio_2_3, status_2_3));

		// when
		boolean isWrapperValid = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isValid(fxoUserInterPortfolioMappingConfigListWrapperDTO,
						context);

		// then
		Assertions.assertThat(isWrapperValid).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1_2);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId_1, interPortfolio_1_3);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2_2);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2_3);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.size()).isEqualTo(1);

		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID,
										userId_2, interPortfolio_2_2),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldValidateToFailureForANullWrapper() throws IOException,
			URISyntaxException {
		// when
		boolean isWrapperValid = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isValid(null, context);

		// then
		Assertions.assertThat(isWrapperValid).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(0))
				.getOneFXOInterPortfolio(Mockito.anyString());

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.size()).isEqualTo(1);

		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_WRAPPER_INVALID);
	}

	public void shouldValidateToSuccessForAValidMappingList()
			throws IOException, URISyntaxException {

		String userId_1 = "tmsguser21";
		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG ABSP PRIM";
		String interPortfolio_3 = "DBSSG ACU BTB";
		Boolean status_1 = Boolean.TRUE;
		Boolean status_2 = Boolean.TRUE;
		Boolean status_3 = Boolean.FALSE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_1 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_1, status_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2, status_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_3, status_3));

		// given
		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = getAFXOUserInterPortfolioMappingConfigListDTO(
				userId_1, interPortfolios_1);

		Mockito.when(
				fxoInterPortfolioService.getOneFXOInterPortfolio(Mockito
						.anyString())).thenReturn(new FXOInterPortfolioDTO());

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAValidMappingList = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAValidFXOUserInterPortfolioMapping(
						fxoUserInterPortfolioMappingConfigListDTO, context);

		// then
		Assertions.assertThat(isAValidMappingList).isTrue();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId_1, interPortfolio_3);
	}

	public void shouldValidateToFailureForAnInValidMappingList()
			throws IOException, URISyntaxException {

		String userId = "tmsguser21";
		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG ABSP PRIM";
		String interPortfolio_3 = "DBSSG ACU BTB";
		Boolean status_1 = Boolean.TRUE;
		Boolean status_2 = Boolean.TRUE;
		Boolean status_3 = Boolean.FALSE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_1 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_1, status_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2, status_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_3, status_3));

		// given
		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = getAFXOUserInterPortfolioMappingConfigListDTO(
				userId, interPortfolios_1);

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_1)).thenReturn(
				getAFXOInterPortfolioDTO(interPortfolio_1, status_1));

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_2)).thenReturn(
				null);

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(
				Arrays.asList(new FenicsTicket()));

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAValidMappingList = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAValidFXOUserInterPortfolioMapping(
						fxoUserInterPortfolioMappingConfigListDTO, context);

		// then
		Assertions.assertThat(isAValidMappingList).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio_3);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.size()).isEqualTo(2);

		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID,
										userId, interPortfolio_2),
								FXOWSConstantKeys.COMMA_DELIMITER));

		Assertions.assertThat(messageAndPaths.get(1)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(1).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(1).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_DELETE_A_PORTFOLIO_DEAL_EXISTS,
										userId, interPortfolio_3),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldValidateToFailureForANullMappingList()
			throws IOException, URISyntaxException {

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAValidMappingList = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAValidFXOUserInterPortfolioMapping(null, context);

		// then
		Assertions.assertThat(isAValidMappingList).isFalse();

		Mockito.verify(fenicsTicketRepository, Mockito.times(0))
				.findByUserIdAndInterPortfolio(Mockito.anyString(),
						Mockito.anyString());

		Mockito.verify(fxoInterPortfolioService, Mockito.times(0))
				.getOneFXOInterPortfolio(Mockito.anyString());

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_COLLECTION_INVALID);

	}

	public void shouldValidateToFailureForAMappingListWithANullPortfolioMapping()
			throws IOException, URISyntaxException {

		String userId = "tmsguser21";
		String interPortfolio_1 = "DBS FA INTERNAL";
		String interPortfolio_2 = "DBSSG ABSP PRIM";
		String interPortfolio_3 = "DBSSG ACU BTB";
		Boolean status_1 = Boolean.TRUE;
		Boolean status_2 = Boolean.TRUE;
		Boolean status_3 = Boolean.FALSE;

		List<FXOInterPortfolioConfigDTO> interPortfolios_1 = Arrays.asList(
				getAFXOInterPortfolioConfigDTO(interPortfolio_1, status_1),
				getAFXOInterPortfolioConfigDTO(interPortfolio_2, status_2),
				getAFXOInterPortfolioConfigDTO(interPortfolio_3, status_3),
				null);

		// given
		FXOUserInterPortfolioMappingConfigListDTO fxoUserInterPortfolioMappingConfigListDTO = getAFXOUserInterPortfolioMappingConfigListDTO(
				userId, interPortfolios_1);

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_1)).thenReturn(
				getAFXOInterPortfolioDTO(interPortfolio_1, status_1));

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio_2)).thenReturn(
				getAFXOInterPortfolioDTO(interPortfolio_2, status_2));

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio_3)).thenReturn(null);

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAValidMappingList = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAValidFXOUserInterPortfolioMapping(
						fxoUserInterPortfolioMappingConfigListDTO, context);

		// then
		Assertions.assertThat(isAValidMappingList).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_1);

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio_2);

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio_3);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_INVALID,
										userId),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldAllowToAddMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";
		Boolean status = Boolean.TRUE;

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio)).thenReturn(
				getAFXOInterPortfolioDTO(interPortfolio, status));

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToAddMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToAddMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToAddMapping).isTrue();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio);

	}

	public void shouldNotAllowToAddInvalidPortfolioMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio)).thenReturn(
				null);

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToAddMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToAddMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToAddMapping).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID,
										userId, interPortfolio),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldNotAllowToAddInactivePortfolioMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fxoInterPortfolioService
						.getOneFXOInterPortfolio(interPortfolio)).thenReturn(
				getAFXOInterPortfolioDTO(interPortfolio, Boolean.FALSE));

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToAddMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToAddMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToAddMapping).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(1))
				.getOneFXOInterPortfolio(interPortfolio);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INACTIVE,
										userId, interPortfolio),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldNotAllowToAddNullPortfolioMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = null;

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToAddMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToAddMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToAddMapping).isFalse();

		Mockito.verify(fxoInterPortfolioService, Mockito.times(0))
				.getOneFXOInterPortfolio(interPortfolio);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_ADD_PORTFOLIO_INVALID,
										userId),
								FXOWSConstantKeys.COMMA_DELIMITER));
	}

	public void shouldAllowToDeleteMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio)).thenReturn(null);

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToDeleteMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToDeleteMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToDeleteMapping).isTrue();

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

	}

	public void shouldNotAllowToDeleteMapping() {

		// given
		String userId = "tmsguser21";
		String interPortfolio = "DBS FA INTERNAL";

		Mockito.when(
				fenicsTicketRepository.findByUserIdAndInterPortfolio(userId,
						interPortfolio)).thenReturn(
				Arrays.asList(new FenicsTicket()));

		ConstraintValidatorContextImpl context = createEmptyConstraintValidatorContextImpl();

		// when
		boolean isAllowedToDeleteMapping = validFXOUserInterPortfolioMappingConfigValidatorTest
				.isAllowedToDeleteMapping(userId, interPortfolio, context);

		// then
		Assertions.assertThat(isAllowedToDeleteMapping).isFalse();

		Mockito.verify(fenicsTicketRepository, Mockito.times(1))
				.findByUserIdAndInterPortfolio(userId, interPortfolio);

		List<MessageAndPath> messageAndPaths = context.getMessageAndPathList();

		Assertions.assertThat(messageAndPaths).isNotNull();
		Assertions.assertThat(messageAndPaths).isNotEmpty();
		Assertions.assertThat(messageAndPaths.get(0)).isNotNull();
		Assertions.assertThat(messageAndPaths.get(0).getMessage()).isNotNull();
		Assertions
				.assertThat(messageAndPaths.get(0).getMessage())
				.isEqualTo(
						FXOStringUtility.joinStrings(
								Arrays.asList(
										FXOAdminMessageCodes.ERR_USERINTERPORTFOLIO_MAPPING_DELETE_A_PORTFOLIO_DEAL_EXISTS,
										userId, interPortfolio),
								FXOWSConstantKeys.COMMA_DELIMITER));

	}
}
