package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.FXOMessageDTO;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.rest.model.MarketRateResponseModel;

@AutoProperty
public class PricingResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String pricingRequestId;

	private String parentPricingRequestId;

	private String pricingResponseId;

	private Long pricingExpiryTime;

	private UserDTO user;

	private CustomerDTO customer;

	private ProductStructureDTO structure;

	private FXOMessageDTO fxoMessage;

	private String requestPurpose;

	private MarketRateResponseDTO currentMarketRateResponse;

	public PricingResponseDTO() {

	}

	public PricingResponseDTO(String pricingRequestId, ProductStructureDTO structure) {
		super();
		this.pricingRequestId = pricingRequestId;
		this.structure = structure;
	}

	public String getPricingRequestId() {
		return pricingRequestId;
	}

	public PricingResponseDTO setPricingRequestId(String pricingRequestId) {
		this.pricingRequestId = pricingRequestId;
		return this;
	}

	public ProductStructureDTO getStructure() {
		return structure;
	}

	public PricingResponseDTO setStructure(ProductStructureDTO structure) {
		this.structure = structure;
		return this;
	}

	public Long getPricingExpiryTime() {
		return pricingExpiryTime;
	}

	public PricingResponseDTO setPricingExpiryTime(Long pricingExpiryTime) {
		this.pricingExpiryTime = pricingExpiryTime;
		return this;
	}

	public String getPricingResponseId() {
		return pricingResponseId;
	}

	public PricingResponseDTO setPricingResponseId(String pricingResponseId) {
		this.pricingResponseId = pricingResponseId;
		return this;
	}

	public UserDTO getUser() {
		return user;
	}

	public PricingResponseDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

	public FXOMessageDTO getFxoMessage() {
		return fxoMessage;
	}

	public PricingResponseDTO setFxoMessage(FXOMessageDTO fxoMessage) {
		this.fxoMessage = fxoMessage;
		return this;
	}

	public String getParentPricingRequestId() {
		return parentPricingRequestId;
	}

	public PricingResponseDTO setParentPricingRequestId(String parentPricingRequestId) {

		this.parentPricingRequestId = parentPricingRequestId;
		return this;
	}

	public CustomerDTO getCustomer() {
		return customer;
	}

	public PricingResponseDTO setCustomer(CustomerDTO customer) {
		this.customer = customer;
		return this;
	}

	public String getRequestPurpose() {
		return requestPurpose;
	}

	public PricingResponseDTO setRequestPurpose(String requestPurpose) {
		this.requestPurpose = requestPurpose;
		return this;
	}

	public static PricingResponseDTO getInstance(String product) {
		return new PricingResponseDTO().setStructure(ProductStructureDTO.instance(product));
	}

	public static PricingResponseDTO getInstanceWithEmptyLegs(String product) {
		PricingResponseDTO pricingResponseDTO = new PricingResponseDTO()
				.setStructure(ProductStructureDTO.instance(product));

		pricingResponseDTO.getStructure().getStrategies().get(0).getLegs().clear();

		return pricingResponseDTO;
	}

	public MarketRateResponseDTO getCurrentMarketRateResponse() {
		return currentMarketRateResponse;
	}

	public PricingResponseDTO setCurrentMarketRateResponse(MarketRateResponseDTO currentMarketRateResponse) {
		this.currentMarketRateResponse = currentMarketRateResponse;
		return this;
	}

}
