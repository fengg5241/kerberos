package com.fxo.api.reports;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.FXOReportParametersMappingDTO;
import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXOReportParametersMappingService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.admin.Meridiem;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.email.FXOEmailConstants;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.constants.reports.FXOReportConstants;
import com.fxo.constants.reports.FXOReportParameterTypes;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractDealConfirmationReportMapperService implements
		IDealConfirmationReportMapper {

	@Autowired
	private IFXOReportParametersMappingService fxoReportParametersMappingService;

	@Autowired
	private ICurrencyPairService currencyPairService;

	@Transactional(readOnly = true, propagation = Propagation.REQUIRED)
	public String getReportFieldValue(String parameterType,
			String parameterSourceValue) {
		FXOReportParametersMappingDTO fxoReportParametersMappingDTO = fxoReportParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						parameterType, parameterSourceValue);

		Objects.requireNonNull(fxoReportParametersMappingDTO, FXOStringUtility
				.joinStrings(Arrays.asList(
						FXOMessageCodes.ERR_REPORT_MAPPING_REQUIRED,
						parameterSourceValue),
						FXOWSConstantKeys.COMMA_DELIMITER));

		return fxoReportParametersMappingDTO.getParameterTargetValue();
	}

	public String getReportFileName(String productType, String customerReference) {

		String reportFileName = getReportFieldValue(
				FXOReportConstants.REPORT_FILE_NAME,
				FXOStringUtility.joinStrings(
						Arrays.asList(productType, customerReference),
						FXOEmailConstants.HYPHEN_DELIMITER));

		Objects.requireNonNull(reportFileName, FXOStringUtility.joinStrings(
				Arrays.asList(FXOMessageCodes.ERR_REPORT_FILENAME_REQUIRED,
						productType, customerReference),
				FXOEmailConstants.COMMA_DELIMITER));

		return reportFileName;
	}

	public String getReportTemplateName(String productType) {

		String reportTemplateName = getReportFieldValue(
				FXOReportConstants.REPORT_TEMPLATE_NAME, productType);

		Objects.requireNonNull(reportTemplateName, FXOStringUtility
				.joinStrings(Arrays.asList(
						FXOMessageCodes.ERR_REPORT_TEMPLATE_REQUIRED,
						productType), FXOEmailConstants.COMMA_DELIMITER));

		return reportTemplateName;
	}

	public String getLogoName(String customerReference) {

		String reportLogoName = getReportFieldValue(
				FXOReportConstants.REPORT_LOGO_NAME, customerReference);

		Objects.requireNonNull(reportLogoName, FXOStringUtility.joinStrings(
				Arrays.asList(FXOMessageCodes.ERR_REPORT_LOGO_REQUIRED,
						customerReference), FXOEmailConstants.COMMA_DELIMITER));

		return reportLogoName;
	}

	public Map<String, Object> getInitializedReportParameterMap(
			TicketingResponseDTO ticketingResponseDTO) {
		ProductStructureDTO productStructureDTO = ticketingResponseDTO
				.getStructure();

		FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
				.extractKeyProductDetails(productStructureDTO);

		Map<String, Object> reportParameterMap = new HashMap<String, Object>();

		String productType = fxoProductStructureExtractDTO.getProductType();

		reportParameterMap.put(FXOReportConstants.FXO_JASPER_XML_FILENAME,
				getReportTemplateName(productType));

		reportParameterMap.put(
				FXOReportConstants.FXO_REPORT_FILENAME,
				getReportFileName(productType, ticketingResponseDTO
						.getCustomer().getCustomerReference()));

		reportParameterMap.put(FXOReportConstants.FXO_REPORT_LOGONAME,
				getLogoName(ticketingResponseDTO.getCustomer()
						.getCustomerReference()));

		return reportParameterMap;
	}

	public BigDecimal formatToPrecision(String currency,
			String counterCurrency, BigDecimal rateBeforeRounding) {

		return MathUtil.formatBigDecimal(rateBeforeRounding,
				currencyPairService.getPrecision(currency, counterCurrency),
				RoundingMode.HALF_UP);
	}

	public String formatJodaDateObject(String dateFormatCode, DateTime dateInput) {

		String dateTimeFormat = getReportFieldValue(
				FXOReportParameterTypes.FXO_REPORT_PARAMETERTYPE_DATETIME_FORMAT,
				dateFormatCode);

		String dateString = (dateInput != null) ? generateDateTimeStringFromDateTimeAndFormat(
				dateTimeFormat, dateInput) : null;

		return dateString;
	}

	public String generateDateTimeStringFromDateTimeAndFormat(String format,
			DateTime dateTimeObject) {
		String dateTimeString = null;

		DateTimeFormatter fmt = DateTimeFormat.forPattern(format);
		dateTimeString = fmt.print(dateTimeObject);

		return dateTimeString;
	}

	public String getReportExpiryTimeString(DateTime expiryDate) {

		// get Meridiem
		Meridiem meridiem = DateTimeUtil.getMeridiem(expiryDate);

		// convert to TwelveHourFormat & format TimeString
		String formattedTimeString = DateTimeFormat.forPattern(
				FenicsConstants.FENICS_TIME_FORMAT).print(
				DateTimeUtil.convertToTwelveHourFormat(expiryDate));

		// generate Display TimeString
		String reportDisplayValue = FXOStringUtility.joinStrings(Arrays.asList(
				formattedTimeString, meridiem.displayValue + ",", "Singapore",
				"time"), FXOWSConstantKeys.SPACE_DELIMITER);

		return reportDisplayValue;

	}

	public String getDefaultTimeString() {
		return getReportFieldValue(
				FXOReportParameterTypes.FXO_REPORT_PARAMETERTYPE_DEFAULTTIME,
				FXOReportParameterTypes.FXO_REPORT_PARAMETERTYPE_DEFAULTTIME);
	}

}
