package com.fxo.api.fenics.service;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FXOTenorExpiryDatesDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.OptionTypes;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;

@Component
public class FenicsTenorExpiryDateRequestGeneratorServiceImpl implements
		IFenicsTenorExpiryDateRequestGeneratorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsTenorExpiryDateRequestGeneratorServiceImpl.class);

	public static final String FENICS_LOGGER = "com.fxo.fenics.logger";

	private static final Logger fenicsLogger = LoggerFactory
			.getLogger(FENICS_LOGGER);

	@Autowired
	FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	FenicsRequestNodeService fenicsRequestNodeService;

	@Autowired
	IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	IFXOConstantsService fxoConstantsService;

	@Autowired
	FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Override
	public String getFenicsPricingXML(
			FXOTenorExpiryDatesDTO fXOTenorExpiryDatesDTO)
			throws ApplicationException {
		BodyType requestBody = populateRequestBody(fXOTenorExpiryDatesDTO);

		String fenicsRequestId = generateUniqueRequestId();
		fXOTenorExpiryDatesDTO.setFenicsRequestId(fenicsRequestId);

		String requestXML = fenicsXMLProcessingService.compositeXML(
				requestBody, fenicsRequestId, null);

		// log FENICS request XML generated
		fenicsLogger.info(String.format(
				"Fenics-TenorExpiryDatesPricingRequest [ %s ] XML built: %s",
				fXOTenorExpiryDatesDTO.getFenicsRequestId(), requestXML));

		return requestXML;
	}

	public BodyType populateRequestBody(
			FXOTenorExpiryDatesDTO fXOTenorExpiryDatesDTO) {

		DataType data = new DataType()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeName))
				.setFormat(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeFormat));

		generateFenicsOptionLegs(data, fXOTenorExpiryDatesDTO);

		BodyType body = new BodyType()
				.setAction(populateRequestAction(FenicsCalculationParameters.MIDRATE));

		body.getData().add(data);

		return body;
	}

	public void generateFenicsOptionLegs(DataType data,
			FXOTenorExpiryDatesDTO fXOTenorExpiryDatesDTO) {

		String legNodenamePrefix = fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName);

		NodeType node = new NodeType();
		node.setName(legNodenamePrefix + " " + 0);
		data.getNode().add(node);

		String fenicsRequestPurpose = FenicsRequestPurpose.EXPIRY_DATE;
		String dealingConvention = null;

		fenicsXMLFieldGenerator.generateCurrencyField(node,
				fXOTenorExpiryDatesDTO.getCurrency(), fenicsRequestPurpose,
				dealingConvention);

		fenicsXMLFieldGenerator.generateCounterCurrencyField(node,
				fXOTenorExpiryDatesDTO.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateMaturityField(node,
				fXOTenorExpiryDatesDTO.getTenor(), fenicsRequestPurpose,
				dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		FXOParametersMappingDTO fxoParametersMappingDTOOptionType = fxoParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
						OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG);

		fenicsXMLFieldGenerator.generateOptionClassField(node,
				fxoParametersMappingDTOOptionType.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateStrikeFieldForSpotRateAPI(node,
				fenicsRequestPurpose, dealingConvention);

		String simpleOptionModel = fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsSimpleOptionModel);
		fenicsXMLFieldGenerator.generateModelField(node, simpleOptionModel,
				fenicsRequestPurpose, dealingConvention);

	}

	public com.fxo.fenics.request.ActionType populateRequestAction(
			String calculationType) {
		com.fxo.fenics.request.ActionType action = new com.fxo.fenics.request.ActionType()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrActionTypeFunc));

		OptionType option1 = new OptionType()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeCalcName))
				.setOptionValue(calculationType);

		action.getOption().add(option1);

		OptionType option2 = new OptionType()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenVal));

		action.getOption().add(option2);

		OptionType option3 = new OptionType()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataRef));

		action.getOption().add(option3);

		return action;
	}

	public String generateUniqueRequestId() {
		return REQUEST_PREFIX
				+ org.springframework.util.StringUtils.delete(UUID.randomUUID()
						.toString(), "-");
	}
}
