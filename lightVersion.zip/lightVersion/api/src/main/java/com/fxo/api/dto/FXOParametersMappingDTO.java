package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXOParametersMappingDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String parameterType;

	private String parameterDescription;

	private String parameterSourceValue;

	private String parameterTargetValue;

	private Integer sequence;

	public String getParameterType() {
		return parameterType;
	}

	public FXOParametersMappingDTO setParameterType(String parameterType) {
		this.parameterType = parameterType;
		return this;
	}

	public String getParameterDescription() {
		return parameterDescription;
	}

	public FXOParametersMappingDTO setParameterDescription(
			String parameterDescription) {
		this.parameterDescription = parameterDescription;
		return this;
	}

	public String getParameterSourceValue() {
		return parameterSourceValue;
	}

	public FXOParametersMappingDTO setParameterSourceValue(
			String parameterSourceValue) {
		this.parameterSourceValue = parameterSourceValue;
		return this;
	}

	public String getParameterTargetValue() {
		return parameterTargetValue;
	}

	public FXOParametersMappingDTO setParameterTargetValue(
			String parameterTargetValue) {
		this.parameterTargetValue = parameterTargetValue;
		return this;
	}

	public Integer getSequence() {
		return sequence;
	}

	public FXOParametersMappingDTO setSequence(Integer sequence) {
		this.sequence = sequence;
		return this;
	}
}
