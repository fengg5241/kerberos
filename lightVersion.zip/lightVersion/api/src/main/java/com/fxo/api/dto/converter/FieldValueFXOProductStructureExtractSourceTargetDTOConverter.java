package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.framework.core.dto.BaseCustomSourceBaseCustomTargetDTOConverter;

@Component
public class FieldValueFXOProductStructureExtractSourceTargetDTOConverter
		extends
		BaseCustomSourceBaseCustomTargetDTOConverter<FieldValueDTO, FXOProductStructureExtractDTO> {

}
