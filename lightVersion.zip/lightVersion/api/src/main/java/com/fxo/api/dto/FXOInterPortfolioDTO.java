package com.fxo.api.dto;

import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.AuditableDTO;

public class FXOInterPortfolioDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String interPortfolio;

	private Boolean active;

	@Override
	public FXOInterPortfolioDTO clone() throws CloneNotSupportedException {
		FXOInterPortfolioDTO interPortfolioDTO = new FXOInterPortfolioDTO();

		interPortfolioDTO.setInterPortfolio(getInterPortfolio())
				.setActive(getActive()).setCreatedBy(getCreatedBy())
				.setCreatedDate(getCreatedDate())
				.setLastUpdatedBy(getLastUpdatedBy())
				.setLastUpdatedDate(getLastUpdatedDate());

		return interPortfolioDTO;

	}


	public Boolean getActive() {
		return active;
	}

	public FXOInterPortfolioDTO setActive(Boolean active) {
		this.active = active;
		return this;
	}


	public String getInterPortfolio() {
		return interPortfolio;
	}


	public FXOInterPortfolioDTO setInterPortfolio(String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

}
