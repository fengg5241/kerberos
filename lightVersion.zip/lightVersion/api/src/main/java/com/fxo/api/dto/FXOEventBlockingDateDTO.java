package com.fxo.api.dto;

import java.util.List;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXOEventBlockingDateDTO extends AuditableDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String eventDescription;

	private String active;

	private LocalDate expiryDateThresholdMin;

	private LocalDate expiryDateThresholdMax;

	private List<CurrencyPairDTO> currencyPair;

	private List<String> product;

	private LocalDate expiryDate;

	public String getEventDescription() {
		return eventDescription;
	}

	public FXOEventBlockingDateDTO setEventDescription(String eventDescription) {
		this.eventDescription = eventDescription;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXOEventBlockingDateDTO setActive(String active) {
		this.active = active;
		return this;
	}

	public LocalDate getExpiryDateThresholdMin() {
		return expiryDateThresholdMin;
	}

	public FXOEventBlockingDateDTO setExpiryDateThresholdMin(
			LocalDate expiryDateThresholdMin) {
		this.expiryDateThresholdMin = expiryDateThresholdMin;
		return this;
	}

	public LocalDate getExpiryDateThresholdMax() {
		return expiryDateThresholdMax;
	}

	public FXOEventBlockingDateDTO setExpiryDateThresholdMax(
			LocalDate expiryDateThresholdMax) {
		this.expiryDateThresholdMax = expiryDateThresholdMax;
		return this;
	}

	public List<CurrencyPairDTO> getCurrencyPair() {
		return currencyPair;
	}

	public FXOEventBlockingDateDTO setCurrencyPair(
			List<CurrencyPairDTO> currencyPair) {
		this.currencyPair = currencyPair;
		return this;
	}

	public List<String> getProduct() {
		return product;
	}

	public FXOEventBlockingDateDTO setProduct(List<String> product) {
		this.product = product;
		return this;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public FXOEventBlockingDateDTO setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public static FXOEventBlockingDateDTO getInstance() {
		return new FXOEventBlockingDateDTO();
	}

}
