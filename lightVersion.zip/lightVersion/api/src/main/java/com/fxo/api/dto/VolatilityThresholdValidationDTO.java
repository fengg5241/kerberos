package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class VolatilityThresholdValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal volatility;

	public BigDecimal getVolatility() {
		return volatility;
	}

	public VolatilityThresholdValidationDTO setVolatility(BigDecimal volatility) {
		this.volatility = volatility;
		return this;
	}

	public static VolatilityThresholdValidationDTO instance(
			BigDecimal volatility) {
		return new VolatilityThresholdValidationDTO().setVolatility(volatility);
	}

}
