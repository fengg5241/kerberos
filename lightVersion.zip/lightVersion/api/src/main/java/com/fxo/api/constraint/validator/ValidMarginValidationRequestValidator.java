package com.fxo.api.constraint.validator;

import java.math.BigDecimal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

import com.fxo.api.constraint.ValidMarginValidationRequest;
import com.fxo.api.dto.MarginValidationDTO;
import com.fxo.constants.admin.FXOMessageCodes;

public class ValidMarginValidationRequestValidator implements
		ConstraintValidator<ValidMarginValidationRequest, MarginValidationDTO> {

	@Override
	public void initialize(
			ValidMarginValidationRequest validMarginValidationRequest) {

	}

	@Override
	public boolean isValid(MarginValidationDTO marginValidationDTO,
			ConstraintValidatorContext context) {
		boolean isValid = true;

		if (StringUtils.isEmpty(marginValidationDTO.getProduct())) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PRODUCT_REQUIRED).addNode("product")
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
			isValid = false;
		}

		if (StringUtils.isEmpty(marginValidationDTO.getOptionType())) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_OPTION_TYPE_REQUIRED)
					.addNode("optionType").addConstraintViolation()
					.disableDefaultConstraintViolation();
			isValid = false;
		}

		if (StringUtils.isEmpty(marginValidationDTO.getCurrency())) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CURRENCY_REQUIRED).addNode("currency")
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
			isValid = false;
		}

		if (StringUtils.isEmpty(marginValidationDTO.getCounterCurrency())) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_COUNTER_CURRENCY_REQUIRED)
					.addNode("counterCurrency").addConstraintViolation()
					.disableDefaultConstraintViolation();
			isValid = false;
		}

		if (StringUtils.isEmpty(marginValidationDTO.getPremiumCurrency())) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PREMIUM_CURRENCY_REQUIRED)
					.addNode("premiumCurrency").addConstraintViolation()
					.disableDefaultConstraintViolation();
			isValid = false;
		}

		if ((!StringUtils.isEmpty(marginValidationDTO.getPremiumCurrency()))
				&& (!StringUtils.isEmpty(marginValidationDTO.getCurrency()))
				&& (marginValidationDTO.getPremiumCurrency()
						.equals(marginValidationDTO.getCurrency()))) {
			if (marginValidationDTO.getAmount() == null
					|| BigDecimal.ZERO.compareTo(marginValidationDTO
							.getAmount()) >= 0) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_AMOUNT_REQUIRED).addNode("amount")
						.addConstraintViolation()
						.disableDefaultConstraintViolation();
				isValid = false;
			}
		}

		if ((!StringUtils.isEmpty(marginValidationDTO.getPremiumCurrency()))
				&& (!StringUtils.isEmpty(marginValidationDTO
						.getCounterCurrency()))
				&& (marginValidationDTO.getPremiumCurrency()
						.equals(marginValidationDTO.getCounterCurrency()))) {
			if (marginValidationDTO.getCounterAmount() == null
					|| BigDecimal.ZERO.compareTo(marginValidationDTO
							.getCounterAmount()) >= 0) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_COUNTER_AMOUNT_REQUIRED)
						.addNode("counterAmount").addConstraintViolation()
						.disableDefaultConstraintViolation();
				isValid = false;
			}
		}

		return isValid;
	}
}
