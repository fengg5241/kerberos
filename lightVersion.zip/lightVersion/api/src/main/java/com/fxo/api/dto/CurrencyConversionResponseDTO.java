package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CurrencyConversionResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String fromCurrency;
	private String toCurrency;
	private BigDecimal amount;
	private BigDecimal convertedAmount;
	private String direction;
	private String strategy;
	private String maturity;
	private DateTime expiryDate;
	private String cutOff;
	private String spot;
	private BigDecimal spotRate;
	private String spotRateCalculationParameter;
	private String sign;

	public String getSign() {
		return sign;
	}

	public CurrencyConversionResponseDTO setSign(String sign) {
		this.sign = sign;
		return this;
	}

	public String getFromCurrency() {
		return fromCurrency;
	}

	public CurrencyConversionResponseDTO setFromCurrency(String fromCurrency) {
		this.fromCurrency = fromCurrency;
		return this;
	}

	public String getToCurrency() {
		return toCurrency;
	}

	public CurrencyConversionResponseDTO setToCurrency(String toCurrency) {
		this.toCurrency = toCurrency;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public CurrencyConversionResponseDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public CurrencyConversionResponseDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public CurrencyConversionResponseDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public CurrencyConversionResponseDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public CurrencyConversionResponseDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public String getCutOff() {
		return cutOff;
	}

	public CurrencyConversionResponseDTO setCutOff(String cutOff) {
		this.cutOff = cutOff;
		return this;
	}

	public String getSpot() {
		return spot;
	}

	public CurrencyConversionResponseDTO setSpot(String spot) {
		this.spot = spot;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public CurrencyConversionResponseDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public String getSpotRateCalculationParameter() {
		return spotRateCalculationParameter;
	}

	public CurrencyConversionResponseDTO setSpotRateCalculationParameter(
			String spotRateCalculationParameter) {
		this.spotRateCalculationParameter = spotRateCalculationParameter;
		return this;
	}

	public BigDecimal getConvertedAmount() {
		return convertedAmount;
	}

	public CurrencyConversionResponseDTO setConvertedAmount(
			BigDecimal convertedAmount) {
		this.convertedAmount = convertedAmount;
		return this;
	}

	public static CurrencyConversionResponseDTO instance() {
		return new CurrencyConversionResponseDTO();
	}
}
