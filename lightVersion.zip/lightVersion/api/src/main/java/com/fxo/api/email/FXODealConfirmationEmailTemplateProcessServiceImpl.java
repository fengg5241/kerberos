package com.fxo.api.email;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.velocity.app.event.implement.IncludeRelativePath;
import org.apache.velocity.exception.VelocityException;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.tools.generic.DateTool;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.LocalDate;
import org.joda.time.format.DateTimeFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineFactoryBean;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOCollectionUtility;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

/**
 * The Class FXODealConfirmationEmailTemplateProcessServiceImpl.
 */
@Service
public class FXODealConfirmationEmailTemplateProcessServiceImpl implements
		IFXODealConfirmationEmailTemplateProcessService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXODealConfirmationEmailTemplateProcessServiceImpl.class);

	/** The velocity engine factory bean. */
	@Autowired(required = true)
	@Qualifier(value = "velocityEngineFactoryBean")
	private VelocityEngineFactoryBean velocityEngineFactoryBean;

	/** The velocity template root. */
	@Value("${email.velocity.templateRoot}")
	private String velocityTemplateRoot;

	@PostConstruct
	public void init() {
		if (velocityEngineFactoryBean != null) {
			velocityEngineFactoryBean
					.setResourceLoaderPath(velocityTemplateRoot);
			velocityEngineFactoryBean.setPreferFileSystemAccess(false);

			Properties props = new Properties();
			props.put("class.resource.loader.class",
					"org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
			props.setProperty(RuntimeConstants.EVENTHANDLER_INCLUDE,
					IncludeRelativePath.class.getName());

			velocityEngineFactoryBean.setVelocityProperties(props);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fxo.api.email.IFXODealConfirmationEmailTemplateProcessService#
	 * processTemplate(java.lang.String, com.fxo.api.dto.TicketingResponseDTO)
	 */
	@Override
	public String processEmailBodyTemplate(String templatePath,
			TicketingResponseDTO ticketingResponseDTO, String emailType,Map<String, Object> contextParams ) {

		Map<String, Object> context = new HashMap<String, Object>();
		context.put("fxoDealTicket", ticketingResponseDTO);
		context.put("dateTool", new DateTool());
		context.put("DateTimeFormat", DateTimeFormat.class);
		context.put("DateTimeZone", DateTimeZone.class);
		context.put("DateTime", DateTime.class);
		context.put("LocalDate", LocalDate.class);
		context.put("LegStrategies", LegStrategies.class);
		context.put("amountFormat", new DecimalFormat("###,###,###.00"));
		context.put("MathUtil", MathUtil.class);
		context.put("RoundingMode", RoundingMode.HALF_UP);
		context.put("FXOStringUtility", FXOStringUtility.class);
		context.put("FXOBooleanUtility", FXOBooleanUtility.class);
		context.put("BigDecimal", BigDecimal.class);
		context.put("ExternalCustomerType",
				CustomerType.EXTERNAL.getCustomerTypeValue());
		context.put("InternalCustomerType",
				CustomerType.INTERNAL.getCustomerTypeValue());
		context.put("emailType", emailType);
		
		if(contextParams!=null)
			context.putAll(contextParams);

		ProductStructureDTO productStructure = ticketingResponseDTO
				.getStructure();

		Integer ratePrecision = (FXODealingUtil
				.isMultiLegStructure(productStructure)) ? FXODealingUtil
				.extractSummary(productStructure).getRatePrecision()
				: FXODealingUtil.extractOptionLegForSingleLegStrucutures(
						productStructure).getRatePrecision();

		context.put("precision", ratePrecision);

		String content = null;
		Boolean velocityProcessError = false;
		try {
			content = buildAndProcessVelocityTemplate(context, templatePath);
		} catch (Exception velocityException) {
			logger.error(String.format(
					"Error while generating EmailBody from template: %s",
					velocityException.getMessage()));
			velocityProcessError = true;
		}

		if (velocityProcessError) {
			throw new ApplicationRuntimeException("", FXOMessageCodes.ERR_EMAIL);
		}
		return content;
	}

	@Override
	public String processEmailSubjectTemplate(String templatePath,
			TicketingResponseDTO ticketingResponseDTO) {

		Map<String, Object> context = new HashMap<String, Object>();
		context.put("fxoDealTicket", ticketingResponseDTO);

		String content = null;
		Boolean velocityProcessError = false;
		try {
			content = buildAndProcessVelocityTemplate(context, templatePath);
		} catch (Exception velocityException) {
			logger.error(String.format(
					"Error while generating EmailSubject from template: %s",
					velocityException.getMessage()));
			velocityProcessError = true;
		}

		if (velocityProcessError) {
			throw new ApplicationRuntimeException("", FXOMessageCodes.ERR_EMAIL);
		}
		return content;
	}

	/**
	 * Builds the and process velocity template.
	 *
	 * @param context
	 * @param templatePath
	 * @return email body String
	 * @throws IOException
	 */
	public String buildAndProcessVelocityTemplate(Map<String, Object> context,
			String templatePath) throws VelocityException, IOException {
		String content = VelocityEngineUtils.mergeTemplateIntoString(
				velocityEngineFactoryBean.createVelocityEngine(), templatePath,
				"UTF-8", context);
		return content;
	}
}
