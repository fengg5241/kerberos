package com.fxo.api.fenics.service;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Products;
import com.fxo.fenics.request.NodeType;

@Component(value = "reverseKnockInFenicsPricingRequestMapperService")
public class ReverseKnockInFenicsPricingRequestMapperServiceImpl extends
		AbstractFenicsSingleLegPricingRequestMapperService {

	public static final String productCode = Products.PRODUCT_REVERSE_KNOCKIN;
	public static final String modelCode = FXOWSConstantKeys.fenicsExoticOptionModel;

	@Override
	public void setCustomFieldsInFenicsLeg(String dealingConvention,
			OptionLegDTO optionLegDTO, NodeType fenicsLegNode) {

		getFenicsXMLFieldGenerator().generateTriggerField(fenicsLegNode,
				optionLegDTO.getTrigger(), fenicsRequestPurpose,
				dealingConvention);

		optionLegDTO.setModel(getFxoConstantsService().getFXOConstantsValue(
				modelCode));

		getFenicsXMLFieldGenerator().generateModelField(fenicsLegNode,
				optionLegDTO.getModel(), fenicsRequestPurpose,
				dealingConvention);
	}
}
