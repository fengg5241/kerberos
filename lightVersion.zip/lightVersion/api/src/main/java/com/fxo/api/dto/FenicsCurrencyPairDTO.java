package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class FenicsCurrencyPairDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private String currency;

	private String counterCurrency;

	public String getCurrency() {
		return currency;
	}

	public FenicsCurrencyPairDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FenicsCurrencyPairDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

}
