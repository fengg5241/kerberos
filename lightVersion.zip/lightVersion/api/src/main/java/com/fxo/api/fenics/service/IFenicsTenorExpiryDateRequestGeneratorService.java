package com.fxo.api.fenics.service;

import com.fxo.api.dto.FXOTenorExpiryDatesDTO;
import com.fxo.exception.ApplicationException;

public interface IFenicsTenorExpiryDateRequestGeneratorService {
	public static final String REQUEST_PREFIX = "ED_";

	public String getFenicsPricingXML(
			FXOTenorExpiryDatesDTO fXOTenorExpiryDatesDTO)
			throws ApplicationException;

}
