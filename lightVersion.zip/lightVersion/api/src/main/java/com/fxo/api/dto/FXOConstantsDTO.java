package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;


@AutoProperty
public class FXOConstantsDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String key;

	private String value;

	public String getKey() {
		return key;
	}

	public FXOConstantsDTO setKey(String key) {
		this.key = key;
		return this;
	}

	public String getValue() {
		return value;
	}

	public FXOConstantsDTO setValue(String value) {
		this.value = value;
		return this;
	}
}
