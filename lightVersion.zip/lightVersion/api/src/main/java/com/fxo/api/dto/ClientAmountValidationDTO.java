package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.constants.admin.DealValidationCodes;

@AutoProperty
public class ClientAmountValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)
	private BigDecimal marginAmount;
	private BigDecimal internalCost;

	public BigDecimal getMarginAmount() {
		return marginAmount;
	}

	public ClientAmountValidationDTO setMarginAmount(BigDecimal marginAmount) {
		this.marginAmount = marginAmount;
		return this;
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public ClientAmountValidationDTO setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
		return this;
	}

	public static ClientAmountValidationDTO instance() {
		return (ClientAmountValidationDTO) new ClientAmountValidationDTO()
				.setValidationCode(DealValidationCodes.DEAL_GOVERNANCE_CLIENT_AMOUNT_VALIDATION);
	}

}
