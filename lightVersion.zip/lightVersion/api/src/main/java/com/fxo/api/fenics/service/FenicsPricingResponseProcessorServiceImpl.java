package com.fxo.api.fenics.service;

import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.api.fenics.factory.FenicsPricingResponseMapperServiceFactory;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.response.GfiMessageType;
import com.fxo.fenics.response.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsDealingUtil;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

/**
 * Process FENICS PricingResponse-XML.
 * 
 * <ol>
 * <li>Identify FenicsResponseType</li>
 * <ul>
 * <li>If Success</li>
 * <ul>
 * <li>then translate GFIResponse To PricingResponseDTO</li>
 * </ul>
 * <li>If Error</li>
 * <ul>
 * <li>then trigger Error flow</li>
 * </ul>
 * <li>If Warning</li>
 * <ul>
 * <li>then log warnings, and then translateGFIResponse To PricingResponseDTO</li>
 * </ul>
 * </ul>
 * 
 * </ol>
 */
@Service
public class FenicsPricingResponseProcessorServiceImpl implements
		IFenicsPricingResponseProcessorService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(FenicsPricingResponseProcessorServiceImpl.class);

	public static final String fenicsSpecialCharactersPattern = "[^\\p{L}\\p{Z}]";

	private @Value("${fenicsErrorPattern}") String fenicsErrorPattern;

	/** The fenics xml processing service. */
	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private FenicsPricingResponseMapperServiceFactory fenicsPricingResponseMapperServiceFactory;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.fxo.api.fenics.service.IFenicsPricingResponseProcessorService#
	 * processFenicsPricingResponseXML(java.lang.String,
	 * com.fxo.api.dto.PricingRequestDTO)
	 */
	@Override
	public PricingResponseDTO processFenicsPricingResponseXML(
			String responseXML, PricingRequestDTO pricingRequestDTO) {

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;

		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);
		} catch (ApplicationException exception) {
			logger.info(exception.getMessage(), exception);
			throw new ApplicationRuntimeException(exception.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE + ","
							+ pricingRequestDTO.getPricingRequestId());
		}

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// declare PricingResponseDTO
		PricingResponseDTO pricingResponseDTO = null;

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_SUCCESS:

			logger.info(String.format(
					"Response is identified as Success for PricingRequest: %s",
					pricingRequestDTO.getPricingRequestId()));

			pricingResponseDTO = translateGFIResponseToPricingResponseDTO(
					pricingRequestDTO, responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:

			logger.info(String.format(
					"Response is identified as Error for PricingRequest: %s",
					pricingRequestDTO.getPricingRequestId()));

			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:

			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info("warning messages from fenics: " + warningMessages);

			// match WarningNodes with ErrorPatterns
			if (checkForErrorInWarningNode(responseMessageObject)) {

				logger.info(String
						.format("Response is identified as Warning, but potential match for Error for PricingRequest: %s",
								pricingRequestDTO.getPricingRequestId()));

				FenicsResponseNodeProcessor
						.processFenicsErrorNode(responseMessageObject);
			} else {

				pricingResponseDTO = translateGFIResponseToPricingResponseDTO(
						pricingRequestDTO, responseMessageObject);
			}

			break;

		default:
			break;
		}

		return pricingResponseDTO.setUser(pricingRequestDTO.getUser())
				.setCustomer(pricingRequestDTO.getCustomer())
				.setRequestPurpose(pricingRequestDTO.getRequestPurpose());
	}

	public boolean checkForErrorInWarningNode(
			GfiMessageType responseMessageObject) {

		// Start with a hypothesis that productStructure contain valid-Values
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnEmptyPredicateResultSet();

		for (OptionType responseOption : FenicsDealingUtil
				.getResponseOptionTypes(responseMessageObject)) {

			predicateResultSet
					.add(FXOStringUtility.matchesPattern(FXOStringUtility
							.filterSpecialCharacters(
									responseOption.getOptionValue(),
									fenicsSpecialCharactersPattern),
							fenicsErrorPattern));
		}

		return FXOBooleanUtility.hasTrue(predicateResultSet);
	}

	/**
	 * Translate GFIResponse to PricingResponseDTO.
	 * 
	 *
	 * @param pricingRequestDTO
	 *            [{@link PricingRequestDTO}]
	 * @param responseMessageObject
	 *            [{@link com.fxo.fenics.response.GfiMessageType}]
	 * @return pricingResponseDTO [{@link PricingResponseDTO}]
	 */
	public PricingResponseDTO translateGFIResponseToPricingResponseDTO(
			PricingRequestDTO pricingRequestDTO,
			com.fxo.fenics.response.GfiMessageType responseMessageObject) {

		IFenicsPricingResponseMapperService fenicsPricingResponseMapperService = fenicsPricingResponseMapperServiceFactory
				.getFenicsPricingResponseMapperService(pricingRequestDTO
						.getStructure().getProduct());

		Objects.requireNonNull(fenicsPricingResponseMapperService,
				FenicsMessageCodes.ERR_FENICS_MAPPING);

		PricingResponseDTO pricingResponseDTO = fenicsPricingResponseMapperService
				.parseFenicsPricingResponseData(responseMessageObject,
						pricingRequestDTO);

		Objects.requireNonNull(pricingResponseDTO,
				FXOMessageCodes.ERR_PRICING_RESPONSE_INVALID);

		// set PricingrequestIdentifier in pricingresponseDTO
		return pricingResponseDTO.setPricingRequestId(
				pricingRequestDTO.getPricingRequestId()).setUser(
				pricingRequestDTO.getUser());
	}
}