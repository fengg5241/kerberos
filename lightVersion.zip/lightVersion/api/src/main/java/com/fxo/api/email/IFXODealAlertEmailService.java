package com.fxo.api.email;

import java.util.List;

import com.fxo.api.dto.TicketingResponseDTO;

/**
 * The Interface IFXODealConfirmationEmailService.
 */
public interface IFXODealAlertEmailService {

	/**
	 * Send deal alert email to RM.<br>
	 * <br>
	 * 
	 * Step-1: retrieve TicketingResponseDTO (via TicketSearchService) <br>
	 * 
	 * Step-2: Identify Template for by productCode 'dealTicket_<%productCode%>.vm' <br>
	 * 
	 * Step-3: Get DealConfirmation Email Body via
	 * IFXODealConfirmationEmailService (input: templateName,
	 * TicketingResponseDTO)<br>
	 * 
	 * Step-4: Generate EmailIDs via DealerID [Dealer Email ID], RMName [RM
	 * Email ID]<br>
	 * 
	 * Step-5: Send Email (to Dealer & RM) via IFXOEmailService (Input:
	 * FXOEmailMessageDTO)<br>
	 *
	 * @param ticketingResponseDTO
	 *            [{@link TicketingResponseDTO}]
	 */
	public void sendDealAlert(String ticketNumber, List<String> alertLegs);
}
