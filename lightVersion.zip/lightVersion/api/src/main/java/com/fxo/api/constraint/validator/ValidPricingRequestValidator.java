package com.fxo.api.constraint.validator;

import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.constraint.ValidPricingRequest;
import com.fxo.api.dto.CustomerDTO;
import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.FXOUserInterPortfolioMappingDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.UserCustomerMappingDTO;
import com.fxo.api.factory.FXOPricingRequestValidationServiceFactory;
import com.fxo.api.service.FXOPricingForDeltaHedgeServiceImpl;
import com.fxo.api.service.IDeltaHedgeValidationService;
import com.fxo.api.service.IFXOUserInterPortfolioMappingService;
import com.fxo.api.service.IPricingRequestValidatorService;
import com.fxo.api.service.IUserCustomerMappingService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.framework.core.dto.FXOMessageDetailDTO;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

public class ValidPricingRequestValidator implements
		ConstraintValidator<ValidPricingRequest, PricingRequestDTO> {

	@Autowired
	private FXOPricingRequestValidationServiceFactory fxoPricingRequestValidationServiceFactory;

	@Autowired
	private IUserCustomerMappingService userCustomerMappingService;

	@Autowired
	private IFXOUserInterPortfolioMappingService fxoUserInterPortfolioMappingService;
	
	@Autowired
	private IDeltaHedgeValidationService deltaHedgeValidationService;

	
	private static final Logger logger = LoggerFactory.getLogger(FXOPricingForDeltaHedgeServiceImpl.class);

	@Override
	public void initialize(ValidPricingRequest pricingRequest) {

	}

	@Override
	public boolean isValid(PricingRequestDTO pricingRequest,
			ConstraintValidatorContext context) {

		// Start with a hypothesis that pricingRequest contain valid-Values
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		boolean isValidCustomerObject = isAValidPortfolioOrCustomer(
				pricingRequest.getCustomer(), pricingRequest.getUser(), context);

		predicateResultSet.add(isValidCustomerObject);

		// verify for Non-Null ProductStructure Object
		Boolean isProductStructureNotNull = (pricingRequest.getStructure() != null);

		predicateResultSet.add(isProductStructureNotNull);

		if (FXOBooleanUtility.isFalse(isProductStructureNotNull)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PRODUCT_STRUCTURE_INVALID)
					.addNode("structure").addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		// verify for a valid ProductStructure content
		else {
			String product = pricingRequest.getStructure().getProduct();

			IPricingRequestValidatorService pricingRequestValidatorService = fxoPricingRequestValidationServiceFactory
					.getPricingRequestValidationService(product);

			boolean isValidProductStructure = pricingRequestValidatorService
					.validateProduct(pricingRequest.getStructure(), context);

			predicateResultSet.add(isValidProductStructure);
		}
		
		if(pricingRequest.getIsDeltaHedge())
		{
			FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
					.extractKeyProductDetails(pricingRequest.getStructure());

			FXOMessageDetailDTO fxoMessageDetailDTO = deltaHedgeValidationService.validate(fxoProductStructureExtractDTO, pricingRequest.getCurrentMarketRateResponse());

				if(FXOBooleanUtility.isFalse(fxoMessageDetailDTO.isValid())){
					predicateResultSet.add(false);
					
					String messageTemplate = FXOStringUtility.joinStrings(fxoMessageDetailDTO.getPlaceholderValues(), FXOStringUtility.COMMA_SEPARATOR);
					
					context.buildConstraintViolationWithTemplate(
							FXOMessageCodes.ERR_DeltaHedgeValidation+FXOStringUtility.COMMA_SEPARATOR+messageTemplate)
							.addNode("structure").addConstraintViolation()
							.disableDefaultConstraintViolation();
				}
			
			
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAValidPortfolioOrCustomer(CustomerDTO customerDTO,
			UserDTO userDTO, ConstraintValidatorContext context) {

		// Start with a hypothesis - Valid Portfolio & Customer
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// verify for non-Null Customer Object
		Boolean hasNonNullCustomer = customerDTO != null;

		predicateResultSet.add(hasNonNullCustomer);

		if (FXOBooleanUtility.isFalse(hasNonNullCustomer)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CUSTOMER_REQUIRED).addNode("customer")
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		else {

			String customerTypeStringValue = customerDTO.getCustomerType();

			// check for a valid CustomerType
			Boolean hasAValidCustomerType = CustomerType
					.isValidValue(customerTypeStringValue);

			predicateResultSet.add(hasAValidCustomerType);

			if (FXOBooleanUtility.isFalse(hasAValidCustomerType)) {

				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_CUSTOMERTYPE_INVALID)
						.addNode("customer").addConstraintViolation()
						.disableDefaultConstraintViolation();
			}

			// If CustomerType is Valid, Proceed to validate Customer Or
			// InterPortfolio
			else {

				if (CustomerType.isExternal(customerTypeStringValue)
						&& FXOStringUtility.isNotEmpty(customerDTO
								.getCustomerId())) {

					Boolean isAValidCustomer = isAValidExternalCustomer(customerDTO,
							context);

					predicateResultSet.add(isAValidCustomer);

				} else if (CustomerType.isInternal(customerTypeStringValue)
						&& FXOStringUtility.isNotEmpty(customerDTO
								.getInterPortfolio())) {

					Boolean isAValidPortfolio = isAValidInternalCustomer(userDTO,
							customerDTO.getInterPortfolio(), context);

					predicateResultSet.add(isAValidPortfolio);
				}
			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public Boolean isAValidExternalCustomer(CustomerDTO customerDTO,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - Valid Customer
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// verify customerType & customerId

		Boolean isCustomerTypeValid = CustomerType.isValidValue(customerDTO
				.getCustomerType());

		predicateResultSet.add(isCustomerTypeValid);

		// check for a valid CustomerType
		if (FXOBooleanUtility.isFalse(isCustomerTypeValid)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CUSTOMERTYPE_INVALID)
					.addNode("customer.customerType").addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		Boolean hasNonNullCustomerId = FXOStringUtility.isNotEmpty(customerDTO
				.getCustomerId());

		predicateResultSet.add(hasNonNullCustomerId);

		// If customerId is Null Value
		if (FXOBooleanUtility.isFalse(hasNonNullCustomerId)) {

			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CUSTOMER_NUMBER_REQUIRED)
					.addNode("customer.customerId").addConstraintViolation()
					.disableDefaultConstraintViolation();

		}

		// If customerId has nonNull Value, validate customerId against
		// UserCustomerMapping Entity
		else {

			UserCustomerMappingDTO userCustomerMappingDTO = userCustomerMappingService
					.getOneCustomerByCustomerId(customerDTO.getCustomerId());

			Boolean hasValidCustomer = userCustomerMappingDTO != null;

			predicateResultSet.add(hasValidCustomer);

			if (FXOBooleanUtility.isFalse(hasValidCustomer)) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_CUSTOMER_INVALID)
						.addNode("customer.customerId")
						.addConstraintViolation()
						.disableDefaultConstraintViolation();
			}

		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public Boolean isAValidInternalCustomer(UserDTO userDTO, String interPortfolio,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - valid Portfolio
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// emptyString check and userPortfolioMapping check

		Boolean isANonNullPortfolio = FXOStringUtility
				.isNotEmpty(interPortfolio);

		predicateResultSet.add(isANonNullPortfolio);

		if (FXOBooleanUtility.isFalse(isANonNullPortfolio)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PORTFOLIO_REQUIRED)
					.addNode("portfolio").addConstraintViolation()
					.disableDefaultConstraintViolation();
		} else {

			FXOUserInterPortfolioMappingDTO fxoUserInterPortfolioMappingDTO = fxoUserInterPortfolioMappingService
					.getOneFXOUserInterPortfolioMappingByUserIdAndPortfolio(
							userDTO.getUserId(), interPortfolio);

			Boolean isAValidPortfolio = (fxoUserInterPortfolioMappingDTO != null);

			predicateResultSet.add(isAValidPortfolio);

			if (FXOBooleanUtility.isFalse(isAValidPortfolio)) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_PORTFOLIO_INVALID)
						.addNode("portfolio").addConstraintViolation()
						.disableDefaultConstraintViolation();
			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}
	
}
