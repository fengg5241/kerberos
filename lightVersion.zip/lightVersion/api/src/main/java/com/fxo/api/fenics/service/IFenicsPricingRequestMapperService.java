package com.fxo.api.fenics.service;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.constants.fenics.FenicsRequestPurpose;

public interface IFenicsPricingRequestMapperService {


	public static final String fenicsRequestPurpose = FenicsRequestPurpose.PRICING;

	
	public com.fxo.fenics.request.DataType getFENICSPricingRequestData(
			PricingRequestDTO pricingRequestDTO);

}
