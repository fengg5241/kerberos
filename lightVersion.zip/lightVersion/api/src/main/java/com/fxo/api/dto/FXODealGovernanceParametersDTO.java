package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXODealGovernanceParametersDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String validationCode;

	private FXOProductCatalogueDTO fxoProductCatalogue;

	private String direction;

	private Integer legCount;

	private String minimum;

	private BigDecimal minimumPercent;

	private String maximum;

	private BigDecimal maximumPercent;

	private String thresholdCurrency;

	private String active;

	private String validateInDealGovernanceService;
	
	private String alert;
	
	private String validateInTicketingService;

	public String getValidationCode() {
		return validationCode;
	}

	public FXODealGovernanceParametersDTO setValidationCode(
			String validationCode) {
		this.validationCode = validationCode;
		return this;
	}

	public FXOProductCatalogueDTO getFxoProductCatalogue() {
		return fxoProductCatalogue;
	}

	public FXODealGovernanceParametersDTO setFxoProductCatalogue(
			FXOProductCatalogueDTO fxoProductCatalogue) {
		this.fxoProductCatalogue = fxoProductCatalogue;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FXODealGovernanceParametersDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FXODealGovernanceParametersDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public FXODealGovernanceParametersDTO setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public BigDecimal getMinimumPercent() {
		return minimumPercent;
	}

	public FXODealGovernanceParametersDTO setMinimumPercent(
			BigDecimal minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public FXODealGovernanceParametersDTO setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public FXODealGovernanceParametersDTO setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public FXODealGovernanceParametersDTO setThresholdCurrency(
			String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXODealGovernanceParametersDTO setActive(String active) {
		this.active = active;
		return this;
	}

	public String getValidateInDealGovernanceService() {
		return validateInDealGovernanceService;
	}

	public FXODealGovernanceParametersDTO setValidateInDealGovernanceService(
			String validateInDealGovernanceService) {
		this.validateInDealGovernanceService = validateInDealGovernanceService;
		return this;
	}
	
	public String getAlert() {
		return alert;
	}

	public FXODealGovernanceParametersDTO setAlert(String alert) {
		this.alert = alert;
		return this;
	}
	
	public String getValidateInTicketingService() {
		return validateInTicketingService;
	}

	public FXODealGovernanceParametersDTO setValidateInTicketingService(
			String validateInTicketingService) {
		this.validateInTicketingService = validateInTicketingService;
		return this;
	}

}
