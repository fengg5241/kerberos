package com.fxo.api.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.service.IFXOTicketingBlotterService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FXOTicketingBlotterServiceFactoryImpl implements
		FXOTicketingBlotterServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FXOTicketingBlotterServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaTicketingBlotterService")
	private IFXOTicketingBlotterService vanillaTicketingBlotterService;

	@Autowired
	@Qualifier(value = "straddleTicketingBlotterService")
	private IFXOTicketingBlotterService straddleTicketingBlotterService;

	@Autowired
	@Qualifier(value = "strangleTicketingBlotterService")
	private IFXOTicketingBlotterService strangleTicketingBlotterService;

	@Autowired
	@Qualifier(value = "riskReversalTicketingBlotterService")
	private IFXOTicketingBlotterService riskReversalTicketingBlotterService;

	@Autowired
	@Qualifier(value = "spreadTicketingBlotterService")
	private IFXOTicketingBlotterService spreadTicketingBlotterService;

	@Autowired
	@Qualifier(value = "knockInTicketingBlotterService")
	private IFXOTicketingBlotterService knockInTicketingBlotterService;

	@Autowired
	@Qualifier(value = "knockOutTicketingBlotterService")
	private IFXOTicketingBlotterService knockOutTicketingBlotterService;

	@Autowired
	@Qualifier(value = "reverseKnockInTicketingBlotterService")
	private IFXOTicketingBlotterService reverseKnockInTicketingBlotterService;

	@Autowired
	@Qualifier(value = "reverseKnockOutTicketingBlotterService")
	private IFXOTicketingBlotterService reverseKnockOutTicketingBlotterService;

	@Autowired
	@Qualifier(value = "europeanKnockInTicketingBlotterService")
	private IFXOTicketingBlotterService europeanKnockInTicketingBlotterService;

	@Autowired
	@Qualifier(value = "europeanKnockOutTicketingBlotterService")
	private IFXOTicketingBlotterService europeanKnockOutTicketingBlotterService;

	@Override
	public IFXOTicketingBlotterService getFXOTicketingBlotterService(
			String product) {

		IFXOTicketingBlotterService fxoTicketingBlotterService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			fxoTicketingBlotterService = vanillaTicketingBlotterService;
			break;

		case Products.PRODUCT_STRADDLE:
			fxoTicketingBlotterService = straddleTicketingBlotterService;
			break;

		case Products.PRODUCT_STRANGLE:
			fxoTicketingBlotterService = strangleTicketingBlotterService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			fxoTicketingBlotterService = riskReversalTicketingBlotterService;
			break;

		case Products.PRODUCT_SPREAD:
			fxoTicketingBlotterService = spreadTicketingBlotterService;
			break;

		case Products.PRODUCT_KNOCKIN:
			fxoTicketingBlotterService = knockInTicketingBlotterService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			fxoTicketingBlotterService = knockOutTicketingBlotterService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			fxoTicketingBlotterService = reverseKnockInTicketingBlotterService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			fxoTicketingBlotterService = reverseKnockOutTicketingBlotterService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			fxoTicketingBlotterService = europeanKnockInTicketingBlotterService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			fxoTicketingBlotterService = europeanKnockOutTicketingBlotterService;
			break;

		default:
			logger.error("failed to locate fxoTicketingBlotterService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return fxoTicketingBlotterService;
	}

}