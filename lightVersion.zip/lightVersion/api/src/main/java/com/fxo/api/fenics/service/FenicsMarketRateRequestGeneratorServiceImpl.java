package com.fxo.api.fenics.service;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.MarketRateDTO;
import com.fxo.api.dto.MarketRateRequestDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.Directions;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.dealing.OptionTypes;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.ActionType;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;

@Component
public class FenicsMarketRateRequestGeneratorServiceImpl implements
		IFenicsMarketRateRequestGeneratorService {

	private static final Logger fenicsLogger = LoggerFactory
			.getLogger(FenicsConstants.FENICS_LOGGER);

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsMarketRateRequestGeneratorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private FenicsRequestNodeService fenicsRequestNodeService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Override
	public String generateFenicsMarketRateQueryRequestXML(
			MarketRateRequestDTO marketRateRequestDTO)
			throws ApplicationException {

		if (FXOStringUtility.isEmpty(marketRateRequestDTO
				.getMarketRateCalculationParameter())) {
			marketRateRequestDTO
					.setMarketRateCalculationParameter(FenicsCalculationParameters.SIDED);
		}

		BodyType requestBody = populateRequestBody(marketRateRequestDTO);

		marketRateRequestDTO.setMarketRateRequestId(FXOStringUtility
				.generateUniqueId(REQUEST_PREFIX));

		String fenicsMarketRateQueryRequestXMLString = fenicsXMLProcessingService
				.compositeXML(requestBody,
						marketRateRequestDTO.getMarketRateRequestId(), null);

		fenicsLogger.info(String.format(
				"Fenics-MarketRateQueryRequest [ %s ] XML built: %s",
				marketRateRequestDTO.getMarketRateRequestId(),
				fenicsMarketRateQueryRequestXMLString));

		return fenicsMarketRateQueryRequestXMLString;
	}

	public BodyType populateRequestBody(
			MarketRateRequestDTO marketRateRequestDTO) {

		DataType fenicsRequestDataType = DataType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeName))
				.setFormat(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeFormat));

		generateFenicsOptionLegs(fenicsRequestDataType, marketRateRequestDTO);

		BodyType fenicsRequestBodyType = BodyType.instance().setAction(
				populateRequestAction(marketRateRequestDTO
						.getMarketRateCalculationParameter()));

		fenicsRequestBodyType.getData().add(fenicsRequestDataType);

		return fenicsRequestBodyType;
	}

	public void generateFenicsOptionLegs(DataType data,
			MarketRateRequestDTO marketRateRequestDTO) {

		AtomicInteger marketRateCounter = new AtomicInteger(0);

		for (MarketRateDTO marketRateDTO : marketRateRequestDTO
				.getMarketRates()) {

			NodeType node = NodeType
					.instance()
					.setName(
							FXOStringUtility.joinStrings(
									fxoConstantsService
											.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName),
									String.valueOf(marketRateCounter
											.getAndIncrement()),
									FXOWSConstantKeys.SPACE_DELIMITER));

			data.getNode().add(node);

			fenicsXMLFieldGenerator.generateCurrencyField(node,
					marketRateDTO.getCurrency(), fenicsRequestPurpose,
					dealingConvention);

			fenicsXMLFieldGenerator.generateCounterCurrencyField(node,
					marketRateDTO.getCounterCurrency(), fenicsRequestPurpose,
					dealingConvention);

			fenicsXMLFieldGenerator.generateLegStrategyField(node,
					marketRateDTO.getStrategy(), fenicsRequestPurpose,
					dealingConvention);

			if (FXOStringUtility.isNotEmpty(marketRateDTO.getMaturity())
					&& FXOStringUtility.areNotIdentical(
							marketRateDTO.getMaturity(),
							Maturities.MATURITIES_ODD_DATE)) {

				fenicsXMLFieldGenerator.generateMaturityField(node,
						marketRateDTO.getMaturity(), fenicsRequestPurpose,
						dealingConvention);
			}

			fenicsXMLFieldGenerator.generateExpiryDateField(node,
					marketRateDTO.getExpiryDate(), fenicsRequestPurpose,
					dealingConvention);

			// get FenicsOptionType From OptionTypeCode
			FXOParametersMappingDTO fxoParametersMappingDTOOptionType = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
							OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG);

			fenicsXMLFieldGenerator
					.generateOptionClassField(node,
							fxoParametersMappingDTOOptionType
									.getParameterTargetValue(),
							fenicsRequestPurpose, dealingConvention);

			// translate direction from fenics value to FXO-Portal
			// representation
			String direction = FXOStringUtility.isNotEmpty(marketRateDTO
					.getDirection()) ? marketRateDTO.getDirection()
					: Directions.DIRECTION_BUY;

			FXOParametersMappingDTO fxoParametersMappingDTODirection = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							direction);

			fenicsXMLFieldGenerator.generateDirectionField(node,
					fxoParametersMappingDTODirection.getParameterTargetValue(),
					fenicsRequestPurpose, dealingConvention);

			fenicsXMLFieldGenerator.generateStrikeFieldForSpotRateAPI(node,
					fenicsRequestPurpose, dealingConvention);

			if (marketRateDTO.getSpotRate() != null) {

				fenicsXMLFieldGenerator.generateSpotField(node, marketRateDTO
						.getSpotRate().toEngineeringString(),
						fenicsRequestPurpose, dealingConvention);
			}

			if (marketRateDTO.getForwardRate() != null) {

				fenicsXMLFieldGenerator.generateForwardField(node,
						marketRateDTO.getForwardRate().toEngineeringString(),
						fenicsRequestPurpose, dealingConvention);
			}

			// Additional inputs for priceDiscovery
			if (FXOStringUtility.isNotEmpty(marketRateDTO.getVolatility())) {
				fenicsXMLFieldGenerator.generateVolatilityField(node,
						marketRateDTO.getVolatility(), fenicsRequestPurpose,
						dealingConvention);
			}

			fenicsXMLFieldGenerator
					.generateModelField(
							node,
							fxoConstantsService
									.getFXOConstantsValue(FXOWSConstantKeys.fenicsSimpleOptionModel),
							fenicsRequestPurpose, dealingConvention);
		}

	}

	public ActionType populateRequestAction(String calculationType) {

		ActionType action = ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrActionTypeFunc));

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeCalcName))
				.setOptionValue(calculationType);

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenVal));

		OptionType option3 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataRef));

		action.getOption().addAll(Arrays.asList(option1, option2, option3));

		return action;
	}

}
