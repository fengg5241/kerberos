package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXODealGovernanceValidationConfigDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String validationCode;

	private String product;

	private String currency;

	private String counterCurrency;

	private String direction;

	private Integer legCount;

	private String minimum;

	private BigDecimal minimumPercent;

	private String maximum;
	
	private String alert;

	private BigDecimal maximumPercent;

	private String thresholdCurrency;

	private String active;

	private String validateInDealGovernanceService;

	private boolean isCustomizedForCurrencyPair;

	public String getValidationCode() {
		return validationCode;
	}

	public FXODealGovernanceValidationConfigDTO setValidationCode(
			String validationCode) {
		this.validationCode = validationCode;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public FXODealGovernanceValidationConfigDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public FXODealGovernanceValidationConfigDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FXODealGovernanceValidationConfigDTO setCounterCurrency(
			String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FXODealGovernanceValidationConfigDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FXODealGovernanceValidationConfigDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public FXODealGovernanceValidationConfigDTO setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public BigDecimal getMinimumPercent() {
		return minimumPercent;
	}

	public FXODealGovernanceValidationConfigDTO setMinimumPercent(
			BigDecimal minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public FXODealGovernanceValidationConfigDTO setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public FXODealGovernanceValidationConfigDTO setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public FXODealGovernanceValidationConfigDTO setThresholdCurrency(
			String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXODealGovernanceValidationConfigDTO setActive(String active) {
		this.active = active;
		return this;
	}

	public String getValidateInDealGovernanceService() {
		return validateInDealGovernanceService;
	}

	public FXODealGovernanceValidationConfigDTO setValidateInDealGovernanceService(
			String validateInDealGovernanceService) {
		this.validateInDealGovernanceService = validateInDealGovernanceService;
		return this;
	}

	public boolean isCustomizedForCurrencyPair() {
		return isCustomizedForCurrencyPair;
	}

	public FXODealGovernanceValidationConfigDTO setCustomizedForCurrencyPair(
			boolean isCustomizedForCurrencyPair) {
		this.isCustomizedForCurrencyPair = isCustomizedForCurrencyPair;
		return this;
	}

	public String getAlert() {
		return alert;
	}

	public FXODealGovernanceValidationConfigDTO setAlert(String alert) {
		this.alert = alert;
		return this;
	}
	
	

}