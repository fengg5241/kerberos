package com.fxo.api.fenics.dto.converter;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.util.FXODateUtility;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;

@Component
public class FenicsCustomDateTimeConverter {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsCustomDateTimeConverter.class);

	public static final String expiryDateFormatDefault = "dd MMM yy";
	public static final String expiryDateTimeFormatDefault = "dd MMM yy HH:mm";
	public static final String deliveryDateFormatDefault = "dd MMM yy";
	public static final String valueDateFormatDefault = "dd MMM yy";
	public static final String spotDateFormatDefault = "dd MMM yy";
	public static final String horizonDateFormatDefault = "HH:mm EEE d MMM yy";
	public static final String premiumDateFormatDefault = "EEE d MMM yy";

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	public DateTime translateExpiryDateStringToDateTime(
			String expiryDateString, String expiryTimeString) {

		return translateDateStringToDateTime(expiryDateString,
				FXOWSConstantKeys.expiryDateFormat, expiryDateFormatDefault,
				expiryTimeString, FXOWSConstantKeys.expiryDateTimeFormat,
				expiryDateTimeFormatDefault);
	}

	public DateTime translateDeliveryDateStringToDateTime(
			String deliveryDateString) {

		return translateDateStringToDateTime(deliveryDateString,
				FXOWSConstantKeys.deliveryDateFormat, deliveryDateFormatDefault);

	}

	public DateTime translateValueDateStringToDateTime(String valueDateString) {

		return translateDateStringToDateTime(valueDateString,
				FXOWSConstantKeys.valueDateFormat, valueDateFormatDefault);
	}

	public DateTime translateSpotDateStringToDateTime(String spotDateString) {

		return translateDateStringToDateTime(spotDateString,
				FXOWSConstantKeys.spotDateFormat, spotDateFormatDefault);
	}

	public DateTime translateHorizonDateStringToDateTime(
			String horizonDateString) {

		return translateDateStringToDateTime(horizonDateString,
				FXOWSConstantKeys.horizonDateFormat, horizonDateFormatDefault);
	}

	public DateTime translatePremiumDateStringToDateTime(
			String premiumDateString) {
		return translateDateStringToDateTime(premiumDateString,
				FXOWSConstantKeys.premiumDateFormat, premiumDateFormatDefault);

	}

	public DateTime translateDateStringToDateTime(String dateString,
			String dateFormatKey, String dateFormatDefault, String timeString,
			String dateTimeFormatKey, String dateTimeFormatDefault) {

		DateTime dateTimeObject = null;

		try {
			if (FXOStringUtility.isNotEmpty(dateString)) {

				String dateFormatConfigured = getDateFormat(dateFormatKey);

				String dateFormatValue = FXOStringUtility
						.isNotEmpty(dateFormatConfigured) ? dateFormatConfigured
						: dateFormatDefault;

				String dateTimeFormatConfigured = getDateFormat(dateTimeFormatKey);

				String dateTimeFormatValue = FXOStringUtility
						.isNotEmpty(dateTimeFormatConfigured) ? dateTimeFormatConfigured
						: dateTimeFormatDefault;

				String dateTimeString = null;
				String dateTimeFormat = null;

				if (FXOStringUtility.isNotEmpty(timeString)) {

					dateTimeString = FXOStringUtility.joinStrings(dateString,
							timeString, FXOWSConstantKeys.SPACE_DELIMITER);

					dateTimeFormat = dateTimeFormatValue;
				} else {

					dateTimeString = dateString;
					dateTimeFormat = dateFormatValue;
				}

				logger.info(String
						.format("Attempting for Date Translation: DateString %s - TimeString %s to dateTimeFormat: %s Translation [Fenics Data to FXOPortal] ",
								dateString, timeString, dateTimeFormat));

				// parse expiryDateTimeString as Joda DateTime of format
				dateTimeObject = FXODateUtility.parseDateTimeString(
						dateTimeString, dateTimeFormat);

			}
		} catch (Exception excep) {
			String message = String
					.format("Date %s - Time %s Translation failed - %s [Fenics Data to FXOPortal] ",
							dateString, timeString, dateFormatKey);

			logger.info(message);

			throw new ApplicationRuntimeException(message,
					FXOStringUtility.joinStrings(
							FXOMessageCodes.ERR_DATE_TRANSLATION,
							"[Fenics Data to FXOPortal]",
							FXOWSConstantKeys.COMMA_DELIMITER));
		}

		return dateTimeObject;
	}

	public DateTime translateDateStringToDateTime(String dateString,
			String dateFormatKey, String dateFormatDefault) {

		DateTime dateTimeObject = null;

		try {
			if (FXOStringUtility.isNotEmpty(dateString)) {

				String dateFormatConfigured = getDateFormat(dateFormatKey);

				String dateFormatValue = FXOStringUtility
						.isNotEmpty(dateFormatConfigured) ? dateFormatConfigured
						: dateFormatDefault;

				logger.info(String
						.format("Attempting for DateString Translation: DateString %s to DateFormat: %s Translation [Fenics Data to FXOPortal] ",
								dateString, dateFormatValue));

				// parse Delivery Date as Joda DateTime of format
				dateTimeObject = FXODateUtility.parseDateTimeString(dateString,
						dateFormatValue);
			}
		} catch (Exception excep) {
			String message = String
					.format("Date Translation Failed : DateString %s Translation [Fenics Data to FXOPortal] ",
							dateString);

			logger.info(message);

			throw new ApplicationRuntimeException(message,
					FXOStringUtility.joinStrings(
							FXOMessageCodes.ERR_DATE_TRANSLATION,
							"[Fenics Data to FXOPortal]",
							FXOWSConstantKeys.COMMA_DELIMITER));
		}

		return dateTimeObject;
	}

	public String getDateFormat(String parameterType) {
		return fxoConstantsService.getFXOConstantsValue(parameterType);
	}

	public void translateFenicsDateStringToDateTime(FieldValueDTO fieldValueDTO) {

		DateTime expiryDateTime = translateExpiryDateStringToDateTime(
				fieldValueDTO.getExpiryDateString(),
				fieldValueDTO.getExpiryTimeString());
		fieldValueDTO.setExpiryDate(expiryDateTime);

		DateTime deliveryDateTime = translateDeliveryDateStringToDateTime(fieldValueDTO
				.getDeliveryDateString());
		fieldValueDTO.setDeliveryDate(deliveryDateTime);

		DateTime valueDateTime = translateValueDateStringToDateTime(fieldValueDTO
				.getValueDateString());
		fieldValueDTO.setValueDate(valueDateTime);

		DateTime spotDateTime = translateSpotDateStringToDateTime(fieldValueDTO
				.getSpotDateString());
		fieldValueDTO.setSpotDate(spotDateTime);

		DateTime horizonDate = translateHorizonDateStringToDateTime(fieldValueDTO
				.getHorizonDateString());
		fieldValueDTO.setHorizonDate(horizonDate);

		DateTime premiumDate = translatePremiumDateStringToDateTime(fieldValueDTO
				.getPremiumDateString());
		fieldValueDTO.setPremiumDate(premiumDate);

	}

}
