package com.fxo.api.email;

import java.math.BigInteger;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOProductCatalogueService;
import com.fxo.api.service.TicketSearchService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.DateTimeUtil;
import com.fxo.framework.util.FXOStringUtility;

public abstract class AbstractFXODealConfirmationEmailServiceImpl {

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractFXODealConfirmationEmailServiceImpl.class);

	@Value("${email.velocity.template.defaultLocalTimeZone}")
	private String defaultLocalTimeZone;

	@Value("${email.velocity.template.defaultTimeZone}")
	private String defaultTimeZone;

	@Autowired
	private TicketSearchService ticketSearchService;

	@Autowired
	private IFXOProductCatalogueService fxoProductCatalogueService;

	@Autowired
	private ICurrencyPairService currencyPairService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	public TicketingResponseDTO extractTicketDetails(BigInteger ticketNumber) {

		if (ticketNumber == null) {
			logger.error("ticketNumber is required - for extraction");
			throw new ApplicationRuntimeException(
					"ticketNumber is required - for extraction",
					FXOMessageCodes.ERR_TICKETING_NUMBER_REQUIRED);
		}

		TicketingResponseDTO ticketingResponseFenicsDetails = ticketSearchService
				.findByTicketNumber(ticketNumber);

		ProductStructureDTO productStructure = ticketingResponseFenicsDetails
				.getStructure();

		// get Precision

		FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
				.extractKeyProductDetails(productStructure);

		CurrencyPairDTO currencyPairDTO = currencyPairService
				.getOneCurrencyPair(
						fxoProductStructureExtractDTO.getCurrency(),
						fxoProductStructureExtractDTO.getCounterCurrency());

		Integer ratePrecision = currencyPairDTO.getRatePrecision();

		if (FXODealingUtil.isMultiLegStructure(productStructure)) {

			FXODealingUtil
					.extractSummary(productStructure)
					.setRatePrecision(ratePrecision)
					.setHasACommodity(currencyPairDTO.getHasACommodity())
					.setCutoff(
							fetchCutOffValue(FXOWSConstantKeys.fenicsCutoffDefault));
		}

		else {
			FXODealingUtil
					.extractOptionLegForSingleLegStrucutures(productStructure)
					.setRatePrecision(ratePrecision)
					.setHasACommodity(currencyPairDTO.getHasACommodity())
					.setCutoff(
							fetchCutOffValue(FXOWSConstantKeys.fenicsCutoffDefault));
		}

		// convert transactionTime to local time zone
		DateTime transactionTime = DateTimeUtil.convertTimeZone(
				ticketingResponseFenicsDetails.getTransactionTime(),
				defaultTimeZone, defaultLocalTimeZone);

		ticketingResponseFenicsDetails.setTransactionTime(transactionTime);

		return ticketingResponseFenicsDetails;
	}

	private String fetchCutOffValue(String key) {

		FXOStringUtility.requireNonNull(key, "Key should be not null", "");

		return fxoConstantsService.getFXOConstantsValue(key);
	}

}