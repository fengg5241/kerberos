package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class OptionLegDTO extends FieldValueDTO {

	private static final long serialVersionUID = 1L;

	private String optionStyle;

	private Integer optionIndex;

	public OptionLegDTO(FieldValueDTO legData) {
		super();
	}

	public OptionLegDTO() {
		super();
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public OptionLegDTO setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
		return this;
	}

	public Integer getOptionIndex() {
		return optionIndex;
	}

	public OptionLegDTO setOptionIndex(Integer optionIndex) {
		this.optionIndex = optionIndex;
		return this;
	}
	public static OptionLegDTO instance() {
		return new OptionLegDTO();
	}
}
