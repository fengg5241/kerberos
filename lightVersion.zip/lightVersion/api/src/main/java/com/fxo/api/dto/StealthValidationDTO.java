package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class StealthValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal stealth;

	public BigDecimal getStealth() {
		return stealth;
	}

	public StealthValidationDTO setStealth(BigDecimal stealth) {
		this.stealth = stealth;
		return this;
	}

	public static StealthValidationDTO instance(BigDecimal stealth) {
		return new StealthValidationDTO().setStealth(stealth);
	}

}
