package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.FXOMessageDTO;

@AutoProperty
public class MarketRateResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<MarketRateDTO> marketRates;

	private FXOMessageDTO fxoMessage;

	public List<MarketRateDTO> getMarketRates() {
		return marketRates;
	}

	public MarketRateResponseDTO setMarketRates(List<MarketRateDTO> marketRates) {
		this.marketRates = marketRates;
		return this;
	}

	public FXOMessageDTO getFxoMessage() {
		return fxoMessage;
	}

	public MarketRateResponseDTO setFxoMessage(FXOMessageDTO fxoMessage) {
		this.fxoMessage = fxoMessage;
		return this;
	}

	public static MarketRateResponseDTO instance() {
		return new MarketRateResponseDTO();
	}
}
