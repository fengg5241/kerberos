package com.fxo.api.fenics.service;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;

/**
 * The Interface IFenicsPricingResponseProcessorService.
 */
public interface IFenicsPricingResponseProcessorService {

	/**
	 * Process FENICS PricingResponse-XML.
	 * 
	 * <ol>
	 * <li>Identify FenicsResponseType</li>
	 * <ul>
	 * <li>If Success</li>
	 * <ul>
	 * <li>then translate GFIResponse To PricingResponseDTO</li>
	 * </ul>
	 * <li>If Error</li>
	 * <ul>
	 * <li>then trigger Error flow</li>
	 * </ul>
	 * <li>If Warning</li>
	 * <ul>
	 * <li>then log warnings, and then translateGFIResponse To
	 * PricingResponseDTO</li>
	 * </ul>
	 * </ul>
	 * 
	 * <li>Set the PricingResponse's standard properties [product,userinfo] -
	 * retrieved from PricingRequest</li>
	 * 
	 * </ol>
	 *
	 * @param responseXML
	 *            [{@link String}]
	 * @param pricingRequestDTO
	 *            [{@link PricingRequestDTO}]
	 * @return pricingRequestDTO [{@link PricingResponseDTO}]
	 */
	public PricingResponseDTO processFenicsPricingResponseXML(
			String responseXML, PricingRequestDTO pricingRequestDTO);

}
