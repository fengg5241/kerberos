package com.fxo.api.fenics.factory;

import java.io.Serializable;

import com.fxo.api.fenics.service.IFenicsPricingRequestMapperService;

public interface FenicsPricingRequestMapperServiceFactory extends Serializable {

	public IFenicsPricingRequestMapperService getFenicsPricingRequestMapperService(
			String product);

}
