package com.fxo.api.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.service.ITicketingRequestValidatorService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FXOTicketingRequestValidationServiceFactoryImpl implements
		FXOTicketingRequestValidationServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FXOTicketingRequestValidationServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaTicketingRequestValidationService")
	private ITicketingRequestValidatorService vanillaTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "straddleTicketingRequestValidationService")
	private ITicketingRequestValidatorService straddleTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "strangleTicketingRequestValidationService")
	private ITicketingRequestValidatorService strangleTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "riskReversalTicketingRequestValidationService")
	private ITicketingRequestValidatorService riskReversalTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "spreadTicketingRequestValidationService")
	private ITicketingRequestValidatorService spreadTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "knockInTicketingRequestValidationService")
	private ITicketingRequestValidatorService knockInTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "knockOutTicketingRequestValidationService")
	private ITicketingRequestValidatorService knockOutTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "reverseKnockInTicketingRequestValidationService")
	private ITicketingRequestValidatorService reverseKnockInTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "reverseKnockOutTicketingRequestValidationService")
	private ITicketingRequestValidatorService reverseKnockOutTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "europeanKnockInTicketingRequestValidationService")
	private ITicketingRequestValidatorService europeanKnockInTicketingRequestValidationService;

	@Autowired
	@Qualifier(value = "europeanKnockOutTicketingRequestValidationService")
	private ITicketingRequestValidatorService europeanKnockOutTicketingRequestValidationService;

	@Override
	public ITicketingRequestValidatorService getTicketingRequestValidationService(
			String product) {

		ITicketingRequestValidatorService ticketingRequestValidatorService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			ticketingRequestValidatorService = vanillaTicketingRequestValidationService;
			break;

		case Products.PRODUCT_STRADDLE:
			ticketingRequestValidatorService = straddleTicketingRequestValidationService;
			break;

		case Products.PRODUCT_STRANGLE:
			ticketingRequestValidatorService = strangleTicketingRequestValidationService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			ticketingRequestValidatorService = riskReversalTicketingRequestValidationService;
			break;

		case Products.PRODUCT_SPREAD:
			ticketingRequestValidatorService = spreadTicketingRequestValidationService;
			break;

		case Products.PRODUCT_KNOCKIN:
			ticketingRequestValidatorService = knockInTicketingRequestValidationService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			ticketingRequestValidatorService = knockOutTicketingRequestValidationService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			ticketingRequestValidatorService = reverseKnockInTicketingRequestValidationService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			ticketingRequestValidatorService = reverseKnockOutTicketingRequestValidationService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			ticketingRequestValidatorService = europeanKnockInTicketingRequestValidationService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			ticketingRequestValidatorService = europeanKnockOutTicketingRequestValidationService;
			break;

		default:
			logger.error("failed to locate TicketingRequestValidationService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return ticketingRequestValidatorService;
	}

}