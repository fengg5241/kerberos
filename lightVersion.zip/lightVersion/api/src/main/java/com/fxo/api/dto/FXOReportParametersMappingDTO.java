package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXOReportParametersMappingDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String parameterType;

	private String parameterDescription;

	private String parameterSourceValue;

	private String parameterTargetValue;

	public String getParameterType() {
		return parameterType;
	}

	public FXOReportParametersMappingDTO setParameterType(String parameterType) {
		this.parameterType = parameterType;
		return this;
	}

	public String getParameterDescription() {
		return parameterDescription;
	}

	public FXOReportParametersMappingDTO setParameterDescription(
			String parameterDescription) {
		this.parameterDescription = parameterDescription;
		return this;
	}

	public String getParameterSourceValue() {
		return parameterSourceValue;
	}

	public FXOReportParametersMappingDTO setParameterSourceValue(
			String parameterSourceValue) {
		this.parameterSourceValue = parameterSourceValue;
		return this;
	}

	public String getParameterTargetValue() {
		return parameterTargetValue;
	}

	public FXOReportParametersMappingDTO setParameterTargetValue(
			String parameterTargetValue) {
		this.parameterTargetValue = parameterTargetValue;
		return this;
	}

}
