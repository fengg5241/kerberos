package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class MarketClearRateDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String rateType;

	private String currency;

	private String counterCurrency;

	private String defaultCurrencyConfigured;

	public String getRateType() {
		return rateType;
	}

	public MarketClearRateDTO setRateType(String rateType) {
		this.rateType = rateType;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public MarketClearRateDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public MarketClearRateDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getDefaultCurrencyConfigured() {
		return defaultCurrencyConfigured;
	}

	public MarketClearRateDTO setDefaultCurrencyConfigured(
			String defaultCurrencyConfigured) {
		this.defaultCurrencyConfigured = defaultCurrencyConfigured;
		return this;
	}

}
