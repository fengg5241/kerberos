package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.reports.IDealConfirmationReportMapper;

public interface DealConfirmationReportMapperServiceFactory extends
		Serializable {

	public IDealConfirmationReportMapper getDealConfirmationReportMapperService(
			String product);

}