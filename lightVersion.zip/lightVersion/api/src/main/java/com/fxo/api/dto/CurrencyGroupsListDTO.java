package com.fxo.api.dto;

import com.fxo.framework.core.dto.BaseDTO;

import org.pojomatic.annotations.AutoProperty;

import java.util.List;

@AutoProperty
public class CurrencyGroupsListDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private List<CurrencyGroupDTO> currencyGroups;

	public List<CurrencyGroupDTO> getCurrencyGroups() {
		return currencyGroups;
	}

	public CurrencyGroupsListDTO setCurrencyGroups(List<CurrencyGroupDTO> currencyGroups) {
		this.currencyGroups = currencyGroups;
		return this;
	}

}
