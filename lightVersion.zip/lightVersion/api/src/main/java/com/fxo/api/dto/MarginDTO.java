package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class MarginDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	public MarginDTO() {
	}

	private String currency;
	private String counterCurrency;
	private String localMarginCurrency;
	private BigDecimal marginAmount = BigDecimal.ZERO;
	private BigDecimal localMarginSpotRate;
	private BigDecimal localMarginAmount = BigDecimal.ZERO;
	private BigDecimal counterLocalMarginSpotRate;
	private BigDecimal counterLocalMarginAmount = BigDecimal.ZERO;

	public String getCurrency() {
		return currency;
	}

	public MarginDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public MarginDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getLocalMarginCurrency() {
		return localMarginCurrency;
	}

	public MarginDTO setLocalMarginCurrency(String localMarginCurrency) {
		this.localMarginCurrency = localMarginCurrency;
		return this;
	}

	public BigDecimal getMarginAmount() {
		return marginAmount;
	}

	public MarginDTO setMarginAmount(BigDecimal marginAmount) {
		this.marginAmount = marginAmount;
		return this;
	}

	public BigDecimal getLocalMarginSpotRate() {
		return localMarginSpotRate;
	}

	public MarginDTO setLocalMarginSpotRate(BigDecimal localMarginSpotRate) {
		this.localMarginSpotRate = localMarginSpotRate;
		return this;
	}

	public BigDecimal getLocalMarginAmount() {
		return localMarginAmount;
	}

	public MarginDTO setLocalMarginAmount(BigDecimal localMarginAmount) {
		this.localMarginAmount = localMarginAmount;
		return this;
	}

	public BigDecimal getCounterLocalMarginSpotRate() {
		return counterLocalMarginSpotRate;
	}

	public MarginDTO setCounterLocalMarginSpotRate(
			BigDecimal counterLocalMarginSpotRate) {
		this.counterLocalMarginSpotRate = counterLocalMarginSpotRate;
		return this;
	}

	public BigDecimal getCounterLocalMarginAmount() {
		return counterLocalMarginAmount;
	}

	public MarginDTO setCounterLocalMarginAmount(
			BigDecimal counterLocalMarginAmount) {
		this.counterLocalMarginAmount = counterLocalMarginAmount;
		return this;
	}

	public static MarginDTO instance() {
		return new MarginDTO();
	}
}