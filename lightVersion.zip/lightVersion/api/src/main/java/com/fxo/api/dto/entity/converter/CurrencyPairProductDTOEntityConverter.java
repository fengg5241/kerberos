package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyPairProductDTO;
import com.fxo.dao.entity.CurrencyPairProduct;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class CurrencyPairProductDTOEntityConverter extends
        BaseDTOEntityConverter<CurrencyPairProductDTO, CurrencyPairProduct> {

}
