package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOProductCatalogueDTO;
import com.fxo.dao.entity.FXOProductCatalogue;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;



@Component
public class FXOProductCatalogueDTOEntityConverter extends
        BaseCustomDTOEntityConverter<FXOProductCatalogueDTO, FXOProductCatalogue> {

}
