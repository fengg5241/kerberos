package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class RateDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String spreadedRate;

	private BigDecimal bidRate;

	private BigDecimal askRate;

	private BigDecimal midRate;

	private BigDecimal computedRate;

	public String getSpreadedRate() {
		return spreadedRate;
	}

	public RateDTO setSpreadedRate(String spreadedRate) {
		this.spreadedRate = spreadedRate;
		return this;
	}

	public BigDecimal getBidRate() {
		return bidRate;
	}

	public RateDTO setBidRate(BigDecimal bidRate) {
		this.bidRate = bidRate;
		return this;
	}

	public BigDecimal getAskRate() {
		return askRate;
	}

	public RateDTO setAskRate(BigDecimal askRate) {
		this.askRate = askRate;
		return this;
	}

	public BigDecimal getMidRate() {
		return midRate;
	}

	public RateDTO setMidRate(BigDecimal midRate) {
		this.midRate = midRate;
		return this;
	}

	public BigDecimal getComputedRate() {
		return computedRate;
	}

	public RateDTO setComputedRate(BigDecimal computedRate) {
		this.computedRate = computedRate;
		return this;
	}

	public static RateDTO instance() {
		return new RateDTO().setAskRate(BigDecimal.ZERO)
				.setBidRate(BigDecimal.ZERO).setMidRate(BigDecimal.ZERO)
				.setComputedRate(BigDecimal.ZERO);
	}

}
