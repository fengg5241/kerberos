package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CustomerDTO;
import com.fxo.dao.entity.UserCustomerMapping;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;



@Component
public class CustomerDTOUserCustomerMappingEntityConverter extends
        BaseCustomDTOEntityConverter<CustomerDTO, UserCustomerMapping> {

}
