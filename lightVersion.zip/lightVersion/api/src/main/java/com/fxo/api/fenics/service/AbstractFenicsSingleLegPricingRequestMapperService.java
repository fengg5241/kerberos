package com.fxo.api.fenics.service;

import java.math.BigDecimal;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.fenics.FenicsNodeTypes;
import com.fxo.constants.fenics.FenicsSolveForTypes;
import com.fxo.fenics.request.NodeType;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsSingleLegPricingRequestMapperService extends
		AbstractFenicsPricingRequestMapperService {

	@Override
	public com.fxo.fenics.request.DataType getFENICSPricingRequestData(
			PricingRequestDTO pricingRequestDTO) {

		enrichPricingRequest(pricingRequestDTO);

		// declare an object of DataType (Fenics Data Node)
		com.fxo.fenics.request.DataType fenicsRequestData = getFenicsRequestDataTypeInitializedForPricing();

		// get the StrategyDTO from collection
		StrategyDTO strategyDTOInRequest = pricingRequestDTO.getStructure()
				.getStrategies().get(0)
				.setNodeType(FenicsNodeTypes.NODE_TYPE_SINGLELEG);

		NodeType fenicsLegNode = generateFenicsOptionLegForPricing(
				strategyDTOInRequest.getSummary().getSolveFor(),
				strategyDTOInRequest.getLegs().get(0));

		fenicsRequestData.getNode().add(fenicsLegNode);

		return fenicsRequestData;
	}

	public com.fxo.fenics.request.NodeType generateFenicsOptionLegForPricing(
			String solveFor, OptionLegDTO optionLegDTO) {

		NodeType fenicsLegNode = getFenicsLegNodeInitializedForPricing(MathUtil
				.increment(optionLegDTO.getOptionIndex(), 1));

		String dealingConvention = getDealingConvention(optionLegDTO);

		getFenicsXMLFieldGenerator().generateCurrencyField(fenicsLegNode,
				optionLegDTO.getCurrency(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterCurrencyField(
				fenicsLegNode, optionLegDTO.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		// generate faceCurrency Field in Leg Node
		getFenicsXMLFieldGenerator().generateFaceCurrencyField(fenicsLegNode,
				optionLegDTO.getFaceCurrency(), fenicsRequestPurpose,
				dealingConvention);

		String legStrategyForFenicsMapping = DealingConvention.config
				.isCounterMarketConvention(dealingConvention) ? LegStrategies
				.invert(optionLegDTO.getLegStrategy()) : optionLegDTO
				.getLegStrategy();

		getFenicsXMLFieldGenerator().generateLegStrategyField(fenicsLegNode,
				legStrategyForFenicsMapping, fenicsRequestPurpose,
				dealingConvention);

		if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(optionLegDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {

			getFenicsXMLFieldGenerator().generateMaturityField(fenicsLegNode,
					optionLegDTO.getMaturity(), fenicsRequestPurpose,
					dealingConvention);
		}

		getFenicsXMLFieldGenerator().generateCutoffField(fenicsLegNode,
				optionLegDTO.getCutoff(), fenicsRequestPurpose,
				dealingConvention);

		if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())
				&& FXOStringUtility.haveIdenticalValues(
						optionLegDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			getFenicsXMLFieldGenerator().generateExpiryDateField(fenicsLegNode,
					optionLegDTO.getExpiryDate(), fenicsRequestPurpose,
					dealingConvention);
		}

		BigDecimal amount = DealingConvention.config
				.isCounterMarketConvention(dealingConvention) ? optionLegDTO
				.getCounterAmount() : optionLegDTO.getAmount();

		BigDecimal counterAmount = DealingConvention.config
				.isCounterMarketConvention(dealingConvention) ? optionLegDTO
				.getAmount() : optionLegDTO.getCounterAmount();

		String fenicsSolveFor = getFenicsSolveForProperty(solveFor);

		if (FXOStringUtility.haveIdenticalValues(fenicsSolveFor,
				FenicsSolveForTypes.SOLVE_FOR_PREMIUM)) {
			getFenicsXMLFieldGenerator().generateStrikeField(fenicsLegNode,
					optionLegDTO.getStrike(), fenicsRequestPurpose,
					dealingConvention);

			getFenicsXMLFieldGenerator().generateAmountField(fenicsLegNode,
					amount, fenicsRequestPurpose, dealingConvention);
		}

		else {

			if (optionLegDTO.getPremium() != null) {
				getFenicsXMLFieldGenerator().generatePremiumField(
						fenicsLegNode, optionLegDTO.getPremium(),
						fenicsRequestPurpose, dealingConvention);
			} else if (optionLegDTO.getCounterPremium() != null) {
				getFenicsXMLFieldGenerator().generateCounterPremiumField(
						fenicsLegNode, optionLegDTO.getCounterPremium(),
						fenicsRequestPurpose, dealingConvention);
			}
			if (amount != null) {
				getFenicsXMLFieldGenerator().generateAmountField(fenicsLegNode,
						amount, fenicsRequestPurpose, dealingConvention);
			} else if (counterAmount != null) {
				getFenicsXMLFieldGenerator().generateCounterAmountField(
						fenicsLegNode, counterAmount, fenicsRequestPurpose,
						dealingConvention);
			}

			getFenicsXMLFieldGenerator().generateSolveForField(fenicsSolveFor,
					fenicsLegNode, fenicsRequestPurpose, dealingConvention);
		}

		getFenicsXMLFieldGenerator().generatePremiumCurrencyField(
				fenicsLegNode, optionLegDTO.getPremiumCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateHorizonDateField(fenicsLegNode,
				optionLegDTO.getHorizonDate(), fenicsRequestPurpose,
				dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getOptionType())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
							optionLegDTO.getOptionType());

			getFenicsXMLFieldGenerator().generateOptionClassField(
					fenicsLegNode,
					fxoParametersMappingDTO.getParameterTargetValue(),
					fenicsRequestPurpose, dealingConvention);
		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTODirection = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							optionLegDTO.getDirection());

			getFenicsXMLFieldGenerator().generateDirectionField(fenicsLegNode,
					fxoParametersMappingDTODirection.getParameterTargetValue(),
					fenicsRequestPurpose, dealingConvention);
		}

		// Additional inputs for priceDiscovery
		String volatility = optionLegDTO.getVolatility();

		if (FXOStringUtility.isNotEmpty(volatility)) {
			getFenicsXMLFieldGenerator().generateVolatilityField(fenicsLegNode,
					volatility, fenicsRequestPurpose, dealingConvention);
		}

		// check for rate Inversion for spot and forward (For counter
		// Pricing)

		if (optionLegDTO.getSpotRate() != null) {

			BigDecimal spotRate = DealingConvention.config
					.isCounterMarketConvention(dealingConvention) ? MathUtil
					.invert(MathUtil.deriveNonNullDecimalValue(optionLegDTO
							.getSpotRate())) : MathUtil
					.deriveNonNullDecimalValue(optionLegDTO.getSpotRate());

			getFenicsXMLFieldGenerator().generateSpotField(fenicsLegNode,
					spotRate.toEngineeringString(), fenicsRequestPurpose,
					dealingConvention);
		}

		if (optionLegDTO.getForwardRate() != null) {
			BigDecimal forwardRate = DealingConvention.config
					.isCounterMarketConvention(dealingConvention) ? MathUtil
					.invert(MathUtil.deriveNonNullDecimalValue(optionLegDTO
							.getForwardRate())) : MathUtil
					.deriveNonNullDecimalValue(optionLegDTO.getForwardRate());

			getFenicsXMLFieldGenerator().generateForwardField(fenicsLegNode,
					forwardRate.toEngineeringString(), fenicsRequestPurpose,
					dealingConvention);
		}

		setCustomFieldsInFenicsLeg(dealingConvention, optionLegDTO,
				fenicsLegNode);

		return fenicsLegNode;
	}

	public abstract void setCustomFieldsInFenicsLeg(String dealingConvention,
			OptionLegDTO optionLegDTO,
			com.fxo.fenics.request.NodeType fenicsLegNode);
}
