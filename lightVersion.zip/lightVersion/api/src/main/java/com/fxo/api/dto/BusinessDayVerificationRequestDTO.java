package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class BusinessDayVerificationRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String entity;

	private LocalDate businessDate;

	public String getEntity() {
		return entity;
	}

	public BusinessDayVerificationRequestDTO setEntity(String entity) {
		this.entity = entity;
		return this;
	}

	public LocalDate getBusinessDate() {
		return businessDate;
	}

	public BusinessDayVerificationRequestDTO setBusinessDate(LocalDate dateValue) {
		this.businessDate = dateValue;
		return this;
	}
	
	public static BusinessDayVerificationRequestDTO instance() {
		return new BusinessDayVerificationRequestDTO();
	}
	
}
