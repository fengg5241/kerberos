package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DistanceFromSpotValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal barrier;
	private BigDecimal spotRate;

	public BigDecimal getBarrier() {
		return barrier;
	}

	public DistanceFromSpotValidationDTO setBarrier(BigDecimal barrier) {
		this.barrier = barrier;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public DistanceFromSpotValidationDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public static DistanceFromSpotValidationDTO instance(BigDecimal barrier,
			BigDecimal spotRate) {
		return new DistanceFromSpotValidationDTO().setBarrier(barrier)
				.setSpotRate(spotRate);
	}

}
