package com.fxo.api.fenics.service;

import java.math.BigDecimal;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.constants.fenics.FenicsNodeTypes;
import com.fxo.fenics.request.NodeType;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsSingleLegTicketingRequestMapperService
		extends AbstractFenicsTicketingRequestMapperService {

	@Override
	public com.fxo.fenics.request.DataType getFENICSTicketingRequestData(
			TicketingRequestDTO ticketingRequestDTO) {

		enrichTicketingRequest(ticketingRequestDTO);

		// declare an object of DataType (Fenics Data Node)
		com.fxo.fenics.request.DataType fenicsRequestData = getFenicsRequestDataTypeInitializedForTicketing();

		// get the StrategyDTO from collection
		FXODealingUtil.extractStrategy(ticketingRequestDTO.getStructure())
				.setNodeType(FenicsNodeTypes.NODE_TYPE_SINGLELEG);

		FXODealingUtil.identifyAndPopulateDealingConventionInProductStructure(ticketingRequestDTO
				.getStructure());

		NodeType fenicsLegNode = generateFenicsOptionLegNodeForTicketing(FXODealingUtil
				.extractOptionLegForSingleLegStrucutures(ticketingRequestDTO
						.getStructure()), ticketingRequestDTO.getUser());

		fenicsRequestData.getNode().add(fenicsLegNode);

		return fenicsRequestData;
	}

	public com.fxo.fenics.request.NodeType generateFenicsOptionLegNodeForTicketing(
			OptionLegDTO optionLegDTO, UserDTO user) {

		com.fxo.fenics.request.NodeType fenicsLegNode = getFenicsLegNodeInitializedForTicketing(MathUtil
				.increment(optionLegDTO.getOptionIndex(), 1));

		String dealingConvention = getDealingConvention(optionLegDTO);

		getFenicsXMLFieldGenerator().generateReferenceField(fenicsLegNode,
				FenicsConstants.FXOWEBPORTAL, fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateBookField(
				fenicsLegNode,
				getBookForFenicsMapping(optionLegDTO.getCustomerType(),
						optionLegDTO.getInterPortfolio()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterpartyField(
				fenicsLegNode,
				getCounterPartyForFenicsMapping(optionLegDTO.getCustomerType(),
						optionLegDTO.getCounterParty()), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateTraderField(fenicsLegNode,
				getFenicsTraderForTicketing(), fenicsRequestPurpose,
				dealingConvention);

		// generate Murex-Strategy Field
		// retrieve Integration-Mapping for the currencyPair

		String murexStrategyField = getMurexStrategyFieldForTicketing(
				optionLegDTO.getProduct(), optionLegDTO.getCurrency(),
				optionLegDTO.getCounterCurrency());

		// If Integration-Mapping exists for currencyPair, Generate
		// Murex-Strategy Field
		if (FXOStringUtility.isNotEmpty(murexStrategyField)) {

			getFenicsXMLFieldGenerator().generateMurexStrategyField(
					fenicsLegNode, murexStrategyField, fenicsRequestPurpose,
					dealingConvention);
		}

		getFenicsXMLFieldGenerator().generateCutoffField(fenicsLegNode,
				optionLegDTO.getCutoff(), fenicsRequestPurpose,
				dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		FXOParametersMappingDTO fxoParametersMappingDTO = getFxoParametersMappingService()
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
						optionLegDTO.getOptionType());

		getFenicsXMLFieldGenerator().generateOptionClassField(fenicsLegNode,
				fxoParametersMappingDTO.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCurrencyField(fenicsLegNode,
				optionLegDTO.getCurrency(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterCurrencyField(
				fenicsLegNode, optionLegDTO.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateFaceCurrencyField(fenicsLegNode,
				optionLegDTO.getFaceCurrency(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generatePremiumCurrencyField(
				fenicsLegNode, optionLegDTO.getPremiumCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateLegStrategyField(fenicsLegNode,
				optionLegDTO.getLegStrategy(), fenicsRequestPurpose,
				dealingConvention);

		// translate direction from fenics value to FXO-Portal representation
		FXOParametersMappingDTO fxoParametersMappingDTODirection = getFxoParametersMappingService()
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
						optionLegDTO.getDirection());

		getFenicsXMLFieldGenerator().generateDirectionField(fenicsLegNode,
				fxoParametersMappingDTODirection.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateHorizonDateField(fenicsLegNode,
				optionLegDTO.getHorizonDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateExpiryDateField(fenicsLegNode,
				optionLegDTO.getExpiryDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateValueDateField(fenicsLegNode,
				optionLegDTO.getValueDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateDeliveryDateField(fenicsLegNode,
				optionLegDTO.getDeliveryDate(), fenicsRequestPurpose,
				dealingConvention);

		// select amount for MarketConvention, counterAmount as
		// CounterMarketConvention
		BigDecimal notionalAmount = (DealingConvention.config
				.isMarketConvention(dealingConvention)) ? optionLegDTO
				.getAmount() : optionLegDTO.getCounterAmount();

		getFenicsXMLFieldGenerator().generateAmountField(fenicsLegNode,
				notionalAmount, fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateMarginAmountField(fenicsLegNode,
				MathUtil.initializeOnNullValue(optionLegDTO.getMarginAmount()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generatePremiumField(fenicsLegNode,
				MathUtil.initializeOnNullValue(optionLegDTO.getPremium()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator()
				.generateCounterPremiumField(
						fenicsLegNode,
						MathUtil.initializeOnNullValue(optionLegDTO
								.getCounterPremium()), fenicsRequestPurpose,
						dealingConvention);

		getFenicsXMLFieldGenerator().generateStrikeField(fenicsLegNode,
				optionLegDTO.getStrike(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateVolatilityField(fenicsLegNode,
				optionLegDTO.getVolatility(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateAvaloqIdField(fenicsLegNode,
				optionLegDTO.getAvaloqId(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateSystemSourceIdField(fenicsLegNode,
				optionLegDTO.getSystemSourceId(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateCreaterIDField(fenicsLegNode,
				user!=null?user.getUserId():"", fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateModifierIDField(fenicsLegNode,
				user!=null?user.getUserId():"", fenicsRequestPurpose,
				dealingConvention);
		
		setCustomFieldsInFenicsLegNode(optionLegDTO, fenicsLegNode);

		return fenicsLegNode;
	}

	public abstract void setCustomFieldsInFenicsLegNode(
			OptionLegDTO optionLegDTO,
			com.fxo.fenics.request.NodeType fenicsLegNode);

}
