package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.BaseCustomDTO;

public class FXOTenorExpiryDatesDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private LocalDate businessDate;

	@Property(policy = PojomaticPolicy.ALL)
	private String tenor;

	@Property(policy = PojomaticPolicy.ALL)
	private String currency;

	@Property(policy = PojomaticPolicy.ALL)
	private String counterCurrency;

	private LocalDate expiryDate;

	private String expiryDateString;

	private String expiryTimeString;

	private String fenicsRequestId;

	public LocalDate getBusinessDate() {
		return businessDate;
	}

	public FXOTenorExpiryDatesDTO setBusinessDate(LocalDate businessDate) {
		this.businessDate = businessDate;
		return this;
	}

	public String getTenor() {
		return tenor;
	}

	public FXOTenorExpiryDatesDTO setTenor(String tenor) {
		this.tenor = tenor;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public FXOTenorExpiryDatesDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FXOTenorExpiryDatesDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public FXOTenorExpiryDatesDTO setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public String getExpiryDateString() {
		return expiryDateString;
	}

	public FXOTenorExpiryDatesDTO setExpiryDateString(String expiryDateString) {
		this.expiryDateString = expiryDateString;
		return this;
	}

	public String getExpiryTimeString() {
		return expiryTimeString;
	}

	public FXOTenorExpiryDatesDTO setExpiryTimeString(String expiryTimeString) {
		this.expiryTimeString = expiryTimeString;
		return this;
	}

	public String getFenicsRequestId() {
		return fenicsRequestId;
	}

	public FXOTenorExpiryDatesDTO setFenicsRequestId(String fenicsRequestId) {
		this.fenicsRequestId = fenicsRequestId;
		return this;
	}
}
