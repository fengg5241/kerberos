package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.FXOTenorsDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class CodeValueTenorSourceTargetDTOConverter extends
		BaseCustomSourceTargetDTOConverter<FXOTenorsDTO, CodeValueDTO> {

}
