package com.fxo.api.factory;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.service.IFXOTicketingService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;

@Component
public class FXOTicketingServiceFactoryImpl implements
		FXOTicketingServiceFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "vanillaFXOTicketingService")
	private IFXOTicketingService vanillaFXOTicketingService;

	@Autowired
	@Qualifier(value = "knockInFXOTicketingService")
	private IFXOTicketingService knockInFXOTicketingService;

	@Autowired
	@Qualifier(value = "reverseKnockInFXOTicketingService")
	private IFXOTicketingService reverseKnockInFXOTicketingService;

	@Autowired
	@Qualifier(value = "europeanKnockInFXOTicketingService")
	private IFXOTicketingService europeanKnockInFXOTicketingService;

	@Autowired
	@Qualifier(value = "knockOutFXOTicketingService")
	private IFXOTicketingService knockOutFXOTicketingService;

	@Autowired
	@Qualifier(value = "reverseKnockOutFXOTicketingService")
	private IFXOTicketingService reverseKnockOutFXOTicketingService;

	@Autowired
	@Qualifier(value = "europeanKnockOutFXOTicketingService")
	private IFXOTicketingService europeanKnockOutFXOTicketingService;

	@Autowired
	@Qualifier(value = "straddleFXOTicketingService")
	private IFXOTicketingService straddleFXOTicketingService;

	@Autowired
	@Qualifier(value = "strangleFXOTicketingService")
	private IFXOTicketingService strangleFXOTicketingService;

	@Autowired
	@Qualifier(value = "riskReversalFXOTicketingService")
	private IFXOTicketingService riskReversalFXOTicketingService;

	@Autowired
	@Qualifier(value = "spreadFXOTicketingService")
	private IFXOTicketingService spreadFXOTicketingService;

	@Override
	public IFXOTicketingService getTicketingService(
			ProductStructureDTO productStructure) {

		Objects.requireNonNull(productStructure,
				FXOMessageCodes.ERR_PRODUCT_STRUCTURE_INVALID);

		String product = productStructure.getProduct();

		Objects.requireNonNull(product, FXOMessageCodes.ERR_PRODUCT_INVALID);

		IFXOTicketingService ticketingService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			ticketingService = vanillaFXOTicketingService;
			break;

		case Products.PRODUCT_STRADDLE:
			ticketingService = straddleFXOTicketingService;
			break;

		case Products.PRODUCT_STRANGLE:
			ticketingService = strangleFXOTicketingService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			ticketingService = riskReversalFXOTicketingService;
			break;

		case Products.PRODUCT_SPREAD:
			ticketingService = spreadFXOTicketingService;
			break;

		case Products.PRODUCT_KNOCKIN:
			ticketingService = knockInFXOTicketingService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			ticketingService = reverseKnockInFXOTicketingService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			ticketingService = europeanKnockInFXOTicketingService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			ticketingService = knockOutFXOTicketingService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			ticketingService = reverseKnockOutFXOTicketingService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			ticketingService = europeanKnockOutFXOTicketingService;
			break;

		default:
			break;
		}

		Objects.requireNonNull(ticketingService,
				FXOMessageCodes.ERR_SERVICE_DISCOVERY);

		return ticketingService;
	}

}
