package com.fxo.api.fenics.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.fenics.service.IFenicsPricingResponseMapperService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FenicsPricingResponseMapperServiceFactoryImpl implements
		FenicsPricingResponseMapperServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsPricingResponseMapperServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService vanillaFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "straddleFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService straddleFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "strangleFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService strangleFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "riskReversalFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService riskReversalFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "spreadFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService spreadFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "knockInFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService knockInFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "knockOutFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService knockOutFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockInFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService reverseKnockInFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockOutFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService reverseKnockOutFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockInFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService europeanKnockInFenicsPricingResponseMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockOutFenicsPricingResponseMapperService")
	private IFenicsPricingResponseMapperService europeanKnockOutFenicsPricingResponseMapperService;

	@Override
	public IFenicsPricingResponseMapperService getFenicsPricingResponseMapperService(
			String product) {
		IFenicsPricingResponseMapperService fenicsPricingResponseMapperService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			fenicsPricingResponseMapperService = vanillaFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_STRADDLE:
			fenicsPricingResponseMapperService = straddleFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_STRANGLE:
			fenicsPricingResponseMapperService = strangleFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			fenicsPricingResponseMapperService = riskReversalFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_SPREAD:
			fenicsPricingResponseMapperService = spreadFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_KNOCKIN:
			fenicsPricingResponseMapperService = knockInFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			fenicsPricingResponseMapperService = knockOutFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			fenicsPricingResponseMapperService = reverseKnockInFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			fenicsPricingResponseMapperService = reverseKnockOutFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			fenicsPricingResponseMapperService = europeanKnockInFenicsPricingResponseMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			fenicsPricingResponseMapperService = europeanKnockOutFenicsPricingResponseMapperService;
			break;

		default:
			logger.error("failed to locate fenicsPricingResponseMapperService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return fenicsPricingResponseMapperService;
	}

}
