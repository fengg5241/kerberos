package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class CurrencyPairProductDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private FXOProductCatalogueDTO product;

	private CurrencyPairDTO currencyPair;

	private String status;

	private List<CodeValueDTO> hierarchy;

	public FXOProductCatalogueDTO getProduct() {
		return product;
	}

	public CurrencyPairProductDTO setProduct(FXOProductCatalogueDTO product) {
		this.product = product;
		return this;
	}

	public CurrencyPairDTO getCurrencyPair() {
		return currencyPair;
	}

	public CurrencyPairProductDTO setCurrencyPair(CurrencyPairDTO currencyPair) {
		this.currencyPair = currencyPair;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairProductDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public List<CodeValueDTO> getHierarchy() {
		return hierarchy;
	}

	public CurrencyPairProductDTO setHierarchy(List<CodeValueDTO> hierarchy) {
		this.hierarchy = hierarchy;
		return this;
	}

}
