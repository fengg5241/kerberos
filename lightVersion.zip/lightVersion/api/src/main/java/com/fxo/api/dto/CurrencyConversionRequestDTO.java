package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CurrencyConversionRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String fromCurrency;
	private String toCurrency;
	private BigDecimal amount;
	private String direction;
	private String strategy;
	private String maturity;
	private DateTime expiryDate;
	private String cutOff;
	private String spot;
	private BigDecimal spotRate;
	private String spotRateCalculationParameter;
	private String sign;

	public String getSign() {
		return sign;
	}

	public CurrencyConversionRequestDTO setSign(String sign) {
		this.sign = sign;
		return this;
	}

	public String getFromCurrency() {
		return fromCurrency;
	}

	public CurrencyConversionRequestDTO setFromCurrency(String fromCurrency) {
		this.fromCurrency = fromCurrency;
		return this;
	}

	public String getToCurrency() {
		return toCurrency;
	}

	public CurrencyConversionRequestDTO setToCurrency(String toCurrency) {
		this.toCurrency = toCurrency;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public CurrencyConversionRequestDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public CurrencyConversionRequestDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public CurrencyConversionRequestDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public CurrencyConversionRequestDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public CurrencyConversionRequestDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public String getCutOff() {
		return cutOff;
	}

	public CurrencyConversionRequestDTO setCutOff(String cutOff) {
		this.cutOff = cutOff;
		return this;
	}

	public String getSpot() {
		return spot;
	}

	public CurrencyConversionRequestDTO setSpot(String spot) {
		this.spot = spot;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public CurrencyConversionRequestDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public String getSpotRateCalculationParameter() {
		return spotRateCalculationParameter;
	}

	public CurrencyConversionRequestDTO setSpotRateCalculationParameter(
			String spotRateCalculationParameter) {
		this.spotRateCalculationParameter = spotRateCalculationParameter;
		return this;
	}

	public static CurrencyConversionRequestDTO instance() {
		return new CurrencyConversionRequestDTO();
	}
}
