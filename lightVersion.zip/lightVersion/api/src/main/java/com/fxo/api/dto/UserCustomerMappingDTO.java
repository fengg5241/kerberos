package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.UserDTO;


@AutoProperty
public class UserCustomerMappingDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private UserDTO user;

	private List<CustomerDTO> customers;

	public List<CustomerDTO> getCustomers() {
		return customers;
	}

	public UserCustomerMappingDTO setCustomers(List<CustomerDTO> customers) {
		this.customers = customers;
		return this;

	}

	public UserDTO getUser() {
		return user;
	}

	public UserCustomerMappingDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

}
