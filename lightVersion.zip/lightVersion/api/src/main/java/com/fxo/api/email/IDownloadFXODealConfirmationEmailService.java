package com.fxo.api.email;

import java.math.BigInteger;

import com.fxo.framework.core.dto.FXOFileInformationDTO;

public interface IDownloadFXODealConfirmationEmailService {

	public FXOFileInformationDTO downloadDealConfirmationEmail(
			BigInteger ticketNumber);
}
