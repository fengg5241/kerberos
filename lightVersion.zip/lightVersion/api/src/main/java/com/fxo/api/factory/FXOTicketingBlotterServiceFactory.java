package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.service.IFXOTicketingBlotterService;

public interface FXOTicketingBlotterServiceFactory extends Serializable {

	public IFXOTicketingBlotterService getFXOTicketingBlotterService(
			String product);

}