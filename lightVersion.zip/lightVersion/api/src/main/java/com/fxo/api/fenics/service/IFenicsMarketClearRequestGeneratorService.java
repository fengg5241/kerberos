package com.fxo.api.fenics.service;

import com.fxo.api.dto.MarketClearRequestDTO;
import com.fxo.exception.ApplicationException;

public interface IFenicsMarketClearRequestGeneratorService {
	static final String REQUEST_PREFIX = "MC_";

	public String getFenicsMarketClearRequestXML(
			MarketClearRequestDTO marketClearRequestDTO)
			throws ApplicationException;

}
