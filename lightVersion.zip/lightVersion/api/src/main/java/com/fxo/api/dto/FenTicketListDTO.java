package com.fxo.api.dto;

import java.util.Arrays;
import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class FenTicketListDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private FenTicketDTO ticket;

	private String status;

	private List<FenTicketDTO> legTickets;

	public List<FenTicketDTO> getLegTickets() {
		return legTickets;
	}

	public FenTicketListDTO setLegTickets(List<FenTicketDTO> legTickets) {
		this.legTickets = legTickets;
		return this;
	}

	public FenTicketDTO getTicket() {
		return ticket;
	}

	public FenTicketListDTO setTicket(FenTicketDTO ticket) {
		this.ticket = ticket;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public FenTicketListDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public static FenTicketListDTO instance(String status) {
		return new FenTicketListDTO().setLegTickets(
				Arrays.asList((FenTicketDTO.instance()))).setStatus(status);
	}

}
