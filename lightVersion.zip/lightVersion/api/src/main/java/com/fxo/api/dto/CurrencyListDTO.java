package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class CurrencyListDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private List<CurrencyDTO> currencies;

	public List<CurrencyDTO> getCurrencies() {
		return currencies;
	}

	public CurrencyListDTO setCurrencies(List<CurrencyDTO> currencies) {
		this.currencies = currencies;
		return this;
	}

}
