package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOReportFieldsExtractDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String callCurrency;

	private String putCurrency;

	private BigDecimal callAmount;

	private BigDecimal putAmount;

	public String getCallCurrency() {
		return callCurrency;
	}

	public FXOReportFieldsExtractDTO setCallCurrency(String callCurrency) {
		this.callCurrency = callCurrency;
		return this;
	}

	public String getPutCurrency() {
		return putCurrency;
	}

	public FXOReportFieldsExtractDTO setPutCurrency(String putCurrency) {
		this.putCurrency = putCurrency;
		return this;
	}

	public BigDecimal getCallAmount() {
		return callAmount;
	}

	public FXOReportFieldsExtractDTO setCallAmount(BigDecimal callAmount) {
		this.callAmount = callAmount;
		return this;
	}

	public BigDecimal getPutAmount() {
		return putAmount;
	}

	public FXOReportFieldsExtractDTO setPutAmount(BigDecimal putAmount) {
		this.putAmount = putAmount;
		return this;
	}
	
	public static FXOReportFieldsExtractDTO instance(){
		return new FXOReportFieldsExtractDTO();
	}

}
