package com.fxo.api.dto;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class FXOCurrentDealingHoursDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private LocalDate dealingDate;

	private DateTime startTime;

	private DateTime endTime;

	private String startTimeUpdatedBy;

	private DateTime startTimeUpdateTimeStamp;

	private String endTimeUpdatedBy;

	private DateTime endTimeUpdateTimeStamp;

	public LocalDate getDealingDate() {
		return dealingDate;
	}

	public FXOCurrentDealingHoursDTO setDealingDate(LocalDate dealingDate) {
		this.dealingDate = dealingDate;
		return this;
	}

	public DateTime getStartTime() {
		return startTime;
	}

	public FXOCurrentDealingHoursDTO setStartTime(DateTime startTime) {
		this.startTime = startTime;
		return this;
	}

	public DateTime getEndTime() {
		return endTime;
	}

	public FXOCurrentDealingHoursDTO setEndTime(DateTime endTime) {
		this.endTime = endTime;
		return this;
	}

	public String getStartTimeUpdatedBy() {
		return startTimeUpdatedBy;
	}

	public FXOCurrentDealingHoursDTO setStartTimeUpdatedBy(
			String startTimeUpdatedBy) {
		this.startTimeUpdatedBy = startTimeUpdatedBy;
		return this;
	}

	public DateTime getStartTimeUpdateTimeStamp() {
		return startTimeUpdateTimeStamp;
	}

	public FXOCurrentDealingHoursDTO setStartTimeUpdateTimeStamp(
			DateTime startTimeUpdateTimeStamp) {
		this.startTimeUpdateTimeStamp = startTimeUpdateTimeStamp;
		return this;
	}

	public String getEndTimeUpdatedBy() {
		return endTimeUpdatedBy;
	}

	public FXOCurrentDealingHoursDTO setEndTimeUpdatedBy(String endTimeUpdatedBy) {
		this.endTimeUpdatedBy = endTimeUpdatedBy;
		return this;
	}

	public DateTime getEndTimeUpdateTimeStamp() {
		return endTimeUpdateTimeStamp;
	}

	public FXOCurrentDealingHoursDTO setEndTimeUpdateTimeStamp(
			DateTime endTimeUpdateTimeStamp) {
		this.endTimeUpdateTimeStamp = endTimeUpdateTimeStamp;
		return this;
	}

}
