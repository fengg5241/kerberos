package com.fxo.api.fenics.service;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.fenics.factory.FenicsTicketingRequestMapperServiceFactory;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.ActionType;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;

@Service
public class FenicsTicketingRequestGeneratorServiceImpl implements
		IFenicsTicketingRequestGeneratorService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(FenicsTicketingRequestGeneratorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsTicketingRequestMapperServiceFactory fenicsTicketingRequestMapperServiceFactory;

	@Override
	public String getFenicsTicketingRequest(
			TicketingRequestDTO ticketingRequestDTO)
			throws ApplicationException {

		return fenicsXMLProcessingService.compositeXML(
				populateFenicsRequestBody(ticketingRequestDTO),
				ticketingRequestDTO.getTicketingRequestId(), null);
	}

	/**
	 * Populate FENICS-RequestBody
	 *
	 * @param pricingRequestDTO
	 * @return the body type
	 */
	public BodyType populateFenicsRequestBody(
			TicketingRequestDTO ticketingRequestDTO) {

		DataType fenicsData = fenicsTicketingRequestMapperServiceFactory
				.getFenicsTicketingRequestMapperService(
						ticketingRequestDTO.getStructure().getProduct())
				.getFENICSTicketingRequestData(ticketingRequestDTO);

		// Declare an object of BodyType (Fenics Body Node)
		BodyType fenicsBody = BodyType.instance().setAction(
				populateFenicsRequestAction());

		// add dataType to Body
		fenicsBody.getData().add(fenicsData);

		// return body
		return fenicsBody;
	}

	public ActionType populateFenicsRequestAction() {

		ActionType action = ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrActionTypeFunc));

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrOptionTypeDataRef));

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrOptionTypeExtraInpName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingHdrOptionTypeExtraInpVal));

		action.getOption().addAll(Arrays.asList(option1, option2));

		return action;
	}

}
