package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class CurrencyPairProductIntegrationMappingDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private CurrencyPairProductDTO currencyPairProduct;

	private String murexStrategy;

	public CurrencyPairProductDTO getCurrencyPairProduct() {
		return currencyPairProduct;
	}

	public CurrencyPairProductIntegrationMappingDTO setCurrencyPairProduct(
			CurrencyPairProductDTO currencyPairProduct) {
		this.currencyPairProduct = currencyPairProduct;
		return this;
	}

	public String getMurexStrategy() {
		return murexStrategy;
	}

	public CurrencyPairProductIntegrationMappingDTO setMurexStrategy(
			String murexStrategy) {
		this.murexStrategy = murexStrategy;
		return this;
	}

}
