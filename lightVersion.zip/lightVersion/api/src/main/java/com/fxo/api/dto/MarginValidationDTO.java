package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.api.constraint.ValidMarginValidationRequest;

@AutoProperty
@ValidMarginValidationRequest
public class MarginValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)
	private BigDecimal marginAmount;
	private BigDecimal internalCost;
	// fields used internally in validation (not exposed to Webservice)
	private Integer legCount;
	private BigDecimal minimumAmount;
	private BigDecimal percentageOfNotional;
	private String thresholdCurrency;
	private BigDecimal notionalAmount;
	private BigDecimal notionalAmountInThresholdCurrency;
	private BigDecimal marginThresholdMinimumAmount;
	private BigDecimal marginThresholdMaximumAmount;
	private boolean isValidMarginAmount;
	private BigDecimal localMarginAmount;
	private BigDecimal localMarginSpotRate;
	private BigDecimal internalCostInThresholdCurrency;

	public BigDecimal getMarginAmount() {
		return marginAmount;
	}

	public MarginValidationDTO setMarginAmount(BigDecimal marginAmount) {
		this.marginAmount = marginAmount;
		return this;
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public MarginValidationDTO setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public MarginValidationDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public BigDecimal getMinimumAmount() {
		return minimumAmount;
	}

	public MarginValidationDTO setMinimumAmount(BigDecimal minimumAmount) {
		this.minimumAmount = minimumAmount;
		return this;
	}

	public BigDecimal getPercentageOfNotional() {
		return percentageOfNotional;
	}

	public MarginValidationDTO setPercentageOfNotional(
			BigDecimal percentageOfNotional) {
		this.percentageOfNotional = percentageOfNotional;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public MarginValidationDTO setThresholdCurrency(String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}

	public BigDecimal getNotionalAmount() {
		return notionalAmount;
	}

	public MarginValidationDTO setNotionalAmount(BigDecimal notionalAmount) {
		this.notionalAmount = notionalAmount;
		return this;
	}

	public BigDecimal getNotionalAmountInThresholdCurrency() {
		return notionalAmountInThresholdCurrency;
	}

	public MarginValidationDTO setNotionalAmountInThresholdCurrency(
			BigDecimal notionalAmountInThresholdCurrency) {
		this.notionalAmountInThresholdCurrency = notionalAmountInThresholdCurrency;
		return this;
	}

	public BigDecimal getMarginThresholdMinimumAmount() {
		return marginThresholdMinimumAmount;
	}

	public MarginValidationDTO setMarginThresholdMinimumAmount(
			BigDecimal marginThresholdMinimumAmount) {
		this.marginThresholdMinimumAmount = marginThresholdMinimumAmount;
		return this;
	}

	public boolean isValidMarginAmount() {
		return isValidMarginAmount;
	}

	public MarginValidationDTO setValidMarginAmount(boolean isValidMarginAmount) {
		this.isValidMarginAmount = isValidMarginAmount;
		return this;
	}

	public BigDecimal getLocalMarginAmount() {
		return localMarginAmount;
	}

	public MarginValidationDTO setLocalMarginAmount(BigDecimal localMarginAmount) {
		this.localMarginAmount = localMarginAmount;
		return this;
	}

	public BigDecimal getLocalMarginSpotRate() {
		return localMarginSpotRate;
	}

	public MarginValidationDTO setLocalMarginSpotRate(
			BigDecimal localMarginSpotRate) {
		this.localMarginSpotRate = localMarginSpotRate;
		return this;
	}

	public BigDecimal getInternalCostInThresholdCurrency() {
		return internalCostInThresholdCurrency;
	}

	public MarginValidationDTO setInternalCostInThresholdCurrency(
			BigDecimal internalCostInThresholdCurrency) {
		this.internalCostInThresholdCurrency = internalCostInThresholdCurrency;
		return this;
	}

	public BigDecimal getMarginThresholdMaximumAmount() {
		return marginThresholdMaximumAmount;
	}

	public MarginValidationDTO setMarginThresholdMaximumAmount(
			BigDecimal marginThresholdMaximumAmount) {
		this.marginThresholdMaximumAmount = marginThresholdMaximumAmount;
		return this;
	}

}
