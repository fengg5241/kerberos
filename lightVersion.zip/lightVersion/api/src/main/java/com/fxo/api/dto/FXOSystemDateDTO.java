package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.FXOMessageDTO;

@AutoProperty
public class FXOSystemDateDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private LocalDate systemDate;
	private String horizonDateString;
	private FXOMessageDTO fxoMessage;

	public String getHorizonDateString() {
		return horizonDateString;
	}

	public void setHorizonDateString(String horizonDateString) {
		this.horizonDateString = horizonDateString;
	}

	public LocalDate getSystemDate() {
		return systemDate;
	}

	public FXOSystemDateDTO setSystemDate(LocalDate systemDate) {
		this.systemDate = systemDate;
		return this;
	}

	public FXOMessageDTO getFxoMessage() {
		return fxoMessage;
	}

	public FXOSystemDateDTO setFxoMessage(FXOMessageDTO fxoMessage) {
		this.fxoMessage = fxoMessage;
		return this;
	}

}
