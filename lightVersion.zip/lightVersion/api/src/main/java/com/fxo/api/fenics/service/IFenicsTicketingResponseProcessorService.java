package com.fxo.api.fenics.service;

import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.dto.TicketingResponseDTO;

public interface IFenicsTicketingResponseProcessorService {

	public TicketingResponseDTO processFenicsTicketingResponse(
			String responseXML,TicketingRequestDTO ticketingRequestDTO);

}
