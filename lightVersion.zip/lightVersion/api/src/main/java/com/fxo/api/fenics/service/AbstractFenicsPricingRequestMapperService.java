package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsPricingRequestMapperService implements
		IFenicsPricingRequestMapperService {

	public static final String PRICING_REQUEST_PREFIX = "PR_REQ_";

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractFenicsPricingRequestMapperService.class);

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	public FenicsXMLFieldGenerator getFenicsXMLFieldGenerator() {
		return fenicsXMLFieldGenerator;
	}

	public FenicsCustomDateTimeConverter getFenicsCustomDateTimeConverter() {
		return fenicsCustomDateTimeConverter;
	}

	public IFXOParametersMappingService getFxoParametersMappingService() {
		return fxoParametersMappingService;
	}

	public IFXOConstantsService getFxoConstantsService() {
		return fxoConstantsService;
	}

	public com.fxo.fenics.request.DataType getFenicsRequestDataTypeInitializedForPricing() {

		// declare an object of DataType (Fenics Data Node)
		com.fxo.fenics.request.DataType fenicsRequestData = new com.fxo.fenics.request.DataType();

		// set the DataType Name and format to the values configured in
		// Database)
		fenicsRequestData
				.setName(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeName));
		fenicsRequestData
				.setFormat(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeFormat));

		return fenicsRequestData;
	}

	public com.fxo.fenics.request.NodeType getFenicsLegNodeInitializedForPricing(
			Integer legIndex) {
		NodeType fenicsLegNode = new NodeType();
		String legNodenamePrefix = fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName);

		legIndex = (legIndex != null) ? legIndex : new Integer(0);

		fenicsLegNode.setName(legNodenamePrefix + " " + legIndex);

		return fenicsLegNode;
	}

	public com.fxo.fenics.request.NodeType getFenicsSummaryNodeInitializedForPricing() {
		NodeType fenicsStrategynode = new NodeType();

		// set NodeName for Strategy Node (configured in database)
		fenicsStrategynode
				.setName(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsStrategyNodeName));
		return fenicsStrategynode;
	}

	public String getFenicsSolveForProperty(String fxoSolveFor) {
		FXOParametersMappingDTO fxoParametersMappingDTO = fxoParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_SOLVEFOR,
						fxoSolveFor);
		return fxoParametersMappingDTO.getParameterTargetValue();
	}

	public static String getDealingConvention(FieldValueDTO fxoFields) {

		return FXOStringUtility.isNotEmpty(fxoFields.getDealingConvention()) ? fxoFields
				.getDealingConvention() : DealingConvention.config
				.getDealingConvention(fxoFields.getCurrency(),
						fxoFields.getFaceCurrency());
	}

	public static String evaluateRateWithDealingConvention(
			String dealingConvention, BigDecimal decimalValue) {

		BigDecimal decimalValueConverted = DealingConvention.config
				.isCounterMarketConvention(dealingConvention) ? MathUtil
				.invert(MathUtil.deriveNonNullDecimalValue(decimalValue))
				: MathUtil.deriveNonNullDecimalValue(decimalValue);

		return MathUtil.getEngineeringString(decimalValueConverted);
	}

	/**
	 * Enrich pricingRequest.
	 *
	 * @param pricingRequestDTO
	 *            [ {@link PricingRequestDTO}]
	 */
	public void enrichPricingRequest(PricingRequestDTO pricingRequestDTO) {

		pricingRequestDTO.setPricingRequestId(FXOStringUtility
				.generateUniqueId(PRICING_REQUEST_PREFIX));

		FXODealingUtil.identifyAndPopulateDealingConventionInProductStructure(pricingRequestDTO
				.getStructure());

		StrategyDTO strategy = FXODealingUtil.extractStrategy(pricingRequestDTO
				.getStructure());

		FieldValueDTO strategySummary = strategy.getSummary().setProduct(
				pricingRequestDTO.getStructure().getProduct());

		strategy.setPurpose(FenicsRequestPurpose.PRICING).setCalculationType(
				FenicsCalculationParameters.SIDED);
		pricingRequestDTO.setRequestPurpose(FenicsRequestPurpose.PRICING);

		List<OptionLegDTO> optionLegDTOs = strategy.getLegs();

		for (OptionLegDTO optionLegDTO : optionLegDTOs) {

			optionLegDTO
					.setProduct(pricingRequestDTO.getStructure().getProduct())
					.setPurpose(strategy.getPurpose())
					.setStrategy(strategySummary.getStrategy())
					.setSolveFor(strategySummary.getSolveFor())
					.setPurpose(FenicsRequestPurpose.PRICING)
					.setCalculationType(FenicsCalculationParameters.SIDED);

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionClass())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionClass());
			}

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionType())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionType());
			}

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionStyle())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionStyle());
			}

		}

	}

}
