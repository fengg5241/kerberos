package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.service.IDealValidationService;

public interface DealValidationServiceFactory extends Serializable {

	public IDealValidationService getDealValidationService(
			String validationCode);
	
}
