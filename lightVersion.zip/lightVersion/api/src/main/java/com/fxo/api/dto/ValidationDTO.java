package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class ValidationDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;
	private String currency;
	private String counterCurrency;
	private String premiumCurrency;
	private String counterPremiumCurrency;
	private String faceCurrency;
	private String counterFaceCurrency;
	private BigDecimal amount;
	private BigDecimal counterAmount;
	private String product;
	private String productType;
	private String productLabel;
	private String optionType;
	private String optionClass;
	private String direction;
	private int legIndex;
	private String fieldLevel;

	private String validatedValue;
	private String validationCode;
	private String minimumThreshold;
	private String maximumThreshold;
	private String customerType;

	public String getCurrency() {
		return currency;
	}

	public ValidationDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public ValidationDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public ValidationDTO setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public ValidationDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public BigDecimal getCounterAmount() {
		return counterAmount;
	}

	public ValidationDTO setCounterAmount(BigDecimal counterAmount) {
		this.counterAmount = counterAmount;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public ValidationDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public ValidationDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public ValidationDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public ValidationDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public int getLegIndex() {
		return legIndex;
	}

	public ValidationDTO setLegIndex(int legIndex) {
		this.legIndex = legIndex;
		return this;
	}

	public String getFieldLevel() {
		return fieldLevel;
	}

	public ValidationDTO setFieldLevel(String fieldLevel) {
		this.fieldLevel = fieldLevel;
		return this;
	}

	public String getProductLabel() {
		return productLabel;
	}

	public ValidationDTO setProductLabel(String productLabel) {
		this.productLabel = productLabel;
		return this;
	}

	public String getFaceCurrency() {
		return faceCurrency;
	}

	public ValidationDTO setFaceCurrency(String faceCurrency) {
		this.faceCurrency = faceCurrency;
		return this;
	}

	public String getCounterFaceCurrency() {
		return counterFaceCurrency;
	}

	public ValidationDTO setCounterFaceCurrency(String counterFaceCurrency) {
		this.counterFaceCurrency = counterFaceCurrency;
		return this;
	}

	public String getCounterPremiumCurrency() {
		return counterPremiumCurrency;
	}

	public ValidationDTO setCounterPremiumCurrency(String counterPremiumCurrency) {
		this.counterPremiumCurrency = counterPremiumCurrency;
		return this;
	}

	public String getValidatedValue() {
		return validatedValue;
	}

	public ValidationDTO setValidatedValue(String validatedValue) {
		this.validatedValue = validatedValue;
		return this;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public ValidationDTO setValidationCode(String validationCode) {
		this.validationCode = validationCode;
		return this;
	}

	public String getMinimumThreshold() {
		return minimumThreshold;
	}

	public ValidationDTO setMinimumThreshold(String minimumThreshold) {
		this.minimumThreshold = minimumThreshold;
		return this;
	}

	public String getMaximumThreshold() {
		return maximumThreshold;
	}

	public ValidationDTO setMaximumThreshold(String maximumThreshold) {
		this.maximumThreshold = maximumThreshold;
		return this;
	}

	public String getProductType() {
		return productType;
	}

	public ValidationDTO setProductType(String productType) {
		this.productType = productType;
		return this;
	}

	public String getCustomerType() {
		return customerType;
	}

	public ValidationDTO setCustomerType(String customerType) {
		this.customerType = customerType;
		return this;
	}

}
