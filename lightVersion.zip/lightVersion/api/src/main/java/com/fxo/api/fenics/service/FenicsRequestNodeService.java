package com.fxo.api.fenics.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.service.IStaticDataService;
import com.fxo.constants.fenics.FenicsNodeTypes;

@Component
public class FenicsRequestNodeService {

	@Autowired
	private IStaticDataService staticDataService;

	public String getNodeType(StrategyDTO strategy) {
		String nodeType = null;

		boolean isNestedNode = isNested(strategy);
		boolean isStrategyNode = hasStrategyCode(strategy);

		if (isNestedNode && isStrategyNode) {
			nodeType = FenicsNodeTypes.NODE_TYPE_STRATEGY;
		} else {
			nodeType = FenicsNodeTypes.NODE_TYPE_SINGLELEG;
		}

		return nodeType;
	}

	public boolean hasStrategyCode(StrategyDTO strategy) {

		boolean isAStrategyNode = false;

		FieldValueDTO summary = strategy.getSummary();

		if (summary != null
				&& !StringUtils.isBlank(summary.getStrategy())
				&& (staticDataService.getAllStrategyCodes().contains(summary
						.getStrategy()))) {
			isAStrategyNode = true;
		}

		return isAStrategyNode;
	}

	public boolean isNested(StrategyDTO strategy) {
		boolean isANestedNode = false;

		FieldValueDTO summary = strategy.getSummary();

		if (summary != null && strategy.getLegs() != null
				&& strategy.getLegs().size() > 1) {
			isANestedNode = true;
		}

		return isANestedNode;
	}

}
