package com.fxo.api.fenics.service;

import java.util.Objects;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Products;
import com.fxo.fenics.request.NodeType;

@Component(value = "reverseKnockOutFenicsTicketingRequestMapperService")
public class ReverseKnockOutFenicsTicketingRequestMapperServiceImpl extends
		AbstractFenicsSingleLegTicketingRequestMapperService {

	public static final String productCode = Products.PRODUCT_REVERSE_KNOCKOUT;
	public static final String modelCode = FXOWSConstantKeys.fenicsExoticOptionModel;

	@Override
	public void setCustomFieldsInFenicsLegNode(OptionLegDTO optionLegDTO,
			NodeType fenicsLegNode) {

		getFenicsXMLFieldGenerator().generateTriggerField(fenicsLegNode,
				optionLegDTO.getTrigger(), fenicsRequestPurpose,
				optionLegDTO.getDealingConvention());

		String ticketingModel = getFxoConstantsService().getFXOConstantsValue(
				modelCode);

		Objects.requireNonNull(ticketingModel,
				FXOMessageCodes.ERR_INVALID_TICKETING_MODEL);

		getFenicsXMLFieldGenerator().generateModelField(fenicsLegNode,
				ticketingModel, fenicsRequestPurpose,
				optionLegDTO.getDealingConvention());
	}
}
