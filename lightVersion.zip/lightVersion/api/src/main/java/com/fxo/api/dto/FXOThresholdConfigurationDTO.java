package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class FXOThresholdConfigurationDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private String product;

	private String optionClass;

	private String optionType;

	private String direction;

	private String currency;

	private String defaultCurrency;

	private String validationCode;

	private String minimum;

	private String minimumConverted;

	private String maximum;

	private String maximumConverted;

	private String minimumPercent;

	private String maximumPercent;

	private BigDecimal spotRate;

	private DateTime updatedAt;

	private String updatedBy;

	public String getProduct() {
		return product;
	}

	public FXOThresholdConfigurationDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public FXOThresholdConfigurationDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public FXOThresholdConfigurationDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FXOThresholdConfigurationDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public FXOThresholdConfigurationDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public FXOThresholdConfigurationDTO setValidationCode(String validationCode) {
		this.validationCode = validationCode;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public FXOThresholdConfigurationDTO setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public FXOThresholdConfigurationDTO setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public String getMinimumPercent() {
		return minimumPercent;
	}

	public FXOThresholdConfigurationDTO setMinimumPercent(String minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMinimumConverted() {
		return minimumConverted;
	}

	public FXOThresholdConfigurationDTO setMinimumConverted(
			String minimumConverted) {
		this.minimumConverted = minimumConverted;
		return this;
	}

	public String getMaximumConverted() {
		return maximumConverted;
	}

	public FXOThresholdConfigurationDTO setMaximumConverted(
			String maximumConverted) {
		this.maximumConverted = maximumConverted;
		return this;
	}

	public String getMaximumPercent() {
		return maximumPercent;
	}

	public FXOThresholdConfigurationDTO setMaximumPercent(String maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public DateTime getUpdatedAt() {
		return updatedAt;
	}

	public FXOThresholdConfigurationDTO setUpdatedAt(DateTime updatedAt) {
		this.updatedAt = updatedAt;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXOThresholdConfigurationDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public FXOThresholdConfigurationDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public String getDefaultCurrency() {
		return defaultCurrency;
	}

	public static FXOThresholdConfigurationDTO instance() {
		return new FXOThresholdConfigurationDTO();
	}

	public FXOThresholdConfigurationDTO setDefaultCurrency(
			String defaultCurrency) {
		this.defaultCurrency = defaultCurrency;
		return this;
	}

}
