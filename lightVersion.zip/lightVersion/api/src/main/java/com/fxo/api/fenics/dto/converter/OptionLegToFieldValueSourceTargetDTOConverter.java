package com.fxo.api.fenics.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.framework.core.dto.BaseCustomSourceBaseCustomTargetDTOConverter;

@Component
public class OptionLegToFieldValueSourceTargetDTOConverter
		extends
		BaseCustomSourceBaseCustomTargetDTOConverter<OptionLegDTO, FieldValueDTO> {

}
