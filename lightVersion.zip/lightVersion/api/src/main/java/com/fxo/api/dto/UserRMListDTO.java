/**
 * 
 */
package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.UserDTO;

/**
 * @author lakshmikanth
 *
 */
@AutoProperty
public class UserRMListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private UserDTO user;
	private List<RMDTO> relationshipManagers;

	public UserDTO getUser() {
		return user;
	}

	public UserRMListDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

	public List<RMDTO> getRelationshipManagers() {
		return relationshipManagers;
	}

	public UserRMListDTO setRelationshipManagers(
			List<RMDTO> relationshipManagers) {
		this.relationshipManagers = relationshipManagers;
		return this;
	}

}
