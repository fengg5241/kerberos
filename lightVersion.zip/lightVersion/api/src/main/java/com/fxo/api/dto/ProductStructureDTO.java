package com.fxo.api.dto;

import java.util.Arrays;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.constants.dealing.Products;
import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class ProductStructureDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String product;

	private String productDescription;

	private boolean isInterfacedWithAvaloq;

	@NotNull
	private List<StrategyDTO> strategies;

	public List<StrategyDTO> getStrategies() {
		return strategies;
	}

	public ProductStructureDTO setStrategies(List<StrategyDTO> strategies) {
		this.strategies = strategies;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public ProductStructureDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public ProductStructureDTO setProductDescription(String productDescription) {
		this.productDescription = productDescription;
		return this;
	}

	public boolean isInterfacedWithAvaloq() {
		return isInterfacedWithAvaloq;
	}

	public ProductStructureDTO setInterfacedWithAvaloq(
			boolean isInterfacedWithAvaloq) {
		this.isInterfacedWithAvaloq = isInterfacedWithAvaloq;
		return this;
	}

	public static ProductStructureDTO instance(String product) {

		return new ProductStructureDTO().setProduct(product)
				.setStrategies(
						Arrays.asList(StrategyDTO.instance(Products.config
								.get(product).numLegs)));
	}

	public static ProductStructureDTO instanceWithEmptyLegs(String product) {
		return new ProductStructureDTO().setProduct(product);
	}

}
