package com.fxo.api.fenics.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Maturities;
import com.fxo.fenics.util.FenicsMaturityConverter;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsSingleLegPricingResponseMapperService
		extends AbstractFenicsPricingResponseMapperService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(AbstractFenicsSingleLegPricingResponseMapperService.class);

	@Override
	public PricingResponseDTO parseFenicsPricingResponseData(
			com.fxo.fenics.response.GfiMessageType responseMessageObject,
			PricingRequestDTO pricingRequestDTO) {

		PricingResponseDTO pricingResponseDTO = PricingResponseDTO
				.getInstanceWithEmptyLegs(pricingRequestDTO.getStructure()
						.getProduct());

		// extract Node(s) from first data element (only single data element
		// will be considered for FXO Services)
		com.fxo.fenics.response.NodeType fenicsResponseLegNode = responseMessageObject
				.getBody().getData().get(0).getNode().get(0);

		FXODealingUtil.identifyAndPopulateDealingConventionInProductStructure(pricingRequestDTO
				.getStructure());

		OptionLegDTO optionLegDTO = processFenicsLegNode(fenicsResponseLegNode,
				FXODealingUtil.fetchDealingConventionFromProductStructure(pricingRequestDTO
						.getStructure()));

		// extract optionLeg from PricingRequest

		OptionLegDTO optionLegDTOFromRequest = FXODealingUtil
				.extractOptionLegForSingleLegStrucutures(pricingRequestDTO
						.getStructure());

		String tenorInPricingRequest = (FXOStringUtility.haveIdenticalValues(
				optionLegDTOFromRequest.getMaturity(),
				Maturities.MATURITIES_ODD_DATE)) ? Maturities.MATURITIES_ODD_DATE
				: optionLegDTO.getMaturity();

		optionLegDTO.setMaturity(tenorInPricingRequest).setMarginAmount(
				MathUtil.initializeOnNullValue(optionLegDTOFromRequest
						.getMarginAmount()));

		setCustomFieldsInOptionLeg(optionLegDTO);

		FXODealingUtil.extractOptionLegs(pricingResponseDTO.getStructure())
				.add(optionLegDTO);

		return pricingResponseDTO;
	}

	public OptionLegDTO processFenicsLegNode(
			com.fxo.fenics.response.NodeType fenicsResponseLegNode,
			String dealingConvention) {

		OptionLegDTO optionLegDTO = translateFenicsResponseLegNode(
				fenicsResponseLegNode, dealingConvention);

		optionLegDTO.setDealingConvention(dealingConvention);
		optionLegDTO.setOptionIndex(0);

		String currency = optionLegDTO.getCurrency();
		String counterCurrency = optionLegDTO.getCounterCurrency();

		Integer ratePrecision = getRatePrecisionForCurrencyPair(currency,
				counterCurrency);

		if (DealingConvention.config
				.isCounterMarketConvention(dealingConvention)) {

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getSpot())) {
				optionLegDTO.setSpot(MarketRateUtility.invertRateSpread(
						optionLegDTO.getSpot(), ratePrecision));
			}

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getForward())) {
				optionLegDTO.setForward(MarketRateUtility.invertRateSpread(
						optionLegDTO.getForward(), ratePrecision));
			}

			optionLegDTO.setLegStrategy(LegStrategies.invert(optionLegDTO
					.getLegStrategy()));
		}

		String sign = MarketRateUtility.getSignFromAmount(currency,
				optionLegDTO.getPremiumCurrency(),
				optionLegDTO.getPercentDeltaAmount(),
				optionLegDTO.getDeltaAmount());

		logger.info(String
				.format("rate from SpreadedRates for OptionLeg - Using Sign [%s] from inputs Currency : %s , PremiumCurrency : %s , PercentDeltaAmount : %f , DeltaAmount : %f ",
						sign, optionLegDTO.getCurrency(),
						optionLegDTO.getPremiumCurrency(),
						optionLegDTO.getPercentDeltaAmount(),
						optionLegDTO.getDeltaAmount()));

		computeMarketRates(optionLegDTO, ratePrecision, sign);

		String fxoExpiryTimeString = (FXOStringUtility.isNotEmpty(optionLegDTO
				.getExpiryTimeString())) ? formatFenicsTimeString(optionLegDTO
				.getExpiryTimeString()) : null;

		optionLegDTO.setExpiryTimeString(fxoExpiryTimeString);

		getFenicsCustomDateTimeConverter().translateFenicsDateStringToDateTime(
				optionLegDTO);

		if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(optionLegDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation
			if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())) {
				optionLegDTO.setMaturity(FenicsMaturityConverter
						.getFXOMaturityCode(optionLegDTO.getMaturity()));
			}
		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							optionLegDTO.getDirection());
			optionLegDTO.setDirection(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		return optionLegDTO;
	}

	public abstract void setCustomFieldsInOptionLeg(OptionLegDTO optionLegDTO);
}
