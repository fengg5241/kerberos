package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.framework.core.dto.BaseCustomSourceTargetDTOConverter;

@Component
public class CodeValueSourceTargetDTOConverter extends
		BaseCustomSourceTargetDTOConverter<FXOParametersMappingDTO, CodeValueDTO> {

}
