package com.fxo.api.email;

import java.util.Map;

import com.fxo.api.dto.TicketingResponseDTO;

public interface IFXODealConfirmationEmailTemplateProcessService {

	public String processEmailBodyTemplate(String templatePath,
			TicketingResponseDTO ticketingResponseDTO, String emailType,Map<String, Object> contextParams );

	public String processEmailSubjectTemplate(String templatePath,
			TicketingResponseDTO ticketingResponseDTO);
	
	
}
