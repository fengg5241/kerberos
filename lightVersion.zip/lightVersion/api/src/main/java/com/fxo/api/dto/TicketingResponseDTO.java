package com.fxo.api.dto;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.UserDTO;

@AutoProperty
public class TicketingResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String ticketingRequestId;

	private String ticketingResponseId;

	private String firstTicketNumber;

	private String lastTicketNumber;

	private String status;

	private ProductStructureDTO structure;

	private UserDTO user;

	private CustomerDTO customer;

	private DateTime transactionTime;
	
	private MarketRateResponseDTO currentMarketRateResponse;

	public TicketingResponseDTO() {

	}

	public TicketingResponseDTO(String ticketingRequestId,
			ProductStructureDTO structure) {
		super();
		this.ticketingRequestId = ticketingRequestId;
		this.structure = structure;
	}

	public String getTicketingRequestId() {
		return ticketingRequestId;
	}

	public TicketingResponseDTO setTicketingRequestId(String ticketingRequestId) {
		this.ticketingRequestId = ticketingRequestId;
		return this;
	}

	public ProductStructureDTO getStructure() {
		return structure;
	}

	public TicketingResponseDTO setStructure(ProductStructureDTO structure) {
		this.structure = structure;
		return this;
	}

	public String getTicketingResponseId() {
		return ticketingResponseId;
	}

	public TicketingResponseDTO setTicketingResponseId(
			String ticketingResponseId) {
		this.ticketingResponseId = ticketingResponseId;
		return this;
	}

	public String getFirstTicketNumber() {
		return firstTicketNumber;
	}

	public TicketingResponseDTO setFirstTicketNumber(String firstTicketNumber) {
		this.firstTicketNumber = firstTicketNumber;
		return this;
	}

	public String getLastTicketNumber() {
		return lastTicketNumber;
	}

	public TicketingResponseDTO setLastTicketNumber(String lastTicketNumber) {
		this.lastTicketNumber = lastTicketNumber;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public TicketingResponseDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public UserDTO getUser() {
		return user;
	}

	public TicketingResponseDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

	public CustomerDTO getCustomer() {
		return this.customer;
	}

	public TicketingResponseDTO setCustomer(CustomerDTO customer) {
		this.customer = customer;
		return this;
	}

	public DateTime getTransactionTime() {
		return transactionTime;
	}

	public TicketingResponseDTO setTransactionTime(DateTime transactionTime) {
		this.transactionTime = transactionTime;
		return this;
	}

	public static TicketingResponseDTO instance(String product) {
		return new TicketingResponseDTO().setStructure(ProductStructureDTO
				.instance(product));
	}

	public static TicketingResponseDTO instanceWithEmptyLegs(String product) {
		return new TicketingResponseDTO().setStructure(ProductStructureDTO
				.instanceWithEmptyLegs(product));
	}
	
	public MarketRateResponseDTO getCurrentMarketRateResponse() {
		return currentMarketRateResponse;
	}

	public TicketingResponseDTO setCurrentMarketRateResponse(MarketRateResponseDTO currentMarketRateResponse) {
		this.currentMarketRateResponse = currentMarketRateResponse;
		return this;
	}

}
