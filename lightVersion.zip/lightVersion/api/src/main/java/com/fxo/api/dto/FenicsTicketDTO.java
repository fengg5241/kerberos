package com.fxo.api.dto;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;
import com.fxo.framework.core.dto.UserDTO;

@AutoProperty
public class FenicsTicketDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private BigInteger ticketNumber;

	private BigDecimal notional;

	private BigDecimal amount;

	private String currency;

	private String counterCurrency;

	private String strategy;

	private String direction;

	private UserDTO customer;

	private DateTime tradeDate;

	private DateTime expiryDate;

	private String status;

	private DateTime deliveryDate;

	private DateTime premiumDate;

	private BigDecimal spot;

	private BigDecimal strike;

	private BigDecimal premium;

	private String premiumCurrency;

	private BigDecimal margin;

	private BigDecimal localMargin;

	private BigDecimal triggerOne;

	private String product;

	private String productLabel;

	private Integer ratePrecision;

	private String createdBy;

	private String customerType;

	private String portfolio;

	public BigInteger getTicketNumber() {
		return ticketNumber;
	}

	public FenicsTicketDTO setTicketNumber(BigInteger ticketNumber) {
		this.ticketNumber = ticketNumber;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public FenicsTicketDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FenicsTicketDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public FenicsTicketDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FenicsTicketDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public DateTime getTradeDate() {
		return tradeDate;
	}

	/*
	 * This assumes that the trade date passed is behind UTC by the timezone
	 * offset
	 */
	public FenicsTicketDTO setTradeDate(DateTime tradeDate) {
		// First add the timezone offset to get UTC time
		DateTime zoneTime = tradeDate.toDateTime(DateTimeZone.getDefault());

		// instantiate a new object at UTC
		this.tradeDate = new DateTime(DateTimeZone.UTC).withDate(
				zoneTime.getYear(), zoneTime.getMonthOfYear(),
				zoneTime.getDayOfMonth()).withTime(zoneTime.getHourOfDay(),
				zoneTime.getMinuteOfHour(), zoneTime.getSecondOfMinute(),
				zoneTime.getMillisOfSecond());
		return this;
	}

	public String getStatus() {
		return status;
	}

	public FenicsTicketDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public FenicsTicketDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public UserDTO getCustomer() {
		return customer;
	}

	public FenicsTicketDTO setCustomer(UserDTO customer) {
		this.customer = customer;
		return this;
	}

	public BigDecimal getNotional() {
		return notional;
	}

	public FenicsTicketDTO setNotional(BigDecimal notional) {
		this.notional = notional;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public FenicsTicketDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public FenicsTicketDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public DateTime getPremiumDate() {
		return premiumDate;
	}

	public FenicsTicketDTO setPremiumDate(DateTime premiumDate) {
		this.premiumDate = premiumDate;
		return this;
	}

	public BigDecimal getSpot() {
		return spot;
	}

	public FenicsTicketDTO setSpot(BigDecimal spot) {
		this.spot = spot;
		return this;
	}

	public BigDecimal getStrike() {
		return strike;
	}

	public FenicsTicketDTO setStrike(BigDecimal strike) {
		this.strike = strike;
		return this;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public FenicsTicketDTO setPremium(BigDecimal premium) {
		this.premium = premium;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public FenicsTicketDTO setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public BigDecimal getMargin() {
		return margin;
	}

	public FenicsTicketDTO setMargin(BigDecimal margin) {
		this.margin = margin;
		return this;
	}

	public BigDecimal getLocalMargin() {
		return localMargin;
	}

	public FenicsTicketDTO setLocalMargin(BigDecimal localMargin) {
		this.localMargin = localMargin;
		return this;
	}

	public String getProduct() {
		return this.product;
	}

	public FenicsTicketDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getProductLabel() {
		return this.productLabel;
	}

	public FenicsTicketDTO setProductLabel(String productLabel) {
		this.productLabel = productLabel;
		return this;
	}

	public BigDecimal getTriggerOne() {
		return this.triggerOne;
	}

	public FenicsTicketDTO setTriggerOne(BigDecimal triggerOne) {
		this.triggerOne = triggerOne;
		return this;
	}

	public Integer getRatePrecision() {
		return this.ratePrecision;
	}

	public FenicsTicketDTO setRatePrecision(Integer ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public FenicsTicketDTO setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
		return this;
	}

	public String getCustomerType() {
		return customerType;
	}

	public FenicsTicketDTO setCustomerType(String customerType) {
		this.customerType = customerType;
		return this;
	}

	public String getPortfolio() {
		return portfolio;
	}

	public FenicsTicketDTO setPortfolio(String portfolio) {
		this.portfolio = portfolio;
		return this;
	}
}
