package com.fxo.api.factory;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.service.IFXOPricingService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;

@Component
public class FXOPricingServiceFactoryImpl implements FXOPricingServiceFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "vanillaFXOPricingService")
	private IFXOPricingService vanillaFXOPricingService;

	@Autowired
	@Qualifier(value = "knockInFXOPricingService")
	private IFXOPricingService knockInFXOPricingService;

	@Autowired
	@Qualifier(value = "reverseKnockInFXOPricingService")
	private IFXOPricingService reverseKnockInFXOPricingService;

	@Autowired
	@Qualifier(value = "europeanKnockInFXOPricingService")
	private IFXOPricingService europeanKnockInFXOPricingService;

	@Autowired
	@Qualifier(value = "knockOutFXOPricingService")
	private IFXOPricingService knockOutFXOPricingService;

	@Autowired
	@Qualifier(value = "reverseKnockOutFXOPricingService")
	private IFXOPricingService reverseKnockOutFXOPricingService;

	@Autowired
	@Qualifier(value = "europeanKnockOutFXOPricingService")
	private IFXOPricingService europeanKnockOutFXOPricingService;

	@Autowired
	@Qualifier(value = "straddleFXOPricingService")
	private IFXOPricingService straddleFXOPricingService;

	@Autowired
	@Qualifier(value = "strangleFXOPricingService")
	private IFXOPricingService strangleFXOPricingService;

	@Autowired
	@Qualifier(value = "riskReversalFXOPricingService")
	private IFXOPricingService riskReversalFXOPricingService;

	@Autowired
	@Qualifier(value = "spreadFXOPricingService")
	private IFXOPricingService spreadFXOPricingService;

	@Override
	public IFXOPricingService getPricingService(
			ProductStructureDTO productStructure) {

		Objects.requireNonNull(productStructure,
				FXOMessageCodes.ERR_PRODUCT_STRUCTURE_INVALID);

		String product = productStructure.getProduct();

		Objects.requireNonNull(product, FXOMessageCodes.ERR_PRODUCT_INVALID);

		IFXOPricingService pricingService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			pricingService = vanillaFXOPricingService;
			break;

		case Products.PRODUCT_STRADDLE:
			pricingService = straddleFXOPricingService;
			break;

		case Products.PRODUCT_STRANGLE:
			pricingService = strangleFXOPricingService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			pricingService = riskReversalFXOPricingService;
			break;

		case Products.PRODUCT_SPREAD:
			pricingService = spreadFXOPricingService;
			break;

		case Products.PRODUCT_KNOCKIN:
			pricingService = knockInFXOPricingService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			pricingService = reverseKnockInFXOPricingService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			pricingService = europeanKnockInFXOPricingService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			pricingService = knockOutFXOPricingService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			pricingService = reverseKnockOutFXOPricingService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			pricingService = europeanKnockOutFXOPricingService;
			break;

		default:
			break;
		}

		Objects.requireNonNull(pricingService,
				FXOMessageCodes.ERR_SERVICE_DISCOVERY);

		return pricingService;
	}

}
