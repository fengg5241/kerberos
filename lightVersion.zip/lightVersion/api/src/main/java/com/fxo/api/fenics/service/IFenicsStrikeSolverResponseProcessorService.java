package com.fxo.api.fenics.service;

import com.fxo.api.dto.StrikeSolverResponseDTO;

public interface IFenicsStrikeSolverResponseProcessorService {

	public StrikeSolverResponseDTO processFenicsStrikeSolverResponse(
			String responseXML, String dealingConvention);

}
