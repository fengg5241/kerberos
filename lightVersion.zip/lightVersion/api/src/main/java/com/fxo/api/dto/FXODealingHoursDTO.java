package com.fxo.api.dto;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;

@AutoProperty
public class FXODealingHoursDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private LocalDate date;
	private String action;
	private DateTime time;
	private String updatedBy;

	public LocalDate getDate() {
		return date;
	}

	public FXODealingHoursDTO setDate(LocalDate date) {
		this.date = date;
		return this;
	}

	public String getAction() {
		return action;
	}

	public FXODealingHoursDTO setAction(String action) {
		this.action = action;
		return this;
	}

	public DateTime getTime() {
		return time;
	}

	public FXODealingHoursDTO setTime(DateTime time) {
		this.time = time;
		return this;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public FXODealingHoursDTO setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
		return this;
	}

}
