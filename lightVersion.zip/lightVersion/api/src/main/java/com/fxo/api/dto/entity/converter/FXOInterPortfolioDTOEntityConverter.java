package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOInterPortfolioDTO;
import com.fxo.dao.entity.FXOInterPortfolio;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class FXOInterPortfolioDTOEntityConverter extends
		BaseDTOEntityConverter<FXOInterPortfolioDTO, FXOInterPortfolio> {

}
