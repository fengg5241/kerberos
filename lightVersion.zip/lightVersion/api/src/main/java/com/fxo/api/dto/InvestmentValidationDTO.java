package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class InvestmentValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)
	private BigDecimal netInvestmentAmount;

	public BigDecimal getNetInvestmentAmount() {
		return netInvestmentAmount;
	}

	public InvestmentValidationDTO setNetInvestmentAmount(
			BigDecimal netInvestmentAmount) {
		this.netInvestmentAmount = netInvestmentAmount;
		return this;
	}

	public static InvestmentValidationDTO instance() {
		return new InvestmentValidationDTO();
	}

}
