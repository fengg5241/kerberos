package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyPairProductExpiryDatesDTO;
import com.fxo.dao.entity.CurrencyPairProductExpiryDates;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class CurrencyPairProductExpiryDatesDTOEntityConverter
		extends
		BaseDTOEntityConverter<CurrencyPairProductExpiryDatesDTO, CurrencyPairProductExpiryDates> {

}
