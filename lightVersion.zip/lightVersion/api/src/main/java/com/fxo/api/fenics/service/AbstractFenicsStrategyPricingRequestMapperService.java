package com.fxo.api.fenics.service;

import java.util.List;

import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.fenics.FenicsNodeTypes;
import com.fxo.fenics.request.NodeType;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsStrategyPricingRequestMapperService extends
		AbstractFenicsPricingRequestMapperService {

	public static final String modelCode = FXOWSConstantKeys.fenicsSimpleOptionModel;

	@Override
	public com.fxo.fenics.request.DataType getFENICSPricingRequestData(
			PricingRequestDTO pricingRequestDTO) {

		enrichPricingRequest(pricingRequestDTO);

		// declare an object of DataType (Fenics Data Node)
		com.fxo.fenics.request.DataType fenicsRequestData = getFenicsRequestDataTypeInitializedForPricing();

		// get the StrategyDTO from collection
		StrategyDTO strategyDTOInRequest = FXODealingUtil
				.extractStrategy(pricingRequestDTO.getStructure());

		strategyDTOInRequest.setNodeType(FenicsNodeTypes.NODE_TYPE_STRATEGY);

		com.fxo.fenics.request.NodeType fenicsSummaryNode = generateFenicsSummaryNodeForPricing(strategyDTOInRequest
				.getSummary());

		// add the FenicsStrategy Node to dataNode
		fenicsRequestData.getNode().add(fenicsSummaryNode);

		List<OptionLegDTO> optionLegDTOs = strategyDTOInRequest.getLegs();

		for (OptionLegDTO optionLegDTO : optionLegDTOs) {

			NodeType fenicsLegNode = generateFenicsOptionLegNodeForPricing(
					strategyDTOInRequest.getSummary(), optionLegDTO);

			fenicsSummaryNode.getNode().add(fenicsLegNode);
		}

		return fenicsRequestData;
	}

	public com.fxo.fenics.request.NodeType generateFenicsSummaryNodeForPricing(
			FieldValueDTO summary) {

		// declare a Node for Strategy Summary in fenics Request
		com.fxo.fenics.request.NodeType fenicsSummaryNode = getFenicsSummaryNodeInitializedForPricing();

		String dealingConvention = getDealingConvention(summary);

		getFenicsXMLFieldGenerator().generateCurrencyField(fenicsSummaryNode,
				summary.getCurrency(), fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterCurrencyField(
				fenicsSummaryNode, summary.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		// generate faceCurrency Field in Leg Node
		getFenicsXMLFieldGenerator().generateFaceCurrencyField(
				fenicsSummaryNode, summary.getFaceCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generatePremiumCurrencyField(
				fenicsSummaryNode, summary.getPremiumCurrency(),
				fenicsRequestPurpose, dealingConvention);

		if (FXOStringUtility.isNotEmpty(summary.getMaturity())
				&& FXOStringUtility.areNotIdentical(summary.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {

			getFenicsXMLFieldGenerator().generateMaturityField(
					fenicsSummaryNode, summary.getMaturity(),
					fenicsRequestPurpose, dealingConvention);
		}

		getFenicsXMLFieldGenerator().generateCutoffField(fenicsSummaryNode,
				summary.getCutoff(), fenicsRequestPurpose, dealingConvention);

		if (FXOStringUtility.isNotEmpty(summary.getMaturity())
				&& FXOStringUtility.haveIdenticalValues(summary.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			getFenicsXMLFieldGenerator().generateExpiryDateField(
					fenicsSummaryNode, summary.getExpiryDate(),
					fenicsRequestPurpose, dealingConvention);
		}

		getFenicsXMLFieldGenerator().generateHorizonDateField(
				fenicsSummaryNode, summary.getHorizonDate(),
				fenicsRequestPurpose, dealingConvention);

		// Additional inputs for priceDiscovery

		if (FXOStringUtility.isNotEmpty(summary.getVolatility())) {
			getFenicsXMLFieldGenerator().generateVolatilityField(
					fenicsSummaryNode, summary.getVolatility(),
					fenicsRequestPurpose, dealingConvention);
		}

		// check for rate Inversion for spot and forward (For counter
		// Pricing)

		if (summary.getSpotRate() != null) {

			getFenicsXMLFieldGenerator().generateSpotField(
					fenicsSummaryNode,
					evaluateRateWithDealingConvention(dealingConvention,
							summary.getSpotRate()), fenicsRequestPurpose,
					dealingConvention);
		}

		if (summary.getForwardRate() != null) {

			getFenicsXMLFieldGenerator().generateForwardField(
					fenicsSummaryNode,
					evaluateRateWithDealingConvention(dealingConvention,
							summary.getForwardRate()), fenicsRequestPurpose,
					dealingConvention);
		}

		setCustomFieldsInFenicsSummaryNode(summary, fenicsSummaryNode);

		return fenicsSummaryNode;
	}

	public com.fxo.fenics.request.NodeType generateFenicsOptionLegNodeForPricing(
			FieldValueDTO summary, OptionLegDTO optionLegDTO) {

		NodeType fenicsLegNode = getFenicsLegNodeInitializedForPricing(MathUtil
				.increment(optionLegDTO.getOptionIndex(), 1));

		getFenicsXMLFieldGenerator().generateAmountField(fenicsLegNode,
				optionLegDTO.getAmount(), fenicsRequestPurpose,
				summary.getDealingConvention());

		getFenicsXMLFieldGenerator().generateVolatilityField(fenicsLegNode,
				optionLegDTO.getVolatility(), fenicsRequestPurpose,
				summary.getDealingConvention());

		setCustomFieldsInFenicsLegNode(optionLegDTO, fenicsLegNode);

		return fenicsLegNode;
	}

	public abstract void setCustomFieldsInFenicsSummaryNode(
			FieldValueDTO summary,
			com.fxo.fenics.request.NodeType fenicsSummaryNode);

	public abstract void setCustomFieldsInFenicsLegNode(
			OptionLegDTO optionLegDTO,
			com.fxo.fenics.request.NodeType fenicsLegNode);
}
