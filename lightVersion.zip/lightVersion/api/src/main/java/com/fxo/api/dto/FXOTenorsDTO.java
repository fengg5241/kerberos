package com.fxo.api.dto;

import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.AuditableDTO;


public class FXOTenorsDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String tenor;

	private String description;

	private Integer sequence;

	private FXOProductCatalogueDTO product;

	public String getTenor() {
		return tenor;
	}

	public FXOTenorsDTO setTenor(String tenor) {
		this.tenor = tenor;
		return this;
	}

	public String getDescription() {
		return description;
	}

	public FXOTenorsDTO setDescription(String description) {
		this.description = description;
		return this;
	}

	public Integer getSequence() {
		return sequence;
	}

	public FXOTenorsDTO setSequence(Integer sequence) {
		this.sequence = sequence;
		return this;
	}

	public FXOProductCatalogueDTO getProduct() {
		return product;
	}

	public void setProduct(FXOProductCatalogueDTO product) {
		this.product = product;
	}

}
