package com.fxo.api.fenics.service;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.response.GfiMessageType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsDealingUtil;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.framework.util.FXOStringUtility;

@Service
public class FenicsTicketingResponseProcessorServiceImpl implements
		IFenicsTicketingResponseProcessorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsTicketingResponseProcessorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Override
	public TicketingResponseDTO processFenicsTicketingResponse(
			String responseXML, TicketingRequestDTO ticketingRequestDTO) {

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;

		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);
		} catch (ApplicationException e) {
			logger.info(e.getMessage(), e);
			throw new ApplicationRuntimeException(e.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE + ","
							+ ticketingRequestDTO.getTicketingRequestId());
		}

		logger.info(String.format(
				"FENICS Ticketing [%s]-ProcessingTime (Sec) : [%s] ",
				responseMessageObject.getHeader().getTransactionId(),
				responseMessageObject.getHeader().getProcessingTime()));

		// declare TicketingResponseDTO
		TicketingResponseDTO ticketingResponseDTO = null;

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_SUCCESS:
			ticketingResponseDTO = processFenicsTicketingDataProcessingService(
					responseMessageObject, ticketingRequestDTO);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:
			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:

			// log warnings
			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info("warning messages from fenics: " + warningMessages);

			ticketingResponseDTO = processFenicsTicketingDataProcessingService(
					responseMessageObject, ticketingRequestDTO);
			break;

		default:
			break;
		}

		return ticketingResponseDTO.setStructure(ProductStructureDTO
				.instanceWithEmptyLegs(ticketingRequestDTO.getStructure()
						.getProduct()));
	}

	private TicketingResponseDTO processFenicsTicketingDataProcessingService(
			GfiMessageType responseMessageObject,
			TicketingRequestDTO ticketingRequestDTO) {

		com.fxo.fenics.response.NodeType responseDataNode = FenicsDealingUtil
				.getTicketingResponseNodeTypeFromBody(responseMessageObject);

		TicketingResponseDTO ticketingResponseDTO = TicketingResponseDTO
				.instanceWithEmptyLegs(
						ticketingRequestDTO.getStructure().getProduct())
				.setTicketingRequestId(
						ticketingRequestDTO.getTicketingRequestId());

		try {
			for (com.fxo.fenics.response.FieldType fenicsResponseField : responseDataNode
					.getField()) {

				Field fxoTicketingResponseField = null;

				if (FXOStringUtility
						.haveIdenticalValuesWithIgnoreCase(
								fenicsResponseField.getName(),
								fxoConstantsService
										.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingDataFirstTicketNumber))) {

					fxoTicketingResponseField = ticketingResponseDTO
							.getClass()
							.getDeclaredField(
									fxoConstantsService
											.getFXOConstantsValue(FXOWSConstantKeys.fxoTicketingPropertyFirstTicketNumber));

				}

				else if (FXOStringUtility
						.haveIdenticalValuesWithIgnoreCase(
								fenicsResponseField.getName(),
								fxoConstantsService
										.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingDataLastTicketNumber))) {

					fxoTicketingResponseField = ticketingResponseDTO
							.getClass()
							.getDeclaredField(
									fxoConstantsService
											.getFXOConstantsValue(FXOWSConstantKeys.fxoTicketingPropertyLastTicketNumber));

				}

				if (fxoTicketingResponseField != null) {
					fxoTicketingResponseField.setAccessible(true);
					fxoTicketingResponseField.set(ticketingResponseDTO,
							fenicsResponseField.getFieldValue());
				}
			}
		} catch (NoSuchFieldException | SecurityException
				| IllegalArgumentException | IllegalAccessException exception) {
			logger.info("Fenics ticket response processing failed", exception);
			throw new ApplicationRuntimeException(
					FenicsMessageCodes.ERR_FENICS_TICKETING_RESPONSE + ","
							+ ticketingRequestDTO.getTicketingRequestId());
		}

		return ticketingResponseDTO;
	}

}