package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CodeValueDTO;
import com.fxo.api.dto.FXOProductCatalogueGroupDTO;
import com.fxo.framework.core.dto.BaseCustomSourceBaseCustomTargetDTOConverter;

@Component
public class ProductGroupCodeValueSourceTargetDTOConverter
		extends
		BaseCustomSourceBaseCustomTargetDTOConverter<FXOProductCatalogueGroupDTO, CodeValueDTO> {

}
