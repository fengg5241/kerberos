package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class CurrencyPairDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private CurrencyDTO currency;

	private CurrencyDTO counterCurrency;

	private Integer ratePrecision;

	private Integer distanceFromSpot;

	private String pipUnitValue;

	private String premiumCurrencyCode;

	private String status;

	private Boolean hasACommodity;
	private String minDistanceFromDeltaSpot;
	private String maxDistanceFromDeltaSpot;
	
	
	public String getMinDistanceFromDeltaSpot() {
		return minDistanceFromDeltaSpot;
	}

	public CurrencyPairDTO setMinDistanceFromDeltaSpot(String minDistanceFromDeltaSpot) {
		this.minDistanceFromDeltaSpot = minDistanceFromDeltaSpot;
		return this;
	}

	public String getMaxDistanceFromDeltaSpot() {
		return maxDistanceFromDeltaSpot;
	}

	public CurrencyPairDTO setMaxDistanceFromDeltaSpot(String maxDistanceFromDeltaSpot) {
		this.maxDistanceFromDeltaSpot = maxDistanceFromDeltaSpot;
		return this;
	}
	
	public Integer getRatePrecision() {
		return ratePrecision;
	}

	public CurrencyPairDTO setRatePrecision(Integer ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public Integer getDistanceFromSpot() {
		return distanceFromSpot;
	}

	public CurrencyPairDTO setDistanceFromSpot(Integer distanceFromSpot) {
		this.distanceFromSpot = distanceFromSpot;
		return this;
	}

	public String getPipUnitValue() {
		return pipUnitValue;
	}

	public CurrencyPairDTO setPipUnitValue(String pipUnitValue) {
		this.pipUnitValue = pipUnitValue;
		return this;
	}

	public CurrencyDTO getCurrency() {
		return currency;
	}

	public CurrencyPairDTO setCurrency(CurrencyDTO ccy) {
		this.currency = ccy;
		return this;
	}

	public CurrencyDTO getCounterCurrency() {
		return counterCurrency;
	}

	public CurrencyPairDTO setCounterCurrency(CurrencyDTO counterccy) {
		this.counterCurrency = counterccy;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyPairDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public String getPremiumCurrencyCode() {
		return premiumCurrencyCode;
	}

	public CurrencyPairDTO setPremiumCurrencyCode(String premiumCurrencyCode) {
		this.premiumCurrencyCode = premiumCurrencyCode;
		return this;
	}

	public Boolean getHasACommodity() {
		this.hasACommodity = (this.currency.getIsCommodity() || this.counterCurrency
				.getIsCommodity());
		return hasACommodity;
	}
	
	public static CurrencyPairDTO getInstance(){
		return new CurrencyPairDTO();
	}

}
