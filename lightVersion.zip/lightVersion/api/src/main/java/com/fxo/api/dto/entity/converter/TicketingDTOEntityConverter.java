package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.TicketingDTO;
import com.fxo.dao.entity.Ticketing;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class TicketingDTOEntityConverter extends
        BaseDTOEntityConverter<TicketingDTO, Ticketing> {

}
