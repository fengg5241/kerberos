package com.fxo.api.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.service.IDealValidationService;
import com.fxo.api.service.IDeltaHedgeValidationService;
import com.fxo.constants.admin.DealValidationCodes;

@Component
public class DealValidationServiceFactoryImpl implements
		DealValidationServiceFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "investmentAmountValidationService")
	private IDealValidationService investmentAmountValidationService;

	@Autowired
	@Qualifier(value = "deltaThresholdValidationService")
	private IDealValidationService deltaThresholdValidationService;

	@Autowired
	@Qualifier(value = "deltaAmountThresholdValidationService")
	private IDealValidationService deltaAmountThresholdValidationService;

	@Autowired
	@Qualifier(value = "tenorValidationService")
	private IDealValidationService tenorValidationService;

	@Autowired
	@Qualifier(value = "marginValidationService")
	private IDealValidationService marginValidationService;

	@Autowired
	@Qualifier(value = "stealthValidationService")
	private IDealValidationService stealthValidationService;

	@Autowired
	@Qualifier(value = "rawPremiumThresholdValidationService")
	private IDealValidationService rawPremiumThresholdValidationService;

	@Autowired
	@Qualifier(value = "volatilityThresholdValidationService")
	private IDealValidationService volatilityThresholdValidationService;

	@Autowired
	@Qualifier(value = "vegaThresholdValidationService")
	private IDealValidationService vegaThresholdValidationService;

	@Autowired
	@Qualifier(value = "distanceFromSpotValidationService")
	private IDealValidationService distanceFromSpotValidationService;

	@Autowired
	@Qualifier(value = "holidayCalendarValidationService")
	private IDealValidationService holidayCalendarValidationService;

	@Autowired
	@Qualifier(value = "clientAmountValidationService")
	private IDealValidationService clientAmountValidationService;

	@Autowired
	@Qualifier(value = "midVolValidationService")
	private IDealValidationService midVolValidationService;

	@Autowired
	@Qualifier(value = "currencyPairValidationService")
	private IDealValidationService currencyPairValidationService;

	@Autowired
	@Qualifier(value = "expiryDateRangeValidationService")
	private IDealValidationService expiryDateRangeValidationService;

	@Autowired
	@Qualifier(value = "staleMarketDataValidationService")
	private IDealValidationService staleMarketDataValidationService;

	@Override
	public IDealValidationService getDealValidationService(String validationCode) {

		IDealValidationService dealValidationService = null;

		switch (validationCode) {
		case DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION:
			dealValidationService = investmentAmountValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DELTA_THRESHOLD_VALIDATION:
			dealValidationService = deltaThresholdValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DELTA_AMOUNT_THRESHOLD_VALIDATION:
			dealValidationService = deltaAmountThresholdValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_TENOR_VALIDATION:
			dealValidationService = tenorValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_MARGIN_VALIDATION:
			dealValidationService = marginValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_STEALTH_VALIDATION:
			dealValidationService = stealthValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_RAW_PREMIUM_THRESHOLD_VALIDATION:
			dealValidationService = rawPremiumThresholdValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_VOLATILITY_THRESHOLD_VALIDATION:
			dealValidationService = volatilityThresholdValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_VEGA_THRESHOLD_VALIDATION:
			dealValidationService = vegaThresholdValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_DISTANCE_FROM_SPOT_VALIDATION:
			dealValidationService = distanceFromSpotValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_HOLIDAY_CALENDAR_VALIDATION:
			dealValidationService = holidayCalendarValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_CLIENT_AMOUNT_VALIDATION:
			dealValidationService = clientAmountValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_MID_VOL_VALIDATION:
			dealValidationService = midVolValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_CURRENCY_PAIR_VALIDATION:
			dealValidationService = currencyPairValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_EXPIRY_DATE_RANGE_VALIDATION:
			dealValidationService = expiryDateRangeValidationService;
			break;

		case DealValidationCodes.DEAL_GOVERNANCE_STALE_MARKET_DATE_VALIDATION:
			dealValidationService = staleMarketDataValidationService;
			break;
			
		default:
			break;
		}

		return dealValidationService;
	}

}
