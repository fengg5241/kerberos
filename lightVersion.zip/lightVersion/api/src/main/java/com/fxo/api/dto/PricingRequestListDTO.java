package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class PricingRequestListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<PricingRequestDTO> pricingRequests;

	public List<PricingRequestDTO> getPricingRequests() {
		return pricingRequests;
	}

	public PricingRequestListDTO setPricingRequests(
			List<PricingRequestDTO> pricingRequests) {
		this.pricingRequests = pricingRequests;
		return this;
	}
}
