package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOCurrentDealingHoursDTO;
import com.fxo.dao.entity.FXOCurrentDealingHours;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class FXOCurrentDealingHoursDTOEntityConverter extends
        BaseDTOEntityConverter<FXOCurrentDealingHoursDTO, FXOCurrentDealingHours> {

}
