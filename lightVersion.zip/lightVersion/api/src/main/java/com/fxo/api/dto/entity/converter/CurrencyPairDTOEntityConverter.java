package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyPairDTO;
import com.fxo.dao.entity.CurrencyPair;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class CurrencyPairDTOEntityConverter extends
        BaseDTOEntityConverter<CurrencyPairDTO, CurrencyPair> {

}
