package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.api.constraint.ValidTicketingRequest;
import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.UserDTO;

@AutoProperty
@ValidTicketingRequest
public class TicketingRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String ticketingRequestId;

	private UserDTO user;

	private CustomerDTO customer;

	private ProductStructureDTO structure;
	
	private boolean isDeltaHedge;
	
	private MarketRateResponseDTO currentMarketRateResponse;
 
	public TicketingRequestDTO(ProductStructureDTO structure) {
		super();
		this.structure = structure;
	}

	public TicketingRequestDTO() {

	}

	public ProductStructureDTO getStructure() {
		return structure;
	}

	public TicketingRequestDTO setStructure(ProductStructureDTO structure) {
		this.structure = structure;
		return this;
	}

	public String getTicketingRequestId() {
		return ticketingRequestId;
	}

	public TicketingRequestDTO setTicketingRequestId(String ticketingRequestId) {
		this.ticketingRequestId = ticketingRequestId;
		return this;
	}

	public UserDTO getUser() {
		return user;
	}

	public TicketingRequestDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

	public CustomerDTO getCustomer() {
		return customer;
	}

	public TicketingRequestDTO setCustomer(CustomerDTO customer) {
		this.customer = customer;
		return this;
	}

	public static TicketingRequestDTO getInstance(String product) {
		return new TicketingRequestDTO().setStructure(ProductStructureDTO
				.instance(product));
	}

	public static TicketingRequestDTO getInstanceWithEmptyLegs(String product) {
		TicketingRequestDTO ticketingRequestDTO = new TicketingRequestDTO()
				.setStructure(ProductStructureDTO.instance(product));

		ticketingRequestDTO.getStructure().getStrategies().get(0).getLegs()
				.clear();

		return ticketingRequestDTO;
	}
	
	public boolean getIsDeltaHedge() {
		return isDeltaHedge;
	}

	public TicketingRequestDTO setIsDeltaHedge(boolean isDeltaHedge) {
		this.isDeltaHedge = isDeltaHedge;
		return this;
	}
	
	public MarketRateResponseDTO getCurrentMarketRateResponse() {
		return currentMarketRateResponse;
	}

	public TicketingRequestDTO setCurrentMarketRateResponse(MarketRateResponseDTO currentMarketRateResponse) {
		this.currentMarketRateResponse = currentMarketRateResponse;
		return this;
	}

}
