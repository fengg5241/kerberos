package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.MarketRateDTO;
import com.fxo.api.dto.MarketRateResponseDTO;
import com.fxo.api.dto.RateDTO;
import com.fxo.api.dto.SpotsDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.service.ISpotRateService;
import com.fxo.api.util.FXODateUtility;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.response.NodeType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsMaturityConverter;
import com.fxo.fenics.util.FenicsPropertyMapper;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.fenics.util.ReflectionUtility;
import com.fxo.framework.util.FXOStringUtility;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

/**
 * The Class FenicsMarketRateResponseProcessorServiceImpl.
 */
@Service
public class FenicsMarketRateResponseProcessorServiceImpl implements
		IFenicsMarketRateResponseProcessorService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(FenicsMarketRateResponseProcessorServiceImpl.class);

	/** The Constant fenicsLogger. */
	private static final Logger fenicsLogger = LoggerFactory
			.getLogger(FenicsConstants.FENICS_LOGGER);

	/** The fenics xml processing service. */
	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	/** The fxo parameters mapping service. */
	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	/** The fenics property mapper. */
	@Autowired
	private FenicsPropertyMapper fenicsPropertyMapper;

	/** The fenics custom date time converter. */
	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	/** The currency pair service. */
	@Autowired
	private ICurrencyPairService currencyPairService;

	/** The spot rate service. */
	@Autowired
	private ISpotRateService spotRateService;

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.fxo.api.fenics.service.IFenicsMarketRateResponseProcessorService#
	 * processFenicsMarketRateResponse(java.lang.String, java.lang.String)
	 */
	@Override
	public MarketRateResponseDTO processFenicsMarketRateQueryResponse(
			String responseXML, String marketRateRequestId) {

		// log FENICS response XMLs' received in the workflow of pricing
		fenicsLogger.info(String.format(
				"Fenics-MarketRateResponse [ %s ] XML: %s",
				marketRateRequestId, responseXML));

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;
		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);
		} catch (ApplicationException e) {
			logger.info(e.getMessage(), e);
			throw new ApplicationRuntimeException(e.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE + ","
							+ marketRateRequestId);
		}

		logger.info(String.format(
				"FENICS MarketRate [%s]-ProcessingTime (Sec) : [%s] ",
				responseMessageObject.getHeader().getTransactionId(),
				responseMessageObject.getHeader().getProcessingTime()));

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// declare PricingResponseDTO
		MarketRateResponseDTO marketRateResponseDTO = null;

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_SUCCESS:
			marketRateResponseDTO = translateFenicsMarketRateQueryResponseMessageToMarketRateResponseDTO(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:
			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:
			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info(String.format("FENICS - Warning Message %s : %s - %s",
					"Market Rate Query ", marketRateRequestId,
					warningMessages.toString()));

			marketRateResponseDTO = translateFenicsMarketRateQueryResponseMessageToMarketRateResponseDTO(responseMessageObject);

			break;

		default:
			break;
		}

		return marketRateResponseDTO;
	}

	/**
	 * translate FenicsMarketRateQueryResponseMessage
	 *
	 * @param responseMessageObject
	 *            the response message object
	 * @return the market rate response dto
	 */
	public MarketRateResponseDTO translateFenicsMarketRateQueryResponseMessageToMarketRateResponseDTO(
			com.fxo.fenics.response.GfiMessageType responseMessageObject) {

		// extract responseNodes from FenicsResponseMessageObject
		List<com.fxo.fenics.response.NodeType> responseNodes = FenicsResponseNodeProcessor
				.extractResponseNodesFromBody(responseMessageObject);

		// get nestedNodes from responseNodes Collection for verification
		if (responseNodes == null || responseNodes.get(0) == null
				|| responseNodes.get(0).getNode() == null) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsMultiLegNestedResponseNode - ResponseNode from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FXOStringUtility.joinStrings(
							FenicsMessageCodes.ERR_FENICS_RESPONSE,
							errorMessage, FXOWSConstantKeys.COMMA_DELIMITER));
		}

		List<MarketRateDTO> marketRatesDTO = new ArrayList<MarketRateDTO>(
				Lists.transform(responseNodes,
						new Function<NodeType, MarketRateDTO>() {

							@Override
							public MarketRateDTO apply(
									NodeType fenicsMarketRateNode) {
								return translateFenicsMarketRateResponseNodeToMarketRateDTO(fenicsMarketRateNode);
							}
						}));

		// set Strategy collection to productStructure
		return MarketRateResponseDTO.instance().setMarketRates(marketRatesDTO);
	}

	/**
	 * Process fenics single leg response node to market rate dto.
	 *
	 * @param responseNode
	 *            the response node
	 * @return the market rate dto
	 */
	public MarketRateDTO translateFenicsMarketRateResponseNodeToMarketRateDTO(
			NodeType responseNode) {

		Map<String, String> fenicsMarketRateResponseFieldMap = fenicsPropertyMapper
				.getFenicsMarketRateResponseFieldMap();

		if (fenicsMarketRateResponseFieldMap == null
				|| fenicsMarketRateResponseFieldMap.isEmpty()) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FXOStringUtility.joinStrings(
							FenicsMessageCodes.ERR_FENICS_RESPONSE,
							errorMessage, FXOWSConstantKeys.COMMA_DELIMITER));
		}

		List<com.fxo.fenics.response.FieldType> responseFieldList = responseNode
				.getField();

		if (responseFieldList == null || responseFieldList.size() == 0) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is empty";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FXOStringUtility.joinStrings(
							FenicsMessageCodes.ERR_FENICS_RESPONSE,
							errorMessage, FXOWSConstantKeys.COMMA_DELIMITER));
		}

		MarketRateDTO marketRateResponseDTO = MarketRateDTO.instance();

		for (com.fxo.fenics.response.FieldType entry : responseFieldList) {
			if (fenicsMarketRateResponseFieldMap.get(entry.getName()) != null) {
				ReflectionUtility.setField(marketRateResponseDTO,
						fenicsMarketRateResponseFieldMap.get(entry.getName()),
						entry.getFieldValue());
			}
		}

		// get currencyPair Precision
		Integer precision = currencyPairService.getPrecision(
				marketRateResponseDTO.getCurrency(),
				marketRateResponseDTO.getCounterCurrency());

		marketRateResponseDTO.setRatePrecision(precision);

		DateTime horizonDate = fenicsCustomDateTimeConverter
				.translateHorizonDateStringToDateTime(marketRateResponseDTO
						.getHorizonDateString());
		marketRateResponseDTO.setHorizonDate(horizonDate);

		DateTime expiryDate = fenicsCustomDateTimeConverter
				.translateExpiryDateStringToDateTime(marketRateResponseDTO
						.getExpiryDateString(), FXODateUtility
						.formatFenicsTimeString(marketRateResponseDTO
								.getExpiryTimeString()));

		marketRateResponseDTO.setExpiryDate(expiryDate);

		// compute DaysDuration for expiryDate
		Integer tradeDateToExpiryDateDuration = (horizonDate != null && expiryDate != null) ? FXODateUtility
				.getDateDuration(horizonDate, expiryDate) - 1 : null;

		marketRateResponseDTO
				.setTradeDateToExpiryDate(tradeDateToExpiryDateDuration);

		DateTime valueDate = fenicsCustomDateTimeConverter
				.translateValueDateStringToDateTime(marketRateResponseDTO
						.getValueDateString());
		marketRateResponseDTO.setValueDate(valueDate);

		DateTime deliveryDate = fenicsCustomDateTimeConverter
				.translateDeliveryDateStringToDateTime(marketRateResponseDTO
						.getDeliveryDateString());

		marketRateResponseDTO.setDeliveryDate(deliveryDate);

		// compute DaysDuration for DeliveryDate
		Integer tradeDateToDeliveryDateDuration = (horizonDate != null && deliveryDate != null) ? FXODateUtility
				.getDateDuration(horizonDate, deliveryDate) - 1 : null;

		marketRateResponseDTO
				.setTradeDateToDeliveryDate(tradeDateToDeliveryDateDuration);

		if ((FXOStringUtility.isNotEmpty(marketRateResponseDTO.getSpot()) && FXOStringUtility
				.isNumeric(marketRateResponseDTO.getSpot()))) {
			marketRateResponseDTO.setSpotRate(new BigDecimal(
					marketRateResponseDTO.getSpot()));
		}

		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getSpot())) {

			RateDTO spotRateDTO = null;

			try {
				spotRateDTO = MarketRateUtility
						.evaluateForwardRateFromForwardSpread(
								marketRateResponseDTO.getSpot(), null,
								marketRateResponseDTO.getRatePrecision());

			} catch (Exception exception) {
				throw new ApplicationRuntimeException(
						"error during evaluation of spotRate",
						FXOStringUtility.joinStrings(Arrays.asList(
								FXOMessageCodes.ERR_SPOT_RATE_RETRIEVAL,
								marketRateResponseDTO.getCurrency(),
								marketRateResponseDTO.getCounterCurrency()),
								FXOWSConstantKeys.COMMA_DELIMITER));
			}

			marketRateResponseDTO.setSpotRate(spotRateDTO.getComputedRate())
					.setBidSpotRate(spotRateDTO.getBidRate())
					.setAskSpotRate(spotRateDTO.getAskRate());
		}

		if ((FXOStringUtility.isNotEmpty(marketRateResponseDTO.getVolatility()) && FXOStringUtility
				.isNumeric(marketRateResponseDTO.getVolatility()))) {
			marketRateResponseDTO.setVolatilityRate(new BigDecimal(
					marketRateResponseDTO.getVolatility()));
		}

		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getVolatility())) {

			RateDTO voltilityRateDTO = null;

			try {
				voltilityRateDTO = MarketRateUtility
						.evaluateVolatilityRateFromVolatilitySpread(
								marketRateResponseDTO.getVolatility(), null,
								marketRateResponseDTO.getRatePrecision());

			} catch (Exception exception) {
				throw new ApplicationRuntimeException(
						"error during evaluation of volatilityRate",
						FXOStringUtility.joinStrings(Arrays.asList(
								FXOMessageCodes.ERR_VOLATILITY_RETRIEVAL,
								marketRateResponseDTO.getCurrency(),
								marketRateResponseDTO.getCounterCurrency()),
								FXOWSConstantKeys.COMMA_DELIMITER));

			}

			marketRateResponseDTO
					.setVolatilityRate(voltilityRateDTO.getComputedRate())
					.setBidVolatilityRate(voltilityRateDTO.getBidRate())
					.setAskVolatilityRate(voltilityRateDTO.getAskRate());

		}

		if ((FXOStringUtility.isNotEmpty(marketRateResponseDTO.getForward()) && FXOStringUtility
				.isNumeric(marketRateResponseDTO.getForward()))) {
			marketRateResponseDTO.setForwardRate(new BigDecimal(
					marketRateResponseDTO.getForward()));
		}

		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getForward())) {

			RateDTO forwardRateDTO = null;

			try {
				forwardRateDTO = MarketRateUtility
						.evaluateForwardRateFromForwardSpread(
								marketRateResponseDTO.getForward(), null,
								marketRateResponseDTO.getRatePrecision());
			} catch (Exception exception) {

				throw new ApplicationRuntimeException(
						"error during evaluation of forwardRate",
						FXOStringUtility.joinStrings(Arrays.asList(
								FXOMessageCodes.ERR_FORWARD_RATE_RETRIEVAL,
								marketRateResponseDTO.getCurrency(),
								marketRateResponseDTO.getCounterCurrency()),
								FXOWSConstantKeys.COMMA_DELIMITER));
			}

			marketRateResponseDTO
					.setForwardRate(forwardRateDTO.getComputedRate())
					.setBidForwardRate(forwardRateDTO.getBidRate())
					.setAskForwardRate(forwardRateDTO.getAskRate());

		}

		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(
						marketRateResponseDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation

			marketRateResponseDTO.setMaturity(FenicsMaturityConverter
					.getFXOMaturityCode(marketRateResponseDTO.getMaturity()));

		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							marketRateResponseDTO.getDirection());
			marketRateResponseDTO.setDirection(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		// translate strategy from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(marketRateResponseDTO.getLegStrategy())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_LEG_STRATEGY,
							marketRateResponseDTO.getLegStrategy());
			marketRateResponseDTO.setStrategy(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		// check if rate is Stale
		Boolean isStaleRate = spotRateService
				.checkForStaleRates(SpotsDTO
						.instance()
						.setCurrency(marketRateResponseDTO.getCurrency())
						.setCounterCurrency(
								marketRateResponseDTO.getCounterCurrency()));

		marketRateResponseDTO.setStaleRateIndicator(isStaleRate);

		return marketRateResponseDTO;
	}

}