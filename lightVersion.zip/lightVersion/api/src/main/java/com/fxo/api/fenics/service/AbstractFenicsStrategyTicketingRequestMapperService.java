package com.fxo.api.fenics.service;

import java.util.List;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.fenics.request.NodeType;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsStrategyTicketingRequestMapperService
		extends AbstractFenicsTicketingRequestMapperService {

	@Override
	public com.fxo.fenics.request.DataType getFENICSTicketingRequestData(
			TicketingRequestDTO ticketingRequestDTO) {

		enrichTicketingRequest(ticketingRequestDTO);

		// declare an object of DataType (Fenics Data Node)
		com.fxo.fenics.request.DataType fenicsRequestData = getFenicsRequestDataTypeInitializedForTicketing();

		// get the StrategyDTO from collection
		StrategyDTO strategyDTOInRequest = ticketingRequestDTO.getStructure()
				.getStrategies().get(0);

		com.fxo.fenics.request.NodeType fenicsStrategyNode = getFenicsRequestStrategyNodeInitializedForTicketing();

		// add the FenicsStrategy Node to dataNode
		fenicsRequestData.getNode().add(fenicsStrategyNode);

		List<OptionLegDTO> optionLegDTOs = strategyDTOInRequest.getLegs();

		for (OptionLegDTO optionLegDTO : optionLegDTOs) {

			NodeType fenicsLegNode = generateFenicsOptionLegNodeForTicketing(
					strategyDTOInRequest.getSummary(), optionLegDTO, ticketingRequestDTO.getUser());

			fenicsStrategyNode.getNode().add(fenicsLegNode);
		}

		return fenicsRequestData;
	}

	public com.fxo.fenics.request.NodeType generateFenicsOptionLegNodeForTicketing(
			FieldValueDTO summary, OptionLegDTO optionLegDTO, UserDTO user) {

		NodeType fenicsLegNode = getFenicsLegNodeInitializedForTicketing(MathUtil
				.increment(optionLegDTO.getOptionIndex(), 1));

		String dealingConvention = getDealingConvention(summary);

		getFenicsXMLFieldGenerator().generateReferenceField(fenicsLegNode,
				FenicsConstants.FXOWEBPORTAL, fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateBookField(
				fenicsLegNode,
				getBookForFenicsMapping(optionLegDTO.getCustomerType(),
						optionLegDTO.getInterPortfolio()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterpartyField(
				fenicsLegNode,
				getCounterPartyForFenicsMapping(optionLegDTO.getCustomerType(),
						optionLegDTO.getCounterParty()), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateTraderField(fenicsLegNode,
				getFenicsTraderForTicketing(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateMarketField(fenicsLegNode,
				getFenicsMarketForTicketing(), fenicsRequestPurpose,
				dealingConvention);

		// generate Murex-Strategy Field
		// retrieve Integration-Mapping for the currencyPair

		String murexStrategyField = getMurexStrategyFieldForTicketing(
				summary.getProduct(), summary.getCurrency(),
				summary.getCounterCurrency());

		// If Integration-Mapping exists for currencyPair, Generate
		// Murex-Strategy Field
		if (FXOStringUtility.isNotEmpty(murexStrategyField)) {

			getFenicsXMLFieldGenerator().generateMurexStrategyField(
					fenicsLegNode, murexStrategyField, fenicsRequestPurpose,
					dealingConvention);
		}

		getFenicsXMLFieldGenerator().generateCutoffField(fenicsLegNode,
				summary.getCutoff(), fenicsRequestPurpose, dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		FXOParametersMappingDTO fxoParametersMappingDTO = getFxoParametersMappingService()
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
						optionLegDTO.getOptionType());

		getFenicsXMLFieldGenerator().generateOptionClassField(fenicsLegNode,
				fxoParametersMappingDTO.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCurrencyField(fenicsLegNode,
				summary.getCurrency(), fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateCounterCurrencyField(
				fenicsLegNode, summary.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateFaceCurrencyField(fenicsLegNode,
				summary.getFaceCurrency(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generatePremiumCurrencyField(
				fenicsLegNode, summary.getPremiumCurrency(),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateHorizonDateField(fenicsLegNode,
				summary.getHorizonDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateExpiryDateField(fenicsLegNode,
				summary.getExpiryDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator()
				.generateValueDateField(fenicsLegNode, summary.getValueDate(),
						fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generateDeliveryDateField(fenicsLegNode,
				summary.getDeliveryDate(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateAmountField(fenicsLegNode,
				optionLegDTO.getAmount(), fenicsRequestPurpose,
				dealingConvention);

		getFenicsXMLFieldGenerator().generateMarginAmountField(fenicsLegNode,
				MathUtil.initializeOnNullValue(optionLegDTO.getMarginAmount()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator().generatePremiumField(fenicsLegNode,
				MathUtil.initializeOnNullValue(optionLegDTO.getPremium()),
				fenicsRequestPurpose, dealingConvention);

		getFenicsXMLFieldGenerator()
				.generateCounterPremiumField(
						fenicsLegNode,
						MathUtil.initializeOnNullValue(optionLegDTO
								.getCounterPremium()), fenicsRequestPurpose,
						dealingConvention);

		getFenicsXMLFieldGenerator().generateVolatilityField(fenicsLegNode,
				optionLegDTO.getVolatility(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateAvaloqIdField(fenicsLegNode,
				optionLegDTO.getAvaloqId(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateSystemSourceIdField(fenicsLegNode,
				optionLegDTO.getSystemSourceId(), fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateCreaterIDField(fenicsLegNode,
				user!=null?user.getUserId():"", fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateModifierIDField(fenicsLegNode,
				user!=null?user.getUserId():"", fenicsRequestPurpose,
				dealingConvention);
		/*
		getFenicsXMLFieldGenerator().generateCreaterIDField(fenicsLegNode,
				"sguser1", fenicsRequestPurpose,
				dealingConvention);
		
		getFenicsXMLFieldGenerator().generateModifierIDField(fenicsLegNode,
				"sguser1", fenicsRequestPurpose,
				dealingConvention);*/

		generateCustomFieldsInFenicsOptionLegNode(optionLegDTO, summary,
				fenicsLegNode);

		return fenicsLegNode;
	}

	public abstract void generateCustomFieldsInFenicsOptionLegNode(
			OptionLegDTO optionLegDTO, FieldValueDTO summary,
			com.fxo.fenics.request.NodeType fenicsLegNode);

}
