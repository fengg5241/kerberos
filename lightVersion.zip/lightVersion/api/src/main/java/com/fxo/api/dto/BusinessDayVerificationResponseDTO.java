package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.constants.dealing.DayOfWeek;
import com.fxo.constants.dealing.FXOVerificationType;
import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class BusinessDayVerificationResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private Boolean isPublicHoliday;

	private Boolean isWeekend;

	private DayOfWeek dayOfWeek;

	private FXOVerificationType status;

	public Boolean isPublicHoliday() {
		return isPublicHoliday;
	}

	public BusinessDayVerificationResponseDTO setPublicHoliday(
			Boolean isPublicHoliday) {
		this.isPublicHoliday = isPublicHoliday;
		return this;
	}

	public FXOVerificationType getStatus() {
		return status;
	}

	public BusinessDayVerificationResponseDTO setStatus(
			FXOVerificationType status) {
		this.status = status;
		return this;
	}

	public DayOfWeek getDayOfWeek() {
		return dayOfWeek;
	}

	public BusinessDayVerificationResponseDTO setDayOfWeek(DayOfWeek dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
		return this;
	}

	public Boolean isWeekend() {
		return isWeekend;
	}

	public BusinessDayVerificationResponseDTO setWeekend(Boolean isWeekend) {
		this.isWeekend = isWeekend;
		return this;
	}

	public static BusinessDayVerificationResponseDTO instance() {
		return new BusinessDayVerificationResponseDTO();
	}

}
