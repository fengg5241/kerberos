package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.api.dto.StrikeSolverResponseDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.ICurrencyPairService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.constants.fenics.FenicsXMLNodeTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.factory.IFenicsXMLMapperFactory;
import com.fxo.fenics.response.NodeType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsMaturityConverter;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.fenics.util.ReflectionUtility;
import com.fxo.framework.core.dto.FXOMessageDTO;
import com.fxo.framework.core.dto.FXOMessageDetailDTO;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

@Service
public class FenicsStrikeSolverResponseProcessorServiceImpl implements
		IFenicsStrikeSolverResponseProcessorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsStrikeSolverResponseProcessorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private ICurrencyPairService currencyPairService;

	@Autowired
	private IFenicsXMLMapperFactory fenicsXMLMapperFactory;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Override
	public StrikeSolverResponseDTO processFenicsStrikeSolverResponse(
			String responseXML, String dealingConvention) {

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;

		String strikeSolverRequestId = null;

		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);

			strikeSolverRequestId = responseMessageObject.getHeader()
					.getTransactionId();

		} catch (ApplicationException e) {
			logger.info(e.getMessage(), e);
			throw new ApplicationRuntimeException(e.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE + ","
							+ strikeSolverRequestId);
		}

		logger.info(String.format(
				"FENICS MarketRate [%s]-ProcessingTime (Sec) : [%s] ",
				strikeSolverRequestId, responseMessageObject.getHeader()
						.getProcessingTime()));

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// declare PricingResponseDTO
		StrikeSolverResponseDTO strikeSolverResponseDTO = null;

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_SUCCESS:
			strikeSolverResponseDTO = processFenicsStrikeSolverDataProcessingService(
					responseMessageObject, dealingConvention);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:
			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:
			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info(String.format("FENICS - Warning Message %s : %s - %s",
					"StrikeSolver Query ", strikeSolverRequestId,
					warningMessages.toString()));

			strikeSolverResponseDTO = processFenicsStrikeSolverDataProcessingService(
					responseMessageObject, dealingConvention);

			break;

		default:
			break;
		}

		BigDecimal internalCost = BigDecimal.ZERO;

		if (FXOStringUtility.haveIdenticalValues(
				strikeSolverResponseDTO.getCurrency(),
				strikeSolverResponseDTO.getPremiumCurrency())) {
			internalCost = strikeSolverResponseDTO.getPremium();
		} else {
			internalCost = strikeSolverResponseDTO.getCounterPremium();
		}

		strikeSolverResponseDTO.setInternalCost(internalCost);

		return strikeSolverResponseDTO;
	}

	public void enrichPricingResponseWithMessages(
			PricingResponseDTO pricingResponseDTO, StringBuffer warningMessages) {

		FXOMessageDetailDTO fxoMessageDetailDTO = new FXOMessageDetailDTO()
				.setMessageCode(FenicsMessageCodes.MSG_FENICS_WARNING)
				.setMessage(warningMessages.toString());

		List<FXOMessageDetailDTO> fxoMessageDetailDTOs = new ArrayList<FXOMessageDetailDTO>();
		fxoMessageDetailDTOs.add(fxoMessageDetailDTO);

		pricingResponseDTO.setFxoMessage(new FXOMessageDTO()
				.setWarnings(fxoMessageDetailDTOs));
	}

	public StrikeSolverResponseDTO processFenicsStrikeSolverDataProcessingService(
			com.fxo.fenics.response.GfiMessageType responseMessageObject,
			String dealingConvention) {

		// extract responseNodes from FenicsResponseMessageObject
		List<com.fxo.fenics.response.NodeType> responseNodes = FenicsResponseNodeProcessor
				.extractResponseNodesFromBody(responseMessageObject);

		return processFenicsSingleLegResponseNodeToStrikeSolverResponseDTO(
				responseNodes.get(0), dealingConvention);

	}

	public StrikeSolverResponseDTO processFenicsSingleLegResponseNodeToStrikeSolverResponseDTO(
			NodeType responseNode, String dealingConvention) {

		Map<String, String> fenicsMarketRateResponseFieldMap = fenicsXMLMapperFactory
				.getXMLResponsePropertyMapper(
						FenicsRequestPurpose.STRIKE_SOLVER, dealingConvention,
						FenicsXMLNodeTypes.NODE_TYPE_LEG);

		if (fenicsMarketRateResponseFieldMap == null
				|| fenicsMarketRateResponseFieldMap.isEmpty()) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		List<com.fxo.fenics.response.FieldType> responseFieldList = responseNode
				.getField();

		if (responseFieldList == null || responseFieldList.size() == 0) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is empty";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		StrikeSolverResponseDTO strikeSolverResponseDTO = new StrikeSolverResponseDTO();

		for (com.fxo.fenics.response.FieldType entry : responseFieldList) {
			if (fenicsMarketRateResponseFieldMap.get(entry.getName()) != null) {
				ReflectionUtility.setField(strikeSolverResponseDTO,
						fenicsMarketRateResponseFieldMap.get(entry.getName()),
						entry.getFieldValue());
			}
		}

		DateTime expiryDate = fenicsCustomDateTimeConverter
				.translateExpiryDateStringToDateTime(strikeSolverResponseDTO
						.getExpiryDateString(),
						formatFenicsTimeString(strikeSolverResponseDTO
								.getExpiryTimeString()));

		strikeSolverResponseDTO.setExpiryDate(expiryDate);

		DateTime deliveryDate = fenicsCustomDateTimeConverter
				.translateDeliveryDateStringToDateTime(strikeSolverResponseDTO
						.getDeliveryDateString());

		strikeSolverResponseDTO.setDeliveryDate(deliveryDate);

		DateTime horizonDate = fenicsCustomDateTimeConverter
				.translateHorizonDateStringToDateTime(strikeSolverResponseDTO
						.getHorizonDateString());

		strikeSolverResponseDTO.setHorizonDate(horizonDate);

		if (FXOStringUtility.isNotEmpty(strikeSolverResponseDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(
						strikeSolverResponseDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation

			strikeSolverResponseDTO.setMaturity(FenicsMaturityConverter
					.getFXOMaturityCode(strikeSolverResponseDTO.getMaturity()));

		}

		if (DealingConvention.config
				.isCounterMarketConvention(dealingConvention)) {

			Integer ratePrecision = currencyPairService.getPrecision(
					strikeSolverResponseDTO.getCurrency(),
					strikeSolverResponseDTO.getCounterCurrency());

			ratePrecision = (ratePrecision == null) ? MathUtil.DEFAULT_PRECISION
					: ratePrecision;

			if (FXOStringUtility.isNotEmpty(strikeSolverResponseDTO.getSpot())) {
				strikeSolverResponseDTO.setSpot(MarketRateUtility
						.invertRateSpread(strikeSolverResponseDTO.getSpot(),
								ratePrecision));
			}

			if (FXOStringUtility.isNotEmpty(strikeSolverResponseDTO
					.getForward())) {
				strikeSolverResponseDTO.setForward(MarketRateUtility
						.invertRateSpread(strikeSolverResponseDTO.getForward(),
								ratePrecision));
			}

			strikeSolverResponseDTO.setLegStrategy(LegStrategies
					.invert(strikeSolverResponseDTO.getLegStrategy()));
		}

		return strikeSolverResponseDTO;
	}

	public BigDecimal adjustToCurrencyPairPrecision(String decimalValueString,
			String currency, String counterCurrency) {

		return MathUtil.createBigDecimal(decimalValueString,
				getRatePrecisionForCurrencyPair(currency, counterCurrency));
	}

	public BigDecimal adjustToCurrencyPairPrecision(BigDecimal decimalValue,
			String currency, String counterCurrency) {

		return MathUtil.roundAndAdjustToPrecision(decimalValue,
				getRatePrecisionForCurrencyPair(currency, counterCurrency));
	}

	public String formatFenicsTimeString(String fenicsTimeString) {

		return fenicsTimeString.split(FXOWSConstantKeys.SPACE_DELIMITER)[0];
	}

	public Integer getRatePrecisionForCurrencyPair(String currency,
			String counterCurrency) {

		Integer ratePrecision = currencyPairService.getPrecision(currency,
				counterCurrency);

		return (ratePrecision == null) ? MathUtil.DEFAULT_PRECISION
				: ratePrecision;
	}

}