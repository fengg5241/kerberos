package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DeltaHedgeValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)
	private BigDecimal deltaSpot;
	private String strategy;
	private String maturity;

	public static DeltaHedgeValidationDTO instance(BigDecimal deltaSpot) {
		return new DeltaHedgeValidationDTO().setDeltaSpot(deltaSpot);
	}

	public BigDecimal getDeltaSpot() {
		return deltaSpot;
	}

	public DeltaHedgeValidationDTO setDeltaSpot(BigDecimal deltaSpot) {
		this.deltaSpot = deltaSpot;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public DeltaHedgeValidationDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public DeltaHedgeValidationDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

}
