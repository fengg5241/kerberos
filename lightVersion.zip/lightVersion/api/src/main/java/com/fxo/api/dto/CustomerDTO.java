package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class CustomerDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String customerId;

	private String rmName;

	private String rmEmailAddress;

	private String customerReference;

	private String customerType;

	private String interPortfolio;

	public String getCustomerId() {
		return customerId;
	}

	public CustomerDTO setCustomerId(String customerId) {
		this.customerId = customerId;
		return this;
	}

	public String getRmName() {
		return rmName;
	}

	public CustomerDTO setRmName(String rmName) {
		this.rmName = rmName;
		return this;
	}

	public String getRmEmailAddress() {
		return rmEmailAddress;
	}

	public CustomerDTO setRmEmailAddress(String rmEmailAddress) {
		this.rmEmailAddress = rmEmailAddress;
		return this;
	}

	public String getCustomerReference() {
		return customerReference;
	}

	public CustomerDTO setCustomerReference(String customerReference) {
		this.customerReference = customerReference;
		return this;
	}

	public String getCustomerType() {
		return customerType;
	}

	public CustomerDTO setCustomerType(String customerType) {
		this.customerType = customerType;
		return this;
	}

	public String getInterPortfolio() {
		return interPortfolio;
	}

	public CustomerDTO setInterPortfolio(String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

}
