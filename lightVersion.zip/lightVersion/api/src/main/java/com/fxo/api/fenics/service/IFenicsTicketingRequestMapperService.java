package com.fxo.api.fenics.service;

import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.constants.fenics.FenicsRequestPurpose;

public interface IFenicsTicketingRequestMapperService {

	public static final String fenicsRequestPurpose = FenicsRequestPurpose.TICKETING;

	public com.fxo.fenics.request.DataType getFENICSTicketingRequestData(
			TicketingRequestDTO ticketingRequestDTO);

}
