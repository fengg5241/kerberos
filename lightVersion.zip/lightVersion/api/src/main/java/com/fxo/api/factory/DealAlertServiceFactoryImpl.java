package com.fxo.api.factory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.service.IDealAlertService;
import com.fxo.constants.admin.DealValidationCodes;

@Component
public class DealAlertServiceFactoryImpl implements
		DealAlertServiceFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "investmentAmountAlertValidationService")
	private IDealAlertService investmentAmountAlertValidationService;

	@Override
	public IDealAlertService getDealAlertService(
			String validationCode) {
		IDealAlertService dealValidationService = null;

		switch (validationCode) {
		case DealValidationCodes.DEAL_GOVERNANCE_INVESTMENT_AMOUNT_VALIDATION:
			dealValidationService = investmentAmountAlertValidationService;
			break;		
		default:
			break;
		}

		return dealValidationService;
	}

}
