package com.fxo.api.fenics.service;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Products;
import com.fxo.constants.dealing.StrategyTypes;
import com.fxo.fenics.request.NodeType;
import com.fxo.framework.util.FXOStringUtility;

@Component(value = "spreadFenicsPricingRequestMapperService")
public class SpreadFenicsPricingRequestMapperServiceImpl extends
		AbstractFenicsStrategyPricingRequestMapperService {

	public static final String productCode = Products.PRODUCT_SPREAD;

	@Override
	public void setCustomFieldsInFenicsSummaryNode(FieldValueDTO summary,
			NodeType fenicsSummaryNode) {
		String dealingConvention = getDealingConvention(summary);

		// translate Strategy fromFXO-Portal representation to fenics value
		if (FXOStringUtility.isNotEmpty(summary.getStrategy())) {

			String strategyCodeForFenicsMapping = DealingConvention.config
					.isMarketConvention(dealingConvention) ? summary
					.getStrategy() : StrategyTypes
					.invert(summary.getStrategy());

			FXOParametersMappingDTO fxoParametersMappingDTOStrategy = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_STRATEGY,
							strategyCodeForFenicsMapping);

			getFenicsXMLFieldGenerator().generateStrategyField(
					fenicsSummaryNode,
					fxoParametersMappingDTOStrategy.getParameterTargetValue(),
					fenicsRequestPurpose, dealingConvention);
		}

		summary.setModel(getFxoConstantsService().getFXOConstantsValue(
				modelCode));
		getFenicsXMLFieldGenerator().generateModelField(fenicsSummaryNode,
				summary.getModel(), fenicsRequestPurpose, dealingConvention);

	}

	@Override
	public void setCustomFieldsInFenicsLegNode(OptionLegDTO optionLegDTO,
			NodeType fenicsLegNode) {

		// translate direction from FXO-Portal representation to fenics value
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTODirection = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							optionLegDTO.getDirection());

			getFenicsXMLFieldGenerator().generateDirectionField(fenicsLegNode,
					fxoParametersMappingDTODirection.getParameterTargetValue(),
					fenicsRequestPurpose, optionLegDTO.getDealingConvention());
		}

		String legStrategyForFenicsMapping = DealingConvention.config
				.isMarketConvention(optionLegDTO.getDealingConvention()) ? optionLegDTO
				.getLegStrategy() : LegStrategies.invert(optionLegDTO
				.getLegStrategy());

		getFenicsXMLFieldGenerator().generateLegStrategyField(fenicsLegNode,
				legStrategyForFenicsMapping, fenicsRequestPurpose,
				optionLegDTO.getDealingConvention());

		getFenicsXMLFieldGenerator().generateStrikeField(fenicsLegNode,
				optionLegDTO.getStrike(), fenicsRequestPurpose,
				optionLegDTO.getDealingConvention());
	}
}
