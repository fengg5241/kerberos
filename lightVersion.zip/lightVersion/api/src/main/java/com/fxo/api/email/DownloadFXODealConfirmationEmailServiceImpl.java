package com.fxo.api.email;

import java.io.ByteArrayInputStream;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.reports.IFXODealConfirmationReportGenerationService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.email.FXOEmailConstants;
import com.fxo.email.dto.FXOEmailMessageDTO;
import com.fxo.email.dto.FXOEmailMessageHeaderDTO;
import com.fxo.email.service.IFXOEmailGenerationService;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.core.dto.FXOFileInformationDTO;
import com.fxo.framework.util.FXOBooleanUtility;

@Service
public class DownloadFXODealConfirmationEmailServiceImpl extends
		AbstractFXODealConfirmationEmailServiceImpl implements
		IDownloadFXODealConfirmationEmailService {

	private static final Logger logger = LoggerFactory
			.getLogger(DownloadFXODealConfirmationEmailServiceImpl.class);

	@Autowired
	private IFXOEmailGenerationService fxoEmailGenerationService;

	@Autowired
	private IFXODealConfirmationReportGenerationService fxoDealConfirmationReportGenerationService;

	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	public FXOFileInformationDTO downloadDealConfirmationEmail(
			BigInteger ticketNumber) {

		// retrieve TicketDetails
		TicketingResponseDTO ticketingResponseDTO = extractTicketDetails(ticketNumber);

		// generate PDF Report
		FXOFileInformationDTO dealConfirmationPDFReportFile = fxoDealConfirmationReportGenerationService
				.generatePDFReport(ticketingResponseDTO);

		return dealConfirmationPDFReportFile;
	}

	/**
	 * @param dealConfirmationPDFReportFile
	 * @return
	 */
	public MimeMessage generateEmailMessageWithAttachment(
			FXOFileInformationDTO dealConfirmationPDFReportFile) {
		// generate DataHandler with PDF Attachment
		Map<String, DataHandler> attachments = generateDataHandler(dealConfirmationPDFReportFile);

		// initialize EmailMessageDTO
		FXOEmailMessageDTO fxoEmailMessageDTO = new FXOEmailMessageDTO();
		fxoEmailMessageDTO.setAttachments(attachments);
		FXOEmailMessageHeaderDTO fxoEmailMessageHeader = new FXOEmailMessageHeaderDTO();
		fxoEmailMessageHeader.setSubject("");

		Map<String, Object> miscValues = new HashMap<String, Object>();

		miscValues.put(FXOEmailConstants.EMAIL_ADDRESS_NOT_REQURIED,
				FXOBooleanUtility.toStringTrueFalse(Boolean.TRUE));

		fxoEmailMessageHeader.setMiscValues(miscValues);

		fxoEmailMessageDTO.setHeader(fxoEmailMessageHeader);

		fxoEmailMessageDTO.setBody("   ");

		// generate MailMessage Object for download
		MimeMessage mimeMessage = fxoEmailGenerationService
				.generateEmailMessage(fxoEmailMessageDTO);

		// to open in edit/compose mode
		try {
			mimeMessage.addHeader("X-Unsent", "1");
		} catch (MessagingException e) {
			throw new ApplicationRuntimeException(FXOMessageCodes.ERR_EMAIL);
		}

		Objects.requireNonNull(mimeMessage, FXOMessageCodes.ERR_EMAIL);
		return mimeMessage;
	}

	public Map<String, DataHandler> generateDataHandler(
			FXOFileInformationDTO dealConfirmationPDFReportFile) {
		MimeBodyPart attachment = new MimeBodyPart();
		ByteArrayInputStream bis = new ByteArrayInputStream(
				dealConfirmationPDFReportFile.getFileData());

		DataSource dataSource = null;
		try {
			dataSource = new ByteArrayDataSource(bis, "application/pdf");
			attachment.setDataHandler(new DataHandler(dataSource));
			attachment.setFileName(dealConfirmationPDFReportFile.getFileName());
		} catch (Exception e) {
			logger.error("failed to generate attach PDF with error : ");
			throw new IllegalStateException(
					"failed to generate attach PDF with error : "
							+ e.getMessage());
		} catch (Error err) {
			logger.error("error in "
					+ "quoteResponseEmailContentGenerationService.generateEmailEnvelope "
					+ err.getMessage());
		}

		Map<String, DataHandler> attachments = new HashMap<String, DataHandler>();
		attachments.put(dealConfirmationPDFReportFile.getFileName() + ".pdf",
				new DataHandler(dataSource));
		return attachments;
	}

}