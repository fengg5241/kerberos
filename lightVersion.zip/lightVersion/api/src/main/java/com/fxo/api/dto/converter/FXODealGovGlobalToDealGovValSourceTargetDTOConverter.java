package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXODealGovernanceParametersDTO;
import com.fxo.api.dto.FXODealGovernanceValidationConfigDTO;
import com.fxo.framework.core.dto.BaseSourceTargetDTOConverter;

@Component
public class FXODealGovGlobalToDealGovValSourceTargetDTOConverter
		extends
		BaseSourceTargetDTOConverter<FXODealGovernanceParametersDTO, FXODealGovernanceValidationConfigDTO> {

}
