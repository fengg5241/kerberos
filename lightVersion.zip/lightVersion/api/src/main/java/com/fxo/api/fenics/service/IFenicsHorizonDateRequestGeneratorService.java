package com.fxo.api.fenics.service;

import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.exception.ApplicationException;

public interface IFenicsHorizonDateRequestGeneratorService {
	public static final String REQUEST_PREFIX = "HD_";

	public static final String fenicsRequestPurpose = FenicsRequestPurpose.MARKET_RATES;
	public static final String dealingConvention = DealingConvention.DEALING_CONVENTION_MARKET;

	public String getFenicsPricingXML() throws ApplicationException;

}
