package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.math.RoundingMode;

import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.ICurrencyPairProductIntegrationMappingService;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Maturities;
import com.fxo.fenics.util.FenicsMaturityConverter;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;

public abstract class AbstractFenicsProductMapperService {

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private ICurrencyPairProductIntegrationMappingService currencyPairProductIntegrationMappingService;

	public void processCommonFieldsInFenicsOptionLegForPricingResponse(
			OptionLegDTO optionLegDTO) {

		// fetch currency and faceCurrency From Summary
		String currency = optionLegDTO.getCurrency();
		String faceCurrency = optionLegDTO.getFaceCurrency();

		boolean rateInversionRequired = (FXOStringUtility.isEmpty(faceCurrency)) ? false
				: (currency.equals(faceCurrency) ? false : true);

		if (rateInversionRequired) {

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getSpot())) {
				optionLegDTO.setSpot(MarketRateUtility.invertRateSpread(
						optionLegDTO.getSpot(), null));
			}

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getForward())) {
				optionLegDTO.setForward(MarketRateUtility.invertRateSpread(
						optionLegDTO.getForward(), null));
			}

			optionLegDTO.setLegStrategy(LegStrategies.invert(optionLegDTO
					.getLegStrategy()));
		}

		if (FXOStringUtility.isNumeric(optionLegDTO.getSpot())) {
			optionLegDTO.setSpotRate(new BigDecimal(optionLegDTO.getSpot()));
		}

		if (FXOStringUtility.isNumeric(optionLegDTO.getForward())) {
			optionLegDTO.setForwardRate(new BigDecimal(optionLegDTO
					.getForward()));
		}

		if (FXOStringUtility.isNumeric(optionLegDTO.getVolatility())) {
			optionLegDTO.setVolatilityRate(new BigDecimal(optionLegDTO
					.getVolatility()));
		}

		fenicsCustomDateTimeConverter
				.translateFenicsDateStringToDateTime(optionLegDTO);

		if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(optionLegDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation

			optionLegDTO.setMaturity(FenicsMaturityConverter
					.getFXOMaturityCode(optionLegDTO.getMaturity()));

		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							optionLegDTO.getDirection());
			optionLegDTO.setDirection(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		// compute percentage values for premium and counterpremium
		if (optionLegDTO.getAmount() != null
				&& optionLegDTO.getPremium() != null) {

			BigDecimal percentPremium = computePercentageValue(
					optionLegDTO.getPremium(), optionLegDTO.getAmount());
			optionLegDTO.setPercentPremium(percentPremium);
		}

		if (optionLegDTO.getCounterAmount() != null
				&& optionLegDTO.getCounterPremium() != null) {

			BigDecimal percentCounterPremium = computePercentageValue(
					optionLegDTO.getCounterPremium(),
					optionLegDTO.getCounterAmount());
			optionLegDTO.setPercentCounterPremium(percentCounterPremium);
		}

	}

	public BigDecimal computePercentageValue(BigDecimal dividend,
			BigDecimal divisor) {

		String defaultPrecisionString = fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.defaultPrecision);

		Integer defaultPrecision = 6;

		if (FXOStringUtility.isNotEmpty(defaultPrecisionString)) {
			defaultPrecision = Integer.valueOf(defaultPrecisionString);
		}

		return ((dividend.divide(divisor, defaultPrecision,
				RoundingMode.HALF_UP)).multiply(new BigDecimal(100)))
				.setScale(defaultPrecision);
	}

	public void processCommonFieldsInFenicsSummaryNodeForPricingResponse(
			FieldValueDTO summary) {

		// fetch currency and faceCurrency From Summary
		String currency = summary.getCurrency();
		String faceCurrency = summary.getFaceCurrency();

		boolean rateInversionRequired = (currency.equals(faceCurrency)) ? false
				: true;

		if (rateInversionRequired) {

			if (FXOStringUtility.isNotEmpty(summary.getSpot())) {
				summary.setSpot(MarketRateUtility.invertRateSpread(
						summary.getSpot(), null));
			}

			if (FXOStringUtility.isNotEmpty(summary.getForward())) {
				summary.setForward(MarketRateUtility.invertRateSpread(
						summary.getForward(), null));
			}

		}

		if (FXOStringUtility.isNumeric(summary.getSpot())) {
			summary.setSpotRate(new BigDecimal(summary.getSpot()));
		}

		if (FXOStringUtility.isNumeric(summary.getForward())) {
			summary.setForwardRate(new BigDecimal(summary.getForward()));
		}

		if (FXOStringUtility.isNumeric(summary.getVolatility())) {
			summary.setVolatilityRate(new BigDecimal(summary.getVolatility()));
		}

		fenicsCustomDateTimeConverter
				.translateFenicsDateStringToDateTime(summary);

		if (FXOStringUtility.isNotEmpty(summary.getMaturity())
				&& FXOStringUtility.areNotIdentical(summary.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation

			summary.setMaturity(FenicsMaturityConverter
					.getFXOMaturityCode(summary.getMaturity()));

		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(summary.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							summary.getDirection());
			summary.setDirection(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		summary.setAmount(null);
		summary.setCounterAmount(null);
	}

	public IFXOConstantsService getFxoConstantsService() {
		return fxoConstantsService;
	}

	public IFXOParametersMappingService getFxoParametersMappingService() {
		return fxoParametersMappingService;
	}

	public ICurrencyPairProductIntegrationMappingService getCurrencyPairProductIntegrationMappingService() {
		return currencyPairProductIntegrationMappingService;
	}

	public FenicsXMLFieldGenerator getFenicsXMLFieldGenerator() {
		return fenicsXMLFieldGenerator;
	}
}
