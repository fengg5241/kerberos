package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXODealGovernanceParametersCcyPairDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private FXODealGovernanceParametersDTO fxoDealGovernanceParameters;

	private CurrencyPairDTO currencyPair;

	private String direction;

	private Integer legCount;

	private String minimum;

	private BigDecimal minimumPercent;

	private String maximum;

	private BigDecimal maximumPercent;

	private String thresholdCurrency;

	private String active;

	private String validateInDealGovernanceService;
	
	private String alert;
	
	private String validateInTicketingService;


	public String getDirection() {
		return direction;
	}

	public FXODealGovernanceParametersCcyPairDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FXODealGovernanceParametersCcyPairDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public String getMinimum() {
		return minimum;
	}

	public FXODealGovernanceParametersCcyPairDTO setMinimum(String minimum) {
		this.minimum = minimum;
		return this;
	}

	public BigDecimal getMinimumPercent() {
		return minimumPercent;
	}

	public FXODealGovernanceParametersCcyPairDTO setMinimumPercent(
			BigDecimal minimumPercent) {
		this.minimumPercent = minimumPercent;
		return this;
	}

	public String getMaximum() {
		return maximum;
	}

	public FXODealGovernanceParametersCcyPairDTO setMaximum(String maximum) {
		this.maximum = maximum;
		return this;
	}

	public BigDecimal getMaximumPercent() {
		return maximumPercent;
	}

	public FXODealGovernanceParametersCcyPairDTO setMaximumPercent(
			BigDecimal maximumPercent) {
		this.maximumPercent = maximumPercent;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public FXODealGovernanceParametersCcyPairDTO setThresholdCurrency(
			String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXODealGovernanceParametersCcyPairDTO setActive(String active) {
		this.active = active;
		return this;
	}

	public String getValidateInDealGovernanceService() {
		return validateInDealGovernanceService;
	}

	public FXODealGovernanceParametersCcyPairDTO setValidateInDealGovernanceService(
			String validateInDealGovernanceService) {
		this.validateInDealGovernanceService = validateInDealGovernanceService;
		return this;
	}

	public CurrencyPairDTO getCurrencyPair() {
		return currencyPair;
	}

	public FXODealGovernanceParametersCcyPairDTO setCurrencyPair(
			CurrencyPairDTO currencyPair) {
		this.currencyPair = currencyPair;
		return this;
	}

	public FXODealGovernanceParametersDTO getFxoDealGovernanceParameters() {
		return fxoDealGovernanceParameters;
	}

	public FXODealGovernanceParametersCcyPairDTO setFxoDealGovernanceParameters(
			FXODealGovernanceParametersDTO fxoDealGovernanceParameters) {
		this.fxoDealGovernanceParameters = fxoDealGovernanceParameters;
		return this;
	}
	
	public String getAlert() {
		return alert;
	}

	public FXODealGovernanceParametersCcyPairDTO setAlert(String alert) {
		this.alert = alert;
		return this;
	}

	public String getValidateInTicketingService() {
		return validateInTicketingService;
	}

	public FXODealGovernanceParametersCcyPairDTO setValidateInTicketingService(
			String validateInTicketingService) {
		this.validateInTicketingService = validateInTicketingService;
		return this;
	}
	
}
