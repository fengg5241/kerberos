package com.fxo.api.dto;

import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.AuditableDTO;

public class FXOCurrencyDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String currency;

	private Integer amountPrecision;

	private String active;

	@Override
	public FXOCurrencyDTO clone() throws CloneNotSupportedException {
		FXOCurrencyDTO fxoCurrencyDTO = new FXOCurrencyDTO();

		fxoCurrencyDTO.setCurrency(getCurrency())
				.setAmountPrecision(getAmountPrecision())
				.setActive(getActive()).setCreatedBy(getCreatedBy())
				.setCreatedDate(getCreatedDate())
				.setLastUpdatedBy(getLastUpdatedBy())
				.setLastUpdatedDate(getLastUpdatedDate());

		return fxoCurrencyDTO;

	}

	public String getCurrency() {
		return currency;
	}

	public FXOCurrencyDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public Integer getAmountPrecision() {
		return amountPrecision;
	}

	public FXOCurrencyDTO setAmountPrecision(Integer amountPrecision) {
		this.amountPrecision = amountPrecision;
		return this;
	}

	public String getActive() {
		return active;
	}

	public FXOCurrencyDTO setActive(String active) {
		this.active = active;
		return this;
	}

}
