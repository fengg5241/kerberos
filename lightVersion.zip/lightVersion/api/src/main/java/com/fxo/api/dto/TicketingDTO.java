package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class TicketingDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String ticketingRequestId;

	private String ticketingResponseId;

	private String status;

	private String message;

	private String strategy;

	private Integer legs;

	private String backOfficeTicketReferenceNumber;

	private Integer fenicsTicketReferenceNumber;

	private Integer version;

	public String getTicketingRequestId() {
		return ticketingRequestId;
	}

	public TicketingDTO setTicketingRequestId(String ticketingRequestId) {
		this.ticketingRequestId = ticketingRequestId;
		return this;
	}

	public String getTicketingResponseId() {
		return ticketingResponseId;
	}

	public TicketingDTO setTicketingResponseId(String ticketingResponseId) {
		this.ticketingResponseId = ticketingResponseId;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public TicketingDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public String getMessage() {
		return message;
	}

	public TicketingDTO setMessage(String message) {
		this.message = message;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public TicketingDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public Integer getLegs() {
		return legs;
	}

	public TicketingDTO setLegs(Integer legs) {
		this.legs = legs;
		return this;
	}

	public String getBackOfficeTicketReferenceNumber() {
		return backOfficeTicketReferenceNumber;
	}

	public TicketingDTO setBackOfficeTicketReferenceNumber(
			String backOfficeTicketReferenceNumber) {
		this.backOfficeTicketReferenceNumber = backOfficeTicketReferenceNumber;
		return this;
	}

	public Integer getFenicsTicketReferenceNumber() {
		return fenicsTicketReferenceNumber;
	}

	public TicketingDTO setFenicsTicketReferenceNumber(
			Integer fenicsTicketReferenceNumber) {
		this.fenicsTicketReferenceNumber = fenicsTicketReferenceNumber;
		return this;
	}

	public Integer getVersion() {
		return version;
	}

	public TicketingDTO setVersion(Integer version) {
		this.version = version;
		return this;
	}
}
