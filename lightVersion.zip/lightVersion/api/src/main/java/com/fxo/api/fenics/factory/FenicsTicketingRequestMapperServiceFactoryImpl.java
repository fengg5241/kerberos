package com.fxo.api.fenics.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.fenics.service.IFenicsTicketingRequestMapperService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FenicsTicketingRequestMapperServiceFactoryImpl implements
		FenicsTicketingRequestMapperServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsTicketingRequestMapperServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService vanillaFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "straddleFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService straddleFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "strangleFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService strangleFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "riskReversalFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService riskReversalFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "spreadFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService spreadFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "knockInFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService knockInFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "knockOutFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService knockOutFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockInFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService reverseKnockInFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockOutFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService reverseKnockOutFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockInFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService europeanKnockInFenicsTicketingRequestMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockOutFenicsTicketingRequestMapperService")
	private IFenicsTicketingRequestMapperService europeanKnockOutFenicsTicketingRequestMapperService;

	@Override
	public IFenicsTicketingRequestMapperService getFenicsTicketingRequestMapperService(
			String product) {
		IFenicsTicketingRequestMapperService fenicsTicketingRequestMapperService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			fenicsTicketingRequestMapperService = vanillaFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_STRADDLE:
			fenicsTicketingRequestMapperService = straddleFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_STRANGLE:
			fenicsTicketingRequestMapperService = strangleFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			fenicsTicketingRequestMapperService = riskReversalFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_SPREAD:
			fenicsTicketingRequestMapperService = spreadFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_KNOCKIN:
			fenicsTicketingRequestMapperService = knockInFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			fenicsTicketingRequestMapperService = knockOutFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			fenicsTicketingRequestMapperService = reverseKnockInFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			fenicsTicketingRequestMapperService = reverseKnockOutFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			fenicsTicketingRequestMapperService = europeanKnockInFenicsTicketingRequestMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			fenicsTicketingRequestMapperService = europeanKnockOutFenicsTicketingRequestMapperService;
			break;

		default:
			logger.error("failed to locate fenicsTicketingRequestMapperService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return fenicsTicketingRequestMapperService;
	}

}
