package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class MidVolValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private String volatility;

	public String getVolatility() {
		return volatility;
	}

	public MidVolValidationDTO setVolatility(String volatility) {
		this.volatility = volatility;
		return this;
	}

	public static MidVolValidationDTO instance(String volatility) {
		return new MidVolValidationDTO().setVolatility(volatility);
	}

}
