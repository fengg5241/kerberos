package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.api.constraint.ValidPricingRequest;
import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.rest.model.PricingRequestModel;

@AutoProperty
@ValidPricingRequest
public class PricingRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String pricingRequestId;

	private String parentPricingRequestId;

	private UserDTO user;

	private CustomerDTO customer;

	private String requestPurpose;

	private ProductStructureDTO structure;

	private boolean isDeltaHedge;

	private MarketRateResponseDTO currentMarketRateResponse;

	public PricingRequestDTO(String pricingRequestId, ProductStructureDTO structure, UserDTO user,
			CustomerDTO customer) {
		super();
		this.structure = structure;
		this.pricingRequestId = pricingRequestId;
		this.user = user;
		this.customer = customer;
	}

	public PricingRequestDTO() {

	}

	public ProductStructureDTO getStructure() {
		return structure;
	}

	public PricingRequestDTO setStructure(ProductStructureDTO structure) {
		this.structure = structure;
		return this;
	}

	public String getPricingRequestId() {
		return pricingRequestId;
	}

	public PricingRequestDTO setPricingRequestId(String pricingRequestId) {
		this.pricingRequestId = pricingRequestId;
		return this;
	}

	public UserDTO getUser() {
		return user;
	}

	public PricingRequestDTO setUser(UserDTO user) {
		this.user = user;
		return this;
	}

	public String getRequestPurpose() {
		return requestPurpose;
	}

	public PricingRequestDTO setRequestPurpose(String requestPurpose) {
		this.requestPurpose = requestPurpose;
		return this;
	}

	public String getParentPricingRequestId() {
		return parentPricingRequestId;
	}

	public PricingRequestDTO setParentPricingRequestId(String parentPricingRequestId) {
		this.parentPricingRequestId = parentPricingRequestId;
		return this;
	}

	public CustomerDTO getCustomer() {
		return customer;
	}

	public PricingRequestDTO setCustomer(CustomerDTO customer) {
		this.customer = customer;
		return this;
	}

	public static PricingRequestDTO getInstance(String product) {
		return new PricingRequestDTO().setStructure(ProductStructureDTO.instance(product));
	}

	public static PricingRequestDTO getInstanceWithEmptyLegs(String product) {
		PricingRequestDTO pricingRequestDTO = new PricingRequestDTO()
				.setStructure(ProductStructureDTO.instance(product));

		pricingRequestDTO.getStructure().getStrategies().get(0).getLegs().clear();

		return pricingRequestDTO;
	}

	public boolean getIsDeltaHedge() {
		return isDeltaHedge;
	}

	public PricingRequestDTO setIsDeltaHedge(boolean isDeltaHedge) {
		this.isDeltaHedge = isDeltaHedge;
		return this;
	}

	public void setDeltaHedge(boolean isDeltaHedge) {
		this.isDeltaHedge = isDeltaHedge;
	}

	public MarketRateResponseDTO getCurrentMarketRateResponse() {
		return currentMarketRateResponse;
	}

	public PricingRequestDTO setCurrentMarketRateResponse(MarketRateResponseDTO currentMarketRateResponse) {
		this.currentMarketRateResponse = currentMarketRateResponse;
		return this;
	}

}
