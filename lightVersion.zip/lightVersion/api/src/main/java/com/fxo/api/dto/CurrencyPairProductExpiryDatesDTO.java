package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class CurrencyPairProductExpiryDatesDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private CurrencyPairProductDTO currencyPairProduct;

	private LocalDate expiryDateThresholdMin;

	private LocalDate expiryDateThresholdMax;

	private LocalDate expiryDate;

	public CurrencyPairProductDTO getCurrencyPairProduct() {
		return currencyPairProduct;
	}

	public CurrencyPairProductExpiryDatesDTO setCurrencyPairProduct(
			CurrencyPairProductDTO currencyPairProduct) {
		this.currencyPairProduct = currencyPairProduct;
		return this;
	}

	public LocalDate getExpiryDateThresholdMin() {
		return expiryDateThresholdMin;
	}

	public CurrencyPairProductExpiryDatesDTO setExpiryDateThresholdMin(
			LocalDate expiryDateThresholdMin) {
		this.expiryDateThresholdMin = expiryDateThresholdMin;
		return this;
	}

	public LocalDate getExpiryDateThresholdMax() {
		return expiryDateThresholdMax;
	}

	public CurrencyPairProductExpiryDatesDTO setExpiryDateThresholdMax(
			LocalDate expiryDateThresholdMax) {
		this.expiryDateThresholdMax = expiryDateThresholdMax;
		return this;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public CurrencyPairProductExpiryDatesDTO setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

}
