package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class StrikeSolverRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String strikeSolverRequestId;

	private String product;

	private String currency;

	private String counterCurrency;

	private String faceCurrency;

	private String premiumCurrency;

	private String cutoff;

	private String direction;

	private String legStrategy;

	private String optionType;

	private String optionClass;

	private String optionStyle;

	private DateTime horizonDate;

	private String maturity;

	private DateTime expiryDate;

	private DateTime deliveryDate;

	private BigDecimal amount;

	private BigDecimal internalCost;

	private BigDecimal spotRate;

	private BigDecimal forwardRate;

	private String volatility;

	public String getStrikeSolverRequestId() {
		return strikeSolverRequestId;
	}

	public StrikeSolverRequestDTO setStrikeSolverRequestId(
			String strikeSolverRequestId) {
		this.strikeSolverRequestId = strikeSolverRequestId;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public StrikeSolverRequestDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public StrikeSolverRequestDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getFaceCurrency() {
		return faceCurrency;
	}

	public StrikeSolverRequestDTO setFaceCurrency(String faceCurrency) {
		this.faceCurrency = faceCurrency;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public StrikeSolverRequestDTO setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public StrikeSolverRequestDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getLegStrategy() {
		return legStrategy;
	}

	public StrikeSolverRequestDTO setLegStrategy(String legStrategy) {
		this.legStrategy = legStrategy;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public StrikeSolverRequestDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public StrikeSolverRequestDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public StrikeSolverRequestDTO setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
		return this;
	}

	public DateTime getHorizonDate() {
		return horizonDate;
	}

	public StrikeSolverRequestDTO setHorizonDate(DateTime horizonDate) {
		this.horizonDate = horizonDate;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public StrikeSolverRequestDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public StrikeSolverRequestDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public StrikeSolverRequestDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public StrikeSolverRequestDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public BigDecimal getForwardRate() {
		return forwardRate;
	}

	public StrikeSolverRequestDTO setForwardRate(BigDecimal forwardRate) {
		this.forwardRate = forwardRate;
		return this;
	}

	public String getVolatility() {
		return volatility;
	}

	public StrikeSolverRequestDTO setVolatility(String volatility) {
		this.volatility = volatility;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public StrikeSolverRequestDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public String getCutoff() {
		return cutoff;
	}

	public StrikeSolverRequestDTO setCutOff(String cutoff) {
		this.cutoff = cutoff;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public StrikeSolverRequestDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public void setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
	}

}
