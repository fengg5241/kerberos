package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyDTO;
import com.fxo.dao.entity.Currency;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class CurrencyDTOEntityConverter extends
        BaseDTOEntityConverter<CurrencyDTO, Currency> {

}
