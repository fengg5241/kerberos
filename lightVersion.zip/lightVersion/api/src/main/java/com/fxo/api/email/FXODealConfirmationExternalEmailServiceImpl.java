package com.fxo.api.email;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.reports.IFXODealConfirmationReportGenerationService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.email.FXOEmailConstants;
import com.fxo.email.dto.FXOEmailMessageDTO;
import com.fxo.email.dto.FXOEmailMessageHeaderDTO;
import com.fxo.email.service.IFXOEmailService;
import com.fxo.framework.util.FXOStringUtility;

@Service(value = "fxoDealConfirmationExternalEmailService")
public class FXODealConfirmationExternalEmailServiceImpl extends
		AbstractFXODealConfirmationEmailServiceImpl implements
		IFXODealConfirmationEmailService {

	@Autowired
	private IFXODealConfirmationReportGenerationService dealConfirmationReportGenerationService;

	@Autowired
	private IFXOEmailService fxoEmailService;

	private static final Logger logger = LoggerFactory
			.getLogger(FXODealConfirmationExternalEmailServiceImpl.class);

	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Async
	@Override
	public void sendDealConfirmation(String ticketNumber) {

		TicketingResponseDTO ticketingResponseDTO = extractTicketDetails((FXOStringUtility
				.isNotEmpty(ticketNumber)) ? new BigInteger(ticketNumber)
				: null);

		Map<String, Object> emailContent = dealConfirmationReportGenerationService
				.generateHTMLEmailBody(ticketingResponseDTO);

		String emailBodyContent = (String) emailContent
				.get(FXOEmailConstants.EMAIL_BODY_HTML_CONTENTS);

		Objects.requireNonNull(emailBodyContent,
				FXOMessageCodes.ERR_EXTERNAL_EMAIL_BODY);

		// create instance of type FXOEmailMessageDTO
		FXOEmailMessageDTO fxoEmailMessageEnvelope = FXOEmailMessageDTO
				.instance().setBody(emailBodyContent);

		Set<String> destinationEmailAddressSet = new HashSet<String>();

		// get Email Addresses of user and RM
		String userEmailAddress = (ticketingResponseDTO.getUser() != null) ? ticketingResponseDTO
				.getUser().getUserEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(userEmailAddress)) {
			destinationEmailAddressSet.add(userEmailAddress);
		}

		String rmEmailAddress = (ticketingResponseDTO.getCustomer() != null) ? ticketingResponseDTO
				.getCustomer().getRmEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(rmEmailAddress)) {
			destinationEmailAddressSet.add(rmEmailAddress);
		}

		// create instance of type FXOEmailMessageHeaderDTO
		FXOEmailMessageHeaderDTO fxoEmailMessageHeader = FXOEmailMessageHeaderDTO
				.instance();

		if (!destinationEmailAddressSet.isEmpty()) {
			fxoEmailMessageHeader
					.setDestinationEmailAddressList(new ArrayList<String>(
							destinationEmailAddressSet));
		}

		// Constructing the emailBody

		fxoEmailMessageHeader.setSubject(String.format(
				"[External Email] - DBS FXO Deal Summary for ticket %s %s",
				ticketNumber, ticketingResponseDTO.getStructure()
						.getProductDescription()));

		Map<String, Object> miscValues = new HashMap<String, Object>();
		miscValues.put(FXOEmailConstants.HTML_EMAIL_LOGO_PATH,
				emailContent.get(FXOEmailConstants.HTML_LOGO_PATH));
		fxoEmailMessageHeader.setMiscValues(miscValues);

		// set EmailHeader in EmailEnvelope
		fxoEmailMessageEnvelope.setHeader(fxoEmailMessageHeader);

		// send EmailMessage
		fxoEmailService.sendMessage(fxoEmailMessageEnvelope);
	}

}
