package com.fxo.api.fenics.service;

import java.util.Objects;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.Products;

@Component(value = "spreadFenicsTicketingRequestMapperService")
public class SpreadFenicsTicketingRequestMapperServiceImpl extends
		AbstractFenicsStrategyTicketingRequestMapperService {

	public static final String productCode = Products.PRODUCT_SPREAD;
	public static final String modelCode = FXOWSConstantKeys.fenicsSimpleOptionModel;

	public void generateCustomFieldsInFenicsOptionLegNode(
			OptionLegDTO optionLegDTO, FieldValueDTO summary,
			com.fxo.fenics.request.NodeType fenicsLegNode) {

		getFenicsXMLFieldGenerator().generateLegStrategyField(fenicsLegNode,
				summary.getLegStrategy(), fenicsRequestPurpose,
				summary.getDealingConvention());

		// translate direction from fenics value to FXO-Portal
		// representation
		FXOParametersMappingDTO fxoParametersMappingDTODirection = getFxoParametersMappingService()
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
						optionLegDTO.getDirection());

		getFenicsXMLFieldGenerator().generateDirectionField(fenicsLegNode,
				fxoParametersMappingDTODirection.getParameterTargetValue(),
				fenicsRequestPurpose, summary.getDealingConvention());

		getFenicsXMLFieldGenerator().generateStrikeField(fenicsLegNode,
				optionLegDTO.getStrike(), fenicsRequestPurpose,
				summary.getDealingConvention());

		String ticketingModel = getFxoConstantsService().getFXOConstantsValue(
				modelCode);

		Objects.requireNonNull(ticketingModel,
				FXOMessageCodes.ERR_INVALID_TICKETING_MODEL);

		getFenicsXMLFieldGenerator().generateModelField(fenicsLegNode,
				ticketingModel, fenicsRequestPurpose,
				optionLegDTO.getDealingConvention());

	}

}
