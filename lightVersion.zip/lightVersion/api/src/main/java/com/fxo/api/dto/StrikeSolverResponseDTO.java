package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class StrikeSolverResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String strikeSolverRequestId;

	private String product;

	private String currency;

	private String counterCurrency;

	private String faceCurrency;

	private String premiumCurrency;

	private String cutoff;

	private String direction;

	private String legStrategy;

	private String optionType;

	private String optionClass;

	private String optionStyle;

	private DateTime horizonDate;

	private String horizonDateString;

	private String maturity;

	private DateTime expiryDate;

	private String expiryDateString;

	private String expiryTimeString;

	private DateTime deliveryDate;

	private String deliveryDateString;

	private BigDecimal amount;

	private BigDecimal internalCost;

	private BigDecimal premium;

	private BigDecimal counterPremium;

	private String spot;

	private String forward;

	private String volatility;

	private BigDecimal strike;

	public String getStrikeSolverRequestId() {
		return strikeSolverRequestId;
	}

	public StrikeSolverResponseDTO setStrikeSolverRequestId(
			String strikeSolverRequestId) {
		this.strikeSolverRequestId = strikeSolverRequestId;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public StrikeSolverResponseDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public StrikeSolverResponseDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getFaceCurrency() {
		return faceCurrency;
	}

	public StrikeSolverResponseDTO setFaceCurrency(String faceCurrency) {
		this.faceCurrency = faceCurrency;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public StrikeSolverResponseDTO setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public StrikeSolverResponseDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getLegStrategy() {
		return legStrategy;
	}

	public StrikeSolverResponseDTO setLegStrategy(String legStrategy) {
		this.legStrategy = legStrategy;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public StrikeSolverResponseDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public StrikeSolverResponseDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public StrikeSolverResponseDTO setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
		return this;
	}

	public DateTime getHorizonDate() {
		return horizonDate;
	}

	public StrikeSolverResponseDTO setHorizonDate(DateTime horizonDate) {
		this.horizonDate = horizonDate;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public StrikeSolverResponseDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public StrikeSolverResponseDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public StrikeSolverResponseDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public String getVolatility() {
		return volatility;
	}

	public StrikeSolverResponseDTO setVolatility(String volatility) {
		this.volatility = volatility;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public StrikeSolverResponseDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public String getCutoff() {
		return cutoff;
	}

	public StrikeSolverResponseDTO setCutoff(String cutoff) {
		this.cutoff = cutoff;
		return this;
	}

	public BigDecimal getStrike() {
		return strike;
	}

	public StrikeSolverResponseDTO setStrike(BigDecimal strike) {
		this.strike = strike;
		return this;
	}

	public String getSpot() {
		return spot;
	}

	public StrikeSolverResponseDTO setSpot(String spot) {
		this.spot = spot;
		return this;
	}

	public String getForward() {
		return forward;
	}

	public StrikeSolverResponseDTO setForward(String forward) {
		this.forward = forward;
		return this;
	}

	public String getExpiryDateString() {
		return expiryDateString;
	}

	public StrikeSolverResponseDTO setExpiryDateString(String expiryDateString) {
		this.expiryDateString = expiryDateString;
		return this;
	}

	public String getExpiryTimeString() {
		return expiryTimeString;
	}

	public StrikeSolverResponseDTO setExpiryTimeString(String expiryTimeString) {
		this.expiryTimeString = expiryTimeString;
		return this;
	}

	public String getDeliveryDateString() {
		return deliveryDateString;
	}

	public StrikeSolverResponseDTO setDeliveryDateString(
			String deliveryDateString) {
		this.deliveryDateString = deliveryDateString;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public StrikeSolverResponseDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public StrikeSolverResponseDTO setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
		return this;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public StrikeSolverResponseDTO setPremium(BigDecimal premium) {
		this.premium = premium;
		return this;
	}

	public BigDecimal getCounterPremium() {
		return counterPremium;
	}

	public StrikeSolverResponseDTO setCounterPremium(BigDecimal counterPremium) {
		this.counterPremium = counterPremium;
		return this;
	}

	public String getHorizonDateString() {
		return horizonDateString;
	}

	public StrikeSolverResponseDTO setHorizonDateString(String horizonDateString) {
		this.horizonDateString = horizonDateString;
		return this;
	}

}
