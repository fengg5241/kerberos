package com.fxo.api.fenics.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.dealing.OptionClasses;
import com.fxo.constants.dealing.OptionStyles;
import com.fxo.constants.dealing.OptionTypes;
import com.fxo.constants.dealing.Products;

@Component(value = "reverseKnockOutFenicsPricingResponseMapperService")
public class ReverseKnockOutFenicsPricingResponseMapperServiceImpl extends
		AbstractFenicsSingleLegPricingResponseMapperService {

	private static final Logger logger = LoggerFactory
			.getLogger(ReverseKnockOutFenicsPricingResponseMapperServiceImpl.class);

	public static final String productCode = Products.PRODUCT_REVERSE_KNOCKOUT;
	public static final String optionStyle = OptionStyles.OPTION_STYLE_EUROPEAN;
	public static final String optionType = OptionTypes.OPTION_TYPE_REVERSE_KNOCKOUT;
	public static final String optionClass = OptionClasses.OPTION_CLASS_SINGLE_BARRIER;

	public void setCustomFieldsInOptionLeg(OptionLegDTO optionLegDTO) {
		optionLegDTO.setProduct(productCode).setOptionStyle(optionStyle)
				.setOptionType(optionType).setOptionClass(optionClass);
	}
}
