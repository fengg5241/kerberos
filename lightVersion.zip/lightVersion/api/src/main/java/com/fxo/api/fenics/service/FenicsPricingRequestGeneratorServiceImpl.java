package com.fxo.api.fenics.service;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.fenics.factory.FenicsPricingRequestMapperServiceFactory;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.ActionType;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;

/**
 * The Class FenicsPricingRequestGeneratorServiceImpl.
 */
@Component
public class FenicsPricingRequestGeneratorServiceImpl implements
		IFenicsPricingRequestGeneratorService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(FenicsPricingRequestGeneratorServiceImpl.class);

	public static final String FENICS_LOGGER = "com.fxo.fenics.logger";

	private static final Logger fenicsLogger = LoggerFactory
			.getLogger(FENICS_LOGGER);

	/** The fenics xml processing service. */
	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	/** The fxo constants service. */
	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsPricingRequestMapperServiceFactory fenicsPricingRequestMapperServiceFactory;

	@Override
	public String getFenicsPricingRequest(PricingRequestDTO pricingRequestDTO)
			throws ApplicationException {

		BodyType fenicsRequestBody = populateFenicsRequestBody(pricingRequestDTO);

		String fenicsRequestXML = fenicsXMLProcessingService.compositeXML(
				fenicsRequestBody, pricingRequestDTO.getPricingRequestId(),
				null);

		fenicsLogger.info(String.format(
				"Fenics-PricingRequest [ %s ] XML built: %s",
				pricingRequestDTO.getPricingRequestId(), fenicsRequestXML));

		return fenicsRequestXML;

	}

	/**
	 * Populate FENICS-RequestBody
	 * 
	 *
	 * @param pricingRequestDTO
	 * @return the body type
	 */
	public BodyType populateFenicsRequestBody(
			PricingRequestDTO pricingRequestDTO) {

		// Declare an object of BodyType (Fenics Body Node)
		BodyType fenicsBody = BodyType.instance().setAction(
				populateRequestAction());

		// declare an object of DataType (Fenics Data Node)
		DataType fenicsData = fenicsPricingRequestMapperServiceFactory
				.getFenicsPricingRequestMapperService(
						pricingRequestDTO.getStructure().getProduct())
				.getFENICSPricingRequestData(pricingRequestDTO);

		// add dataType to Body
		fenicsBody.getData().add(fenicsData);

		// return body
		return fenicsBody;
	}

	/**
	 * Populate request action.
	 * 
	 *
	 * @param strategyDTO
	 *            [{@link StrategyDTO}]
	 * @return actionTypeObject [{@link ActionType}]
	 */
	public ActionType populateRequestAction() {

		ActionType action = ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrActionTypeFunc));

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeCalcName))
				.setOptionValue(FenicsCalculationParameters.SIDED);

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenVal));

		OptionType option3 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataRef));

		action.getOption().addAll(Arrays.asList(option1, option2, option3));

		return action;
	}
}
