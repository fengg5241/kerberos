package com.fxo.api.fenics.service;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.exception.ApplicationException;

public interface IFenicsPricingRequestGeneratorService {

	public String getFenicsPricingRequest(PricingRequestDTO pricingRequestDTO)
			throws ApplicationException;

}
