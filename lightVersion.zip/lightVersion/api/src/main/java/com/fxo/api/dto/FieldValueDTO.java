package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.rest.model.FieldValueModel;

@AutoProperty
public class FieldValueDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	public FieldValueDTO() {
	}

	// option details
	private String product;
	private String optionType;
	private String optionClass;
	private String optionStyle;
	private String purpose;

	// customer
	private String counterParty;
	private String customerType;
	private String interPortfolio;

	// fenics Key Inputs
	private String market;
	private String scenario;
	private String model;
	private String book;
	private String broker;
	private String trader;

	// Transaction Inputs
	private String solveFor;
	private String direction;
	private String currency;
	private String counterCurrency;
	private Boolean hasACommodity;
	private String legStrategy;
	private String strategy;

	// option details
	private String requestType;
	private Integer legCount = 0;

	// Product & Fenics Option Details
	private String dealingConvention;
	private String fenicsOptionClass;
	private String cutoff;

	// Fenics Node Details
	private boolean nestedNode = false;
	private String calculationType;

	// Amount & Amount Currency
	private String faceCurrency;
	private BigDecimal amount;
	private BigDecimal notionalInPremiumCurrency;
	private BigDecimal counterAmount;
	private BigDecimal counterNotionalInPremiumCurrency;

	// maturity & Dates
	private String maturity;
	private DateTime expiryDate;
	private String expiryDateString;
	private DateTime expiryTime;
	private String expiryTimeString;
	private Integer daysToExpiry;
	private Integer tradeDateToExpiryDate;
	private DateTime deliveryDate;
	private String deliveryDateString;
	private Integer daysToDelivery;
	private Integer tradeDateToDeliveryDate;
	private DateTime premiumDate;
	private String premiumDateString;
	private DateTime valueDate;
	private String valueDateString;
	private DateTime horizonDate;
	private String horizonDateString;
	private DateTime spotDate;
	private String spotDateString;

	// Strike & Triggers
	private BigDecimal strike;
	private BigDecimal counterStrike;
	private BigDecimal trigger;
	private BigDecimal loTrigger;
	private BigDecimal hiTrigger;

	// market Data
	private Integer ratePrecision;

	// spot
	private String spot;
	private BigDecimal spotRate;
	private BigDecimal bidSpotRate;
	private BigDecimal askSpotRate;
	private BigDecimal callCurrencyToUSDSpotRate;
	private BigDecimal putCurrencyToUSDSpotRate;

	// forward
	private String forward;
	private BigDecimal forwardRate;
	private BigDecimal bidForwardRate;
	private BigDecimal askForwardRate;

	// volatility
	private String volatility;
	private BigDecimal volatilityRate;
	private BigDecimal bidVolatilityRate;
	private BigDecimal askVolatilityRate;

	// margin
	private BigDecimal marginAmount = BigDecimal.ZERO;
	private String localMarginCurrency;
	private BigDecimal localMarginSpotRate;
	private String localMarginSpotCurrency;
	private String localMarginSpotCounterCurrency;
	private BigDecimal localMarginAmount = BigDecimal.ZERO;
	private BigDecimal counterLocalMarginSpotRate;
	private String counterLocalMarginSpotCurrency;
	private String counterLocalMarginSpotCounterCurrency;
	private BigDecimal counterLocalMarginAmount = BigDecimal.ZERO;

	// premium
	private String premiumCurrency;
	private String premiumType;
	private BigDecimal premium;
	private BigDecimal percentPremium;
	private String percentPremiumAsString;
	private BigDecimal counterPremium;
	private BigDecimal percentCounterPremium;
	private String percentCounterPremiumAsString;

	// Internal Cost
	private BigDecimal internalCost;
	private BigDecimal percentInternalCost;
	private String percentInternalCostAsString;

	// greeks
	private BigDecimal percentDelta;
	private BigDecimal delta;
	private BigDecimal percentVega;
	private BigDecimal vega;

	// Dollar Amounts (Greeks)
	private BigDecimal percentVegaAmount;
	private BigDecimal counterPercentVegaAmount;
	private BigDecimal vegaAmount;
	private BigDecimal counterVegaAmount;
	private BigDecimal percentDeltaAmount;
	private BigDecimal counterPercentDeltaAmount;
	private BigDecimal deltaAmount;
	private BigDecimal counterDeltaAmount;
	private BigDecimal breakEven;
	private BigDecimal counterBreakEven;
	
	// Fenics Specific Fields
	private BigDecimal stealth;

	// Murex ticket Identifiers
	private String backOfficeReferenceNumber;
	
	//Customized fields
	private String avaloqId;
	private String systemSourceId;
	private String murexId;

	public String getStrategy() {
		return strategy;
	}

	public FieldValueDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public FieldValueDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getCutoff() {
		return cutoff;
	}

	public FieldValueDTO setCutoff(String cutoff) {
		this.cutoff = cutoff;
		return this;
	}

	public String getMarket() {
		return market;
	}

	public FieldValueDTO setMarket(String market) {
		this.market = market;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public FieldValueDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FieldValueDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public FieldValueDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public FieldValueDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public FieldValueDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public BigDecimal getStrike() {
		return strike;
	}

	public FieldValueDTO setStrike(BigDecimal strike) {
		this.strike = strike;
		return this;
	}

	public BigDecimal getTrigger() {
		return trigger;
	}

	public FieldValueDTO setTrigger(BigDecimal trigger) {
		this.trigger = trigger;
		return this;
	}

	public BigDecimal getLoTrigger() {
		return loTrigger;
	}

	public FieldValueDTO setLoTrigger(BigDecimal loTrigger) {
		this.loTrigger = loTrigger;
		return this;
	}

	public BigDecimal getHiTrigger() {
		return hiTrigger;
	}

	public FieldValueDTO setHiTrigger(BigDecimal hiTrigger) {
		this.hiTrigger = hiTrigger;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FieldValueDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getFaceCurrency() {
		return faceCurrency;
	}

	public FieldValueDTO setFaceCurrency(String faceCurrency) {
		this.faceCurrency = faceCurrency;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public FieldValueDTO setPremiumCurrency(String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public FieldValueDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public BigDecimal getCounterAmount() {
		return counterAmount;
	}

	public FieldValueDTO setCounterAmount(BigDecimal counterAmount) {
		this.counterAmount = counterAmount;
		return this;
	}

	public String getModel() {
		return model;
	}

	public FieldValueDTO setModel(String model) {
		this.model = model;
		return this;
	}

	public String getPremiumType() {
		return premiumType;
	}

	public FieldValueDTO setPremiumType(String premiumType) {
		this.premiumType = premiumType;
		return this;
	}

	public DateTime getPremiumDate() {
		return premiumDate;
	}

	public FieldValueDTO setPremiumDate(DateTime premiumDate) {
		this.premiumDate = premiumDate;
		return this;
	}

	public DateTime getValueDate() {
		return valueDate;
	}

	public FieldValueDTO setValueDate(DateTime valueDate) {
		this.valueDate = valueDate;
		return this;
	}

	public String getBook() {
		return book;
	}

	public FieldValueDTO setBook(String book) {
		this.book = book;
		return this;
	}

	public String getBroker() {
		return broker;
	}

	public FieldValueDTO setBroker(String broker) {
		this.broker = broker;
		return this;
	}

	public String getCounterParty() {
		return counterParty;
	}

	public FieldValueDTO setCounterParty(String counterParty) {
		this.counterParty = counterParty;
		return this;
	}

	public String getTrader() {
		return trader;
	}

	public FieldValueDTO setTrader(String trader) {
		this.trader = trader;
		return this;
	}

	public BigDecimal getMarginAmount() {
		return marginAmount;
	}

	public FieldValueDTO setMarginAmount(BigDecimal marginAmount) {
		this.marginAmount = marginAmount;
		return this;
	}

	public String getBackOfficeReferenceNumber() {
		return backOfficeReferenceNumber;
	}

	public FieldValueDTO setBackOfficeReferenceNumber(
			String backOfficeReferenceNumber) {
		this.backOfficeReferenceNumber = backOfficeReferenceNumber;
		return this;
	}

	public DateTime getHorizonDate() {
		return horizonDate;
	}

	public FieldValueDTO setHorizonDate(DateTime horizonDate) {
		this.horizonDate = horizonDate;
		return this;
	}

	public DateTime getSpotDate() {
		return spotDate;
	}

	public FieldValueDTO setSpotDate(DateTime spotDate) {
		this.spotDate = spotDate;
		return this;
	}

	public String getSpot() {
		return spot;
	}

	public FieldValueDTO setSpot(String spot) {
		this.spot = spot;
		return this;
	}

	public String getForward() {
		return forward;
	}

	public FieldValueDTO setForward(String forward) {
		this.forward = forward;
		return this;
	}

	public BigDecimal getForwardRate() {
		return forwardRate;
	}

	public FieldValueDTO setForwardRate(BigDecimal forwardRate) {
		this.forwardRate = forwardRate;
		return this;
	}

	public String getVolatility() {
		return volatility;
	}

	public FieldValueDTO setVolatility(String volatility) {
		this.volatility = volatility;
		return this;
	}

	public String getScenario() {
		return scenario;
	}

	public FieldValueDTO setScenario(String scenario) {
		this.scenario = scenario;
		return this;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public FieldValueDTO setPremium(BigDecimal premium) {
		this.premium = premium;
		return this;
	}

	public BigDecimal getCounterPremium() {
		return counterPremium;
	}

	public FieldValueDTO setCounterPremium(BigDecimal counterPremium) {
		this.counterPremium = counterPremium;
		return this;
	}

	public BigDecimal getPercentDelta() {
		return percentDelta;
	}

	public FieldValueDTO setPercentDelta(BigDecimal percentDelta) {
		this.percentDelta = percentDelta;
		return this;
	}

	public BigDecimal getDelta() {
		return delta;
	}

	public FieldValueDTO setDelta(BigDecimal delta) {
		this.delta = delta;
		return this;
	}

	public BigDecimal getStealth() {
		return stealth;
	}

	public FieldValueDTO setStealth(BigDecimal stealth) {
		this.stealth = stealth;
		return this;
	}

	public BigDecimal getPercentVega() {
		return percentVega;
	}

	public FieldValueDTO setPercentVega(BigDecimal percentVega) {
		this.percentVega = percentVega;
		return this;
	}

	public BigDecimal getPercentVegaAmount() {
		return percentVegaAmount;
	}

	public FieldValueDTO setPercentVegaAmount(BigDecimal percentVegaAmount) {
		this.percentVegaAmount = percentVegaAmount;
		return this;
	}

	public BigDecimal getCounterPercentDeltaAmount() {
		return counterPercentDeltaAmount;
	}

	public FieldValueDTO setCounterPercentDeltaAmount(
			BigDecimal counterPercentDeltaAmount) {
		this.counterPercentDeltaAmount = counterPercentDeltaAmount;
		return this;
	}

	public BigDecimal getCounterDeltaAmount() {
		return counterDeltaAmount;
	}

	public FieldValueDTO setCounterDeltaAmount(BigDecimal counterDeltaAmount) {
		this.counterDeltaAmount = counterDeltaAmount;
		return this;
	}

	public BigDecimal getCounterPercentVegaAmount() {
		return counterPercentVegaAmount;
	}

	public FieldValueDTO setCounterPercentVegaAmount(
			BigDecimal counterPercentVegaAmount) {
		this.counterPercentVegaAmount = counterPercentVegaAmount;
		return this;
	}

	public BigDecimal getCounterVegaAmount() {
		return counterVegaAmount;
	}

	public FieldValueDTO setCounterVegaAmount(BigDecimal counterVegaAmount) {
		this.counterVegaAmount = counterVegaAmount;
		return this;
	}

	public BigDecimal getPercentDeltaAmount() {
		return percentDeltaAmount;
	}

	public FieldValueDTO setPercentDeltaAmount(BigDecimal percentDeltaAmount) {
		this.percentDeltaAmount = percentDeltaAmount;
		return this;
	}

	public BigDecimal getDeltaAmount() {
		return deltaAmount;
	}

	public FieldValueDTO setDeltaAmount(BigDecimal deltaAmount) {
		this.deltaAmount = deltaAmount;
		return this;
	}

	public BigDecimal getVega() {
		return vega;
	}

	public FieldValueDTO setVega(BigDecimal vega) {
		this.vega = vega;
		return this;
	}

	public BigDecimal getVegaAmount() {
		return vegaAmount;
	}

	public FieldValueDTO setVegaAmount(BigDecimal vegaAmount) {
		this.vegaAmount = vegaAmount;
		return this;
	}

	public String getLegStrategy() {
		return legStrategy;
	}

	public FieldValueDTO setLegStrategy(String legStrategy) {
		this.legStrategy = legStrategy;
		return this;
	}

	public String getSolveFor() {
		return solveFor;
	}

	public FieldValueDTO setSolveFor(String solveFor) {
		this.solveFor = solveFor;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public FieldValueDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public DateTime getExpiryTime() {
		return expiryTime;
	}

	public FieldValueDTO setExpiryTime(DateTime expiryTime) {
		this.expiryTime = expiryTime;
		return this;
	}

	public String getFenicsOptionClass() {
		return fenicsOptionClass;
	}

	public FieldValueDTO setFenicsOptionClass(String fenicsOptionClass) {
		this.fenicsOptionClass = fenicsOptionClass;
		return this;
	}

	public String getPurpose() {
		return purpose;
	}

	public FieldValueDTO setPurpose(String purpose) {
		this.purpose = purpose;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public FieldValueDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public BigDecimal getVolatilityRate() {
		return volatilityRate;
	}

	public FieldValueDTO setVolatilityRate(BigDecimal volatilityRate) {
		this.volatilityRate = volatilityRate;
		return this;
	}

	public String getRequestType() {
		return requestType;
	}

	public FieldValueDTO setRequestType(String requestType) {
		this.requestType = requestType;
		return this;
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public FieldValueDTO setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
		return this;
	}

	public BigDecimal getPercentPremium() {
		return percentPremium;
	}

	public FieldValueDTO setPercentPremium(BigDecimal percentPremium) {
		this.percentPremium = percentPremium;
		return this;
	}

	public BigDecimal getPercentCounterPremium() {
		return percentCounterPremium;
	}

	public FieldValueDTO setPercentCounterPremium(
			BigDecimal percentCounterPremium) {
		this.percentCounterPremium = percentCounterPremium;
		return this;
	}

	public BigDecimal getCounterStrike() {
		return counterStrike;
	}

	public FieldValueDTO setCounterStrike(BigDecimal counterStrike) {
		this.counterStrike = counterStrike;
		return this;
	}

	public BigDecimal getLocalMarginAmount() {
		return localMarginAmount;
	}

	public FieldValueDTO setLocalMarginAmount(BigDecimal localMarginAmount) {
		this.localMarginAmount = localMarginAmount;
		return this;
	}

	public BigDecimal getCounterLocalMarginAmount() {
		return counterLocalMarginAmount;
	}

	public FieldValueDTO setCounterLocalMarginAmount(
			BigDecimal counterLocalMarginAmount) {
		this.counterLocalMarginAmount = counterLocalMarginAmount;
		return this;
	}

	public String getLocalMarginCurrency() {
		return localMarginCurrency;
	}

	public FieldValueDTO setLocalMarginCurrency(String localMarginCurrency) {
		this.localMarginCurrency = localMarginCurrency;
		return this;
	}

	public BigDecimal getLocalMarginSpotRate() {
		return localMarginSpotRate;
	}

	public FieldValueDTO setLocalMarginSpotRate(BigDecimal localMarginSpotRate) {
		this.localMarginSpotRate = localMarginSpotRate;
		return this;
	}

	public BigDecimal getCounterLocalMarginSpotRate() {
		return counterLocalMarginSpotRate;
	}

	public FieldValueDTO setCounterLocalMarginSpotRate(
			BigDecimal counterLocalMarginSpotRate) {
		this.counterLocalMarginSpotRate = counterLocalMarginSpotRate;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public FieldValueDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getLocalMarginSpotCurrency() {
		return localMarginSpotCurrency;
	}

	public FieldValueDTO setLocalMarginSpotCurrency(
			String localMarginSpotCurrency) {
		this.localMarginSpotCurrency = localMarginSpotCurrency;
		return this;
	}

	public String getLocalMarginSpotCounterCurrency() {
		return localMarginSpotCounterCurrency;
	}

	public FieldValueDTO setLocalMarginSpotCounterCurrency(
			String localMarginSpotCounterCurrency) {
		this.localMarginSpotCounterCurrency = localMarginSpotCounterCurrency;
		return this;
	}

	public String getCounterLocalMarginSpotCurrency() {
		return counterLocalMarginSpotCurrency;
	}

	public FieldValueDTO setCounterLocalMarginSpotCurrency(
			String counterlocalMarginSpotCurrency) {
		this.counterLocalMarginSpotCurrency = counterlocalMarginSpotCurrency;
		return this;
	}

	public String getCounterLocalMarginSpotCounterCurrency() {
		return counterLocalMarginSpotCounterCurrency;
	}

	public FieldValueDTO setCounterLocalMarginSpotCounterCurrency(
			String counterlocalMarginSpotCounterCurrency) {
		this.counterLocalMarginSpotCounterCurrency = counterlocalMarginSpotCounterCurrency;
		return this;
	}

	public BigDecimal getCallCurrencyToUSDSpotRate() {
		return callCurrencyToUSDSpotRate;
	}

	public FieldValueDTO setCallCurrencyToUSDSpotRate(
			BigDecimal callCurrencyToUSDSpotRate) {
		this.callCurrencyToUSDSpotRate = callCurrencyToUSDSpotRate;
		return this;
	}

	public BigDecimal getPutCurrencyToUSDSpotRate() {
		return putCurrencyToUSDSpotRate;
	}

	public FieldValueDTO setPutCurrencyToUSDSpotRate(
			BigDecimal putCurrencyToUSDSpotRate) {
		this.putCurrencyToUSDSpotRate = putCurrencyToUSDSpotRate;
		return this;
	}

	public boolean isNestedNode() {
		return nestedNode;
	}

	public FieldValueDTO setNestedNode(boolean nestedNode) {
		this.nestedNode = nestedNode;
		return this;
	}

	public String getExpiryDateString() {
		return expiryDateString;
	}

	public FieldValueDTO setExpiryDateString(String expiryDateString) {
		this.expiryDateString = expiryDateString;
		return this;
	}

	public String getExpiryTimeString() {
		return expiryTimeString;
	}

	public FieldValueDTO setExpiryTimeString(String expiryTimeString) {
		this.expiryTimeString = expiryTimeString;
		return this;
	}

	public String getDeliveryDateString() {
		return deliveryDateString;
	}

	public FieldValueDTO setDeliveryDateString(String deliveryDateString) {
		this.deliveryDateString = deliveryDateString;
		return this;
	}

	public String getPremiumDateString() {
		return premiumDateString;
	}

	public FieldValueDTO setPremiumDateString(String premiumDateString) {
		this.premiumDateString = premiumDateString;
		return this;
	}

	public String getValueDateString() {
		return valueDateString;
	}

	public FieldValueDTO setValueDateString(String valueDateString) {
		this.valueDateString = valueDateString;
		return this;
	}

	public String getHorizonDateString() {
		return horizonDateString;
	}

	public FieldValueDTO setHorizonDateString(String horizonDateString) {
		this.horizonDateString = horizonDateString;
		return this;
	}

	public String getSpotDateString() {
		return spotDateString;
	}

	public FieldValueDTO setSpotDateString(String spotDateString) {
		this.spotDateString = spotDateString;
		return this;
	}

	public String getCalculationType() {
		return calculationType;
	}

	public FieldValueDTO setCalculationType(String calculationType) {
		this.calculationType = calculationType;
		return this;
	}

	public static FieldValueDTO instance() {
		return new FieldValueDTO();
	}

	public String getDealingConvention() {
		return dealingConvention;
	}

	public FieldValueDTO setDealingConvention(String dealingConvention) {
		this.dealingConvention = dealingConvention;
		return this;
	}

	public BigDecimal getNotionalInPremiumCurrency() {
		return notionalInPremiumCurrency;
	}

	public FieldValueDTO setNotionalInPremiumCurrency(
			BigDecimal notionalInPremiumCurrency) {
		this.notionalInPremiumCurrency = notionalInPremiumCurrency;
		return this;
	}

	public BigDecimal getCounterNotionalInPremiumCurrency() {
		return counterNotionalInPremiumCurrency;
	}

	public FieldValueDTO setCounterNotionalInPremiumCurrency(
			BigDecimal counterNotionalInPremiumCurrency) {
		this.counterNotionalInPremiumCurrency = counterNotionalInPremiumCurrency;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FieldValueDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public Integer getDaysToExpiry() {
		return daysToExpiry;
	}

	public FieldValueDTO setDaysToExpiry(Integer daysToExpiry) {
		this.daysToExpiry = daysToExpiry;
		return this;
	}

	public Integer getDaysToDelivery() {
		return daysToDelivery;
	}

	public FieldValueDTO setDaysToDelivery(Integer daysToDelivery) {
		this.daysToDelivery = daysToDelivery;
		return this;
	}

	public Integer getTradeDateToExpiryDate() {
		return tradeDateToExpiryDate;
	}

	public FieldValueDTO setTradeDateToExpiryDate(Integer tradeDateToExpiryDate) {
		this.tradeDateToExpiryDate = tradeDateToExpiryDate;
		return this;
	}

	public Integer getTradeDateToDeliveryDate() {
		return tradeDateToDeliveryDate;
	}

	public FieldValueDTO setTradeDateToDeliveryDate(
			Integer tradeDateToDeliveryDate) {
		this.tradeDateToDeliveryDate = tradeDateToDeliveryDate;
		return this;
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public FieldValueDTO setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
		return this;
	}

	public Integer getRatePrecision() {
		return ratePrecision;
	}

	public FieldValueDTO setRatePrecision(Integer ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public BigDecimal getPercentInternalCost() {
		return percentInternalCost;
	}

	public FieldValueDTO setPercentInternalCost(BigDecimal percentInternalCost) {
		this.percentInternalCost = percentInternalCost;
		return this;
	}

	public BigDecimal getBidSpotRate() {
		return bidSpotRate;
	}

	public FieldValueDTO setBidSpotRate(BigDecimal bidSpotRate) {
		this.bidSpotRate = bidSpotRate;
		return this;
	}

	public BigDecimal getAskSpotRate() {
		return askSpotRate;
	}

	public FieldValueDTO setAskSpotRate(BigDecimal askSpotRate) {
		this.askSpotRate = askSpotRate;
		return this;
	}

	public BigDecimal getBidForwardRate() {
		return bidForwardRate;
	}

	public FieldValueDTO setBidForwardRate(BigDecimal bidForwardRate) {
		this.bidForwardRate = bidForwardRate;
		return this;
	}

	public BigDecimal getAskForwardRate() {
		return askForwardRate;
	}

	public FieldValueDTO setAskForwardRate(BigDecimal askForwardRate) {
		this.askForwardRate = askForwardRate;
		return this;
	}

	public BigDecimal getBidVolatilityRate() {
		return bidVolatilityRate;
	}

	public FieldValueDTO setBidVolatilityRate(BigDecimal bidVolatilityRate) {
		this.bidVolatilityRate = bidVolatilityRate;
		return this;
	}

	public BigDecimal getAskVolatilityRate() {
		return askVolatilityRate;
	}

	public FieldValueDTO setAskVolatilityRate(BigDecimal askVolatilityRate) {
		this.askVolatilityRate = askVolatilityRate;
		return this;
	}

	public String getPercentPremiumAsString() {
		return percentPremiumAsString;
	}

	public FieldValueDTO setPercentPremiumAsString(String percentPremiumAsString) {
		this.percentPremiumAsString = percentPremiumAsString;
		return this;
	}

	public String getPercentCounterPremiumAsString() {
		return percentCounterPremiumAsString;
	}

	public FieldValueDTO setPercentCounterPremiumAsString(
			String percentCounterPremiumAsString) {
		this.percentCounterPremiumAsString = percentCounterPremiumAsString;
		return this;
	}

	public String getPercentInternalCostAsString() {
		return percentInternalCostAsString;
	}

	public FieldValueDTO setPercentInternalCostAsString(
			String percentInternalCostAsString) {
		this.percentInternalCostAsString = percentInternalCostAsString;
		return this;
	}

	public Boolean getHasACommodity() {
		return hasACommodity;
	}

	public FieldValueDTO setHasACommodity(Boolean hasACommodity) {
		this.hasACommodity = hasACommodity;
		return this;
	}

	public String getInterPortfolio() {
		return interPortfolio;
	}

	public FieldValueDTO setInterPortfolio(String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

	public String getCustomerType() {
		return customerType;
	}

	public FieldValueDTO setCustomerType(String customerType) {
		this.customerType = customerType;
		return this;
	}

	public BigDecimal getBreakEven() {
		return breakEven;
	}

	public void setBreakEven(BigDecimal breakEven) {
		this.breakEven = breakEven;
	}

	public BigDecimal getCounterBreakEven() {
		return counterBreakEven;
	}

	public void setCounterBreakEven(BigDecimal counterBreakEven) {
		this.counterBreakEven = counterBreakEven;
	}
	
	public String getAvaloqId() {
		return avaloqId;
	}

	public FieldValueDTO setAvaloqId(String avaloqId) {
		this.avaloqId = avaloqId;
		return this;
	}

	public String getSystemSourceId() {
		return systemSourceId;
	}

	public FieldValueDTO setSystemSourceId(String systemSourceId) {
		this.systemSourceId = systemSourceId;
		return this;
	}

	public String getMurexId() {
		return murexId;
	}

	public FieldValueDTO setMurexId(String murexId) {
		this.murexId = murexId;
		return this;
	}
}
