package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class CurrencyPairValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	public static CurrencyPairValidationDTO instance(String currency,
			String counterCurrency) {
		return (CurrencyPairValidationDTO) new CurrencyPairValidationDTO()
				.setCurrency(currency).setCounterCurrency(counterCurrency);
	}

}
