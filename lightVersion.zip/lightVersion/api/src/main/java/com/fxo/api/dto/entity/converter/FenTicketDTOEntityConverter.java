package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FenTicketDTO;
import com.fxo.dao.entity.FenTicket;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class FenTicketDTOEntityConverter extends
BaseDTOEntityConverter<FenTicketDTO, FenTicket> {

}
