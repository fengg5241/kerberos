package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.SpotsDTO;
import com.fxo.dao.entity.Spots;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;



@Component
public class SpotsDTOEntityConverter extends
        BaseCustomDTOEntityConverter<SpotsDTO, Spots> {

}
