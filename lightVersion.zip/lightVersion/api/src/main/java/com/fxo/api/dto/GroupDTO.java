package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class GroupDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String groupName;

	private String groupCode;

	public String getGroupName() {
		return this.groupName;
	}

	public GroupDTO setGroupName(String groupName) {
		this.groupName = groupName;
		return this;
	}

	public String getGroupCode() {
		return this.groupCode;
	}

	public GroupDTO setGroupCode(String groupCode) {
		this.groupCode = groupCode;
		return this;
	}
}
