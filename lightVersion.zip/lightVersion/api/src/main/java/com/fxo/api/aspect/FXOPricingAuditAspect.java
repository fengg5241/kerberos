package com.fxo.api.aspect;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

import ch.lambdaj.Lambda;

import com.fxo.api.dto.CustomerDTO;
import com.fxo.api.dto.FXOPricingAuditDTO;
import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.api.dto.PricingResponseListDTO;
import com.fxo.api.service.IFXOPricingAuditService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.FXORequestPurpose;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.util.FXOStringUtility;
import com.google.common.base.Function;
import com.google.common.collect.Lists;

@Aspect
public class FXOPricingAuditAspect {

	@Autowired
	private IFXOPricingAuditService fxoPricingAuditService;

	@AfterReturning(value = "execution(com.fxo.api.dto.PricingResponseDTO com.fxo.api.service.IFXOPricingService.submitPricingRequest(..))", returning = "pricingResponseDTO")
	public void recordPricingActivity(PricingResponseDTO pricingResponseDTO) {

		FXOPricingAuditDTO fxoPricingAuditDTO = extractFXOPricingAuditFromPricingResponse(pricingResponseDTO);

		if (FXOStringUtility.haveIdenticalValues(
				fxoPricingAuditDTO.getRequestPurpose(),
				FXORequestPurpose.PRICING)) {

			fxoPricingAuditService.recordPricingActivity(fxoPricingAuditDTO);
		}
	}

	public FXOPricingAuditDTO extractFXOPricingAuditFromPricingResponse(
			PricingResponseDTO pricingResponseDTO) {

		FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
				.extractKeyProductDetails(pricingResponseDTO.getStructure());

		FXOPricingAuditDTO fxoPricingAuditDTO = FXOPricingAuditDTO
				.instance()
				.setPricingResponseId(pricingResponseDTO.getPricingResponseId())
				.setPricingRequestId(pricingResponseDTO.getPricingRequestId())
				.setProduct(fxoProductStructureExtractDTO.getProduct())
				.setStrategy(fxoProductStructureExtractDTO.getStrategy())
				.setLegCount(fxoProductStructureExtractDTO.getLegCount())
				.setRequestPurpose(pricingResponseDTO.getRequestPurpose())
				.setStrategy(fxoProductStructureExtractDTO.getStrategy());

		UserDTO userDTO = pricingResponseDTO.getUser();

		if (userDTO != null) {
			fxoPricingAuditDTO.setCreatedBy(userDTO.getUserId());
		}

		CustomerDTO customerDTO = pricingResponseDTO.getCustomer();

		if (customerDTO != null) {

			fxoPricingAuditDTO.setCustomerId(customerDTO.getCustomerId())
					.setRmName(customerDTO.getRmName());
		}

		return fxoPricingAuditDTO.setDealGovernanceResponse(FXODealingUtil
				.getResponseType(pricingResponseDTO.getFxoMessage()));
	}

	@AfterReturning(value = "execution(com.fxo.api.dto.PricingResponseListDTO com.fxo.api.service.IFXOPricingDiscoveryService.*(..))", returning = "pricingResponseListDTO")
	public void recordPricingDiscoveryActivity(
			PricingResponseListDTO pricingResponseListDTO) {

		List<PricingResponseDTO> pricingResponseDTOs = pricingResponseListDTO
				.getPricingResponses();

		List<FXOPricingAuditDTO> fxoPricingAuditDTOs_Extract = Lists.transform(
				pricingResponseDTOs,
				extractFXOPricingAuditFromPricingResponseFunction());

		List<FXOPricingAuditDTO> fxoPricingAuditDTOs = new ArrayList<FXOPricingAuditDTO>(
				fxoPricingAuditDTOs_Extract);

		Lambda.forEach(fxoPricingAuditDTOs).setRequestPurpose(
				FXORequestPurpose.PRICING_DISCOVERY);

		fxoPricingAuditService.recordBulkPricingActivity(fxoPricingAuditDTOs);
	}

	Function<PricingResponseDTO, FXOPricingAuditDTO> extractFXOPricingAuditFromPricingResponseFunction() {

		Function<PricingResponseDTO, FXOPricingAuditDTO> extractFXOPricingAuditFromPricingResponseFunction = new Function<PricingResponseDTO, FXOPricingAuditDTO>() {

			@Override
			public FXOPricingAuditDTO apply(
					PricingResponseDTO pricingResponseDTO) {
				return extractFXOPricingAuditFromPricingResponse(pricingResponseDTO);
			}
		};

		return extractFXOPricingAuditFromPricingResponseFunction;
	}

	@AfterThrowing(pointcut = "execution(com.fxo.api.dto.PricingResponseDTO com.fxo.api.service.IFXOPricingService.submitPricingRequest(..))", throwing = "appRunTimeException")
	public void recordPricingExceptionActivity(JoinPoint joinPoint,
			ApplicationRuntimeException appRunTimeException) {

		Objects.requireNonNull(joinPoint.getArgs(),
				FXOMessageCodes.ERR_PRICING_REQUEST_INVALID);

		Assert.notEmpty(joinPoint.getArgs(),
				FXOMessageCodes.ERR_PRICING_REQUEST_INVALID);

		Objects.requireNonNull(joinPoint.getArgs()[0],
				FXOMessageCodes.ERR_PRICING_REQUEST_INVALID);

		Assert.isInstanceOf(PricingRequestDTO.class, joinPoint.getArgs()[0],
				FXOMessageCodes.ERR_PRICING_REQUEST_INVALID);

		PricingRequestDTO pricingRequestDTO = (PricingRequestDTO) joinPoint
				.getArgs()[0];
		FXOPricingAuditDTO fxoPricingAuditDTO = extractFXOPricingAuditFromPricingRequest(pricingRequestDTO);

		if (FXOStringUtility.haveIdenticalValues(
				fxoPricingAuditDTO.getRequestPurpose(),
				FXORequestPurpose.PRICING)) {

			fxoPricingAuditDTO.setMessageCode(appRunTimeException
					.getSupportCode());

			fxoPricingAuditService.recordPricingActivity(fxoPricingAuditDTO);
		}
	}

	Function<PricingRequestDTO, FXOPricingAuditDTO> extractFXOPricingAuditFromPricingRequestOnExceptionFunction() {

		Function<PricingRequestDTO, FXOPricingAuditDTO> extractFXOPricingAuditDTOFunction = new Function<PricingRequestDTO, FXOPricingAuditDTO>() {

			@Override
			public FXOPricingAuditDTO apply(PricingRequestDTO pricingRequestDTO) {
				return extractFXOPricingAuditFromPricingRequest(pricingRequestDTO);
			}
		};

		return extractFXOPricingAuditDTOFunction;
	}

	public FXOPricingAuditDTO extractFXOPricingAuditFromPricingRequest(
			PricingRequestDTO pricingRequestDTO) {

		FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
				.extractKeyProductDetails(pricingRequestDTO.getStructure());

		FXOPricingAuditDTO fxoPricingAuditDTO = FXOPricingAuditDTO.instance()
				.setPricingRequestId(pricingRequestDTO.getPricingRequestId())
				.setProduct(fxoProductStructureExtractDTO.getProduct())
				.setStrategy(fxoProductStructureExtractDTO.getStrategy())
				.setLegCount(fxoProductStructureExtractDTO.getLegCount())
				.setRequestPurpose(pricingRequestDTO.getRequestPurpose())
				.setStrategy(fxoProductStructureExtractDTO.getStrategy());

		UserDTO userDTO = pricingRequestDTO.getUser();

		if (userDTO != null) {
			fxoPricingAuditDTO.setCreatedBy(userDTO.getUserId());
		}

		CustomerDTO customerDTO = pricingRequestDTO.getCustomer();

		if (customerDTO != null) {

			fxoPricingAuditDTO.setCustomerId(customerDTO.getCustomerId())
					.setRmName(customerDTO.getRmName());
		}

		return fxoPricingAuditDTO;
	}

}
