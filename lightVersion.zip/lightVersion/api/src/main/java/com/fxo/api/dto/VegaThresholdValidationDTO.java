package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class VegaThresholdValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal vegaAmount;

	public BigDecimal getVegaAmount() {
		return vegaAmount;
	}

	public VegaThresholdValidationDTO setVegaAmount(BigDecimal vegaAmount) {
		this.vegaAmount = vegaAmount;
		return this;
	}
	
	public static VegaThresholdValidationDTO instance(){
		return new VegaThresholdValidationDTO();
	}

}
