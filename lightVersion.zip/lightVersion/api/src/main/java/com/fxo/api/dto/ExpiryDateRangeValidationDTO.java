package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class ExpiryDateRangeValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private LocalDate expiryDate;

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public ExpiryDateRangeValidationDTO setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public static ExpiryDateRangeValidationDTO instance(LocalDate expiryDate,
			String product, String currency, String counterCurrency) {

		return (ExpiryDateRangeValidationDTO) new ExpiryDateRangeValidationDTO()
				.setExpiryDate(expiryDate).setProduct(product)
				.setCurrency(currency).setCounterCurrency(counterCurrency);
	}

}
