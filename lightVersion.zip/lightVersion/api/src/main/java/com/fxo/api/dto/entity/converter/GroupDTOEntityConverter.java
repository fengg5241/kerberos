package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.GroupDTO;
import com.fxo.dao.entity.Group;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class GroupDTOEntityConverter extends
        BaseDTOEntityConverter<GroupDTO, Group> {

}
