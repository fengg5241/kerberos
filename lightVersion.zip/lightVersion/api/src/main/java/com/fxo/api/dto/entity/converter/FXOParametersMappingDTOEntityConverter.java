package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.dao.entity.FXOParametersMapping;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class FXOParametersMappingDTOEntityConverter extends
        BaseDTOEntityConverter<FXOParametersMappingDTO, FXOParametersMapping> {

}
