package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class TenorValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Web-service)

	private String maturity;
	private LocalDate expiryDate;

	public String getMaturity() {
		return maturity;
	}

	public TenorValidationDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public TenorValidationDTO setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public static TenorValidationDTO instance(String maturity,
			LocalDate expiryDate) {
		return new TenorValidationDTO().setMaturity(maturity).setExpiryDate(
				expiryDate);
	}

}
