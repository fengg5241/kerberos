package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.HolidaysDTO;
import com.fxo.dao.entity.Holidays;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;



@Component
public class HolidaysDTOEntityConverter extends
        BaseCustomDTOEntityConverter<HolidaysDTO, Holidays> {

}
