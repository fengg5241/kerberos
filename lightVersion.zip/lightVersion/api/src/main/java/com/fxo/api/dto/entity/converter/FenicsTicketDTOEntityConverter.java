package com.fxo.api.dto.entity.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FenicsTicketDTO;
import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.factory.FXOTicketingBlotterServiceFactory;
import com.fxo.dao.entity.FenicsTicket;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class FenicsTicketDTOEntityConverter extends
		BaseDTOEntityConverter<FenicsTicketDTO, FenicsTicket> {

	public List<TicketingResponseDTO> toResponseDtos(List<FenicsTicket> entities) {
		List<TicketingResponseDTO> dtos = new ArrayList<>(entities.size());
		for (FenicsTicket entity : entities) {
			dtos.add(toResponseDto(entity));
		}
		return dtos;
	}

	public TicketingResponseDTO toResponseDto(FenicsTicket entity) {
		return fxoTicketingBlotterServiceFactory.getFXOTicketingBlotterService(
				entity.getProduct()).toResponseModel(entity);
	}

	@Override
	public FenicsTicketDTO fromEntity(FenicsTicket entity) {
		FenicsTicketDTO dto = super.fromEntity(entity);
		UserDTO user = getUserDTO(entity);
		dto.setCustomer(user);
		return dto;
	}

	private UserDTO getUserDTO(FenicsTicket entity) {
		return new UserDTO().setUserId(entity.getRmName())
				.setUserType(entity.getUserType())
				.setCustomerId(entity.getCustomerId());
	}

	@Override
	public FenicsTicket toEntity(FenicsTicketDTO dto) {
		FenicsTicket ticket = super.toEntity(dto);
		ticket.setUserId(dto.getCustomer().getUserId()).setUserType(
				dto.getCustomer().getUserType());
		ticket.setCustomerId(dto.getCustomer().getCustomerId());
		return ticket;
	}

	@Override
	public FenicsTicket toEntity(FenicsTicketDTO dto,
			FenicsTicket existingEntity) {
		FenicsTicket ticket = super.toEntity(dto, existingEntity);
		ticket.setUserId(dto.getCustomer().getUserId()).setUserType(
				dto.getCustomer().getUserType());
		ticket.setCustomerId(dto.getCustomer().getCustomerId());
		return ticket;
	}

	@Autowired
	private FXOTicketingBlotterServiceFactory fxoTicketingBlotterServiceFactory;

}
