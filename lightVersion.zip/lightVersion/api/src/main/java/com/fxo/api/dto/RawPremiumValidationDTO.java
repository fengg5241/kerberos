package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class RawPremiumValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal rawPremium;

	public BigDecimal getRawPremium() {
		return rawPremium;
	}

	public RawPremiumValidationDTO setRawPremium(BigDecimal rawPremium) {
		this.rawPremium = rawPremium;
		return this;
	}

	public static RawPremiumValidationDTO instance(BigDecimal rawPremium) {
		return new RawPremiumValidationDTO().setRawPremium(rawPremium);
	}

}
