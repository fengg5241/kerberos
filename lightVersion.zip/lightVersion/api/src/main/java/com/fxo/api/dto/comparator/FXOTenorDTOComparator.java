package com.fxo.api.dto.comparator;

import java.util.Comparator;

import com.fxo.api.dto.FXOTenorsDTO;

public class FXOTenorDTOComparator implements Comparator<FXOTenorsDTO> {

	@Override
	public int compare(FXOTenorsDTO tenor1, FXOTenorsDTO tenor2) {
		return tenor1.getSequence().compareTo(tenor1.getSequence());
	}
}