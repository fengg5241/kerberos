package com.fxo.api.dto;

import java.math.BigInteger;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FenTicketDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private BigInteger ticketNumber;

	private String murexTicketNumber;

	public BigInteger getTicketNumber() {
		return ticketNumber;
	}

	public FenTicketDTO setTicketNumber(BigInteger ticketNumber) {
		this.ticketNumber = ticketNumber;
		return this;
	}

	public String getMurexTicketNumber() {
		return murexTicketNumber;
	}

	public FenTicketDTO setMurexTicketNumber(String murexTicketNumber) {
		this.murexTicketNumber = murexTicketNumber;
		return this;
	}

	public static FenTicketDTO instance() {
		return new FenTicketDTO();
	}

}
