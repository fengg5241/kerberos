package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class SpotsDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String currency;

	private String counterCurrency;

	private BigDecimal bid;

	private BigDecimal ask;

	private BigDecimal spotRate;

	private String strategy;

	private String direction;

	private Integer precision;

	private DateTime lastRefreshedTimeStamp;

	private String sign;

	public SpotsDTO() {
	}

	public SpotsDTO(String currency, String counterCurrency) {
		this.currency = currency;
		this.counterCurrency = counterCurrency;
	}

	public String getSign() {
		return sign;
	}

	public SpotsDTO setSign(String sign) {
		this.sign = sign;
		return this;
	}

	public String getCurrency() {
		return currency;
	}

	public SpotsDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public SpotsDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public BigDecimal getBid() {
		return bid;
	}

	public SpotsDTO setBid(BigDecimal bid) {
		this.bid = bid;
		return this;
	}

	public BigDecimal getAsk() {
		return ask;
	}

	public SpotsDTO setAsk(BigDecimal ask) {
		this.ask = ask;
		return this;
	}

	public DateTime getLastRefreshedTimeStamp() {
		return lastRefreshedTimeStamp;
	}

	public SpotsDTO setLastRefreshedTimeStamp(DateTime lastRefreshedTimeStamp) {
		this.lastRefreshedTimeStamp = lastRefreshedTimeStamp;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public SpotsDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public SpotsDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public SpotsDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public Integer getPrecision() {
		return precision;
	}

	public SpotsDTO setPrecision(Integer precision) {
		this.precision = precision;
		return this;
	}

	public static SpotsDTO instance() {
		return new SpotsDTO();
	}

}
