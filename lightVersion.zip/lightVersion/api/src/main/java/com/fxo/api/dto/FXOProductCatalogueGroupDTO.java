package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOProductCatalogueGroupDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String groupCode;

	private FXOProductCatalogueDTO product;

	private String parent;

	private String dealGovernanceConfigLevel;

	private String description;

	public String getGroupCode() {
		return groupCode;
	}

	public FXOProductCatalogueGroupDTO setGroupCode(String groupCode) {
		this.groupCode = groupCode;
		return this;
	}

	public FXOProductCatalogueDTO getProduct() {
		return product;
	}

	public FXOProductCatalogueGroupDTO setProductId(
			FXOProductCatalogueDTO product) {
		this.product = product;
		return this;
	}

	public String getParent() {
		return parent;
	}

	public FXOProductCatalogueGroupDTO setParent(String parent) {
		this.parent = parent;
		return this;
	}

	public String getDescription() {
		return description;
	}

	public FXOProductCatalogueGroupDTO setDescription(String description) {
		this.description = description;
		return this;
	}

	public String getDealGovernanceConfigLevel() {
		return dealGovernanceConfigLevel;
	}

	public FXOProductCatalogueGroupDTO setDealGovernanceConfigLevel(
			String dealGovernanceConfigLevel) {
		this.dealGovernanceConfigLevel = dealGovernanceConfigLevel;
		return this;
	}

}
