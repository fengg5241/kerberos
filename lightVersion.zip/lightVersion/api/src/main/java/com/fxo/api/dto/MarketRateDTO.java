package com.fxo.api.dto;

import java.math.BigDecimal;
import java.sql.Timestamp;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;
import com.fxo.framework.core.dto.FXOMessageDTO;

@AutoProperty
public class MarketRateDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String currency;
	private String counterCurrency;
	private String direction;
	private String strategy;
	private String maturity;
	private String cutOff;

	private Timestamp tradeDate;
	private DateTime expiryDate;
	private Integer daysToExpiry;
	private Integer tradeDateToExpiryDate;
	private DateTime valueDate;
	private DateTime horizonDate;
	private DateTime deliveryDate;
	private Integer daysToDelivery;
	private Integer tradeDateToDeliveryDate;

	private String spot;
	private BigDecimal spotRate;
	private BigDecimal bidSpotRate;
	private BigDecimal askSpotRate;

	private String volatility;
	private BigDecimal volatilityRate;
	private BigDecimal bidVolatilityRate;
	private BigDecimal askVolatilityRate;

	private String forward;
	private BigDecimal forwardRate;
	private BigDecimal bidForwardRate;
	private BigDecimal askForwardRate;

	private Boolean staleRateIndicator;

	private String spotCurrency;
	private String spotCounterCurrency;

	private BigDecimal strike;
	private BigDecimal counterStrike;
	private Integer ratePrecision;
	private String legStrategy;

	private String marketRateCalculationParameter;
	private String expiryDateString;
	private DateTime expiryTime;
	private String expiryTimeString;
	private String deliveryDateString;
	private String valueDateString;
	private String horizonDateString;

	private FXOMessageDTO fxoMessage;

	public String getCurrency() {
		return currency;
	}

	public MarketRateDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public MarketRateDTO setCounterCurrency(String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public MarketRateDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public MarketRateDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public Timestamp getTradeDate() {
		return tradeDate;
	}

	public MarketRateDTO setTradeDate(Timestamp tradeDate) {
		this.tradeDate = tradeDate;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public MarketRateDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public MarketRateDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public DateTime getValueDate() {
		return valueDate;
	}

	public MarketRateDTO setValueDate(DateTime valueDate) {
		this.valueDate = valueDate;
		return this;
	}

	public DateTime getHorizonDate() {
		return horizonDate;
	}

	public MarketRateDTO setHorizonDate(DateTime horizonDate) {
		this.horizonDate = horizonDate;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public MarketRateDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public String getSpot() {
		return spot;
	}

	public MarketRateDTO setSpot(String spot) {
		this.spot = spot;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public MarketRateDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public BigDecimal getForwardRate() {
		return forwardRate;
	}

	public MarketRateDTO setForwardRate(BigDecimal forwardRate) {
		this.forwardRate = forwardRate;
		return this;
	}

	public String getVolatility() {
		return volatility;
	}

	public MarketRateDTO setVolatility(String volatility) {
		this.volatility = volatility;
		return this;
	}

	public BigDecimal getVolatilityRate() {
		return volatilityRate;
	}

	public MarketRateDTO setVolatilityRate(BigDecimal volatilityRate) {
		this.volatilityRate = volatilityRate;
		return this;
	}

	public String getForward() {
		return forward;
	}

	public MarketRateDTO setForward(String forward) {
		this.forward = forward;
		return this;
	}

	public String getSpotCurrency() {
		return spotCurrency;
	}

	public MarketRateDTO setSpotCurrency(String spotCurrency) {
		this.spotCurrency = spotCurrency;
		return this;
	}

	public String getSpotCounterCurrency() {
		return spotCounterCurrency;
	}

	public MarketRateDTO setSpotCounterCurrency(String spotCounterCurrency) {
		this.spotCounterCurrency = spotCounterCurrency;
		return this;
	}

	public BigDecimal getStrike() {
		return strike;
	}

	public MarketRateDTO setStrike(BigDecimal strike) {
		this.strike = strike;
		return this;
	}

	public BigDecimal getCounterStrike() {
		return counterStrike;
	}

	public MarketRateDTO setCounterStrike(BigDecimal counterStrike) {
		this.counterStrike = counterStrike;
		return this;
	}

	public String getMarketRateCalculationParameter() {
		return marketRateCalculationParameter;
	}

	public MarketRateDTO setMarketRateCalculationParameter(
			String marketRateCalculationParameter) {
		this.marketRateCalculationParameter = marketRateCalculationParameter;
		return this;
	}

	public String getCutOff() {
		return cutOff;
	}

	public MarketRateDTO setCutOff(String cutOff) {
		this.cutOff = cutOff;
		return this;
	}

	public Integer getRatePrecision() {
		return ratePrecision;
	}

	public MarketRateDTO setRatePrecision(Integer ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public String getLegStrategy() {
		return legStrategy;
	}

	public MarketRateDTO setLegStrategy(String legStrategy) {
		this.legStrategy = legStrategy;
		return this;
	}

	public String getExpiryDateString() {
		return expiryDateString;
	}

	public MarketRateDTO setExpiryDateString(String expiryDateString) {
		this.expiryDateString = expiryDateString;
		return this;
	}

	public DateTime getExpiryTime() {
		return expiryTime;
	}

	public MarketRateDTO setExpiryTime(DateTime expiryTime) {
		this.expiryTime = expiryTime;
		return this;
	}

	public String getExpiryTimeString() {
		return expiryTimeString;
	}

	public MarketRateDTO setExpiryTimeString(String expiryTimeString) {
		this.expiryTimeString = expiryTimeString;
		return this;
	}

	public String getDeliveryDateString() {
		return deliveryDateString;
	}

	public MarketRateDTO setDeliveryDateString(String deliveryDateString) {
		this.deliveryDateString = deliveryDateString;
		return this;
	}

	public String getValueDateString() {
		return valueDateString;
	}

	public MarketRateDTO setValueDateString(String valueDateString) {
		this.valueDateString = valueDateString;
		return this;
	}

	public String getHorizonDateString() {
		return horizonDateString;
	}

	public MarketRateDTO setHorizonDateString(String horizonDateString) {
		this.horizonDateString = horizonDateString;
		return this;
	}

	public Integer getDaysToExpiry() {
		return daysToExpiry;
	}

	public MarketRateDTO setDaysToExpiry(Integer daysToExpiry) {
		this.daysToExpiry = daysToExpiry;
		return this;
	}

	public Integer getDaysToDelivery() {
		return daysToDelivery;
	}

	public MarketRateDTO setDaysToDelivery(Integer daysToDelivery) {
		this.daysToDelivery = daysToDelivery;
		return this;
	}

	public Boolean getStaleRateIndicator() {
		return staleRateIndicator;
	}

	public MarketRateDTO setStaleRateIndicator(Boolean staleRateIndicator) {
		this.staleRateIndicator = staleRateIndicator;
		return this;
	}

	public Integer getTradeDateToExpiryDate() {
		return tradeDateToExpiryDate;
	}

	public MarketRateDTO setTradeDateToExpiryDate(Integer tradeDateToExpiryDate) {
		this.tradeDateToExpiryDate = tradeDateToExpiryDate;
		return this;
	}

	public Integer getTradeDateToDeliveryDate() {
		return tradeDateToDeliveryDate;
	}

	public MarketRateDTO setTradeDateToDeliveryDate(
			Integer tradeDateToDeliveryDate) {
		this.tradeDateToDeliveryDate = tradeDateToDeliveryDate;
		return this;
	}

	public BigDecimal getBidSpotRate() {
		return bidSpotRate;
	}

	public MarketRateDTO setBidSpotRate(BigDecimal bidSpotRate) {
		this.bidSpotRate = bidSpotRate;
		return this;
	}

	public BigDecimal getAskSpotRate() {
		return askSpotRate;
	}

	public MarketRateDTO setAskSpotRate(BigDecimal askSpotRate) {
		this.askSpotRate = askSpotRate;
		return this;
	}

	public BigDecimal getBidVolatilityRate() {
		return bidVolatilityRate;
	}

	public MarketRateDTO setBidVolatilityRate(BigDecimal bidVolatilityRate) {
		this.bidVolatilityRate = bidVolatilityRate;
		return this;
	}

	public BigDecimal getAskVolatilityRate() {
		return askVolatilityRate;
	}

	public MarketRateDTO setAskVolatilityRate(BigDecimal askVolatilityRate) {
		this.askVolatilityRate = askVolatilityRate;
		return this;
	}

	public BigDecimal getBidForwardRate() {
		return bidForwardRate;
	}

	public MarketRateDTO setBidForwardRate(BigDecimal bidForwardRate) {
		this.bidForwardRate = bidForwardRate;
		return this;
	}

	public BigDecimal getAskForwardRate() {
		return askForwardRate;
	}

	public MarketRateDTO setAskForwardRate(BigDecimal askForwardRate) {
		this.askForwardRate = askForwardRate;
		return this;
	}

	public FXOMessageDTO getFxoMessage() {
		return fxoMessage;
	}

	public MarketRateDTO setFxoMessage(FXOMessageDTO fxoMessage) {
		this.fxoMessage = fxoMessage;
		return this;
	}

	public static MarketRateDTO instance() {
		return new MarketRateDTO();
	}

}
