package com.fxo.api.dto;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.NotNull;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class StrategyDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String purpose;
	private String calculationType;
	private String nodeType;
	private boolean nestedNode;

	private FieldValueDTO summary;

	@NotNull
	private List<OptionLegDTO> legs;

	public List<OptionLegDTO> getLegs() {
		return legs;
	}

	public StrategyDTO setLegs(List<OptionLegDTO> legs) {
		this.legs = legs;
		return this;
	}

	public FieldValueDTO getSummary() {
		return summary;
	}

	public StrategyDTO setSummary(FieldValueDTO summary) {
		this.summary = summary;
		return this;
	}

	public String getPurpose() {
		return purpose;
	}

	public StrategyDTO setPurpose(String requestType) {
		this.purpose = requestType;
		return this;
	}

	public String getNodeType() {
		return nodeType;
	}

	public StrategyDTO setNodeType(String nodeType) {
		this.nodeType = nodeType;
		return this;
	}

	public boolean isNestedNode() {
		return nestedNode;
	}

	public StrategyDTO setNestedNode(boolean nestedNode) {
		this.nestedNode = nestedNode;
		return this;
	}

	public String getCalculationType() {
		return calculationType;
	}

	public StrategyDTO setCalculationType(String calculationType) {
		this.calculationType = calculationType;
		return this;
	}

	public static StrategyDTO instance(int numLegs) {
		ArrayList<OptionLegDTO> legs = new ArrayList<>(numLegs);
		for (int counter = 0; counter < numLegs; counter++)
			legs.add(OptionLegDTO.instance());
		return new StrategyDTO().setSummary(FieldValueDTO.instance()).setLegs(
				legs);
	}

}
