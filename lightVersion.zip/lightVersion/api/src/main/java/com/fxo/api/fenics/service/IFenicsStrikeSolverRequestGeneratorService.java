package com.fxo.api.fenics.service;

import com.fxo.api.dto.StrikeSolverRequestDTO;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.exception.ApplicationException;

public interface IFenicsStrikeSolverRequestGeneratorService {
	static final String REQUEST_PREFIX = "STRK_";

	String fenicsRequestPurpose = FenicsRequestPurpose.STRIKE_SOLVER;

	public String getFenicsPricingXML(
			StrikeSolverRequestDTO strikeSolverRequestDTO)
			throws ApplicationException;

}
