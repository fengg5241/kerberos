package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class CurrencyGroupDTO extends AuditableDTO{

	private static final long serialVersionUID = 1L;

	private String group;

	private List<CurrencyDTO> currencies;

	public List<CurrencyDTO> getCurrencies() {
		return currencies;
	}

	public CurrencyGroupDTO setCurrencies(List<CurrencyDTO> currencies) {
		this.currencies = currencies;
		return this;
	}

	public String getGroup() {
		return group;
	}

	public CurrencyGroupDTO setGroup(String group) {
		this.group = group;
		return this;
	}

}
