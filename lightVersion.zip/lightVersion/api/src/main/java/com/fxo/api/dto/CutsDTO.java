package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseDTO;


@AutoProperty
public class CutsDTO extends BaseDTO {

	private static final long serialVersionUID = 1L;

	private Integer cut;

	private String cutSymbol;

	private String cutShortName;

	private String cutLongName;

	private String cityCode;

	public Integer getCut() {
		return cut;
	}

	public CutsDTO setCut(Integer cut) {
		this.cut = cut;
		return this;
	}

	public String getCutSymbol() {
		return cutSymbol;
	}

	public CutsDTO setCutSymbol(String cutSymbol) {
		this.cutSymbol = cutSymbol;
		return this;
	}

	public String getCutShortName() {
		return cutShortName;
	}

	public CutsDTO setCutShortName(String cutShortName) {
		this.cutShortName = cutShortName;
		return this;
	}

	public String getCutLongName() {
		return cutLongName;
	}

	public CutsDTO setCutLongName(String cutLongName) {
		this.cutLongName = cutLongName;
		return this;
	}

	public String getCityCode() {
		return cityCode;
	}

	public CutsDTO setCityCode(String cityCode) {
		this.cityCode = cityCode;
		return this;
	}

}
