package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXODealGovernanceParametersCcyPairDTO;
import com.fxo.api.dto.FXODealGovernanceValidationConfigDTO;
import com.fxo.framework.core.dto.BaseSourceTargetDTOConverter;

@Component
public class FXODealGovCcyPairToDealGovValSourceTargetDTOConverter
		extends
		BaseSourceTargetDTOConverter<FXODealGovernanceParametersCcyPairDTO, FXODealGovernanceValidationConfigDTO> {

}
