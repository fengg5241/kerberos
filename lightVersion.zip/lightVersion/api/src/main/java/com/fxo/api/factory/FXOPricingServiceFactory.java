package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.service.IFXOPricingService;

public interface FXOPricingServiceFactory extends Serializable {
	public IFXOPricingService getPricingService(
			ProductStructureDTO productStructureDTO);
}