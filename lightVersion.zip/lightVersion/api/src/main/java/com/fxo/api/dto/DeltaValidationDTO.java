package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DeltaValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal percentDeltaAmount;
	private BigDecimal deltaAmount;

	public BigDecimal getPercentDeltaAmount() {
		return percentDeltaAmount;
	}

	public DeltaValidationDTO setPercentDeltaAmount(
			BigDecimal percentDeltaAmount) {
		this.percentDeltaAmount = percentDeltaAmount;
		return this;
	}

	public BigDecimal getDeltaAmount() {
		return deltaAmount;
	}

	public DeltaValidationDTO setDeltaAmount(BigDecimal deltaAmount) {
		this.deltaAmount = deltaAmount;
		return this;
	}

	public static DeltaValidationDTO instance(BigDecimal percentDeltaAmount,
			BigDecimal deltaAmount) {
		return new DeltaValidationDTO().setPercentDeltaAmount(
				percentDeltaAmount).setDeltaAmount(deltaAmount);
	}

}
