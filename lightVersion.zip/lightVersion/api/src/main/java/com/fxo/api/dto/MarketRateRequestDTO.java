package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class MarketRateRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String marketRateRequestId;

	private String marketRateCalculationParameter;

	private List<MarketRateDTO> marketRates;

	public List<MarketRateDTO> getMarketRates() {
		return marketRates;
	}

	public MarketRateRequestDTO setMarketRates(List<MarketRateDTO> marketRates) {
		this.marketRates = marketRates;
		return this;
	}

	public String getMarketRateCalculationParameter() {
		return marketRateCalculationParameter;
	}

	public MarketRateRequestDTO setMarketRateCalculationParameter(
			String marketRateCalculationParameter) {
		this.marketRateCalculationParameter = marketRateCalculationParameter;
		return this;
	}

	public String getMarketRateRequestId() {
		return marketRateRequestId;
	}

	public MarketRateRequestDTO setMarketRateRequestId(
			String marketRateRequestId) {
		this.marketRateRequestId = marketRateRequestId;
		return this;
	}

	public static MarketRateRequestDTO instance() {
		return new MarketRateRequestDTO();
	}
}
