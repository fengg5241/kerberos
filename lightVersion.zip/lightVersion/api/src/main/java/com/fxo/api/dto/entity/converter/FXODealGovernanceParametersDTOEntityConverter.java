package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXODealGovernanceParametersDTO;
import com.fxo.dao.entity.FXODealGovernanceParameters;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class FXODealGovernanceParametersDTOEntityConverter extends
        BaseDTOEntityConverter<FXODealGovernanceParametersDTO, FXODealGovernanceParameters> {

}
