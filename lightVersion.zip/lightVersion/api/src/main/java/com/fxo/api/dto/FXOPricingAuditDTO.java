package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.AuditableDTO;

@AutoProperty
public class FXOPricingAuditDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	private String pricingRequestId;

	private String pricingResponseId;

	private String product;

	private String strategy;

	private Integer legCount;

	private String customerId;

	private String rmName;

	private String dealGovernanceResponse;

	private String requestPurpose;

	private String messageCode;

	public String getPricingRequestId() {
		return pricingRequestId;
	}

	public FXOPricingAuditDTO setPricingRequestId(String pricingRequestId) {
		this.pricingRequestId = pricingRequestId;
		return this;
	}

	public String getPricingResponseId() {
		return pricingResponseId;
	}

	public FXOPricingAuditDTO setPricingResponseId(String pricingResponseId) {
		this.pricingResponseId = pricingResponseId;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public FXOPricingAuditDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public FXOPricingAuditDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FXOPricingAuditDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public String getCustomerId() {
		return customerId;
	}

	public FXOPricingAuditDTO setCustomerId(String customerId) {
		this.customerId = customerId;
		return this;
	}

	public String getRmName() {
		return rmName;
	}

	public FXOPricingAuditDTO setRmName(String rmName) {
		this.rmName = rmName;
		return this;
	}

	public String getDealGovernanceResponse() {
		return dealGovernanceResponse;
	}

	public FXOPricingAuditDTO setDealGovernanceResponse(
			String dealGovernanceResponse) {
		this.dealGovernanceResponse = dealGovernanceResponse;
		return this;
	}

	public String getRequestPurpose() {
		return requestPurpose;
	}

	public FXOPricingAuditDTO setRequestPurpose(String requestPurpose) {
		this.requestPurpose = requestPurpose;
		return this;
	}

	public static FXOPricingAuditDTO instance() {
		return new FXOPricingAuditDTO();
	}

	public String getMessageCode() {
		return messageCode;
	}

	public FXOPricingAuditDTO setMessageCode(String messageCode) {
		this.messageCode = messageCode;
		return this;
	}

}
