package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.service.ITicketingRequestValidatorService;

public interface FXOTicketingRequestValidationServiceFactory extends
		Serializable {

	public ITicketingRequestValidatorService getTicketingRequestValidationService(
			String product);

}