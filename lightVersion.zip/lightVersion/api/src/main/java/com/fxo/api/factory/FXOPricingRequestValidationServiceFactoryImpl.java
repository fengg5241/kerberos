package com.fxo.api.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.service.IPricingRequestValidatorService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FXOPricingRequestValidationServiceFactoryImpl implements
		FXOPricingRequestValidationServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FXOPricingRequestValidationServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaPricingRequestValidationService")
	private IPricingRequestValidatorService vanillaPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "straddlePricingRequestValidationService")
	private IPricingRequestValidatorService straddlePricingRequestValidationService;

	@Autowired
	@Qualifier(value = "stranglePricingRequestValidationService")
	private IPricingRequestValidatorService stranglePricingRequestValidationService;

	@Autowired
	@Qualifier(value = "riskReversalPricingRequestValidationService")
	private IPricingRequestValidatorService riskReversalPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "spreadPricingRequestValidationService")
	private IPricingRequestValidatorService spreadPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "knockInPricingRequestValidationService")
	private IPricingRequestValidatorService knockInPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "knockOutPricingRequestValidationService")
	private IPricingRequestValidatorService knockOutPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "reverseKnockInPricingRequestValidationService")
	private IPricingRequestValidatorService reverseKnockInPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "reverseKnockOutPricingRequestValidationService")
	private IPricingRequestValidatorService reverseKnockOutPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "europeanKnockInPricingRequestValidationService")
	private IPricingRequestValidatorService europeanKnockInPricingRequestValidationService;

	@Autowired
	@Qualifier(value = "europeanKnockOutPricingRequestValidationService")
	private IPricingRequestValidatorService europeanKnockOutPricingRequestValidationService;

	@Override
	public IPricingRequestValidatorService getPricingRequestValidationService(
			String product) {

		IPricingRequestValidatorService pricingRequestValidatorService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			pricingRequestValidatorService = vanillaPricingRequestValidationService;
			break;

		case Products.PRODUCT_STRADDLE:
			pricingRequestValidatorService = straddlePricingRequestValidationService;
			break;

		case Products.PRODUCT_STRANGLE:
			pricingRequestValidatorService = stranglePricingRequestValidationService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			pricingRequestValidatorService = riskReversalPricingRequestValidationService;
			break;

		case Products.PRODUCT_SPREAD:
			pricingRequestValidatorService = spreadPricingRequestValidationService;
			break;

		case Products.PRODUCT_KNOCKIN:
			pricingRequestValidatorService = knockInPricingRequestValidationService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			pricingRequestValidatorService = knockOutPricingRequestValidationService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			pricingRequestValidatorService = reverseKnockInPricingRequestValidationService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			pricingRequestValidatorService = reverseKnockOutPricingRequestValidationService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			pricingRequestValidatorService = europeanKnockInPricingRequestValidationService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			pricingRequestValidatorService = europeanKnockOutPricingRequestValidationService;
			break;

		default:
			logger.error("failed to locate PricingRequestValidationService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return pricingRequestValidatorService;
	}

}