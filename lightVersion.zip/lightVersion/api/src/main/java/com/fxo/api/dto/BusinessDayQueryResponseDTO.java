package com.fxo.api.dto;

import org.joda.time.LocalDate;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class BusinessDayQueryResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String entity;

	private LocalDate businessDate;

	public String getEntity() {
		return entity;
	}

	public BusinessDayQueryResponseDTO setEntity(String entity) {
		this.entity = entity;
		return this;
	}

	public LocalDate getBusinessDate() {
		return businessDate;
	}

	public BusinessDayQueryResponseDTO setBusinessDate(LocalDate businessDate) {
		this.businessDate = businessDate;
		return this;
	}
	
	public static BusinessDayQueryResponseDTO instance() {
		return new BusinessDayQueryResponseDTO();
	}

}
