package com.fxo.api.fenics.service;

import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.exception.ApplicationException;

public interface IFenicsTicketingRequestGeneratorService {

	
	public String getFenicsTicketingRequest(TicketingRequestDTO ticketingRequestDTO) throws  ApplicationException ;
	
	


	
}
