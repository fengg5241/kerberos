package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOCurrencyDTO;
import com.fxo.dao.entity.FXOCurrency;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class FXOCurrencyDTOEntityConverter extends
		BaseDTOEntityConverter<FXOCurrencyDTO, FXOCurrency> {

}
