package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;


@AutoProperty
public class CodeValueDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String code;

	private String value;

	public String getCode() {
		return code;
	}

	public CodeValueDTO setCode(String code) {
		this.code = code;
		return this;
	}

	public String getValue() {
		return value;
	}

	public CodeValueDTO setValue(String value) {
		this.value = value;
		return this;
	}



}
