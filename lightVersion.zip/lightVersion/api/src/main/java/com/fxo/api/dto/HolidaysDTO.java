package com.fxo.api.dto;

import java.sql.Date;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class HolidaysDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String currency;

	private Date holidayDate;

	public String getCurrency() {
		return currency;
	}

	public HolidaysDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public Date getHolidayDate() {
		return holidayDate;
	}

	public HolidaysDTO setHolidayDate(Date holidayDate) {
		this.holidayDate = holidayDate;
		return this;
	}

}
