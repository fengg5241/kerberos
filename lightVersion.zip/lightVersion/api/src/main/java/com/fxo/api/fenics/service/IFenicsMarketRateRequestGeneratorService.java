package com.fxo.api.fenics.service;

import com.fxo.api.dto.MarketRateRequestDTO;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.exception.ApplicationException;

public interface IFenicsMarketRateRequestGeneratorService {
	static final String REQUEST_PREFIX = "MR_";

	static final String fenicsRequestPurpose = FenicsRequestPurpose.MARKET_RATES;
	static final String dealingConvention = null;

	public String generateFenicsMarketRateQueryRequestXML(MarketRateRequestDTO marketRateRequestDTO)
			throws ApplicationException;

}
