package com.fxo.api.fenics.service;

import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.constants.fenics.FenicsRequestPurpose;

public interface IFenicsPricingResponseMapperService {

	public static final String fenicsRequestPurpose = FenicsRequestPurpose.PRICING;
	public static final String fenicsCalculationParameters = FenicsCalculationParameters.SIDED;

	public PricingResponseDTO parseFenicsPricingResponseData(
			com.fxo.fenics.response.GfiMessageType responseMessageObject,
			PricingRequestDTO pricingRequestDTO);

}
