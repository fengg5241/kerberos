package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOTenorExpiryDatesDTO;
import com.fxo.dao.entity.FXOTenorExpiryDates;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class FXOTenorExpiryDatesDTOEntityConverter
		extends
		BaseCustomDTOEntityConverter<FXOTenorExpiryDatesDTO, FXOTenorExpiryDates> {

}
