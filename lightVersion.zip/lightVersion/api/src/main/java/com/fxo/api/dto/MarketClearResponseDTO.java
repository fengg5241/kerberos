package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class MarketClearResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String marketClearRequestId;

	private List<MarketClearRateDTO> rateTypes;

	public String getMarketClearRequestId() {
		return marketClearRequestId;
	}

	public MarketClearResponseDTO setMarketClearRequestId(
			String marketClearRequestId) {
		this.marketClearRequestId = marketClearRequestId;
		return this;
	}

	public List<MarketClearRateDTO> getRateTypes() {
		return rateTypes;
	}

	public MarketClearResponseDTO setRateTypes(
			List<MarketClearRateDTO> rateTypes) {
		this.rateTypes = rateTypes;
		return this;
	}
	
	public static MarketClearResponseDTO instance(){
		return new MarketClearResponseDTO();
	}
}
