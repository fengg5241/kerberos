package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class PricingResponseListDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private List<PricingResponseDTO> pricingResponses;

	public List<PricingResponseDTO> getPricingResponses() {
		return pricingResponses;
	}

	public PricingResponseListDTO setPricingResponses(
			List<PricingResponseDTO> pricingResponses) {
		this.pricingResponses = pricingResponses;
		return this;
	}

}
