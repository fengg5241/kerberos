package com.fxo.api.fenics.service;


public interface IFenicsMarketClearResponseProcessorService {

	public void processFenicsMarketClearResponse(String responseXML);

}
