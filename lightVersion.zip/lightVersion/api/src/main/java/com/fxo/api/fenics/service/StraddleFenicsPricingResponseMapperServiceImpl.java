package com.fxo.api.fenics.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.OptionClasses;
import com.fxo.constants.dealing.OptionStyles;
import com.fxo.constants.dealing.OptionTypes;
import com.fxo.constants.dealing.Products;
import com.fxo.framework.util.FXOStringUtility;

@Component(value = "straddleFenicsPricingResponseMapperService")
public class StraddleFenicsPricingResponseMapperServiceImpl extends
		AbstractFenicsStrategyPricingResponseMapperService {

	private static final Logger logger = LoggerFactory
			.getLogger(StraddleFenicsPricingResponseMapperServiceImpl.class);

	private static final String productCode = Products.PRODUCT_STRADDLE;
	public static final String optionStyle = OptionStyles.OPTION_STYLE_EUROPEAN;
	public static final String optionType = OptionTypes.OPTION_TYPE_VANILLA_SINGLE_LEG;
	public static final String optionClass = OptionClasses.OPTION_CLASS_VANILLA;

	@Override
	public void setMiscFieldsInOptionLeg(String dealingConvention,
			OptionLegDTO optionLegDTO) {
		optionLegDTO.setProduct(productCode).setOptionStyle(optionStyle)
				.setOptionType(optionType).setOptionClass(optionClass);

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(optionLegDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTO = getFxoParametersMappingService()
					.getOneParameterMappingByParameterTypeAndParameterTargetValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							optionLegDTO.getDirection());
			optionLegDTO.setDirection(fxoParametersMappingDTO
					.getParameterSourceValue());
		}

		if (DealingConvention.config
				.isCounterMarketConvention(dealingConvention)) {

			optionLegDTO.setLegStrategy(LegStrategies.invert(optionLegDTO
					.getLegStrategy()));
		}

	}
}
