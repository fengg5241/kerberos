package com.fxo.api.dto;

import java.math.BigDecimal;

import org.joda.time.DateTime;
import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOProductStructureExtractDTO extends BaseCustomDTO implements
		Cloneable {

	private static final long serialVersionUID = 1L;

	private String product;

	private String productType;

	private String optionType;

	private String optionClass;

	private String optionStyle;

	private String strategy;

	private Integer legCount;

	private String currency;

	private String counterCurrency;

	private String faceCurrency;

	private String counterFaceCurrency;

	private Boolean hasACommodity;

	private String premiumCurrency;

	private String counterPremiumCurrency;

	private String direction;

	private String legStrategy;

	private String maturity;

	private DateTime expiryDate;

	private DateTime deliveryDate;

	private BigDecimal marginAmount;

	private BigDecimal localMarginAmount;

	private BigDecimal counterLocalMarginAmount;

	private BigDecimal internalCost;

	private BigDecimal percentInternalCost;

	private BigDecimal spotRate;

	private BigDecimal trigger;

	private BigDecimal strike;

	private BigDecimal counterStrike;

	private BigDecimal premium;

	private BigDecimal percentPremium;

	private BigDecimal counterPremium;

	private BigDecimal percentCounterPremium;

	private BigDecimal amount;

	private BigDecimal counterAmount;

	private BigDecimal notionalInPremiumCurrency;

	private BigDecimal notionalInForeCurrency;

	private BigDecimal counterNotionalInPremiumCurrency;

	private BigDecimal counterNotionalInCounterCurrency;

	private BigDecimal percentVegaAmount;

	private BigDecimal vegaAmount;

	private BigDecimal percentDeltaAmount;

	private BigDecimal deltaAmount;

	private BigDecimal delta;

	private BigDecimal stealth;

	private BigDecimal volatilityRate;

	private Integer optionIndex;

	private String fieldLevel;

	public String getCurrency() {
		return currency;
	}

	public FXOProductStructureExtractDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getCounterCurrency() {
		return counterCurrency;
	}

	public FXOProductStructureExtractDTO setCounterCurrency(
			String counterCurrency) {
		this.counterCurrency = counterCurrency;
		return this;
	}

	public String getFaceCurrency() {
		return faceCurrency;
	}

	public FXOProductStructureExtractDTO setFaceCurrency(String faceCurrency) {
		this.faceCurrency = faceCurrency;
		return this;
	}

	public String getCounterFaceCurrency() {
		return counterFaceCurrency;
	}

	public FXOProductStructureExtractDTO setCounterFaceCurrency(
			String counterFaceCurrency) {
		this.counterFaceCurrency = counterFaceCurrency;
		return this;
	}

	public String getPremiumCurrency() {
		return premiumCurrency;
	}

	public FXOProductStructureExtractDTO setPremiumCurrency(
			String premiumCurrency) {
		this.premiumCurrency = premiumCurrency;
		return this;
	}

	public String getCounterPremiumCurrency() {
		return counterPremiumCurrency;
	}

	public FXOProductStructureExtractDTO setCounterPremiumCurrency(
			String counterPremiumCurrency) {
		this.counterPremiumCurrency = counterPremiumCurrency;
		return this;
	}

	public String getMaturity() {
		return maturity;
	}

	public FXOProductStructureExtractDTO setMaturity(String maturity) {
		this.maturity = maturity;
		return this;
	}

	public DateTime getExpiryDate() {
		return expiryDate;
	}

	public FXOProductStructureExtractDTO setExpiryDate(DateTime expiryDate) {
		this.expiryDate = expiryDate;
		return this;
	}

	public DateTime getDeliveryDate() {
		return deliveryDate;
	}

	public FXOProductStructureExtractDTO setDeliveryDate(DateTime deliveryDate) {
		this.deliveryDate = deliveryDate;
		return this;
	}

	public BigDecimal getMarginAmount() {
		return marginAmount;
	}

	public FXOProductStructureExtractDTO setMarginAmount(BigDecimal marginAmount) {
		this.marginAmount = marginAmount;
		return this;
	}

	public BigDecimal getLocalMarginAmount() {
		return localMarginAmount;
	}

	public FXOProductStructureExtractDTO setLocalMarginAmount(
			BigDecimal localMarginAmount) {
		this.localMarginAmount = localMarginAmount;
		return this;
	}

	public BigDecimal getCounterLocalMarginAmount() {
		return counterLocalMarginAmount;
	}

	public FXOProductStructureExtractDTO setCounterLocalMarginAmount(
			BigDecimal counterLocalMarginAmount) {
		this.counterLocalMarginAmount = counterLocalMarginAmount;
		return this;
	}

	public BigDecimal getPremium() {
		return premium;
	}

	public FXOProductStructureExtractDTO setPremium(BigDecimal premium) {
		this.premium = premium;
		return this;
	}

	public BigDecimal getCounterPremium() {
		return counterPremium;
	}

	public FXOProductStructureExtractDTO setCounterPremium(
			BigDecimal counterPremium) {
		this.counterPremium = counterPremium;
		return this;
	}

	public BigDecimal getPercentPremium() {
		return percentPremium;
	}

	public FXOProductStructureExtractDTO setPercentPremium(
			BigDecimal percentPremium) {
		this.percentPremium = percentPremium;
		return this;
	}

	public BigDecimal getPercentCounterPremium() {
		return percentCounterPremium;
	}

	public FXOProductStructureExtractDTO setPercentCounterPremium(
			BigDecimal percentCounterPremium) {
		this.percentCounterPremium = percentCounterPremium;
		return this;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public FXOProductStructureExtractDTO setAmount(BigDecimal amount) {
		this.amount = amount;
		return this;
	}

	public BigDecimal getCounterAmount() {
		return counterAmount;
	}

	public FXOProductStructureExtractDTO setCounterAmount(
			BigDecimal counterAmount) {
		this.counterAmount = counterAmount;
		return this;
	}

	public BigDecimal getPercentVegaAmount() {
		return percentVegaAmount;
	}

	public FXOProductStructureExtractDTO setPercentVegaAmount(
			BigDecimal percentVegaAmount) {
		this.percentVegaAmount = percentVegaAmount;
		return this;
	}

	public BigDecimal getVegaAmount() {
		return vegaAmount;
	}

	public FXOProductStructureExtractDTO setVegaAmount(BigDecimal vegaAmount) {
		this.vegaAmount = vegaAmount;
		return this;
	}

	public BigDecimal getPercentDeltaAmount() {
		return percentDeltaAmount;
	}

	public FXOProductStructureExtractDTO setPercentDeltaAmount(
			BigDecimal percentDeltaAmount) {
		this.percentDeltaAmount = percentDeltaAmount;
		return this;
	}

	public BigDecimal getDeltaAmount() {
		return deltaAmount;
	}

	public FXOProductStructureExtractDTO setDeltaAmount(BigDecimal deltaAmount) {
		this.deltaAmount = deltaAmount;
		return this;
	}

	public BigDecimal getDelta() {
		return delta;
	}

	public FXOProductStructureExtractDTO setDelta(BigDecimal delta) {
		this.delta = delta;
		return this;
	}

	public BigDecimal getStealth() {
		return stealth;
	}

	public FXOProductStructureExtractDTO setStealth(BigDecimal stealth) {
		this.stealth = stealth;
		return this;
	}

	public BigDecimal getVolatilityRate() {
		return volatilityRate;
	}

	public FXOProductStructureExtractDTO setVolatilityRate(
			BigDecimal volatilityRate) {
		this.volatilityRate = volatilityRate;
		return this;
	}

	public String getProduct() {
		return product;
	}

	public FXOProductStructureExtractDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getDirection() {
		return direction;
	}

	public FXOProductStructureExtractDTO setDirection(String direction) {
		this.direction = direction;
		return this;
	}

	public String getLegStrategy() {
		return legStrategy;
	}

	public FXOProductStructureExtractDTO setLegStrategy(String legStrategy) {
		this.legStrategy = legStrategy;
		return this;
	}

	public Integer getOptionIndex() {
		return optionIndex;
	}

	public FXOProductStructureExtractDTO setOptionIndex(Integer optionIndex) {
		this.optionIndex = optionIndex;
		return this;
	}

	public String getProductType() {
		return productType;
	}

	public FXOProductStructureExtractDTO setProductType(String productType) {
		this.productType = productType;
		return this;
	}

	public String getFieldLevel() {
		return fieldLevel;
	}

	public FXOProductStructureExtractDTO setFieldLevel(String fieldLevel) {
		this.fieldLevel = fieldLevel;
		return this;
	}

	public BigDecimal getPercentInternalCost() {
		return percentInternalCost;
	}

	public FXOProductStructureExtractDTO setPercentInternalCost(
			BigDecimal percentInternalCost) {
		this.percentInternalCost = percentInternalCost;
		return this;
	}

	public BigDecimal getNotionalInPremiumCurrency() {
		return notionalInPremiumCurrency;
	}

	public FXOProductStructureExtractDTO setNotionalInPremiumCurrency(
			BigDecimal notionalInPremiumCurrency) {
		this.notionalInPremiumCurrency = notionalInPremiumCurrency;
		return this;
	}

	public BigDecimal getCounterNotionalInPremiumCurrency() {
		return counterNotionalInPremiumCurrency;
	}

	public FXOProductStructureExtractDTO setCounterNotionalInPremiumCurrency(
			BigDecimal counterNotionalInPremiumCurrency) {
		this.counterNotionalInPremiumCurrency = counterNotionalInPremiumCurrency;
		return this;
	}

	public static FXOProductStructureExtractDTO instance() {
		return new FXOProductStructureExtractDTO();
	}

	public BigDecimal getInternalCost() {
		return internalCost;
	}

	public FXOProductStructureExtractDTO setInternalCost(BigDecimal internalCost) {
		this.internalCost = internalCost;
		return this;
	}

	public BigDecimal getStrike() {
		return strike;
	}

	public FXOProductStructureExtractDTO setStrike(BigDecimal strike) {
		this.strike = strike;
		return this;
	}

	public BigDecimal getCounterStrike() {
		return counterStrike;
	}

	public FXOProductStructureExtractDTO setCounterStrike(
			BigDecimal counterStrike) {
		this.counterStrike = counterStrike;
		return this;
	}

	public String getStrategy() {
		return strategy;
	}

	public FXOProductStructureExtractDTO setStrategy(String strategy) {
		this.strategy = strategy;
		return this;
	}

	public Integer getLegCount() {
		return legCount;
	}

	public FXOProductStructureExtractDTO setLegCount(Integer legCount) {
		this.legCount = legCount;
		return this;
	}

	public BigDecimal getSpotRate() {
		return spotRate;
	}

	public FXOProductStructureExtractDTO setSpotRate(BigDecimal spotRate) {
		this.spotRate = spotRate;
		return this;
	}

	public BigDecimal getTrigger() {
		return trigger;
	}

	public FXOProductStructureExtractDTO setTrigger(BigDecimal trigger) {
		this.trigger = trigger;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public FXOProductStructureExtractDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public FXOProductStructureExtractDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getOptionStyle() {
		return optionStyle;
	}

	public FXOProductStructureExtractDTO setOptionStyle(String optionStyle) {
		this.optionStyle = optionStyle;
		return this;
	}

	public BigDecimal getNotionalInForeCurrency() {
		return notionalInForeCurrency;
	}

	public FXOProductStructureExtractDTO setNotionalInForeCurrency(
			BigDecimal notionalInForeCurrency) {
		this.notionalInForeCurrency = notionalInForeCurrency;
		return this;
	}

	public BigDecimal getCounterNotionalInCounterCurrency() {
		return counterNotionalInCounterCurrency;
	}

	public FXOProductStructureExtractDTO setCounterNotionalInCounterCurrency(
			BigDecimal counterNotionalInCounterCurrency) {
		this.counterNotionalInCounterCurrency = counterNotionalInCounterCurrency;
		return this;
	}

	public Boolean getHasACommodity() {
		return hasACommodity;
	}

	public FXOProductStructureExtractDTO setHasACommodity(Boolean hasACommodity) {
		this.hasACommodity = hasACommodity;
		return this;
	}

	@Override
	public FXOProductStructureExtractDTO clone() {
		return instance()
				.setProduct(product)
				.setProductType(productType)
				.setOptionType(optionType)
				.setStrategy(strategy)
				.setLegCount(legCount)
				.setCurrency(currency)
				.setCounterCurrency(counterCurrency)
				.setFaceCurrency(faceCurrency)
				.setPremiumCurrency(premiumCurrency)
				.setCounterPremiumCurrency(counterPremiumCurrency)
				.setAmount(amount)
				.setCounterAmount(counterAmount)
				.setPremium(premium)
				.setCounterPremium(counterPremium)
				.setNotionalInPremiumCurrency(notionalInPremiumCurrency)
				.setNotionalInForeCurrency(notionalInForeCurrency)
				.setCounterNotionalInPremiumCurrency(
						counterNotionalInPremiumCurrency)
				.setCounterNotionalInCounterCurrency(
						counterNotionalInCounterCurrency)
				.setInternalCost(internalCost).setStrike(strike)
				.setCounterStrike(counterStrike).setSpotRate(spotRate)
				.setTrigger(trigger).setHasACommodity(hasACommodity);
	}

}
