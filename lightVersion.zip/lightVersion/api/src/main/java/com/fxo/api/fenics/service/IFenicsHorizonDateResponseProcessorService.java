package com.fxo.api.fenics.service;

import com.fxo.api.dto.FXOSystemDateDTO;

public interface IFenicsHorizonDateResponseProcessorService {

	public FXOSystemDateDTO processFenicsResponse(
			String responseXML);

}
