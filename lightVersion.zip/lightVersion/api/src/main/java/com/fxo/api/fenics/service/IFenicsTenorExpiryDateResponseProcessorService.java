package com.fxo.api.fenics.service;

import com.fxo.api.dto.FXOTenorExpiryDatesDTO;

public interface IFenicsTenorExpiryDateResponseProcessorService {

	public FXOTenorExpiryDatesDTO processFenicsTenorExpiryDateResponse(
			String responseXML, FXOTenorExpiryDatesDTO fxoTenorExpiryDatesDTO);

}
