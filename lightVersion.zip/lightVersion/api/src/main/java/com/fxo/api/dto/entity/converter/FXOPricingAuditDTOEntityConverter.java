package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOPricingAuditDTO;
import com.fxo.dao.entity.FXOPricingAudit;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

@Component
public class FXOPricingAuditDTOEntityConverter extends
		BaseDTOEntityConverter<FXOPricingAuditDTO, FXOPricingAudit> {

}
