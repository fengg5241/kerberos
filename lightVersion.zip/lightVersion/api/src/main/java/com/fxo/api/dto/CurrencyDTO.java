package com.fxo.api.dto;

import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.BaseDTO;

public class CurrencyDTO extends BaseDTO implements Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String currency;

	private String longName;

	private String shortName;

	@Property(policy = PojomaticPolicy.ALL)
	private String symbol;

	private String countryName;

	private Integer amountPrecision;

	private Integer ratePrecision;

	private String status;

	private String premiumCurrencyCode;

	private Boolean isCommodity;

	public String getCurrency() {
		return currency;
	}

	public CurrencyDTO setCurrency(String currency) {
		this.currency = currency;
		return this;
	}

	public String getLongName() {
		return longName;
	}

	public CurrencyDTO setLongName(String longName) {
		this.longName = longName;
		return this;
	}

	public String getShortName() {
		return shortName;
	}

	public CurrencyDTO setShortName(String shortName) {
		this.shortName = shortName;
		return this;
	}

	public String getSymbol() {
		return symbol;
	}

	public CurrencyDTO setSymbol(String symbol) {
		this.symbol = symbol;
		return this;
	}

	public String getCountryName() {
		return countryName;
	}

	public CurrencyDTO setCountryName(String countryName) {
		this.countryName = countryName;
		return this;
	}

	public Integer getAmountPrecision() {
		return amountPrecision;
	}

	public CurrencyDTO setAmountPrecision(Integer amountPrecision) {
		this.amountPrecision = amountPrecision;
		return this;
	}

	public Integer getRatePrecision() {
		return ratePrecision;
	}

	public CurrencyDTO setRatePrecision(Integer ratePrecision) {
		this.ratePrecision = ratePrecision;
		return this;
	}

	public String getStatus() {
		return status;
	}

	public CurrencyDTO setStatus(String status) {
		this.status = status;
		return this;
	}

	public String getPremiumCurrencyCode() {
		return premiumCurrencyCode;
	}

	public CurrencyDTO setPremiumCurrencyCode(String premiumCurrencyCode) {
		this.premiumCurrencyCode = premiumCurrencyCode;
		return this;
	}

	public Boolean getIsCommodity() {
		return isCommodity;
	}

	public CurrencyDTO setIsCommodity(Boolean isCommodity) {
		this.isCommodity = isCommodity;
		return this;
	}

	@Override
	public CurrencyDTO clone() throws CloneNotSupportedException {
		return new CurrencyDTO().setCurrency(getCurrency())
				.setAmountPrecision(getAmountPrecision())
				.setCountryName(getCountryName()).setLongName(getLongName())
				.setRatePrecision(getRatePrecision())
				.setShortName(getShortName()).setSymbol(getSymbol())
				.setStatus(getStatus())
				.setPremiumCurrencyCode(getPremiumCurrencyCode())
				.setIsCommodity(getIsCommodity());
	}

}
