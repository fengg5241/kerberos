package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.RateDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.ICurrencyPairGroupService;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsXMLNodeTypes;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.factory.IFenicsXMLMapperFactory;
import com.fxo.fenics.util.ReflectionUtility;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

public abstract class AbstractFenicsPricingResponseMapperService implements
		IFenicsPricingResponseMapperService {

	/** The Constant logger. */
	private static final Logger logger = LoggerFactory
			.getLogger(AbstractFenicsPricingResponseMapperService.class);

	public static final Integer DEFAULT_PRECISION = 6;

	@Autowired
	private IFenicsXMLMapperFactory fenicsXMLMapperFactory;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private ICurrencyPairGroupService currencyPairService;

	/**
	 * <p>
	 * Translate FenicsResponse [Leg Node] to OptionLegDTO [FXO Representation]
	 * <p>
	 * <ol>
	 * <li>
	 * Mapping properties are derived based on dealingConvention
	 * <ul>
	 * <li>FenicsPricingResponseLegFieldMarketConventionMap for market
	 * Convention</li>
	 * <li>FenicsPricingResponseLegFieldCounterMarketConventionMap for Counter
	 * Market Convention</li>
	 * </ul>
	 * </li>
	 * 
	 * @param fenicsResponseLegNode
	 *            [{@link com.fxo.fenics.response.NodeType}]
	 * @param dealingConvention
	 *            [{@link String}]
	 * @return OptionLeg [{@link OptionLegDTO}]
	 */
	public OptionLegDTO translateFenicsResponseLegNode(
			com.fxo.fenics.response.NodeType fenicsResponseLegNode,
			String dealingConvention) {

		Map<String, String> fenicsResponseFieldMap = fenicsXMLMapperFactory
				.getXMLResponsePropertyMapper(fenicsRequestPurpose,
						dealingConvention, FenicsXMLNodeTypes.NODE_TYPE_LEG);

		if (fenicsResponseFieldMap == null || fenicsResponseFieldMap.isEmpty()) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while translating FenicsResponseNode - responseNodes-Leg from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		List<com.fxo.fenics.response.FieldType> fenicsResponseFieldList = fenicsResponseLegNode
				.getField();

		if (fenicsResponseFieldList == null
				|| fenicsResponseFieldList.size() == 0) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while translating FenicsResponseNode - responseNodes-Leg from fenics is empty";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		OptionLegDTO optionLegDTO = OptionLegDTO.instance();

		for (com.fxo.fenics.response.FieldType fenicsResponseField : fenicsResponseFieldList) {
			if (fenicsResponseFieldMap.get(fenicsResponseField.getName()) != null) {
				ReflectionUtility.setFieldInSuperClass(optionLegDTO,
						fenicsResponseFieldMap.get(fenicsResponseField
								.getName()), fenicsResponseField
								.getFieldValue());
			}
		}

		return optionLegDTO;
	}

	/**
	 * translate FenicsResponseSummaryNode to FieldValueDTO [FXO Representation]
	 * <p>
	 * <ol>
	 * <li>
	 * Mapping properties are derived based on dealingConvention
	 * <ul>
	 * <li>FenicsPricingResponseSummaryFieldMarketConventionMap for market
	 * Convention</li>
	 * <li>FenicsPricingResponseSummaryFieldCounterMarketConventionMap for
	 * Counter Market Convention</li>
	 * </ul>
	 * </li>
	 * 
	 * @param fenicsResponseSummaryNode
	 *            [{@link com.fxo.fenics.response.NodeType}]
	 * @param dealingConvention
	 *            [{@link String}]
	 * @return summary [{@link FieldValueDTO}]
	 */
	public FieldValueDTO translateFenicsResponseSummaryNode(
			com.fxo.fenics.response.NodeType fenicsResponseSummaryNode,
			String dealingConvention) {

		FieldValueDTO fieldValueDTO = new FieldValueDTO();

		List<com.fxo.fenics.response.FieldType> responseFieldList = fenicsResponseSummaryNode
				.getField();

		if (responseFieldList == null || responseFieldList.size() == 0) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while translate FenicsResponseStrategySummaryNode - responseNodes-Leg from fenics is empty";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		Map<String, String> map = fenicsXMLMapperFactory
				.getXMLResponsePropertyMapper(fenicsRequestPurpose,
						dealingConvention, FenicsXMLNodeTypes.NODE_TYPE_SUMMARY);

		if (map == null || map.isEmpty()) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while translate FenicsResponseStrategySummaryNode - responseNodes-Leg from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		for (com.fxo.fenics.response.FieldType entry : responseFieldList) {
			if (map.get(entry.getName()) != null) {
				ReflectionUtility.setField(fieldValueDTO,
						map.get(entry.getName()), entry.getFieldValue());
			}
		}

		return fieldValueDTO;
	}

	public void computeMarketRates(FieldValueDTO summary,
			Integer ratePrecision, String sign) {

		// spot

		String spot = summary.getSpot();

		RateDTO rateDTO_Spot = (FXOStringUtility.isNotEmpty(spot)) ? MarketRateUtility
				.extractRate(summary.getSpot(), sign, ratePrecision) : RateDTO
				.instance();

		summary.setSpotRate(rateDTO_Spot.getComputedRate());
		summary.setBidSpotRate(rateDTO_Spot.getBidRate());
		summary.setAskSpotRate(rateDTO_Spot.getAskRate());

		// forward
		String forward = summary.getForward();

		RateDTO rateDTO_Forward = (FXOStringUtility.isNotEmpty(forward)) ? MarketRateUtility
				.extractRate(forward, sign, ratePrecision) : RateDTO.instance();

		summary.setForwardRate(rateDTO_Forward.getComputedRate());
		summary.setBidForwardRate(rateDTO_Forward.getBidRate());
		summary.setAskForwardRate(rateDTO_Forward.getAskRate());

		// volatility

		String volatility = summary.getVolatility();

		RateDTO rateDTO_Volatility = (FXOStringUtility.isNotEmpty(volatility)) ? MarketRateUtility
				.extractRate(volatility, sign, ratePrecision) : RateDTO
				.instance();

		summary.setVolatilityRate(rateDTO_Volatility.getComputedRate());
		summary.setBidVolatilityRate(rateDTO_Volatility.getBidRate());
		summary.setAskVolatilityRate(rateDTO_Volatility.getAskRate());

	}

	public Integer getRatePrecisionForCurrencyPair(String currency,
			String counterCurrency) {

		Integer ratePrecision = currencyPairService.getPrecision(currency,
				counterCurrency);

		return (ratePrecision == null) ? DEFAULT_PRECISION : ratePrecision;
	}

	public BigDecimal adjustToCurrencyPairPrecision(String decimalValueString,
			String currency, String counterCurrency) {

		Integer ratePrecision = getRatePrecisionForCurrencyPair(currency,
				counterCurrency);

		return MathUtil.createBigDecimal(decimalValueString, ratePrecision);
	}

	public BigDecimal adjustToCurrencyPairPrecision(BigDecimal decimalValue,
			String currency, String counterCurrency) {

		Integer ratePrecision = getRatePrecisionForCurrencyPair(currency,
				counterCurrency);

		return MathUtil.roundAndAdjustToPrecision(decimalValue, ratePrecision);
	}

	public String formatFenicsTimeString(String fenicsTimeString) {

		return fenicsTimeString.split(FXOWSConstantKeys.SPACE_DELIMITER)[0];
	}

	public IFenicsXMLMapperFactory getFenicsXMLMapperFactory() {
		return fenicsXMLMapperFactory;
	}

	public FenicsCustomDateTimeConverter getFenicsCustomDateTimeConverter() {
		return fenicsCustomDateTimeConverter;
	}

	public IFXOParametersMappingService getFxoParametersMappingService() {
		return fxoParametersMappingService;
	}

}
