package com.fxo.api.fenics.service;

import com.fxo.api.dto.MarketRateResponseDTO;

public interface IFenicsMarketRateResponseProcessorService {

	public MarketRateResponseDTO processFenicsMarketRateQueryResponse(
			String responseXML, String marketRateRequestId);

}
