package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXODealGovernanceParametersDTO;
import com.fxo.dao.entity.FXOInterportDealGovernanceParameters;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;

/**
 * currently converting to FXODealGovernanceParametersDTO as FXOInterportDealGovernanceParameters is same as FXODealGovernanceParameters
 * @author ishasaxena
 *
 */
@Component
public class FXOInterportDealGovernanceParametersDTOEntityConverter
		extends BaseDTOEntityConverter<FXODealGovernanceParametersDTO, FXOInterportDealGovernanceParameters> {

}
