package com.fxo.api.dto;

import java.math.BigDecimal;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class DeltaAmountValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

	// values derived from Pricing/Ticketing Request inputs (Inputs from
	// Webservice)

	private BigDecimal percentDeltaAmount;
	private BigDecimal deltaAmount;

	public BigDecimal getPercentDeltaAmount() {
		return percentDeltaAmount;
	}

	public DeltaAmountValidationDTO setPercentDeltaAmount(
			BigDecimal percentDeltaAmount) {
		this.percentDeltaAmount = percentDeltaAmount;
		return this;
	}

	public BigDecimal getDeltaAmount() {
		return deltaAmount;
	}

	public DeltaAmountValidationDTO setDeltaAmount(BigDecimal deltaAmount) {
		this.deltaAmount = deltaAmount;
		return this;
	}

	public static DeltaAmountValidationDTO instance(BigDecimal deltaAmount) {
		return new DeltaAmountValidationDTO().setDeltaAmount(deltaAmount);
	}

}
