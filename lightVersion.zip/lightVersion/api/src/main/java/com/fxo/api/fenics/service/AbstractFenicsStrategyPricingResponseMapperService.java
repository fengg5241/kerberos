package com.fxo.api.fenics.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.PricingRequestDTO;
import com.fxo.api.dto.PricingResponseDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.api.util.MarketRateUtility;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.Maturities;
import com.fxo.fenics.util.FenicsMaturityConverter;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.framework.util.FXOStringUtility;

public abstract class AbstractFenicsStrategyPricingResponseMapperService extends
		AbstractFenicsPricingResponseMapperService {

	private static final Logger logger = LoggerFactory
			.getLogger(AbstractFenicsStrategyPricingResponseMapperService.class);

	@Override
	public PricingResponseDTO parseFenicsPricingResponseData(
			com.fxo.fenics.response.GfiMessageType fenicsResponseMessageObject,
			PricingRequestDTO pricingRequestDTO) {

		PricingResponseDTO pricingResponseDTO = PricingResponseDTO
				.getInstanceWithEmptyLegs(pricingRequestDTO.getStructure()
						.getProduct());

		FXODealingUtil.extractStrategy(pricingResponseDTO.getStructure())
				.setPurpose(fenicsRequestPurpose);

		// extract FENICS Fields
		com.fxo.fenics.response.NodeType fenicsResponseSummaryNode = FenicsResponseNodeProcessor
				.extractResponseSummaryNode(fenicsResponseMessageObject);

		String dealingConvention = FXODealingUtil
				.fetchDealingConventionFromProductStructure(pricingRequestDTO.getStructure());

		FieldValueDTO responseSummaryDTO = processFenicsResponseSummaryNode(
				fenicsResponseSummaryNode, dealingConvention,
				FXODealingUtil.extractSummary(pricingRequestDTO.getStructure()));

		FXODealingUtil.extractStrategy(pricingResponseDTO.getStructure())
				.setSummary(responseSummaryDTO);

		// extract Node(s) from first data element (only single data element
		// will be considered for FXO Services)
		List<com.fxo.fenics.response.NodeType> fenicsResponseLegNodes = FenicsResponseNodeProcessor
				.extractResponseLegNodes(fenicsResponseMessageObject);

		for (com.fxo.fenics.response.NodeType fenicsResponseLegNode : fenicsResponseLegNodes) {

			OptionLegDTO optionLegDTO = processFenicsLegNode(
					fenicsResponseLegNode, dealingConvention,
					responseSummaryDTO);

			FXODealingUtil.extractOptionLegs(pricingResponseDTO.getStructure())
					.add(optionLegDTO);
		}

		FXODealingUtil.identifyAndPopulateDealingConventionInProductStructure(pricingResponseDTO
				.getStructure());

		return pricingResponseDTO;
	}

	public FieldValueDTO processFenicsResponseSummaryNode(
			com.fxo.fenics.response.NodeType fenicsResponseSummaryNode,
			String dealingConvention,
			FieldValueDTO strategySummaryObjectInPricingRequest) {

		FieldValueDTO summary = translateFenicsResponseSummaryNode(
				fenicsResponseSummaryNode, dealingConvention);

		Integer ratePrecision = getRatePrecisionForCurrencyPair(
				summary.getCurrency(), summary.getCounterCurrency());

		if (DealingConvention.config
				.isCounterMarketConvention(dealingConvention)) {

			if (FXOStringUtility.isNotEmpty(summary.getSpot())) {
				summary.setSpot(MarketRateUtility.invertRateSpread(
						summary.getSpot(), ratePrecision));
			}

			if (FXOStringUtility.isNotEmpty(summary.getForward())) {
				summary.setForward(MarketRateUtility.invertRateSpread(
						summary.getForward(), ratePrecision));
			}

		}

		String sign = MarketRateUtility.getSignFromAmount(
				summary.getCurrency(), summary.getPremiumCurrency(),
				summary.getPercentDeltaAmount(), summary.getDeltaAmount());

		logger.info(String
				.format("rate from SpreadedRates for summary - Using Sign [%s] from inputs Currency : %s , PremiumCurrency : %s , PercentDeltaAmount : %f , DeltaAmount : %f ",
						sign, summary.getCurrency(),
						summary.getPremiumCurrency(),
						summary.getPercentDeltaAmount(),
						summary.getDeltaAmount()));

		computeMarketRates(summary, ratePrecision, sign);

		String fxoExpiryTimeString = (FXOStringUtility.isNotEmpty(summary
				.getExpiryTimeString())) ? formatFenicsTimeString(summary
				.getExpiryTimeString()) : null;

		summary.setExpiryTimeString(fxoExpiryTimeString);

		getFenicsCustomDateTimeConverter().translateFenicsDateStringToDateTime(
				summary);

		if (FXOStringUtility.isNotEmpty(summary.getMaturity())
				&& FXOStringUtility.areNotIdentical(summary.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation
			if (FXOStringUtility.isNotEmpty(summary.getMaturity())) {
				summary.setMaturity(FenicsMaturityConverter
						.getFXOMaturityCode(summary.getMaturity()));
			}
		}

		return summary
				.setAmount(null)
				.setCounterAmount(null)
				.setOptionType(null)
				.setMarginAmount(
						strategySummaryObjectInPricingRequest.getMarginAmount())
				.setMaturity(
						strategySummaryObjectInPricingRequest.getMaturity())
				.setCurrency(
						strategySummaryObjectInPricingRequest.getCurrency())
				.setCounterCurrency(
						strategySummaryObjectInPricingRequest
								.getCounterCurrency())
				.setFaceCurrency(
						strategySummaryObjectInPricingRequest.getFaceCurrency())
				.setPremiumCurrency(
						strategySummaryObjectInPricingRequest
								.getPremiumCurrency())
				.setStrategy(
						strategySummaryObjectInPricingRequest.getStrategy())
				.setSolveFor(
						strategySummaryObjectInPricingRequest.getSolveFor())
				.setPurpose(fenicsRequestPurpose)
				.setCalculationType(fenicsCalculationParameters)
				.setDirection(
						strategySummaryObjectInPricingRequest.getDirection())
				.setLegStrategy(
						strategySummaryObjectInPricingRequest.getLegStrategy())
				.setStrike(strategySummaryObjectInPricingRequest.getStrike());
	}

	public OptionLegDTO processFenicsLegNode(
			com.fxo.fenics.response.NodeType fenicsResponseLegNode,
			String dealingConvention, FieldValueDTO responseSummaryDTO) {

		OptionLegDTO optionLegDTO = translateFenicsResponseLegNode(
				fenicsResponseLegNode, dealingConvention);

		setMiscFieldsInOptionLeg(dealingConvention, optionLegDTO);

		String currency = responseSummaryDTO.getCurrency();
		String counterCurrency = responseSummaryDTO.getCounterCurrency();

		Integer ratePrecision = getRatePrecisionForCurrencyPair(currency,
				counterCurrency);

		if (DealingConvention.config
				.isCounterMarketConvention(dealingConvention)) {

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getSpot())) {
				optionLegDTO.setSpot(MarketRateUtility.invertRateSpread(
						optionLegDTO.getSpot(), ratePrecision));
			}

			if (FXOStringUtility.isNotEmpty(optionLegDTO.getForward())) {
				optionLegDTO.setForward(MarketRateUtility.invertRateSpread(
						optionLegDTO.getForward(), ratePrecision));
			}

		}

		String sign = MarketRateUtility.getSignFromAmount(currency,
				responseSummaryDTO.getPremiumCurrency(),
				optionLegDTO.getPercentDeltaAmount(),
				optionLegDTO.getDeltaAmount());

		logger.info(String
				.format("rate from SpreadedRates for OptionLeg - Using Sign [%s] from inputs Currency : %s , PremiumCurrency : %s , PercentDeltaAmount : %f , DeltaAmount : %f ",
						sign, optionLegDTO.getCurrency(),
						optionLegDTO.getPremiumCurrency(),
						optionLegDTO.getPercentDeltaAmount(),
						optionLegDTO.getDeltaAmount()));

		computeMarketRates(optionLegDTO, ratePrecision, sign);

		String fxoExpiryTimeString = (FXOStringUtility.isNotEmpty(optionLegDTO
				.getExpiryTimeString())) ? formatFenicsTimeString(optionLegDTO
				.getExpiryTimeString()) : null;

		optionLegDTO.setExpiryTimeString(fxoExpiryTimeString);

		getFenicsCustomDateTimeConverter().translateFenicsDateStringToDateTime(
				optionLegDTO);

		if (FXOStringUtility.isNotEmpty(optionLegDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(optionLegDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			// translate tenor from fenics value to FXO-Portal representation

			optionLegDTO.setMaturity(FenicsMaturityConverter
					.getFXOMaturityCode(optionLegDTO.getMaturity()));

		}

		return optionLegDTO;
	}

	public abstract void setMiscFieldsInOptionLeg(String dealingConvention,
			OptionLegDTO optionLegDTO);
}
