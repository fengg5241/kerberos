package com.fxo.api.dto.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.CurrencyConversionRequestDTO;
import com.fxo.api.dto.CurrencyConversionResponseDTO;
import com.fxo.framework.core.dto.BaseCustomSourceBaseCustomTargetDTOConverter;

@Component
public class CurrencyConversionSourceTargetDTOConverter
		extends
		BaseCustomSourceBaseCustomTargetDTOConverter<CurrencyConversionRequestDTO, CurrencyConversionResponseDTO> {

}
