package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOProductCatalogueGroupDTO;
import com.fxo.dao.entity.FXOProductCatalogueGroup;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;



@Component
public class FXOProductCatalogueGroupDTOEntityConverter extends
        BaseCustomDTOEntityConverter<FXOProductCatalogueGroupDTO, FXOProductCatalogueGroup> {

}
