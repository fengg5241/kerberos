package com.fxo.api.factory;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.reports.IDealConfirmationReportMapper;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;

@Component
public class DealConfirmationReportMapperServiceFactoryImpl implements
		DealConfirmationReportMapperServiceFactory {

	private static final long serialVersionUID = 1L;

	@Autowired
	@Qualifier(value = "vanillaDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper vanillaDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "straddleDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper straddleDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "strangleDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper strangleDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "riskReversalDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper riskReversalDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "spreadDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper spreadDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "knockInDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper knockInDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "knockOutDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper knockOutDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockInDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper reverseKnockInDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockOutDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper reverseKnockOutDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockInDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper europeanKnockInDealConfirmationReportMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockOutDealConfirmationReportMapperService")
	private IDealConfirmationReportMapper europeanKnockOutDealConfirmationReportMapperService;

	@Override
	public IDealConfirmationReportMapper getDealConfirmationReportMapperService(
			String product) {

		Objects.requireNonNull(product,
				FXOMessageCodes.ERR_PRODUCT_STRUCTURE_INVALID);

		Objects.requireNonNull(product, FXOMessageCodes.ERR_PRODUCT_INVALID);

		IDealConfirmationReportMapper dealConfirmationReportMapperService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			dealConfirmationReportMapperService = vanillaDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_STRADDLE:
			dealConfirmationReportMapperService = straddleDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_STRANGLE:
			dealConfirmationReportMapperService = strangleDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			dealConfirmationReportMapperService = riskReversalDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_SPREAD:
			dealConfirmationReportMapperService = spreadDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_KNOCKIN:
			dealConfirmationReportMapperService = knockInDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			dealConfirmationReportMapperService = knockOutDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			dealConfirmationReportMapperService = reverseKnockInDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			dealConfirmationReportMapperService = reverseKnockOutDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			dealConfirmationReportMapperService = europeanKnockInDealConfirmationReportMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			dealConfirmationReportMapperService = europeanKnockOutDealConfirmationReportMapperService;
			break;

		default:
			dealConfirmationReportMapperService = null;
			break;
		}

		Objects.requireNonNull(dealConfirmationReportMapperService,
				FXOMessageCodes.ERR_SERVICE_DISCOVERY);

		return dealConfirmationReportMapperService;
	}
}
