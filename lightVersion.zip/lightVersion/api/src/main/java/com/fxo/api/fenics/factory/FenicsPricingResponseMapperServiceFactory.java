package com.fxo.api.fenics.factory;

import java.io.Serializable;

import com.fxo.api.fenics.service.IFenicsPricingResponseMapperService;

public interface FenicsPricingResponseMapperServiceFactory extends Serializable {

	public IFenicsPricingResponseMapperService getFenicsPricingResponseMapperService(
			String product);

}
