package com.fxo.api.fenics.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsPropertyMapper;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;

@Service
public class FenicsMarketClearResponseProcessorServiceImpl implements
		IFenicsMarketClearResponseProcessorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsMarketClearResponseProcessorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private FenicsPropertyMapper fenicsPropertyMapper;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Override
	public void processFenicsMarketClearResponse(String responseXML) {

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;
		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);
		} catch (ApplicationException e) {
			logger.info(e.getMessage(), e);
			throw new ApplicationRuntimeException(e.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE);
		}

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:
			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:
			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info(String.format("FENICS - Warning Message %s : %s - %s",
					"Market-Clear", responseMessageObject.getHeader()
							.getTransactionId(), warningMessages.toString()));

			break;

		default:
			break;
		}

	}

}