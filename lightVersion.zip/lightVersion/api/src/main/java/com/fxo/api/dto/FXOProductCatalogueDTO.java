package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class FXOProductCatalogueDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String product;

	private String productLabel;

	private String optionClass;

	private String optionClassLabel;

	private String optionType;

	private String optionTypeLabel;

	private boolean isStrategy;

	private Long pricingExpiryTime;

	private boolean choiceLegPricingRequired;

	private Integer defaultLegCount;

	private boolean isInterfacedWithAvaloq;

	private String model;

	public String getProduct() {
		return product;
	}

	public FXOProductCatalogueDTO setProduct(String product) {
		this.product = product;
		return this;
	}

	public String getOptionClass() {
		return optionClass;
	}

	public FXOProductCatalogueDTO setOptionClass(String optionClass) {
		this.optionClass = optionClass;
		return this;
	}

	public String getOptionType() {
		return optionType;
	}

	public FXOProductCatalogueDTO setOptionType(String optionType) {
		this.optionType = optionType;
		return this;
	}

	public boolean isStrategy() {
		return isStrategy;
	}

	public FXOProductCatalogueDTO setStrategy(boolean isStrategy) {
		this.isStrategy = isStrategy;
		return this;
	}

	public String getProductLabel() {
		return productLabel;
	}

	public FXOProductCatalogueDTO setProductLabel(String productLabel) {
		this.productLabel = productLabel;
		return this;
	}

	public String getOptionClassLabel() {
		return optionClassLabel;
	}

	public FXOProductCatalogueDTO setOptionClassLabel(String optionClassLabel) {
		this.optionClassLabel = optionClassLabel;
		return this;
	}

	public String getOptionTypeLabel() {
		return optionTypeLabel;
	}

	public FXOProductCatalogueDTO setOptionTypeLabel(String optionTypeLabel) {
		this.optionTypeLabel = optionTypeLabel;
		return this;
	}

	public Long getPricingExpiryTime() {
		return pricingExpiryTime;
	}

	public FXOProductCatalogueDTO setPricingExpiryTime(Long pricingExpiryTime) {
		this.pricingExpiryTime = pricingExpiryTime;
		return this;
	}

	public boolean isChoiceLegPricingRequired() {
		return choiceLegPricingRequired;
	}

	public FXOProductCatalogueDTO setChoiceLegPricingRequired(
			boolean choiceLegPricingRequired) {
		this.choiceLegPricingRequired = choiceLegPricingRequired;
		return this;
	}

	public Integer getDefaultLegCount() {
		return defaultLegCount;
	}

	public FXOProductCatalogueDTO setDefaultLegCount(Integer defaultLegCount) {
		this.defaultLegCount = defaultLegCount;
		return this;
	}

	public boolean isInterfacedWithAvaloq() {
		return isInterfacedWithAvaloq;
	}

	public FXOProductCatalogueDTO setInterfacedWithAvaloq(
			boolean isInterfacedWithAvaloq) {
		this.isInterfacedWithAvaloq = isInterfacedWithAvaloq;
		return this;
	}

	public String getModel() {
		return model;
	}

	public FXOProductCatalogueDTO setModel(String model) {
		this.model = model;
		return this;
	}

	public static FXOProductCatalogueDTO instance(String product) {
		return new FXOProductCatalogueDTO().setProduct(product);
	}

}
