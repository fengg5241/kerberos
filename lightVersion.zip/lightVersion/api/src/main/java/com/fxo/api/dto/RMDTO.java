package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class RMDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String rmName;

	public String getRmName() {
		return rmName;
	}

	public RMDTO setRmName(String rmName) {
		this.rmName = rmName;
		return this;
	}

}
