package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOConstantsDTO;
import com.fxo.dao.entity.FXOConstants;
import com.fxo.framework.core.dto.entity.converter.BaseDTOEntityConverter;



@Component
public class FXOConstantsDTOEntityConverter extends
        BaseDTOEntityConverter<FXOConstantsDTO, FXOConstants> {

}
