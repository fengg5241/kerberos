package com.fxo.api.fenics.service;

import java.util.List;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.dto.CurrencyPairProductIntegrationMappingDTO;
import com.fxo.api.dto.FieldValueDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.StrategyDTO;
import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.ICurrencyPairProductIntegrationMappingService;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsConstants;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;

public abstract class AbstractFenicsTicketingRequestMapperService implements
		IFenicsTicketingRequestMapperService {

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private ICurrencyPairProductIntegrationMappingService currencyPairProductIntegrationMappingService;

	public FenicsXMLFieldGenerator getFenicsXMLFieldGenerator() {
		return fenicsXMLFieldGenerator;
	}

	public FenicsCustomDateTimeConverter getFenicsCustomDateTimeConverter() {
		return fenicsCustomDateTimeConverter;
	}

	public IFXOParametersMappingService getFxoParametersMappingService() {
		return fxoParametersMappingService;
	}

	public IFXOConstantsService getFxoConstantsService() {
		return fxoConstantsService;
	}

	public com.fxo.fenics.request.DataType getFenicsRequestDataTypeInitializedForTicketing() {

		// set the DataType Name and format to the values configured in
		// Database)
		return com.fxo.fenics.request.DataType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsTicketingDataTypeName))
				.setFormat(
						getFxoConstantsService()
								.getFXOConstantsValue(
										FXOWSConstantKeys.fenicsTicketingDataTypeFormat));
	}

	public com.fxo.fenics.request.NodeType getFenicsRequestStrategyNodeInitializedForTicketing() {

		// set the DataType Name and format to the values configured in
		// Database)
		return com.fxo.fenics.request.NodeType.instance().setName("[]");

	}

	public com.fxo.fenics.request.NodeType getFenicsLegNodeInitializedForTicketing(
			Integer legIndex) {

		return com.fxo.fenics.request.NodeType
				.instance()
				.setName(
						FXOStringUtility.joinStrings(
								fxoConstantsService
										.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName),
								String.valueOf((legIndex != null) ? legIndex
										: new Integer(0)),
								FXOWSConstantKeys.SPACE_DELIMITER));
	}

	public com.fxo.fenics.request.NodeType getFenicsSummaryNodeInitializedForTicketing() {
		NodeType fenicsStrategynode = new NodeType();

		// set NodeName for Strategy Node (configured in database)
		return fenicsStrategynode
				.setName(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsStrategyNodeName));
	}

	public String getBookForFenicsMapping(String customerType,
			String interPortfolio) {

		return (CustomerType.isExternal(customerType)) ? getFenicsBookForTicketing()
				: interPortfolio;

	}

	public String getFenicsBookForTicketing() {
		return fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsBook);
	}

	public String getFenicsTraderForTicketing() {
		return fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsTrader);
	}

	public String getFenicsMarketForTicketing() {
		return fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarket);
	}

	public String getCounterPartyForFenicsMapping(String customerType,
			String customerId) {

		return (CustomerType.isExternal(customerType)) ? customerId
				: getFenicsInternalCustomerIdForTicketing();

	}

	public String getFenicsInternalCustomerIdForTicketing() {
		return fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsInternalCustomerId);
	}

	public String getMurexStrategyFieldForTicketing(String product,
			String currency, String counterCurrency) {
		CurrencyPairProductIntegrationMappingDTO currencyPairProductIntegrationMappingDTO = currencyPairProductIntegrationMappingService
				.getOneCurrencyPairProductIntegrationMapping(product, currency,
						counterCurrency);

		return (currencyPairProductIntegrationMappingDTO != null) ? currencyPairProductIntegrationMappingDTO
				.getMurexStrategy() : null;
	}

	public static String getDealingConvention(FieldValueDTO fxoFields) {

		return FXOStringUtility.isNotEmpty(fxoFields.getDealingConvention()) ? fxoFields
				.getDealingConvention() : DealingConvention.config
				.getDealingConvention(fxoFields.getCurrency(),
						fxoFields.getFaceCurrency());
	}

	public void enrichTicketingRequest(TicketingRequestDTO ticketingRequestDTO) {

		FXODealingUtil.identifyAndPopulateDealingConventionInProductStructure(ticketingRequestDTO
				.getStructure());

		StrategyDTO strategy = FXODealingUtil.extractStrategy(
				ticketingRequestDTO.getStructure()).setPurpose(
				fenicsRequestPurpose);

		FieldValueDTO strategySummary = strategy.getSummary().setProduct(
				ticketingRequestDTO.getStructure().getProduct());

		List<OptionLegDTO> optionLegDTOs = strategy.getLegs();

		for (OptionLegDTO optionLegDTO : optionLegDTOs) {

			optionLegDTO
					.setProduct(ticketingRequestDTO.getStructure().getProduct())
					.setPurpose(strategy.getPurpose())
					.setStrategy(strategySummary.getStrategy())
					.setPurpose(fenicsRequestPurpose)
					.setCounterParty(
							ticketingRequestDTO.getCustomer().getCustomerId())
					.setCustomerType(
							ticketingRequestDTO.getCustomer().getCustomerType())
					.setInterPortfolio(
							ticketingRequestDTO.getCustomer()
									.getInterPortfolio());

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionClass())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionClass());
			}

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionType())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionType());
			}

			if (FXOStringUtility.isEmpty(optionLegDTO.getOptionStyle())) {
				optionLegDTO.setOptionClass(strategySummary.getOptionStyle());
			}
		}
	}

	public String getFenicsExpiryTimeString(DateTime expiryDate) {

		return (expiryDate != null) ? FXOStringUtility.joinStrings(
				DateTimeFormat.forPattern(FenicsConstants.FENICS_TIME_FORMAT)
						.print(expiryDate), FenicsConstants.FENICS_TIME_ZONE,
				FXOWSConstantKeys.SPACE_DELIMITER) : null;

	}

}
