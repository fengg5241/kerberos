package com.fxo.api.dto;

import org.pojomatic.annotations.PojomaticPolicy;
import org.pojomatic.annotations.Property;

import com.fxo.framework.core.dto.AuditableDTO;

public class FXOUserInterPortfolioMappingDTO extends AuditableDTO {

	private static final long serialVersionUID = 1L;

	@Property(policy = PojomaticPolicy.ALL)
	private String userID;

	@Property(policy = PojomaticPolicy.ALL)
	private String interPortfolio;

	private Boolean active;

	public Boolean getActive() {
		return active;
	}

	public FXOUserInterPortfolioMappingDTO setActive(Boolean active) {
		this.active = active;
		return this;
	}

	public String getUserID() {
		return userID;
	}

	public FXOUserInterPortfolioMappingDTO setUserID(String userID) {
		this.userID = userID;
		return this;
	}

	public String getInterPortfolio() {
		return interPortfolio;
	}

	public FXOUserInterPortfolioMappingDTO setInterPortfolio(
			String interPortfolio) {
		this.interPortfolio = interPortfolio;
		return this;
	}

	@Override
	public FXOUserInterPortfolioMappingDTO clone()
			throws CloneNotSupportedException {
		FXOUserInterPortfolioMappingDTO interPortfolioDTO = new FXOUserInterPortfolioMappingDTO();

		interPortfolioDTO.setUserID(getUserID())
				.setInterPortfolio(getInterPortfolio()).setActive(getActive())
				.setCreatedBy(getCreatedBy()).setCreatedDate(getCreatedDate())
				.setLastUpdatedBy(getLastUpdatedBy())
				.setLastUpdatedDate(getLastUpdatedDate());

		return interPortfolioDTO;

	}

}
