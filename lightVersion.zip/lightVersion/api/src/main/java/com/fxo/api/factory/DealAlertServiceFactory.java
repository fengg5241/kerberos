package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.service.IDealAlertService;

public interface DealAlertServiceFactory extends Serializable {

	public IDealAlertService getDealAlertService(
			String validationCode);

}
