package com.fxo.api.fenics.service;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.MarketClearRateDTO;
import com.fxo.api.dto.MarketClearRequestDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsRequestPurpose;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.ActionType;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;

@Component
public class FenicsMarketClearRequestGeneratorServiceImpl implements
		IFenicsMarketClearRequestGeneratorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsMarketClearRequestGeneratorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private FenicsRequestNodeService fenicsRequestNodeService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Override
	public String getFenicsMarketClearRequestXML(
			MarketClearRequestDTO marketClearRequestDTO)
			throws ApplicationException {
		BodyType requestBody = populateRequestBody(marketClearRequestDTO);

		marketClearRequestDTO
				.setMarketClearRequestId(generateUniqueMarketRequestId());

		return fenicsXMLProcessingService.compositeXML(requestBody,
				marketClearRequestDTO.getMarketClearRequestId(), null);
	}

	public BodyType populateRequestBody(
			MarketClearRequestDTO marketClearRequestDTO) {

		DataType data = DataType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearDataTypeName))
				.setFormat(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearDataTypeFormat));

		// get rateTypes to be cleared
		List<MarketClearRateDTO> rateTypes = marketClearRequestDTO
				.getRateTypes();

		for (MarketClearRateDTO rateType : rateTypes) {

			NodeType fenicsDataNode = NodeType.instance().setName(
					rateType.getRateType());

			fenicsXMLFieldGenerator.generateRateTypeField(fenicsDataNode,
					rateType.getRateType(), FenicsRequestPurpose.MARKET_CLEAR,
					null);

			fenicsXMLFieldGenerator.generateCurrencyField(fenicsDataNode,
					rateType.getCurrency(), FenicsRequestPurpose.MARKET_CLEAR,
					null);

			fenicsXMLFieldGenerator.generateCounterCurrencyField(
					fenicsDataNode, rateType.getCounterCurrency(),
					FenicsRequestPurpose.MARKET_CLEAR, null);

			data.getNode().add(fenicsDataNode);
		}

		BodyType body = BodyType.instance().setAction(populateRequestAction());

		body.getData().add(data);

		return body;
	}

	public ActionType populateRequestAction() {

		ActionType action = ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrActionTypeVersion))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrActionTypeFunc));

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeScenVal));

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeClearRate))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeClearRateValue));

		OptionType option3 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsMarketClearHdrOptionTypeDataRef));

		action.getOption().addAll(Arrays.asList(option1, option2, option3));

		return action;
	}

	public String generateUniqueMarketRequestId() {

		return FXOStringUtility.joinStrings(REQUEST_PREFIX,
				org.springframework.util.StringUtils.delete(UUID.randomUUID()
						.toString(), "-"), FXOWSConstantKeys.EMPTY_DELIMITER);
	}
}
