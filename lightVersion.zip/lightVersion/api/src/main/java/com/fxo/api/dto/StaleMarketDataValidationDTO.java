package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

@AutoProperty
public class StaleMarketDataValidationDTO extends ValidationDTO {

	private static final long serialVersionUID = 1L;

}
