package com.fxo.api.fenics.factory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.fxo.api.fenics.service.IFenicsPricingRequestMapperService;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.Products;
import com.fxo.exception.ApplicationRuntimeException;

@Component
public class FenicsPricingRequestMapperServiceFactoryImpl implements
		FenicsPricingRequestMapperServiceFactory {

	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsPricingRequestMapperServiceFactoryImpl.class);

	@Autowired
	@Qualifier(value = "vanillaFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService vanillaFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "straddleFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService straddleFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "strangleFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService strangleFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "riskReversalFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService riskReversalFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "spreadFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService spreadFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "knockInFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService knockInFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "knockOutFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService knockOutFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockInFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService reverseKnockInFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "reverseKnockOutFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService reverseKnockOutFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockInFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService europeanKnockInFenicsPricingRequestMapperService;

	@Autowired
	@Qualifier(value = "europeanKnockOutFenicsPricingRequestMapperService")
	private IFenicsPricingRequestMapperService europeanKnockOutFenicsPricingRequestMapperService;

	@Override
	public IFenicsPricingRequestMapperService getFenicsPricingRequestMapperService(
			String product) {
		IFenicsPricingRequestMapperService fenicsPricingRequestMapperService = null;

		switch (product) {
		case Products.PRODUCT_VANILLA:
			fenicsPricingRequestMapperService = vanillaFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_STRADDLE:
			fenicsPricingRequestMapperService = straddleFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_STRANGLE:
			fenicsPricingRequestMapperService = strangleFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_RISKREVERSAL:
			fenicsPricingRequestMapperService = riskReversalFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_SPREAD:
			fenicsPricingRequestMapperService = spreadFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_KNOCKIN:
			fenicsPricingRequestMapperService = knockInFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_KNOCKOUT:
			fenicsPricingRequestMapperService = knockOutFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKIN:
			fenicsPricingRequestMapperService = reverseKnockInFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_REVERSE_KNOCKOUT:
			fenicsPricingRequestMapperService = reverseKnockOutFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKIN:
			fenicsPricingRequestMapperService = europeanKnockInFenicsPricingRequestMapperService;
			break;

		case Products.PRODUCT_EUROPEAN_KNOCKOUT:
			fenicsPricingRequestMapperService = europeanKnockOutFenicsPricingRequestMapperService;
			break;

		default:
			logger.error("failed to locate fenicsPricingRequestMapperService for Product: "
					+ product);
			throw new ApplicationRuntimeException("",
					FXOMessageCodes.ERR_SYSTEM);
		}

		return fenicsPricingRequestMapperService;
	}

}
