package com.fxo.api.fenics.service;

import java.math.BigDecimal;
import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.dto.StrikeSolverRequestDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.api.service.IFXOProductCatalogueService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.DealingConvention;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.dealing.LegStrategies;
import com.fxo.constants.dealing.Maturities;
import com.fxo.constants.dealing.SolveForTypes;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.ActionType;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;
import com.fxo.framework.util.MathUtil;

@Component
public class FenicsStrikeSolverRequestGeneratorServiceImpl implements
		IFenicsStrikeSolverRequestGeneratorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsStrikeSolverRequestGeneratorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private FenicsRequestNodeService fenicsRequestNodeService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Autowired
	private IFXOProductCatalogueService fxoProductCatalogueService;

	@Override
	public String getFenicsPricingXML(
			StrikeSolverRequestDTO strikeSolverRequestDTO)
			throws ApplicationException {

		BodyType requestBody = populateRequestBody(strikeSolverRequestDTO
				.setStrikeSolverRequestId(FXOStringUtility
						.generateUniqueId(REQUEST_PREFIX)));

		return fenicsXMLProcessingService.compositeXML(requestBody,
				strikeSolverRequestDTO.getStrikeSolverRequestId(), null);
	}

	public BodyType populateRequestBody(
			StrikeSolverRequestDTO strikeSolverRequestDTO) {

		BodyType body = BodyType.instance();

		body.setAction(populateRequestAction());

		DataType data = DataType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeName))
				.setFormat(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeFormat));

		generateFenicsOptionLegs(data, strikeSolverRequestDTO);

		body.getData().add(data);

		return body;
	}

	public void generateFenicsOptionLegs(DataType data,
			StrikeSolverRequestDTO strikeSolverRequestDTO) {

		NodeType fenicsLegNode = NodeType
				.instance()
				.setName(
						FXOStringUtility.joinStrings(
								fxoConstantsService
										.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName),
								String.valueOf(1),
								FXOWSConstantKeys.SPACE_DELIMITER));

		data.getNode().add(fenicsLegNode);

		String dealingConvention = FXODealingUtil.evaluateDealingConventionWithCurrencyAndFaceCurreny(
				strikeSolverRequestDTO.getCurrency(),
				strikeSolverRequestDTO.getFaceCurrency());

		fenicsXMLFieldGenerator.generateCurrencyField(fenicsLegNode,
				strikeSolverRequestDTO.getCurrency(), fenicsRequestPurpose,
				dealingConvention);

		fenicsXMLFieldGenerator.generateCounterCurrencyField(fenicsLegNode,
				strikeSolverRequestDTO.getCounterCurrency(),
				fenicsRequestPurpose, dealingConvention);

		// generate faceCurrency Field in Leg Node
		fenicsXMLFieldGenerator.generateFaceCurrencyField(fenicsLegNode,
				strikeSolverRequestDTO.getFaceCurrency(), fenicsRequestPurpose,
				dealingConvention);

		String legStrategyForFenicsMapping = DealingConvention.config
				.isCounterMarketConvention(dealingConvention) ? LegStrategies
				.invert(strikeSolverRequestDTO.getLegStrategy())
				: strikeSolverRequestDTO.getLegStrategy();

		fenicsXMLFieldGenerator.generateLegStrategyField(fenicsLegNode,
				legStrategyForFenicsMapping, fenicsRequestPurpose,
				dealingConvention);

		if (FXOStringUtility.isNotEmpty(strikeSolverRequestDTO.getMaturity())
				&& FXOStringUtility.areNotIdentical(
						strikeSolverRequestDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {

			fenicsXMLFieldGenerator.generateMaturityField(fenicsLegNode,
					strikeSolverRequestDTO.getMaturity(), fenicsRequestPurpose,
					dealingConvention);
		}

		fenicsXMLFieldGenerator.generateCutoffField(fenicsLegNode,
				strikeSolverRequestDTO.getCutoff(), fenicsRequestPurpose,
				dealingConvention);

		if (FXOStringUtility.isNotEmpty(strikeSolverRequestDTO.getMaturity())
				&& FXOStringUtility.haveIdenticalValues(
						strikeSolverRequestDTO.getMaturity(),
						Maturities.MATURITIES_ODD_DATE)) {
			fenicsXMLFieldGenerator.generateExpiryDateField(fenicsLegNode,
					strikeSolverRequestDTO.getExpiryDate(),
					fenicsRequestPurpose, dealingConvention);
		}

		FXOParametersMappingDTO fxoParametersMappingDTO_SolveFor = fxoParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_SOLVEFOR,
						SolveForTypes.SOLVE_FOR_STRIKE);

		fenicsXMLFieldGenerator.generateSolveForField(
				fxoParametersMappingDTO_SolveFor.getParameterTargetValue(),
				fenicsLegNode, fenicsRequestPurpose, dealingConvention);

		BigDecimal internalCost = strikeSolverRequestDTO.getInternalCost();

		if (FXOStringUtility.haveIdenticalValues(
				strikeSolverRequestDTO.getCurrency(),
				strikeSolverRequestDTO.getPremiumCurrency())) {
			fenicsXMLFieldGenerator.generatePremiumField(fenicsLegNode,
					internalCost, fenicsRequestPurpose, dealingConvention);
		} else {
			fenicsXMLFieldGenerator.generateCounterPremiumField(fenicsLegNode,
					internalCost, fenicsRequestPurpose, dealingConvention);
		}

		if (strikeSolverRequestDTO.getAmount() != null) {
			fenicsXMLFieldGenerator.generateAmountField(fenicsLegNode,
					strikeSolverRequestDTO.getAmount(), fenicsRequestPurpose,
					dealingConvention);
		}

		fenicsXMLFieldGenerator.generatePremiumCurrencyField(fenicsLegNode,
				strikeSolverRequestDTO.getPremiumCurrency(),
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateHorizonDateField(fenicsLegNode,
				strikeSolverRequestDTO.getHorizonDate(), fenicsRequestPurpose,
				dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		if (FXOStringUtility.isNotEmpty(strikeSolverRequestDTO.getOptionType())) {
			FXOParametersMappingDTO fxoParametersMappingDTO_OptionStyle = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
							strikeSolverRequestDTO.getOptionType());

			fenicsXMLFieldGenerator.generateOptionClassField(fenicsLegNode,
					fxoParametersMappingDTO_OptionStyle
							.getParameterTargetValue(), fenicsRequestPurpose,
					dealingConvention);
		}

		// translate direction from fenics value to FXO-Portal representation
		if (FXOStringUtility.isNotEmpty(strikeSolverRequestDTO.getDirection())) {
			FXOParametersMappingDTO fxoParametersMappingDTODirection = fxoParametersMappingService
					.getOneParameterMappingByParameterTypeAndParameterSourceValue(
							FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
							strikeSolverRequestDTO.getDirection());

			fenicsXMLFieldGenerator.generateDirectionField(fenicsLegNode,
					fxoParametersMappingDTODirection.getParameterTargetValue(),
					fenicsRequestPurpose, dealingConvention);
		}

		// Additional inputs for priceDiscovery
		String volatility = strikeSolverRequestDTO.getVolatility();

		if (FXOStringUtility.isNotEmpty(volatility)) {
			fenicsXMLFieldGenerator.generateVolatilityField(fenicsLegNode,
					volatility, fenicsRequestPurpose, dealingConvention);
		}

		// check for rate Inversion for spot and forward (For counter
		// Pricing)

		if (strikeSolverRequestDTO.getSpotRate() != null) {

			BigDecimal spotRate = DealingConvention.config
					.isCounterMarketConvention(dealingConvention) ? MathUtil
					.invert(MathUtil
							.deriveNonNullDecimalValue(strikeSolverRequestDTO
									.getSpotRate())) : MathUtil
					.deriveNonNullDecimalValue(strikeSolverRequestDTO
							.getSpotRate());

			fenicsXMLFieldGenerator.generateSpotField(fenicsLegNode,
					spotRate.toEngineeringString(), fenicsRequestPurpose,
					dealingConvention);
		}

		if (strikeSolverRequestDTO.getForwardRate() != null) {
			BigDecimal forwardRate = DealingConvention.config
					.isCounterMarketConvention(dealingConvention) ? MathUtil
					.invert(MathUtil
							.deriveNonNullDecimalValue(strikeSolverRequestDTO
									.getForwardRate())) : MathUtil
					.deriveNonNullDecimalValue(strikeSolverRequestDTO
							.getForwardRate());

			fenicsXMLFieldGenerator.generateForwardField(fenicsLegNode,
					forwardRate.toEngineeringString(), fenicsRequestPurpose,
					dealingConvention);
		}

		// Model
		String pricingModel = fxoProductCatalogueService.getOneProduct(
				strikeSolverRequestDTO.getProduct()).getModel();

		fenicsXMLFieldGenerator.generateModelField(fenicsLegNode, pricingModel,
				fenicsRequestPurpose, dealingConvention);
	}

	public ActionType populateRequestAction() {

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeCalcName))
				.setOptionValue(FenicsCalculationParameters.SIDED);

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenVal));

		OptionType option3 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataRef));

		ActionType action = ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrActionTypeFunc));

		action.getOption().addAll(Arrays.asList(option1, option2, option3));

		return action;
	}

}
