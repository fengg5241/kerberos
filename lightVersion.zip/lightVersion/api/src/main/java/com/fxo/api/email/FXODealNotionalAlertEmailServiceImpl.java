package com.fxo.api.email;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.email.FXOEmailConstants;
import com.fxo.dao.entity.Ticketing;
import com.fxo.dao.repository.TicketingRepository;
import com.fxo.email.dto.FXOEmailMessageDTO;
import com.fxo.email.dto.FXOEmailMessageHeaderDTO;
import com.fxo.email.service.IFXOEmailService;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;

@Service(value = "fxoDealNotionalAlertEmailService")
public class FXODealNotionalAlertEmailServiceImpl extends
		AbstractFXODealConfirmationEmailServiceImpl implements
		IFXODealAlertEmailService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXODealNotionalAlertEmailServiceImpl.class);

	@Value("${email.velocity.template.subject.notionalAlert}")
	private String subjectTemplatePrefix;

	@Value("${email.velocity.template.body.notionalAlert}")
	private String bodyTemplatePrefix;

	@Value("${email.velocity.template.fileType}")
	private String templateFileType;

	@Value("${email.velocity.notionalAlert.groupEmailIds}")
	private String notionalAlertEmailGroupIds;

	@Value("${email.velocity.interportfolio.groupEmailIds}")
	private String interPortfolioEmailGroupIds;

	@Autowired
	private TicketingRepository ticketingRepository;

	@Autowired
	private IFXODealConfirmationEmailTemplateProcessService fxoDealConfirmationEmailTemplateProcessService;

	@Autowired
	private IFXOEmailService fxoEmailService;

	private List<String> notionalAlertEmailAddresses;

	@PostConstruct
	public void initIt() throws Exception {

		notionalAlertEmailAddresses = FXOStringUtility
				.splitStringsByDelimiter(notionalAlertEmailGroupIds,
						FXOWSConstantKeys.COMMA_DELIMITER);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.fxo.api.email.IFXODealAlertEmailService#sendDealAlert
	 * (com.fxo.api.dto.TicketingResponseDTO)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Async
	public void sendDealAlert(String ticketNumber, List<String> alertlegs) {

		// Step-1: retrieve TicketingResponseDTO (via TicketSearchService

		BigInteger dealTicketNumber = (FXOStringUtility
				.isNotEmpty(ticketNumber)) ? new BigInteger(ticketNumber)
				: null;

		if (ticketNumber == null) {
			logger.error("ticketNumber is required - for DealConfirmation Email");
			throw new ApplicationRuntimeException(
					"ticketNumber is required - for DealConfirmation Email",
					FXOMessageCodes.ERR_EMAIL);
		}

		TicketingResponseDTO ticketingResponseFenicsDetails = extractTicketDetails(dealTicketNumber);

		String product = ticketingResponseFenicsDetails.getStructure()
				.getProduct();

		// create instance of type FXOEmailMessageDTO
		FXOEmailMessageDTO fxoEmailMessageEnvelope = new FXOEmailMessageDTO();

		// get Email Body from TemplateService
		Map<String, Object> contextParams = new HashMap<String, Object>();
		contextParams.put("alertLegs", FXOStringUtility.joinStrings(alertlegs, ","));
		
		String emailBody = fxoDealConfirmationEmailTemplateProcessService
				.processEmailBodyTemplate(bodyTemplatePrefix + product
						+ templateFileType, ticketingResponseFenicsDetails, FXOEmailConstants.NOTIONAL_ALERT_EMAIL, contextParams);
		


		fxoEmailMessageEnvelope.setBody(emailBody);

		// create instance of type FXOEmailMessageHeaderDTO
		FXOEmailMessageHeaderDTO fxoEmailMessageHeader = new FXOEmailMessageHeaderDTO();

		// get email Subject from TemplateService
		String emailSubject = fxoDealConfirmationEmailTemplateProcessService
				.processEmailSubjectTemplate(subjectTemplatePrefix 
						+ templateFileType, ticketingResponseFenicsDetails);

		fxoEmailMessageHeader.setSubject(emailSubject);

		// To Mail Addresses
		Set<String> destinationEmailAddressSet = new HashSet<String>();

		// include Email Addresses of user
		String userEmailAddress = (ticketingResponseFenicsDetails.getUser() != null) ? ticketingResponseFenicsDetails
				.getUser().getUserEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(userEmailAddress)) {
			destinationEmailAddressSet.add(userEmailAddress);
		}

		// include RelationshipManager EmailAddress
		String rmEmailAddress = (ticketingResponseFenicsDetails.getCustomer() != null) ? ticketingResponseFenicsDetails
				.getCustomer().getRmEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(rmEmailAddress)) {
			destinationEmailAddressSet.add(rmEmailAddress);
		}

		if (!destinationEmailAddressSet.isEmpty()) {
			fxoEmailMessageHeader
					.setDestinationEmailAddressList(new ArrayList<String>(
							destinationEmailAddressSet));
		}

		// Carbon copy
		Set<String> carbonCopyEmailAddressSet = new HashSet<String>();

		// add groupEmail Addresses to DestinionHeader
		if (notionalAlertEmailAddresses != null) {

			for (String groupEmailAddress : notionalAlertEmailAddresses) {
				carbonCopyEmailAddressSet.add(groupEmailAddress);
				logger.info(
						"carbonCopyEmailAddressSet -> EmailAddress identified for Commodity{}",
						groupEmailAddress);
			}

		}

		if (!carbonCopyEmailAddressSet.isEmpty()) {
			fxoEmailMessageHeader
					.setCarbonCopyDestinationEmailAddressList(new ArrayList<String>(
							carbonCopyEmailAddressSet));
		}

		// set EmailHeader in EmailEnvelope
		fxoEmailMessageEnvelope.setHeader(fxoEmailMessageHeader);

		// send EmailMessage
		String messageID = fxoEmailService.sendMessage(fxoEmailMessageEnvelope);

		if (FXOStringUtility.isNotEmpty(messageID)) {
			updateTicketingRecordWithEmailMessageID(
					ticketingResponseFenicsDetails.getTicketingRequestId(),
					messageID);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateTicketingRecordWithEmailMessageID(
			String ticketingRequestID, String messageID) {
		Ticketing ticketing = ticketingRepository
				.findOneByTicketingRequestId(ticketingRequestID);

		// Set MessageID in Ticketing entity
		ticketing.setEmailMessageID(messageID);

		ticketingRepository.save(ticketing);
	}

}