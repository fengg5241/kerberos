package com.fxo.api.constraint.validator;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.fxo.api.constraint.ValidTicketingRequest;
import com.fxo.api.dto.CustomerDTO;
import com.fxo.api.dto.FXOProductStructureExtractDTO;
import com.fxo.api.dto.FXOUserInterPortfolioMappingDTO;
import com.fxo.api.dto.MarketRateRequestDTO;
import com.fxo.api.dto.MarketRateResponseDTO;
import com.fxo.api.dto.OptionLegDTO;
import com.fxo.api.dto.TicketingRequestDTO;
import com.fxo.api.dto.UserCustomerMappingDTO;
import com.fxo.api.factory.FXOTicketingRequestValidationServiceFactory;
import com.fxo.api.service.IDeltaHedgeValidationService;
import com.fxo.api.service.IFXOUserInterPortfolioMappingService;
import com.fxo.api.service.ITicketingRequestValidatorService;
import com.fxo.api.service.IUserCustomerMappingService;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.framework.core.dto.FXOMessageDetailDTO;
import com.fxo.framework.core.dto.UserDTO;
import com.fxo.framework.util.FXOBooleanUtility;
import com.fxo.framework.util.FXOStringUtility;

public class ValidTicketingRequestValidator implements
		ConstraintValidator<ValidTicketingRequest, TicketingRequestDTO> {

	@Autowired
	private FXOTicketingRequestValidationServiceFactory fxoTicketingRequestValidationServiceFactory;

	@Autowired
	private IUserCustomerMappingService userCustomerMappingService;

	@Autowired
	private IFXOUserInterPortfolioMappingService fxoUserInterPortfolioMappingService;
	
	@Autowired
	private IDeltaHedgeValidationService deltaHedgeValidationService;

	@Override
	public void initialize(ValidTicketingRequest ticketingRequest) {

	}

	@Override
	public boolean isValid(TicketingRequestDTO ticketingRequest,
			ConstraintValidatorContext context) {

		// Start with a hypothesis that ticketingRequest contain valid-Values
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		Boolean isAValidPortfolioOrCustomer = isAValidPortfolioOrCustomer(
				ticketingRequest, context);

		predicateResultSet.add(isAValidPortfolioOrCustomer);

		Boolean isUserValid = (ticketingRequest.getUser() != null);

		predicateResultSet.add(isAValidPortfolioOrCustomer);

		if (FXOBooleanUtility.isFalse(isUserValid)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_USER_INFO_REQUIRED).addNode("user")
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		Boolean hasNonNullStructure = (ticketingRequest.getStructure() != null);

		predicateResultSet.add(hasNonNullStructure);

		if (FXOBooleanUtility.isFalse(hasNonNullStructure)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PRODUCT_STRUCTURE_INVALID)
					.addNode("structure").addConstraintViolation()
					.disableDefaultConstraintViolation();
		} else {
			String product = ticketingRequest.getStructure().getProduct();

			ITicketingRequestValidatorService ticketingRequestValidatorService = fxoTicketingRequestValidationServiceFactory
					.getTicketingRequestValidationService(product);

			boolean isProductValid = ticketingRequestValidatorService
					.validateProduct(ticketingRequest.getStructure(), context);

			predicateResultSet.add(isProductValid);
		}

		if (ticketingRequest.getStructure() != null
				&& ticketingRequest.getStructure().getStrategies() != null) {

			Boolean hasNonNullAvaloqId = validateForAvaloqIds(ticketingRequest
					.getStructure().getStrategies().get(0).getLegs(), context);
			predicateResultSet.add(hasNonNullAvaloqId);
			
			if (FXOBooleanUtility.isFalse(hasNonNullAvaloqId)) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_SYSTEM_SOURCE_ID_INVALID).addNode("structure.strategies.legs.systemsourceid")
						.addConstraintViolation()
						.disableDefaultConstraintViolation();
			}
		}

		if(ticketingRequest.getIsDeltaHedge())
		{

			FXOProductStructureExtractDTO fxoProductStructureExtractDTO = FXODealingUtil
					.extractKeyProductDetails(ticketingRequest.getStructure());
			
			MarketRateResponseDTO marketRateResponseDTO = deltaHedgeValidationService.getMarketRateResponse(fxoProductStructureExtractDTO);
			
			ticketingRequest.setCurrentMarketRateResponse(marketRateResponseDTO);
			
			FXOMessageDetailDTO fxoMessageDetailDTO = deltaHedgeValidationService.validate(fxoProductStructureExtractDTO, ticketingRequest.getCurrentMarketRateResponse());
			
			if(FXOBooleanUtility.isFalse(fxoMessageDetailDTO.isValid())){
				predicateResultSet.add(false);
				
				String messageTemplate = FXOStringUtility.joinStrings(fxoMessageDetailDTO.getPlaceholderValues(), FXOStringUtility.COMMA_SEPARATOR);
				
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_DeltaHedgeValidation+FXOStringUtility.COMMA_SEPARATOR+messageTemplate)
						.addNode("structure").addConstraintViolation()
						.disableDefaultConstraintViolation();
			}
		}
		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAValidPortfolioOrCustomer(
			TicketingRequestDTO ticketingRequest,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - Valid Portfolio & Customer
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		CustomerDTO customerDTO = ticketingRequest.getCustomer();

		Boolean hasNonNullCustomer = (customerDTO != null);

		predicateResultSet.add(hasNonNullCustomer);

		if (FXOBooleanUtility.isFalse(hasNonNullCustomer)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CUSTOMERTYPE_INVALID)
					.addNode("customer").addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		else {

			String customerTypeStringValue = customerDTO.getCustomerType();

			// check for a valid CustomerType
			Boolean hasAValidCustomerType = CustomerType
					.isValidValue(customerTypeStringValue);

			predicateResultSet.add(hasAValidCustomerType);

			if (FXOBooleanUtility.isFalse(hasAValidCustomerType)) {

				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_CUSTOMERTYPE_INVALID)
						.addNode("customer").addConstraintViolation()
						.disableDefaultConstraintViolation();
			}

			// If CustomerType is Valid, Proceed to validate Customer Or
			// InterPortfolio
			else {

				if (CustomerType.isExternal(customerTypeStringValue)) {

					Boolean isAValidCustomer = isAValidCustomer(customerDTO,
							context);

					predicateResultSet.add(isAValidCustomer);

				} else if (CustomerType.isInternal(customerTypeStringValue)) {

					Boolean isAValidPortfolio = isAValidPortfolio(
							ticketingRequest.getUser(), ticketingRequest
									.getCustomer().getInterPortfolio(), context);

					predicateResultSet.add(isAValidPortfolio);
				}
			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAValidCustomer(CustomerDTO customerDTO,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - Valid Customer
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		Boolean hasNonNullCustomer = customerDTO != null
				&& FXOStringUtility.isNotEmpty(customerDTO.getCustomerId());

		predicateResultSet.add(hasNonNullCustomer);

		if (FXOBooleanUtility.isFalse(hasNonNullCustomer)) {
			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_CUSTOMER_REQUIRED).addNode("customer")
					.addConstraintViolation()
					.disableDefaultConstraintViolation();
		}

		// validate customerId against UserCustomerMapping Entity
		else {

			UserCustomerMappingDTO userCustomerMappingDTO = userCustomerMappingService
					.getOneCustomerByCustomerId(customerDTO.getCustomerId());

			Boolean hasValidCustomer = userCustomerMappingDTO != null;

			predicateResultSet.add(hasValidCustomer);

			if (FXOBooleanUtility.isFalse(hasValidCustomer)) {
				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_CUSTOMER_INVALID)
						.addNode("customer.customerId")
						.addConstraintViolation()
						.disableDefaultConstraintViolation();
			}

		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean isAValidPortfolio(UserDTO userDTO, String interPortfolio,
			ConstraintValidatorContext context) {

		// Start with a hypothesis - valid Portfolio
		Set<Boolean> predicateResultSet = FXOBooleanUtility
				.getAnInitializedPredicateResultSet();

		// emptyString check and userPortfolioMapping check

		Boolean isANonNullPortfolio = FXOStringUtility
				.isNotEmpty(interPortfolio);

		if (FXOBooleanUtility.isFalse(isANonNullPortfolio)) {

			predicateResultSet.add(isANonNullPortfolio);

			context.buildConstraintViolationWithTemplate(
					FXOMessageCodes.ERR_PORTFOLIO_REQUIRED)
					.addNode("portfolio").addConstraintViolation()
					.disableDefaultConstraintViolation();
		} else {

			FXOUserInterPortfolioMappingDTO fxoUserInterPortfolioMappingDTO = fxoUserInterPortfolioMappingService
					.getOneFXOUserInterPortfolioMappingByUserIdAndPortfolio(
							userDTO.getUserId(), interPortfolio);

			Boolean isAValidPortfolio = (fxoUserInterPortfolioMappingDTO != null);

			if (FXOBooleanUtility.isFalse(isAValidPortfolio)) {

				predicateResultSet.add(isAValidPortfolio);

				context.buildConstraintViolationWithTemplate(
						FXOMessageCodes.ERR_PORTFOLIO_INVALID)
						.addNode("portfolio").addConstraintViolation()
						.disableDefaultConstraintViolation();
			}
		}

		return FXOBooleanUtility.aggregate(predicateResultSet);
	}

	public boolean validateForAvaloqIds(List<OptionLegDTO> optionLegs,
			ConstraintValidatorContext context) {

		// Set<String> avaloqIds = new
		// HashSet<String>(Lambda.extract(optionLegs,
		// Lambda.on(OptionLegDTO.class).getAvaloqId()));

		boolean doesLegsContainValidAvaloqIds = true;

		for (OptionLegDTO optionLegDTO : optionLegs) {
			String avaloqId = optionLegDTO.getAvaloqId();
			String sourceId = optionLegDTO.getSystemSourceId();

			boolean isBothEmpty = FXOStringUtility.isEmpty(avaloqId)
					&& FXOStringUtility.isEmpty(sourceId);
			boolean isBothNonEmpty = FXOStringUtility.isNotEmpty(avaloqId)
					&& FXOStringUtility.isNotEmpty(sourceId);
			if (FXOBooleanUtility.isFalse(isBothEmpty || isBothNonEmpty)) {
				doesLegsContainValidAvaloqIds = false;
				break;
			}
		}
		return doesLegsContainValidAvaloqIds;
	}

}
