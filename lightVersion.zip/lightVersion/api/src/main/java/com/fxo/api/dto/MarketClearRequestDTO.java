package com.fxo.api.dto;

import java.util.List;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class MarketClearRequestDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private String marketClearRequestId;

	private List<MarketClearRateDTO> rateTypes;

	public String getMarketClearRequestId() {
		return marketClearRequestId;
	}

	public MarketClearRequestDTO setMarketClearRequestId(
			String marketClearRequestId) {
		this.marketClearRequestId = marketClearRequestId;
		return this;
	}

	public List<MarketClearRateDTO> getRateTypes() {
		return rateTypes;
	}

	public MarketClearRequestDTO setRateTypes(List<MarketClearRateDTO> rateTypes) {
		this.rateTypes = rateTypes;
		return this;
	}
}
