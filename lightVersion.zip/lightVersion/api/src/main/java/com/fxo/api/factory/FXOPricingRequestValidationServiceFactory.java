package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.service.IPricingRequestValidatorService;

public interface FXOPricingRequestValidationServiceFactory extends Serializable {

	public IPricingRequestValidatorService getPricingRequestValidationService(
			String product);

}