package com.fxo.api.factory;

import java.io.Serializable;

import com.fxo.api.dto.ProductStructureDTO;
import com.fxo.api.service.IFXOTicketingService;

public interface FXOTicketingServiceFactory extends Serializable {
	public IFXOTicketingService getTicketingService(
			ProductStructureDTO productStructureDTO);
}