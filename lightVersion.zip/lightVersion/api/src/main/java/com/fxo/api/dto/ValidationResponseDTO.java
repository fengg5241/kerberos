package com.fxo.api.dto;

import org.pojomatic.annotations.AutoProperty;

import com.fxo.framework.core.dto.BaseCustomDTO;

@AutoProperty
public class ValidationResponseDTO extends BaseCustomDTO {

	private static final long serialVersionUID = 1L;

	private boolean isValid;
	private String minimumValue;
	private String maximumValue;
	private String validatedValue;
	private String validatedProperty;
	private String miscValue;
	private String thresholdCurrency;
	private String messageType;

	public boolean isValid() {
		return isValid;
	}

	public ValidationResponseDTO setValid(boolean isValid) {
		this.isValid = isValid;
		return this;
	}

	public String getMinimumValue() {
		return minimumValue;
	}

	public ValidationResponseDTO setMinimumValue(String minimumValue) {
		this.minimumValue = minimumValue;
		return this;
	}

	public String getMaximumValue() {
		return maximumValue;
	}

	public ValidationResponseDTO setMaximumValue(String maximumValue) {
		this.maximumValue = maximumValue;
		return this;
	}

	public String getValidatedValue() {
		return validatedValue;
	}

	public ValidationResponseDTO setValidatedValue(String validatedValue) {
		this.validatedValue = validatedValue;
		return this;
	}

	public String getValidatedProperty() {
		return validatedProperty;
	}

	public ValidationResponseDTO setValidatedProperty(String validatedProperty) {
		this.validatedProperty = validatedProperty;
		return this;
	}

	public String getMiscValue() {
		return miscValue;
	}

	public ValidationResponseDTO setMiscValue(String miscValue) {
		this.miscValue = miscValue;
		return this;
	}

	public String getThresholdCurrency() {
		return thresholdCurrency;
	}

	public ValidationResponseDTO setThresholdCurrency(String thresholdCurrency) {
		this.thresholdCurrency = thresholdCurrency;
		return this;
	}

	public String getMessageType() {
		return messageType;
	}

	public ValidationResponseDTO setMessageType(String messageType) {
		this.messageType = messageType;
		return this;
	}

}
