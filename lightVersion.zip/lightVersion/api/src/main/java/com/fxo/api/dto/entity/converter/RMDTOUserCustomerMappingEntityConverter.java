package com.fxo.api.dto.entity.converter;

import org.springframework.stereotype.Component;

import com.fxo.api.dto.RMDTO;
import com.fxo.dao.entity.UserCustomerMapping;
import com.fxo.framework.core.dto.entity.converter.BaseCustomDTOEntityConverter;

@Component
public class RMDTOUserCustomerMappingEntityConverter extends
		BaseCustomDTOEntityConverter<RMDTO, UserCustomerMapping> {

}
