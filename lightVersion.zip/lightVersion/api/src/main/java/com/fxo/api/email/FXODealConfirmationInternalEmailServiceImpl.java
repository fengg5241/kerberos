package com.fxo.api.email;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.fxo.api.dto.TicketingResponseDTO;
import com.fxo.api.util.FXODealingUtil;
import com.fxo.constants.admin.FXOMessageCodes;
import com.fxo.constants.dealing.CustomerType;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.email.FXOEmailConstants;
import com.fxo.dao.entity.Ticketing;
import com.fxo.dao.repository.TicketingRepository;
import com.fxo.email.dto.FXOEmailMessageDTO;
import com.fxo.email.dto.FXOEmailMessageHeaderDTO;
import com.fxo.email.service.IFXOEmailService;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.framework.util.FXOStringUtility;

@Service(value = "fxoDealConfirmationInternalEmailService")
public class FXODealConfirmationInternalEmailServiceImpl extends
		AbstractFXODealConfirmationEmailServiceImpl implements
		IFXODealConfirmationEmailService {

	private static final Logger logger = LoggerFactory
			.getLogger(FXODealConfirmationInternalEmailServiceImpl.class);

	@Value("${email.velocity.template.subject.dealConfirmation}")
	private String subjectTemplatePrefix;

	@Value("${email.velocity.template.body.dealConfirmation}")
	private String bodyTemplatePrefix;

	@Value("${email.velocity.template.fileType}")
	private String templateFileType;

	@Value("${email.velocity.commodity.groupEmailIds}")
	private String commodityEmailGroupIds;

	@Value("${email.velocity.interportfolio.groupEmailIds}")
	private String interPortfolioEmailGroupIds;

	@Autowired
	private TicketingRepository ticketingRepository;

	@Autowired
	private IFXODealConfirmationEmailTemplateProcessService fxoDealConfirmationEmailTemplateProcessService;

	@Autowired
	private IFXOEmailService fxoEmailService;

	private List<String> groupCommodityEmailAddresses;

	private List<String> groupInterPortfolioEmailAddresses;

	@PostConstruct
	public void initIt() throws Exception {

		groupCommodityEmailAddresses = FXOStringUtility
				.splitStringsByDelimiter(commodityEmailGroupIds,
						FXOWSConstantKeys.COMMA_DELIMITER);

		groupInterPortfolioEmailAddresses = FXOStringUtility
				.splitStringsByDelimiter(interPortfolioEmailGroupIds,
						FXOWSConstantKeys.COMMA_DELIMITER);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.fxo.api.email.IFXODealConfirmationEmailService#sendDealConfirmation
	 * (com.fxo.api.dto.TicketingResponseDTO)
	 */
	@Override
	@Transactional(readOnly = true, propagation = Propagation.REQUIRES_NEW)
	@Async
	public void sendDealConfirmation(String ticketNumber) {

		// Step-1: retrieve TicketingResponseDTO (via TicketSearchService

		BigInteger dealTicketNumber = (FXOStringUtility
				.isNotEmpty(ticketNumber)) ? new BigInteger(ticketNumber)
				: null;

		if (ticketNumber == null) {
			logger.error("ticketNumber is required - for DealConfirmation Email");
			throw new ApplicationRuntimeException(
					"ticketNumber is required - for DealConfirmation Email",
					FXOMessageCodes.ERR_EMAIL);
		}

		TicketingResponseDTO ticketingResponseFenicsDetails = extractTicketDetails(dealTicketNumber);

		String product = ticketingResponseFenicsDetails.getStructure()
				.getProduct();

		// create instance of type FXOEmailMessageDTO
		FXOEmailMessageDTO fxoEmailMessageEnvelope = new FXOEmailMessageDTO();

		// get Email Body from TemplateService
		String emailBody = fxoDealConfirmationEmailTemplateProcessService
				.processEmailBodyTemplate(bodyTemplatePrefix + product
						+ templateFileType, ticketingResponseFenicsDetails, FXOEmailConstants.DEAL_TICKET_EMAIL, null);

		fxoEmailMessageEnvelope.setBody(emailBody);

		// create instance of type FXOEmailMessageHeaderDTO
		FXOEmailMessageHeaderDTO fxoEmailMessageHeader = new FXOEmailMessageHeaderDTO();

		// get email Subject from TemplateService
		String emailSubject = fxoDealConfirmationEmailTemplateProcessService
				.processEmailSubjectTemplate(subjectTemplatePrefix + product
						+ templateFileType, ticketingResponseFenicsDetails);

		fxoEmailMessageHeader.setSubject(emailSubject);

		// To Mail Addresses
		Set<String> destinationEmailAddressSet = new HashSet<String>();

		// include Email Addresses of user
		String userEmailAddress = (ticketingResponseFenicsDetails.getUser() != null) ? ticketingResponseFenicsDetails
				.getUser().getUserEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(userEmailAddress)) {
			destinationEmailAddressSet.add(userEmailAddress);
		}

		// include RelationshipManager EmailAddress
		String rmEmailAddress = (ticketingResponseFenicsDetails.getCustomer() != null) ? ticketingResponseFenicsDetails
				.getCustomer().getRmEmailAddress() : null;

		if (FXOStringUtility.isNotEmpty(rmEmailAddress)) {
			destinationEmailAddressSet.add(rmEmailAddress);
		}

		if (!destinationEmailAddressSet.isEmpty()) {
			fxoEmailMessageHeader
					.setDestinationEmailAddressList(new ArrayList<String>(
							destinationEmailAddressSet));
		}

		// Carbon copy
		Set<String> carbonCopyEmailAddressSet = new HashSet<String>();

		// Include splUserGroup-Email Addresses, if CurrencyPair has Commodity
		if (FXODealingUtil.hasACommodity(ticketingResponseFenicsDetails
				.getStructure())) {

			// add groupEmail Addresses to DestinionHeader
			if (groupCommodityEmailAddresses != null) {

				for (String groupEmailAddress : groupCommodityEmailAddresses) {
					carbonCopyEmailAddressSet.add(groupEmailAddress);
					logger.info(
							"carbonCopyEmailAddressSet -> EmailAddress identified for Commodity{}",
							groupEmailAddress);
				}

			}

		}

		if (CustomerType.isInternal(ticketingResponseFenicsDetails
				.getCustomer().getCustomerType())
				&& FXOStringUtility.isNotEmpty(ticketingResponseFenicsDetails
						.getCustomer().getInterPortfolio())) {

			// add groupEmail Addresses to DestinionHeader
			if (groupInterPortfolioEmailAddresses != null) {

				for (String groupInterPortfolioEmailAddress : groupInterPortfolioEmailAddresses) {
					carbonCopyEmailAddressSet.add(groupInterPortfolioEmailAddress);
					logger.info(
							"carbonCopyEmailAddressSet -> EmailAddress identified for Interportfolio{}",
							groupInterPortfolioEmailAddress);
				}

			}

		}

		if (!carbonCopyEmailAddressSet.isEmpty()) {
			fxoEmailMessageHeader
					.setCarbonCopyDestinationEmailAddressList(new ArrayList<String>(
							carbonCopyEmailAddressSet));
		}

		// set EmailHeader in EmailEnvelope
		fxoEmailMessageEnvelope.setHeader(fxoEmailMessageHeader);

		// send EmailMessage
		String messageID = fxoEmailService.sendMessage(fxoEmailMessageEnvelope);

		if (FXOStringUtility.isNotEmpty(messageID)) {
			updateTicketingRecordWithEmailMessageID(
					ticketingResponseFenicsDetails.getTicketingRequestId(),
					messageID);
		}
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateTicketingRecordWithEmailMessageID(
			String ticketingRequestID, String messageID) {
		Ticketing ticketing = ticketingRepository
				.findOneByTicketingRequestId(ticketingRequestID);

		// Set MessageID in Ticketing entity
		ticketing.setEmailMessageID(messageID);

		ticketingRepository.save(ticketing);
	}

}