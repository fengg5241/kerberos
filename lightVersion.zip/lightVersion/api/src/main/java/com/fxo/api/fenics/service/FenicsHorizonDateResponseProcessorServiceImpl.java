package com.fxo.api.fenics.service;

import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fxo.api.dto.FXOSystemDateDTO;
import com.fxo.api.fenics.dto.converter.FenicsCustomDateTimeConverter;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.fenics.FenicsResponseTypes;
import com.fxo.exception.ApplicationException;
import com.fxo.exception.ApplicationRuntimeException;
import com.fxo.fenics.constants.FenicsMessageCodes;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsPropertyMapper;
import com.fxo.fenics.util.FenicsResponseNodeProcessor;
import com.fxo.fenics.util.ReflectionUtility;

@Service
public class FenicsHorizonDateResponseProcessorServiceImpl implements
		IFenicsHorizonDateResponseProcessorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsHorizonDateResponseProcessorServiceImpl.class);

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private FenicsPropertyMapper fenicsPropertyMapper;

	@Autowired
	private FenicsCustomDateTimeConverter fenicsCustomDateTimeConverter;

	@Override
	public FXOSystemDateDTO processFenicsResponse(String responseXML) {

		// get Fenics Response Object (GFIMessageType) from responseXML
		com.fxo.fenics.response.GfiMessageType responseMessageObject = null;
		try {
			responseMessageObject = fenicsXMLProcessingService
					.getFenicsResponseObject(responseXML);
		} catch (ApplicationException e) {
			logger.info(e.getMessage(), e);
			throw new ApplicationRuntimeException(e.getMessage(),
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + "");
		}

		logger.info(String.format(
				"FENICS HorizonDate [%s]-ProcessingTime (Sec) : [%s] ",
				responseMessageObject.getHeader().getTransactionId(),
				responseMessageObject.getHeader().getProcessingTime()));

		// check for successful response / error / warning
		String responseType = FenicsResponseNodeProcessor
				.identifyFenicsResponseType(responseMessageObject);

		// declare PricingResponseDTO
		FXOSystemDateDTO fenicsHorizonDateQueryResponseDTO = null;

		// handle them separately after identification

		switch (responseType) {

		// call the corresponding ResponseNodeProcessor based on NodeType

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_SUCCESS:
			fenicsHorizonDateQueryResponseDTO = processFenicsHorizonDateData(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_ERROR:

			logger.info("Error Messages from FENICS");

			FenicsResponseNodeProcessor
					.processFenicsErrorNode(responseMessageObject);
			break;

		case FenicsResponseTypes.FENICS_RESPONSE_TYPE_WARNING:
			StringBuffer warningMessages = FenicsResponseNodeProcessor
					.processFenicsWarningNode(responseMessageObject);

			logger.info("Warning Messages from FENICS: "
					+ warningMessages.toString());

			fenicsHorizonDateQueryResponseDTO = processFenicsHorizonDateData(responseMessageObject);

			break;

		default:
			break;
		}

		return fenicsHorizonDateQueryResponseDTO;
	}

	public FXOSystemDateDTO processFenicsHorizonDateData(
			com.fxo.fenics.response.GfiMessageType responseMessageObject) {

		// extract responseNodes from FenicsResponseMessageObject
		List<com.fxo.fenics.response.NodeType> responseNodes = FenicsResponseNodeProcessor
				.extractResponseNodesFromBody(responseMessageObject);

		com.fxo.fenics.response.NodeType responseNode = responseNodes.get(0);

		FXOSystemDateDTO fenicsHorizonDateQueryResponseDTO = new FXOSystemDateDTO();

		Map<String, String> map = fenicsPropertyMapper
				.getFenicsHorizonDateQueryResponseFieldMap();

		if (map == null || map.isEmpty()) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is invalid";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		List<com.fxo.fenics.response.FieldType> responseFieldList = responseNode
				.getField();

		if (responseFieldList == null || responseFieldList.size() == 0) {
			// throw ApplicationRuntimeException
			String errorMessage = "Error while processing FenicsResponseNode - responseNodes-Leg from fenics is empty";
			logger.info(errorMessage);
			throw new ApplicationRuntimeException(errorMessage,
					FenicsMessageCodes.ERR_FENICS_RESPONSE + "," + errorMessage);
		}

		for (com.fxo.fenics.response.FieldType entry : responseFieldList) {
			if (map.get(entry.getName()) != null) {
				ReflectionUtility.setField(fenicsHorizonDateQueryResponseDTO,
						map.get(entry.getName()), entry.getFieldValue());
			}
		}

		DateTime horizonDate = fenicsCustomDateTimeConverter
				.translateHorizonDateStringToDateTime(fenicsHorizonDateQueryResponseDTO
						.getHorizonDateString());

		fenicsHorizonDateQueryResponseDTO.setSystemDate(horizonDate
				.toLocalDate());

		return fenicsHorizonDateQueryResponseDTO;
	}

}