package com.fxo.api.fenics.service;

import static com.fxo.constants.dealing.FXOWSConstantKeys.SPACE_DELIMITER;
import static com.fxo.constants.dealing.FXOWSConstantKeys.ZERO;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fxo.api.dto.FXOParametersMappingDTO;
import com.fxo.api.service.IFXOConstantsService;
import com.fxo.api.service.IFXOParametersMappingService;
import com.fxo.constants.admin.FXOParameterTypes;
import com.fxo.constants.dealing.FXOWSConstantKeys;
import com.fxo.constants.fenics.FenicsCalculationParameters;
import com.fxo.exception.ApplicationException;
import com.fxo.fenics.request.BodyType;
import com.fxo.fenics.request.DataType;
import com.fxo.fenics.request.NodeType;
import com.fxo.fenics.request.OptionType;
import com.fxo.fenics.service.FenicsXMLProcessingService;
import com.fxo.fenics.util.FenicsXMLFieldGenerator;
import com.fxo.framework.util.FXOStringUtility;

@Component
public class FenicsHorizonDateRequestGeneratorServiceImpl implements
		IFenicsHorizonDateRequestGeneratorService {

	private static final Logger logger = LoggerFactory
			.getLogger(FenicsHorizonDateRequestGeneratorServiceImpl.class);

	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.currency}") String defaultCurrency;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.counterCurrency}") String defaultCounterCurrency;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.direction}") String defaultDirection;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.strategy}") String defaultStrategy;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.maturity}") String defaultMaturity;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.optionType}") String defaultOptionType;
	private @Value("${com.fxo.fenics.horizonDateQueryDefaults.strike}") String defaultStrike;

	@Autowired
	private FenicsXMLProcessingService fenicsXMLProcessingService;

	@Autowired
	private FenicsRequestNodeService fenicsRequestNodeService;

	@Autowired
	private IFXOParametersMappingService fxoParametersMappingService;

	@Autowired
	private IFXOConstantsService fxoConstantsService;

	@Autowired
	private FenicsXMLFieldGenerator fenicsXMLFieldGenerator;

	@Override
	public String getFenicsPricingXML() throws ApplicationException {
		return fenicsXMLProcessingService.compositeXML(populateRequestBody(),
				FXOStringUtility.generateUniqueId(REQUEST_PREFIX), null);
	}

	public BodyType populateRequestBody() {

		DataType fenicsHorizonDateQueryDateType = DataType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeName))
				.setFormat(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingDataTypeFormat));

		NodeType fenicsHorizonDateQueryLegNode = NodeType
				.instance()
				.setName(
						FXOStringUtility.joinStrings(
								fxoConstantsService
										.getFXOConstantsValue(FXOWSConstantKeys.fenicsLegNodeName),
								ZERO, SPACE_DELIMITER));

		fenicsXMLFieldGenerator.generateCurrencyField(
				fenicsHorizonDateQueryLegNode, defaultCurrency,
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateCounterCurrencyField(
				fenicsHorizonDateQueryLegNode, defaultCounterCurrency,
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateLegStrategyField(
				fenicsHorizonDateQueryLegNode, defaultStrategy,
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateMaturityField(
				fenicsHorizonDateQueryLegNode, defaultMaturity,
				fenicsRequestPurpose, dealingConvention);

		// get FenicsOptionType From OptionTypeCode
		FXOParametersMappingDTO fxoParametersMappingDTOOptionType = fxoParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_OPTION_TYPE,
						defaultOptionType);

		fenicsXMLFieldGenerator.generateOptionClassField(
				fenicsHorizonDateQueryLegNode,
				fxoParametersMappingDTOOptionType.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		// translate direction from fenics value to FXO-Portal
		// representation
		FXOParametersMappingDTO fxoParametersMappingDTODirection = fxoParametersMappingService
				.getOneParameterMappingByParameterTypeAndParameterSourceValue(
						FXOParameterTypes.FXO_PARAMETER_TYPE_DIRECTION,
						defaultDirection);

		fenicsXMLFieldGenerator.generateDirectionField(
				fenicsHorizonDateQueryLegNode,
				fxoParametersMappingDTODirection.getParameterTargetValue(),
				fenicsRequestPurpose, dealingConvention);

		fenicsXMLFieldGenerator.generateStrikeFieldForSpotRateAPI(
				fenicsHorizonDateQueryLegNode, fenicsRequestPurpose,
				dealingConvention);

		String simpleOptionModel = fxoConstantsService
				.getFXOConstantsValue(FXOWSConstantKeys.fenicsSimpleOptionModel);
		fenicsXMLFieldGenerator.generateModelField(
				fenicsHorizonDateQueryLegNode, simpleOptionModel,
				fenicsRequestPurpose, dealingConvention);

		fenicsHorizonDateQueryDateType.getNode().add(
				fenicsHorizonDateQueryLegNode);

		// generate Instance of Type 'BodyType' and setRequestAction
		BodyType fenicsHorizonDateQueryBodyType = BodyType.instance()
				.setAction(populateRequestAction());

		fenicsHorizonDateQueryBodyType.getData().add(
				fenicsHorizonDateQueryDateType);

		return fenicsHorizonDateQueryBodyType;
	}

	public com.fxo.fenics.request.ActionType populateRequestAction() {

		com.fxo.fenics.request.ActionType action = com.fxo.fenics.request.ActionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeName))
				.setVersion(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingActionTypeVer))
				.setFunction(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrActionTypeFunc));

		OptionType option1 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeCalcName))
				.setOptionValue(FenicsCalculationParameters.MIDRATE);

		OptionType option2 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenName))
				.setOptionValue(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeScenVal));

		OptionType option3 = OptionType
				.instance()
				.setName(
						fxoConstantsService
								.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataName))
				.setRef(fxoConstantsService
						.getFXOConstantsValue(FXOWSConstantKeys.fenicsPricingHdrOptionTypeDataRef));

		action.getOption().addAll(Arrays.asList(option1, option2, option3));

		return action;
	}

}
